//©alifalfrl__ wa : 081249703469
//jangan hapus credit!!!!

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
require('./menu-yonz')
if (!global.game) global.game = {}
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./source/message');
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
let prem = []
if (fs.existsSync("./library/database/premium.json")) {
    const data = fs.readFileSync("./library/database/premium.json", "utf8")
    if (data.trim()) {
        try {
            prem = JSON.parse(data)
            if (!Array.isArray(prem)) prem = []
        } catch (e) {
            prem = []
        }
    }
}
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

const pathList = './library/database/lists.json';
if (!fs.existsSync(pathList)) {
  fs.writeFileSync(pathList, JSON.stringify({}));
}
function loadLists() {
  try {
    return JSON.parse(fs.readFileSync(pathList));
  } catch (e) {
    fs.writeFileSync(pathList, JSON.stringify({}));
    return {};
  }
}

function saveLists(data) {
  fs.writeFileSync(pathList, JSON.stringify(data, null, 2));
}

if (!global.db) global.db = {};
if (!global.db.users) global.db.users = {};
if (!global.db.groups) global.db.groups = {};

function isRegistered(sender) {
    return true; 
}

function addRegisteredUser(sender, data = {}) {
    if (!global.db.users) global.db.users = {}
    global.db.users[sender] = {
        ...(global.db.users[sender] || {}),
        ...data,
        registered: true
    }
    return global.db.users[sender]
}

function checkLimit(sender, isPrem, isCreator) {
    if (isCreator || isPrem) return false;
    if (!global.db.users[sender]) {
        global.db.users[sender] = { limit: 25 };
    }
    return global.db.users[sender].limit <= 0;
}

function addLimit(sender, isPrem, isCreator) {
    if (isCreator || isPrem) return;
    if (!global.db.users[sender]) {
        global.db.users[sender] = { limit: 25 };
    }
    global.db.users[sender].limit -= 1;
}

const listSettingsPath = './library/database/list_settings.json';

function loadListSettings() {
    try {
        if (fs.existsSync(listSettingsPath)) {
            return JSON.parse(fs.readFileSync(listSettingsPath, 'utf8'));
        }
        return {};
    } catch (e) {
        return {};
    }
}

function saveListSettings(data) {
    fs.writeFileSync(listSettingsPath, JSON.stringify(data, null, 2));
}

function getListWithTemplate(chatId, userName, groupName, listItems) {
    const settings = loadListSettings();
    const chatSettings = settings[chatId];
    const sortedItems = [...listItems].sort((a, b) => {
        return a.name.localeCompare(b.name, 'id', { sensitivity: 'base' });
    });
    
    if (!chatSettings || !chatSettings.template) {
    let defaultText = `DAFTAR LIST\n\n`;
    sortedItems.forEach((item, index) => {
        defaultText += `${chatSettings?.prefix || "▣ "} ${item.name}\n`;
    });
    defaultText += `\nKetik nama item untuk melihat detail`;
    return defaultText;
}
    
    const now = moment().tz('Asia/Jakarta');
    const hour = now.hour();
    let waktuHari = '';
    
    if (hour >= 0 && hour < 5) waktuHari = 'Dini Hari';
    else if (hour >= 5 && hour < 10) waktuHari = 'Pagi';
    else if (hour >= 10 && hour < 15) waktuHari = 'Siang';
    else if (hour >= 15 && hour < 18) waktuHari = 'Sore';
    else if (hour >= 18 && hour < 24) waktuHari = 'Malam';
    
    const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const monthNames = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    const tanggalLengkap = `${dayNames[now.day()]}, ${now.date()} ${monthNames[now.month()]} ${now.year()}`;
    
    let template = chatSettings.template;
    template = template
        .replace(/@name/g, userName || 'User')
        .replace(/@group/g, groupName || 'Grup')
        .replace(/@time/g, now.format('HH:mm:ss'))
        .replace(/@date/g, now.format('DD/MM/YYYY'))
        .replace(/@fulldate/g, tanggalLengkap)
        .replace(/@daytime/g, waktuHari)
        .replace(/@x/g, sortedItems.map((item) => `${chatSettings?.prefix || "▣ "}${item.name}`).join('\n'))
        .replace(/@prefix\s+[^\n]+/gi, '');
    
    return template.trim();
}


async function downloadAndSaveMediaList(msg, type = 'image') {
    try {
        const mediaBuffer = await msg.download();
        const mediaDir = './library/media/list/';
        if (!fs.existsSync(mediaDir)) {
            fs.mkdirSync(mediaDir, { recursive: true });
        }
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(7);
        const filename = `${timestamp}_${random}.jpg`;
        const filepath = path.join(mediaDir, filename);
        fs.writeFileSync(filepath, mediaBuffer);
        return filepath;
    } catch (error) {
        throw error;
    }
}

const menuStylePath = './library/database/menustyle.json';
function getMenuStyle() {
    try {
        if (fs.existsSync(menuStylePath)) {
            const data = JSON.parse(fs.readFileSync(menuStylePath, 'utf8'));
            if (data && data.style) return data.style;
        }
    } catch (e) {}
    return 'v1';
}
function setMenuStyle(style) {
    try {
        const dir = path.dirname(menuStylePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(menuStylePath, JSON.stringify({ style }, null, 2));
        return true;
    } catch (e) {
        return false;
    }
}

// ================= Helper: Menu Info (cuaca, RAM, limit bar, total user, dll) =================
function safeReadJSON(filePath, fallback = []) {
    try {
        if (!fs.existsSync(filePath)) return fallback;
        const raw = fs.readFileSync(filePath, 'utf8');
        if (!raw || !raw.trim()) return fallback;
        return JSON.parse(raw);
    } catch (e) {
        return fallback;
    }
}

function safeWriteJSON(filePath, data) {
    try {
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        return false;
    }
}

// ================= Levenshtein Distance (buat deteksi typo command) =================
function levenshtein(a, b) {
    a = String(a); b = String(b);
    const m = a.length, n = b.length;
    if (m === 0) return n;
    if (n === 0) return m;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,      // hapus
                dp[i][j - 1] + 1,      // tambah
                dp[i - 1][j - 1] + cost // ganti
            );
        }
    }
    return dp[m][n];
}

// ================= Auto Correct Command (deteksi typo) =================
const autoCorrectPath = './library/database/autocorrect.json';
function loadAutoCorrect() {
    return safeReadJSON(autoCorrectPath, {});
}
function saveAutoCorrect(data) {
    return safeWriteJSON(autoCorrectPath, data);
}
// Default AKTIF, kecuali sudah pernah dimatikan khusus untuk chat tsb atau secara global.
function isAutoCorrect(chatId) {
    const db = loadAutoCorrect();
    if (db[chatId] === false) return false;
    if (db[chatId] === undefined && db._global === false) return false;
    return true;
}

// ================= Sewa Grup (Rented Groups) =================
const sewaGcPath = './library/database/sewagc.json';
function loadSewaGc() {
    return safeReadJSON(sewaGcPath, {});
}
function saveSewaGc(data) {
    return safeWriteJSON(sewaGcPath, data);
}
function isGroupSewa(chatId) {
    const sewaDb = loadSewaGc();
    const g = sewaDb[chatId];
    if (!g) return false;
    if (g.expired && g.expired < Date.now()) return false;
    return true;
}

// ================= Daftar Command Valid (anti false-trigger "Belum Sewa") =================
// Dipakai supaya notifikasi "Grup Belum Sewa" hanya muncul saat user benar-benar
// memakai command yang terdaftar (case di switch), bukan setiap chat biasa yang
// ikut terhitung isCmd karena mode no-prefix global sedang aktif.
let _validCommandsCache = null;
function getValidCommands() {
    if (_validCommandsCache) return _validCommandsCache;
    const set = new Set();
    try {
        const src = fs.readFileSync(__filename, 'utf8');
        const regex = /case\s+["']([^"']+)["']\s*:/g;
        let match;
        while ((match = regex.exec(src)) !== null) {
            set.add(match[1].toLowerCase());
        }
    } catch (e) {}

    try {
        const pluginsPath = path.join(__dirname, 'plugins');
        if (fs.existsSync(pluginsPath)) {
            const files = fs.readdirSync(pluginsPath);
            for (const file of files) {
                if (!file.endsWith('.js')) continue;
                try {
                    const content = fs.readFileSync(path.join(pluginsPath, file), 'utf8');
                    const cmdArrayMatches = content.match(/command\s*:\s*\[([^\]]+)\]/gi) || [];
                    for (const m of cmdArrayMatches) {
                        const names = m.match(/["']([^"']+)["']/g) || [];
                        for (const n of names) set.add(n.replace(/["']/g, '').toLowerCase());
                    }
                } catch (e) {}
            }
        }
    } catch (e) {}

    _validCommandsCache = set;
    return _validCommandsCache;
}

// ================= Mute Grup (persist ke mutegc.json, support mute by ID) =================
const muteGcPath = './library/database/mutegc.json';
function loadMuteGc() {
    return safeReadJSON(muteGcPath, {});
}
function saveMuteGc(data) {
    return safeWriteJSON(muteGcPath, data);
}
function isGroupMuted(chatId) {
    const muteDb = loadMuteGc();
    return !!(muteDb[chatId] && muteDb[chatId].mute === true);
}

const AUTODL_TIKTOK_REGEX = /(https?:\/\/(?:vt|vm|www)\.?tiktok\.com\/[^\s]+)/i;
const AUTODL_IG_REGEX = /(https?:\/\/(?:www\.)?instagram\.com\/(?:p|reel|reels|tv|stories)\/[^\s]+)/i;

async function autoDownloadAIO(url) {
    try {
        const apiUrl = `${global.there}/download/aio?url=${encodeURIComponent(url)}&apikey=Yonz`;
        const res = await fetch(apiUrl);
        const json = await res.json();
        if (!json || json.status !== true) return null;

        const result = json.result || {};
        const medias = Array.isArray(result.medias) ? result.medias : [];

        const video = medias.find(md => md.type === 'video' && md.quality === 'hd_no_watermark')
            || medias.find(md => md.type === 'video' && md.quality === 'no_watermark')
            || medias.find(md => md.type === 'video');
        const audio = medias.find(md => md.type === 'audio');
        const images = medias.filter(md => md.type === 'image');

        return {
            title: result.title || '',
            platform: result.platform || '',
            video: video?.url || null,
            audio: audio?.url || null,
            images: images.map(im => im.url).filter(Boolean),
            medias
        };
    } catch (e) {
        console.log('autoDownloadAIO error:', e.message);
        return null;
    }
}

function getWIBTime() {
    return moment().tz('Asia/Jakarta').toDate();
}

function getTodayWIB() {
    return moment().tz('Asia/Jakarta').format('YYYY-MM-DD');
}

const limitUsagePath = './library/database/limitusage.json';
const dbPremPath = './library/database/premium.json';

// Cek apakah jid adalah premium yang masih aktif (baca langsung dari premium.json biar selalu fresh)
global.isPrem = (jid) => {
    const premDB = safeReadJSON(dbPremPath, []);
    return premDB.some(v => v.jid === jid && v.expired > Date.now());
};

function getPremiumDaysLeft(jid) {
    const premDB = safeReadJSON(dbPremPath, []);
    const user = premDB.find(v => v.jid === jid && v.expired > Date.now());
    if (!user) return 0;
    return Math.max(0, Math.ceil((user.expired - Date.now()) / (1000 * 60 * 60 * 24)));
}

function getUserMaxLimit(jid) {
    return global.isPrem(jid) ? (global.limitPremium || 100) : (global.limitFree || 15);
}

function getUsedToday(jid) {
    const usageDB = safeReadJSON(limitUsagePath, []);
    const today = getTodayWIB();
    const entry = usageDB.find(v => v.jid === jid);
    return (entry && entry.date === today) ? (entry.count || 0) : 0;
}

// Tambah pemakaian limit harian user. Panggil ini di command yang mau dibatasi limitnya.
function addLimitUsage(jid, amount = 1) {
    const usageDB = safeReadJSON(limitUsagePath, []);
    const today = getTodayWIB();
    let entry = usageDB.find(v => v.jid === jid);
    if (!entry) {
        entry = { jid, date: today, count: 0 };
        usageDB.push(entry);
    }
    if (entry.date !== today) {
        entry.date = today;
        entry.count = 0;
    }
    entry.count += amount;
    safeWriteJSON(limitUsagePath, usageDB);
    return entry.count;
}

function buildLimitBar(used, max, length = 10) {
    if (!isFinite(max) || max <= 0) return '█'.repeat(length);
    const filled = Math.min(Math.round((used / max) * length), length);
    const empty = length - filled;
    return '█'.repeat(Math.max(0, filled)) + '░'.repeat(Math.max(0, empty));
}

function getTotalRegisteredUsers() {
    try { return Object.keys(global.db?.users || {}).length; } catch (e) { return 0; }
}

function getTotalActiveSewa() {
    try { return Object.keys(global.db?.groups || {}).length; } catch (e) { return 0; }
}

// Ambil info cuaca dari BMKG berdasarkan kode wilayah (global.adm4)
async function getCuacaMenu(adm4 = global.adm4) {
    const fallback = { cuaca: 'Tidak diketahui', suhu: '-', emoji: '🌥️', kotkab: '-' };
    try {
        if (!adm4) return fallback;
        const res = await fetch(`https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=${adm4}`, { timeout: 8000 });
        const json = await res.json();
        const cuacaHariIni = json?.data?.[0]?.cuaca?.[0]?.[0];
        if (!cuacaHariIni) return fallback;
        const weather = cuacaHariIni.weather_desc || fallback.cuaca;
        const suhu = cuacaHariIni.t ?? fallback.suhu;
        let emoji = '🌥️';
        if (/cerah/i.test(weather)) emoji = '☀️';
        else if (/berawan/i.test(weather)) emoji = '☁️';
        else if (/hujan/i.test(weather)) emoji = '🌧️';
        else if (/petir/i.test(weather)) emoji = '⛈️';
        else if (/kabut/i.test(weather)) emoji = '🌫️';
        return { cuaca: weather, suhu, emoji, kotkab: json?.lokasi?.kotkab || fallback.kotkab };
    } catch (e) {
        return fallback;
    }
}

function getRamInfo() {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    return {
        used: formatp(usedMem),
        total: formatp(totalMem),
        percent: ((usedMem / totalMem) * 100).toFixed(1)
    };
}
// ================= End Helper Menu Info =================

module.exports = yonz = async (yonz, m, chatUpdate, store) => {
    try {
        await LoadDataBase(yonz, m)
const botNumber = await yonz.decodeJid(yonz.user.id)
const db = global.db
const mess = global.mess
const owner = global.owner
const botname = global.botname
const versi = global.versi
		const body = ((m.type === 'conversation') ? m.message.conversation :
		(m.type == 'imageMessage') ? m.message.imageMessage.caption :
		(m.type == 'videoMessage') ? m.message.videoMessage.caption :
		(m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text :
		(m.type == 'reactionMessage') ? m.message.reactionMessage.text :
		(m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId :
		(m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
		(m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId :
		(m.type == 'interactiveResponseMessage'  && m.quoted) ? (m.message.interactiveResponseMessage?.nativeFlowResponseMessage ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : '') :
		(m.type == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || '') :
		(m.type == 'editedMessage') ? (m.message.editedMessage?.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text || m.message.editedMessage?.message?.protocolMessage?.editedMessage?.conversation || '') :
		(m.type == 'protocolMessage') ? (m.message.protocolMessage?.editedMessage?.extendedTextMessage?.text || m.message.protocolMessage?.editedMessage?.conversation || m.message.protocolMessage?.editedMessage?.imageMessage?.caption || m.message.protocolMessage?.editedMessage?.videoMessage?.caption || '') : '') || '';
		const budy = (typeof m.text == 'string' ? m.text : '')

		let usedPrefix;
		const multiPrefix = ['.'];
		const processedText = body;

		const noPfxDBPath = './library/database/noprefix.json';
		const noPfxConfigPath = './library/database/nopfx_config.json';

		// Fungsi untuk cek status no-prefix
		function isNoPrefixEnabled() {
		    try {
		        if (!fs.existsSync(noPfxConfigPath)) {
		            fs.writeFileSync(noPfxConfigPath, JSON.stringify({ enabled: true }, null, 2));
		        }
		        const config = JSON.parse(fs.readFileSync(noPfxConfigPath));
		        return config.enabled === true;
		    } catch (e) {
		        return true; // default aktif
		    }
		}

		function loadNoPfx() {
		    try {
		        if (!fs.existsSync(noPfxDBPath)) {
		            fs.writeFileSync(noPfxDBPath, JSON.stringify({ global: [], groups: {} }, null, 2));
		        }
		        return JSON.parse(fs.readFileSync(noPfxDBPath));
		    } catch (e) {
		        return { global: [], groups: {} };
		    }
		}

		function saveNoPfx(data) {
		    try { fs.writeFileSync(noPfxDBPath, JSON.stringify(data, null, 2)); } catch(e) {}
		}

		function getNoPfxList(chatId) {
		    const db = loadNoPfx();
		    const globalList = Array.isArray(db.global) ? db.global : [];
		    const groupList = chatId && db.groups && Array.isArray(db.groups[chatId]) ? db.groups[chatId] : [];
		    return [...new Set([...globalList, ...groupList])];
		}

		// ========== CEK STATUS NO-PREFIX ==========
		const noPrefixEnabled = isNoPrefixEnabled();

		// Cek apakah pesan ini merupakan no-prefix command (hanya jika enabled)
		const _rawText = typeof processedText === 'string' ? processedText.trim() : '';
		const _firstWord = _rawText.split(/ +/)[0].toLowerCase();
		const _noPfxList = noPrefixEnabled ? getNoPfxList(m.chat) : [];
		// Jika no-prefix diaktifkan (on), SEMUA fitur/command bisa dipakai tanpa prefix.
		// Whitelist (_noPfxList) tetap dipakai sebagai fallback kalau suatu saat mode global dimatikan
		// tapi ada command tertentu yang tetap ingin bebas prefix.
		// Pesan yang berupa link (http/https) jangan dianggap sebagai no-prefix command,
		// supaya fitur autodownload (yang butuh isCmd === false) tetap bisa jalan.
		const _isPlainUrl = /^https?:\/\//i.test(_rawText);
		const _isNoPfxCmd = !_isPlainUrl && !multiPrefix.some(p => _rawText.startsWith(p)) && _rawText.length > 0 && (noPrefixEnabled || _noPfxList.includes(_firstWord));

		// Jika no-prefix command, perlakukan seolah pakai prefix '.'
		let _syntheticPrefix = '';
		if (_isNoPfxCmd) {
		    _syntheticPrefix = '.';
		    usedPrefix = '.';
		}

		const isCmd = (typeof processedText === 'string' && processedText.length > 0 && multiPrefix.some(p => processedText.startsWith(p))) || _isNoPfxCmd;
		const prefix = usedPrefix || '.';

		const args = _isNoPfxCmd
		    ? _rawText.split(/ +/).slice(1)
		    : (isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : body.trim().split(/ +/).slice(1));

		const getQuoted = (m.quoted || m)
		const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m

		const command = _isNoPfxCmd
		    ? _firstWord
		    : (isCmd ? processedText.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : '');
		const isPremium = prem.some(user => user.jid === m.sender && user.expired > Date.now())
		const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
		const isCreator2 = isCreator
		const text = q = args.join(' ')
		const mime = (quoted.msg || quoted).mimetype || ''
		const qmsg = (quoted.msg || quoted)

		const autoresponPath = "./library/database/autorespon/"
		if (!fs.existsSync(autoresponPath)) fs.mkdirSync(autoresponPath, { recursive: true })
		
		const mediaPath = "./library/database/media/"
		if (!fs.existsSync(mediaPath)) fs.mkdirSync(mediaPath, { recursive: true })
		
		const getCurrentTime = () => moment.tz("Asia/Jakarta").format("HH:mm")
		const getCurrentDate = () => moment.tz("Asia/Jakarta").format("DD/MM/YYYY")
		const getHari = () => {
			const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
			return days[moment.tz("Asia/Jakarta").day()]
		}
		const getGreeting = () => {
			const hour = moment.tz("Asia/Jakarta").hour()
			if (hour < 12) return "Pagi"
			if (hour < 15) return "Siang"
			if (hour < 18) return "Sore"
			return "Malam"
		}
		
		const downloadMediaFile = async (msg) => {
			try {
				if (!msg || !msg.message) return null
				const buffer = await yonz.downloadMediaMessage(msg)
				if (!buffer) return null
				const filename = `media_${Date.now()}_${Math.random().toString(36).substring(7)}.${mime.split('/')[1] || 'jpg'}`
				const filepath = path.join(mediaPath, filename)
				fs.writeFileSync(filepath, buffer)
				return filename
			} catch (e) {
				return null
			}
		}

		const getGroupAdminsList = async (chatId) => {
			try {
				const groupMetadata = await yonz.groupMetadata(chatId)
				return groupMetadata.participants.filter(p => p.admin).map(p => p.id)
			} catch (e) {
				return []
			}
		}

		const isUserAdminGroup = async (chatId, userId) => {
			try {
				const admins = await getGroupAdminsList(chatId)
				return admins.includes(userId)
			} catch (e) {
				return false
			}
		}

		if (m.isGroup && isGroupMuted(m.chat) && !isCreator) return

		if (isCmd) {
			console.log(chalk.cyan.bold(` ╭─────[ COMMAND NOTIFICATION ]`), chalk.blue.bold(`\n  Command :`), chalk.white.bold(`${prefix+command}`), chalk.blue.bold(`\n  From :`), chalk.white.bold(m.isGroup ? `Group - ${m.sender.split("@")[0]}\n` : m.sender.split("@")[0] +`\n`), chalk.cyan.bold(`╰────────────────────────────\n`))
		}

		const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

		const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `clutch sigma`,jpegThumbnail: ""}}}

		if (m.isGroup && isGroupMuted(m.chat) && !isCreator) return

		if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
			var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
			if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
				var gclink = (`https://chat.whatsapp.com/` + await yonz.groupInviteCode(m.chat))
				var isLinkThisGc = new RegExp(gclink, 'i')
				var isgclink = isLinkThisGc.test(m.text)
				if (isgclink) return
				let delet = m.key.participant
				let bang = m.key.id
				await yonz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
				await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
				await sleep(1000)
				await yonz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
			}}

		if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
			var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
			if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
				var gclink = (`https://chat.whatsapp.com/` + await yonz.groupInviteCode(m.chat))
				var isLinkThisGc = new RegExp(gclink, 'i')
				var isgclink = isLinkThisGc.test(m.text)
				if (isgclink) return
				let delet = m.key.participant
				let bang = m.key.id
				await yonz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
				await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
			}}

		const example = (teks) => {
			return `\n *Contoh penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
		}

		const Reply = async (teks, mentions = []) => {
			return yonz.sendReplyThumbnail(m.chat, teks, null, {
				mentions,
				contextInfo: {
					isForwarded: true,
					forwardingScore: 9999,
					businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" },
					forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }
				}
			})
		}

		const SEWA_EXEMPT_CMD = ['addsewagc', 'delsewagc', 'listsewagc']
		const isKnownCmd = isCmd && command && getValidCommands().has(command.toLowerCase())
		if (isKnownCmd && m.isGroup && !isCreator && !SEWA_EXEMPT_CMD.includes(command) && !isGroupSewa(m.chat)) {
			return Reply(
				`💌 *Grup Belum Sewa*\n` +
				`Hubungi Owner untuk sewa\n\n` +
				`➜ Owner: ${global.namaOwner}\n` +
				`➜ Link: ${global.linkowner || global.linkOwner}`
			)
		}

		const isRegistered = (sender) => {
			if (global.db.settings?.wajibDaftar === false) return true
			return !!(global.db?.users?.[sender]?.registered)
		}

		const daftar = async (teks) => {
			return Reply(teks)
		}

		const buildMainMenuText = () => {
			const userStatus = isCreator ? "Owner" : isPremium ? "Premium" : "Free User";

			let totalFitur = 0;
			try {
				const commandJsPath = path.join(__dirname, 'yonz-cmd.js');
				if (fs.existsSync(commandJsPath)) {
					const commandJsContent = fs.readFileSync(commandJsPath, 'utf8');
					const caseMatches = commandJsContent.match(/case\s+["']([^"']+)["']\s*:/gi);
					if (caseMatches) totalFitur = caseMatches.length;
				}
				const pluginsPath = path.join(__dirname, 'plugins');
				if (fs.existsSync(pluginsPath)) {
					const files = fs.readdirSync(pluginsPath);
					for (const file of files) {
						if (file.endsWith('.js')) {
							const pluginContent = fs.readFileSync(path.join(pluginsPath, file), 'utf8');
							const pluginCaseMatches = pluginContent.match(/command\s*:\s*\[([^\]]+)\]/gi);
							if (pluginCaseMatches) {
								for (const match of pluginCaseMatches) {
									const commands = match.match(/["']([^"']+)["']/g);
									if (commands) totalFitur += commands.length;
								}
							}
						}
					}
				}
			} catch (e) {
				totalFitur = "?";
			}

			const userName = m.pushName || m.sender.split('@')[0];
			const limitInfo = isCreator ? "Unlimited" : isPremium ? "Unlimited" : (global.db?.users?.[m.sender]?.limit ?? "-");

			return `╭━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${versi}
│ 火  Waktu  : ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━〔 𝗦𝗨𝗣𝗣𝗢𝗥𝗧 〕━━━⬣
│ ➜ Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣`;
		}

		const menureply = async (teks, isMain = false) => {
			const caption = isMain ? buildMainMenuText() : teks;
			try {
				const videoPath = './media/menu.mp4';
				if (fs.existsSync(videoPath)) {
					await yonz.sendMessage(m.chat, {
						video: fs.readFileSync(videoPath),
						caption,
						gifPlayback: true,
						mimetype: 'video/mp4'
					}, { quoted: m });
				} else {
					await yonz.sendMessage(m.chat, { text: caption }, { quoted: m });
				}
			} catch (e) {
				console.log(e);
				await yonz.sendMessage(m.chat, { text: caption }, { quoted: m });
			}
		}

		const sendMenuVersion = async (menuStyle, teks = '') => {
			const userName = m.pushName || m.sender.split('@')[0];

			let totalFitur = 0;
			try {
				const commandJsContent = fs.readFileSync(path.join(__dirname, 'yonz-cmd.js'), 'utf8');
				const caseMatches = commandJsContent.match(/case\s+["']([^"']+)["']\s*:/gi);
				if (caseMatches) totalFitur = caseMatches.length;
			} catch (e) {
				totalFitur = "?";
			}

			const now = moment().tz('Asia/Jakarta');
			const tanggal = now.format('dddd, DD MMMM YYYY');
			const hariini = tanggal;
			const jam = now.format('HH:mm:ss');

			// ===== Cuaca (BMKG) =====
			const cuacaData = await getCuacaMenu(global.adm4);

			// ===== RAM =====
			const ram = getRamInfo();

			// ===== Status & Limit =====
			let userStatus, limitInfo, limitBar;
			const maxLimit = getUserMaxLimit(m.sender);
			const usedToday = getUsedToday(m.sender);
			const remainingLimit = Math.max(0, maxLimit - usedToday);
			if (isCreator) {
				userStatus = "👑 Owner";
				limitInfo = "∞ Unlimited";
				limitBar = '█'.repeat(10);
			} else if (global.isPrem(m.sender)) {
				const daysLeft = getPremiumDaysLeft(m.sender);
				userStatus = `💎 Premium (${daysLeft} hari lagi)`;
				limitBar = buildLimitBar(usedToday, maxLimit);
				limitInfo = `${usedToday}/${maxLimit} • Sisa: ${remainingLimit}`;
			} else {
				userStatus = "👤 Free User";
				limitBar = buildLimitBar(usedToday, maxLimit);
				limitInfo = `${usedToday}/${maxLimit} • Sisa: ${remainingLimit}`;
			}

			// ===== Statistik Bot =====
			const totalPengguna = getTotalRegisteredUsers();
			const totalSewaBotCount = getTotalActiveSewa();

			// ===== Gold RPG (kalau user sudah main RPG) =====
			let rpgGold = 0;
			try {
				const rpgDBPath = './library/database/rpg.json';
				if (fs.existsSync(rpgDBPath)) {
					const rpgData = JSON.parse(fs.readFileSync(rpgDBPath));
					if (rpgData.players && rpgData.players[m.sender]) {
						rpgGold = rpgData.players[m.sender].gold || 0;
					}
				}
			} catch (e) {
				console.log('Error reading RPG gold:', e);
			}

			const infoText = `╭━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
│ 水  [${limitBar}]
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${global.versi}
│ 火  Waktu  : ${jam} WIB
│ 風  Cuaca  : ${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C
│ 地  RAM    : ${ram.used} / ${ram.total} (${ram.percent}%)
│ 人  Pengguna : ${totalPengguna}
│ 群  Sewa Aktif : ${totalSewaBotCount} Group
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━ 〔 𝗕𝗢𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 〕━━━⬣
│ 炎  Bot WhatsApp Premium
│ 光  Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣${teks ? `\n${teks}` : ''}`;

			const sectionsMain = [
				{
					title: "✨ MENU UTAMA",
					highlight_label: "POPULAR",
					rows: [
						{ title: "📜 SEMUA FITUR", description: "Menampilkan seluruh list perintah bot", id: `${prefix}allmenu` },
						{ title: "🛒 STORE MENU", description: "Daftar produk dan layanan digital", id: `${prefix}menu-store` },
						{ title: "👑 MENU OWNER", description: "Perintah khusus untuk pemilik bot", id: `${prefix}menu-owner` },
						{ title: `🪪 OWNER ${global.botname}`, description: "Informasi kontak pengembang bot", id: `${prefix}owner` }
					]
				},
				{
					title: "📂 KATEGORI FITUR",
					rows: [
						{ title: "🎨 STICKERS", description: "Menu membuat dan mencari stiker", id: `${prefix}menu-stickers` },
						{ title: "🖼️ MAKER", description: "Membuat logo dan efek gambar", id: `${prefix}menu-maker` },
						{ title: "⬇️ DOWNLOADER", description: "Unduh video, musik, dan media", id: `${prefix}menu-download` },
						{ title: "🔍 SEARCH", description: "Pencarian informasi secara global", id: `${prefix}menu-search` },
						{ title: "🎮 GAME", description: "Kumpulan permainan seru", id: `${prefix}menu-game` },
						{ title: "🤖 AI", description: "Fitur kecerdasan buatan", id: `${prefix}menu-ai` },
						{ title: "🔐 ENCRYPT", description: "Kunci atau privasi file", id: `${prefix}menu-enc` },
						{ title: "📜 SERTIFIKAT", description: "Membuat sertifikat otomatis", id: `${prefix}menu-stk` },
						{ title: "⚔️ RPG GAMES", description: "Petualangan RPG dan level up", id: `${prefix}menu-rpg` },
						{ title: "🖥️ PANEL", description: "Kontrol server dan panel bot", id: `${prefix}menu-panel` },
						{ title: "👥 GROUP", description: "Fitur khusus administrasi grup", id: `${prefix}menu-group` },
						{ title: "🖌️ POTOANIME", description: "Edit foto menjadi gaya anime", id: `${prefix}menu-potoanime` },
						{ title: "⛩️ ANIME", description: "Informasi dan update seputar anime", id: `${prefix}menu-anime` },
						{ title: "🔞 NSFW", description: "Konten dewasa (18+)", id: `${prefix}menu-nsfw` },
						{ title: "💃 CECAN", description: "Koleksi foto wanita cantik", id: `${prefix}menu-cecan` },
						{ title: "🕌 ISLAMI", description: "Fitur religi dan edukasi Islam", id: `${prefix}menu-islami` },
						{ title: "📸 EHPOTO", description: "Berbagai efek foto menarik", id: `${prefix}menu-ehpoto` },
						{ title: "😂 FUN", description: "Fitur hiburan dan lelucon", id: `${prefix}menu-fun` },
						{ title: "🔮 PRIMBON", description: "Ramalan, zodiak, dan mitos", id: `${prefix}menu-primbon` },
						{ title: "🛠️ TOOLS", description: "Kumpulan tools serbaguna", id: `${prefix}menu-tools` }
					]
				}
			];

			const sectionsSupport = [
				{
					title: "Memberi support dan berdonasi",
					highlight_label: global.namaOwner,
					rows: [
						{ title: "Owner / Dev", description: `➜ ${global.botname}`, id: `${prefix}owner` },
						{ title: "Grup Chat", description: `➜ ${global.botname}`, id: `${prefix}gcbot` }
					]
				}
			];

			// Sections v1 -- persis sesuai referensi
			const sectionsV1 = [
				{
					title: "✨ MENU UTAMA",
					highlight_label: "POPULAR",
					rows: [
						{ title: " SEMUA FITUR", description: "Menampilkan seluruh list perintah bot", id: `${prefix}allmenu` },
						{ title: " STORE MENU", description: "Daftar produk dan layanan digital", id: `${prefix}menu-store` },
						{ title: " MENU OWNER", description: "Perintah khusus untuk pemilik bot", id: `${prefix}menu-owner` },
						{ title: `🪪 OWNER ${global.botname}`, description: "Informasi kontak pengembang bot", id: `${prefix}owner` }
					]
				},
				{
					title: " KATEGORI FITUR",
					rows: [
						{ title: " STICKERS", description: "Menu membuat dan mencari stiker", id: `${prefix}menu-stickers` },
						{ title: " MAKER", description: "Membuat logo dan efek gambar", id: `${prefix}menu-maker` },
						{ title: "DOWNLOADER", description: "Unduh video, musik, dan media", id: `${prefix}menu-download` },
						{ title: " SEARCH", description: "Pencarian informasi secara global", id: `${prefix}menu-search` },
						{ title: "GAME", description: "Kumpulan permainan seru", id: `${prefix}menu-game` },
						{ title: " SERTIFIKAT", description: "Membuat sertifikat otomatis", id: `${prefix}menu-stk` },
						{ title: "⚔️ RPG GAMES", description: "Petualangan RPG dan level up", id: `${prefix}menu-rpg` },
						{ title: " PANEL", description: "Kontrol server dan panel bot", id: `${prefix}menu-panel` },
						{ title: " GROUP", description: "Fitur khusus administrasi grup", id: `${prefix}menu-group` },
						{ title: " POTOANIME", description: "Edit foto menjadi gaya anime", id: `${prefix}menu-potoanime` },
						{ title: "⛩️ ANIME", description: "Informasi dan update seputar anime", id: `${prefix}menu-anime` },
						{ title: " NSFW", description: "Konten dewasa (18+)", id: `${prefix}menu-nsfw` },
						{ title: "CECAN", description: "Koleksi foto wanita cantik", id: `${prefix}menu-cecan` },
						{ title: " ISLAMI", description: "Fitur religi dan edukasi Islam", id: `${prefix}menu-islami` },
						{ title: " EHPOTO", description: "Berbagai efek foto menarik", id: `${prefix}menu-ehpoto` },
						{ title: "FUN", description: "Fitur hiburan dan lelucon", id: `${prefix}menu-fun` },
						{ title: " PRIMBON", description: "Ramalan, zodiak, dan mitos", id: `${prefix}menu-primbon` },
						{ title: " ENCRYPT", description: "Kunci atau privasi file", id: `${prefix}menu-enc` }
					]
				}
			];
			const noInfoOkOkLhV1 = [];

			// Sections v2 -- persis sesuai referensi (small caps)
			const sectionsV2 = [
				{
					title: 'Menu Utama',
					highlight_label: 'Rekomendasi',
					rows: [
						{ title: 'sᴇᴍᴜᴀ ꜰɪᴛᴜʀ', description: `➜ ${global.botname}`, id: `${prefix}allmenu` },
						{ title: 'sᴛᴏʀᴇ ᴍᴇɴᴜ', description: `➜ ${global.botname}`, id: `${prefix}menu-store` },
						{ title: 'ᴍᴇɴᴜ ᴏᴡɴᴇʀ', description: `➜ ${global.botname}`, id: `${prefix}menu-owner` },
						{ title: 'ᴏᴡɴᴇʀ / ᴅᴇᴠ', description: `➜ ${global.botname}`, id: `${prefix}owner` }
					]
				},
				{
					title: "ᴋᴀᴛᴇɢᴏʀɪ ᴍᴇɴᴜ ʟᴀɪɴ",
					rows: [
						{ title: 'ᴍᴇɴᴜ sᴛɪᴄᴋᴇʀs', description: `➜ ${global.botname}`, id: `${prefix}menu-stickers` },
						{ title: 'ᴍᴇɴᴜ ᴍᴀᴋᴇʀ', description: `➜ ${global.botname}`, id: `${prefix}menu-maker` },
						{ title: 'ᴍᴇɴᴜ ᴅᴏᴡɴʟᴏᴀᴅ', description: `➜ ${global.botname}`, id: `${prefix}menu-download` },
						{ title: 'ᴍᴇɴᴜ sᴇᴀʀᴄʜ', description: `➜ ${global.botname}`, id: `${prefix}menu-search` },
						{ title: 'ᴍᴇɴᴜ ɢᴀᴍᴇ', description: `➜ ${global.botname}`, id: `${prefix}menu-game` },
						{ title: 'ᴍᴇɴᴜ ᴀɪ', description: `➜ ${global.botname}`, id: `${prefix}menu-ai` },
						{ title: 'ᴍᴇɴᴜ ᴇɴᴄ', description: `➜ ${global.botname}`, id: `${prefix}menu-enc` },
						{ title: 'ᴍᴇɴᴜ sᴇʀᴛɪꜰɪᴋᴀᴛ', description: `➜ ${global.botname}`, id: `${prefix}menu-stk` },
						{ title: 'ᴍᴇɴᴜ ʀᴘɢ', description: `➜ ${global.botname}`, id: `${prefix}menu-rpg` },
						{ title: 'ᴍᴇɴᴜ ᴘᴀɴᴇʟ', description: `➜ ${global.botname}`, id: `${prefix}menu-panel` },
						{ title: 'ᴍᴇɴᴜ ɢʀᴏᴜᴘ', description: `➜ ${global.botname}`, id: `${prefix}menu-group` },
						{ title: 'ᴍᴇɴᴜ ᴘᴏᴛᴏᴀɴɪᴍᴇ', description: `➜ ${global.botname}`, id: `${prefix}menu-potoanime` },
						{ title: 'ᴍᴇɴᴜ ᴀɴɪᴍᴇ', description: `➜ ${global.botname}`, id: `${prefix}menu-anime` },
						{ title: 'ᴍᴇɴᴜ ɴsꜰᴡ', description: `➜ ${global.botname}`, id: `${prefix}menu-nsfw` },
						{ title: 'ᴍᴇɴᴜ ᴄᴇᴄᴀɴ', description: `➜ ${global.botname}`, id: `${prefix}menu-cecan` },
						{ title: 'ᴍᴇɴᴜ ɪsʟᴀᴍɪ', description: `➜ ${global.botname}`, id: `${prefix}menu-islami` },
						{ title: 'ᴍᴇɴᴜ ᴇʜᴘᴏᴛᴏ', description: `➜ ${global.botname}`, id: `${prefix}menu-ehpoto` },
						{ title: 'ᴍᴇɴᴜ ꜰᴜɴ', description: `➜ ${global.botname}`, id: `${prefix}menu-fun` },
						{ title: 'ᴍᴇɴᴜ ᴘʀɪᴍʙᴏɴ', description: `➜ ${global.botname}`, id: `${prefix}menu-primbon` }
					]
				}
			];
			const noInfoOkOkLhV2 = [
				{
					title: "𝙈𝙚𝙢𝙗𝙚𝙧𝙞 𝙨𝙪𝙥𝙥𝙤𝙧𝙩 𝙙𝙖𝙣 𝙗𝙚𝙧𝙙𝙤𝙣𝙖𝙨𝙞",
					highlight_label: global.namaOwner,
					rows: [
						{ title: 'ᴏᴡɴᴇʀ / ᴅᴇᴠ', description: `➜ ${global.botname}`, id: `${prefix}owner` },
						{ title: 'ᴅᴏɴᴀsɪ & sᴜᴘᴘᴏʀᴛ', description: `➜ ${global.botname}`, id: `${prefix}donasi` },
						{ title: 'sᴇᴡᴀ ʙᴏᴛ', description: `➜ ${global.botname}`, id: `${prefix}sewa` },
						{ title: 'ᴜᴘɢʀᴀᴅᴇ ᴘʀᴇᴍɪᴜᴍ', description: `➜ ${global.botname}`, id: `${prefix}prem` },
						{ title: 'ɢʀᴜᴘ ᴄʜᴀᴛ', description: `➜ ${global.botname}`, id: `${prefix}gcbot` },
						{ title: 'sᴄʀɪᴘᴛ ʙᴏᴛ', description: `➜ ${global.botname}`, id: `${prefix}script` }
					]
				}
			];

			// Sections v3/v4 -- persis sesuai referensi (Title Case)
			const sectionsV3 = [
				{
					title: 'Menu Utama',
					highlight_label: 'Rekomendasi',
					rows: [
						{ title: 'Semua Fitur', description: `➜ ${global.botname}`, id: `${prefix}allmenu` },
						{ title: 'Store Menu', description: `➜ ${global.botname}`, id: `${prefix}menu-store` },
						{ title: 'Menu Owner', description: `➜ ${global.botname}`, id: `${prefix}menu-owner` },
						{ title: 'Owner / Dev', description: `➜ ${global.botname}`, id: `${prefix}owner` }
					]
				},
				{
					title: "Kategori Menu Lain",
					rows: [
						{ title: 'Menu Stickers', description: `➜ ${global.botname}`, id: `${prefix}menu-stickers` },
						{ title: 'Menu Maker', description: `➜ ${global.botname}`, id: `${prefix}menu-maker` },
						{ title: 'Menu Download', description: `➜ ${global.botname}`, id: `${prefix}menu-download` },
						{ title: 'Menu Search', description: `➜ ${global.botname}`, id: `${prefix}menu-search` },
						{ title: 'Menu Game', description: `➜ ${global.botname}`, id: `${prefix}menu-game` },
						{ title: "Menu AI", description: `➜ ${global.botname}`, id: `${prefix}menu-ai` },
						{ title: "Menu Enc", description: `➜ ${global.botname}`, id: `${prefix}menu-enc` },
						{ title: 'Menu Sertifikat', description: `➜ ${global.botname}`, id: `${prefix}menu-stk` },
						{ title: 'Menu Rpg', description: `➜ ${global.botname}`, id: `${prefix}menu-rpg` },
						{ title: 'Menu Panel', description: `➜ ${global.botname}`, id: `${prefix}menu-panel` },
						{ title: 'Menu Group', description: `➜ ${global.botname}`, id: `${prefix}menu-group` },
						{ title: 'Menu Potoanime', description: `➜ ${global.botname}`, id: `${prefix}menu-potoanime` },
						{ title: 'Menu Anime', description: `➜ ${global.botname}`, id: `${prefix}menu-anime` },
						{ title: 'Menu Nsfw', description: `➜ ${global.botname}`, id: `${prefix}menu-nsfw` },
						{ title: 'Menu Cecan', description: `➜ ${global.botname}`, id: `${prefix}menu-cecan` },
						{ title: 'Menu Islami', description: `➜ ${global.botname}`, id: `${prefix}menu-islami` },
						{ title: 'Menu Ehpoto', description: `➜ ${global.botname}`, id: `${prefix}menu-ehpoto` },
						{ title: 'Menu Fun', description: `➜ ${global.botname}`, id: `${prefix}menu-fun` },
						{ title: 'Menu Primbon', description: `➜ ${global.botname}`, id: `${prefix}menu-primbon` }
					]
				}
			];

			let totalSewaBot = 0;
			try { totalSewaBot = Object.keys(global.db?.groups || {}).length; } catch (e) {}

			const thumb = global.image.menu;
			const videoPath = './media/menu.mp4';

			try {
				if (menuStyle === 'v1') {
					let menuBody = `
╭━━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
│ 水  [${limitBar}]
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${global.versi}
│ 火  Waktu  : ${jam} WIB
│ 風  Cuaca  : ${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C
│ 地  RAM    : ${ram.used} / ${ram.total} (${ram.percent}%)
│ 人  Pengguna : ${totalPengguna}
│ 群  Sewa Aktif : ${totalSewaBotCount} Group
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━ 〔 𝗕𝗢𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 〕━━━⬣
│ 炎  Bot WhatsApp Premium
│ 光  Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣
${teks}`;

					let media = null;
					try {
						if (fs.existsSync(videoPath)) {
							media = await prepareWAMessageMedia({ video: { url: videoPath }, gifPlayback: true }, { upload: yonz.waUploadToServer });
						}
					} catch (e) {}

					const headerContent = media ? { hasMediaAttachment: true, videoMessage: media.videoMessage } : { hasMediaAttachment: false };

					let msg = generateWAMessageFromContent(m.chat, {
						viewOnceMessage: {
							message: {
								interactiveMessage: proto.Message.InteractiveMessage.create({
									body: proto.Message.InteractiveMessage.Body.create({ text: `> Hai Saya  ${global.botname2} yang siap nemenin kamu kapanpun dan dimanapun` }),
									footer: proto.Message.InteractiveMessage.Footer.create({ text: menuBody }),
									header: proto.Message.InteractiveMessage.Header.create({ title: "", ...headerContent }),
									nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
										buttons: [
											{ name: "single_select", buttonParamsJson: JSON.stringify({ title: `Buka Menu ${global.botname2}`, sections: sectionsV1, icon: "DEFAULT" }) },
											{ name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: `Saluran ${global.botname}`, url: global.linkSaluran, merchant_url: global.linkSaluran }) }
										],
										messageParamsJson: JSON.stringify({
											limited_time_offer: {
												text: `📅 ${hariini}`,
												url: global.linkSaluran
											}
										})
									}),
									contextInfo: { mentionedJid: [m.sender] }
								})
							}
						}
					}, { quoted: m });
					await yonz.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

				} else if (menuStyle === 'v2') {
					let menuBody = `
╭━━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
│ 水  [${limitBar}]
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${global.versi}
│ 火  Waktu  : ${jam} WIB
│ 風  Cuaca  : ${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C
│ 地  RAM    : ${ram.used} / ${ram.total} (${ram.percent}%)
│ 人  Pengguna : ${totalPengguna}
│ 群  Sewa Aktif : ${totalSewaBotCount} Group
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━ 〔 𝗕𝗢𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 〕━━━⬣
│ 炎  Bot WhatsApp Premium
│ 光  Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣
${teks}`;

					let thumbBuffer = null;
					try {
						const got = require('got');
						thumbBuffer = (await got(global.image.menu, { responseType: 'buffer' })).body;
					} catch (e) {}

					const btn = new yonz.ButtonV2(yonz);
					btn.setBody(`> *Haii ${m.pushName} Saya ${global.botname}, Asisten kamu di Tahun 2026 Yang siap bantu kamu kapanpun dan dimanapun Silahkan pilih menu di bawah ya*`)
					   .setFooter(menuBody)
					   .setThumbnail(thumbBuffer || global.image.menu)
					   .addRawButton({
						   buttonText: { displayText: 'ʟɪsᴛ ᴍᴇɴᴜ' },
						   buttonId: 'menu_list',
						   type: 1,
						   nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: '🍀 ʟɪsᴛ ᴍᴇɴᴜ', sections: sectionsV2 }) }
					   })
					   .addRawButton({
						   buttonText: { displayText: ' sᴜᴘᴘᴏʀᴛ' },
						   buttonId: 'support_list',
						   type: 1,
						   nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: '💎 sᴜᴘᴘᴏʀᴛ', sections: noInfoOkOkLhV2 }) }
					   });
					await btn.send(m.chat);

				} else if (menuStyle === 'v3') {
					let menuText = `╼ ׅ ֹ𔖰᷼𔖮 *Info User*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ User : *${m.pushName}*
┆𖢷 ׁ 𖹭₊ Status : *${userStatus}*
┆𖢷 ׁ 𖹭₊ Limit : *${limitInfo}* [${limitBar}]
┆𖢷 ׁ 𖹭₊ Gold RPG : *${rpgGold}* 🪙
╰─╼𔕬─┈───┈───┈

╼ ׅ ֹ𔖰᷼𔖮 *Info Bot*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Bot Name : *${global.botname} v${global.versi}*
┆𖢷 ׁ 𖹭₊ Total Fitur : *${totalFitur}*
┆𖢷 ׁ 𖹭₊ Total Sewa : *${totalSewaBot} Group*
┆𖢷 ׁ 𖹭₊ Total Pengguna : *${totalPengguna}*
┆𖢷 ׁ 𖹭₊ Cuaca : *${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C*
┆𖢷 ׁ 𖹭₊ RAM : *${ram.used}/${ram.total} (${ram.percent}%)*
╰─╼𔕬─┈───┈───┈
 ${teks}`;

					const thumbPath = "./source/media/foto/imgdokumen.jpg";
					if (fs.existsSync(thumbPath)) {
						try {
							const jimp = require('jimp');
							const img = await jimp.read(thumbPath);
							if (img.bitmap.width !== 300 || img.bitmap.height !== 300) {
								img.cover(300, 300);
								await img.writeAsync(thumbPath);
							}
						} catch (e) {}
					}

					try {
						await yonz.sendMessage(m.chat, {
							buttons: [
								{ buttonId: 'action', buttonText: { displayText: 'Lihat Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: `Select menu`, sections: sectionsV3 }) } }
							],
							headerType: 1,
							viewOnce: true,
							image: { url: global.image.menuv3 },
							caption: menuText,
							contextInfo: {
								mentionedJid: [m.sender],
								isForwarded: true,
								forwardingScore: 9999,
								businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" },
								forwardedNewsletterMessageInfo: {
									newsletterName: global.namaSaluran,
									newsletterJid: global.idSaluran
								}
							}
						}, { quoted: m });
					} catch (err) {
						console.log('menu v3 error', err);
						await yonz.sendMessage(m.chat, {
							image: { url: global.image.reply },
							caption: menuText,
							contextInfo: {
								mentionedJid: [m.sender]
							}
						}, { quoted: m });
					}

				} else if (menuStyle === 'v4') {
					let menuText = `╼ ׅ ֹ𔖰᷼𔖮 *Info User*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ User : *${m.pushName}*
┆𖢷 ׁ 𖹭₊ Status : *${userStatus}*
┆𖢷 ׁ 𖹭₊ Limit : *${limitInfo}* [${limitBar}]
┆𖢷 ׁ 𖹭₊ Gold RPG : *${rpgGold}* 🪙
╰─╼𔕬─┈───┈───┈

╼ ׅ ֹ𔖰᷼𔖮 *Info Bot*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Bot Name : *${global.botname} v${global.versi}*
┆𖢷 ׁ 𖹭₊ Total Fitur : *${totalFitur}*
┆𖢷 ׁ 𖹭₊ Total Sewa : *${totalSewaBot} Group*
┆𖢷 ׁ 𖹭₊ Total Pengguna : *${totalPengguna}*
┆𖢷 ׁ 𖹭₊ Cuaca : *${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C*
┆𖢷 ׁ 𖹭₊ RAM : *${ram.used}/${ram.total} (${ram.percent}%)*
╰─╼𔕬─┈───┈───┈
 ${teks}`;

					await yonz.sendMessage(m.chat, {
						footer: '',
						image: { url: global.image.reply },
						caption: menuText,
						buttons: [
							{ buttonId: 'action', buttonText: { displayText: 'Lihat Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: `Select menu`, sections: sectionsV3 }) } }
						],
						contextInfo: {
							mentionedJid: [m.sender]
						}
					}, { quoted: m });

				} else if (menuStyle === 'v5') {
					let allText = `${infoText}\n`;
					sectionsMain.forEach(sec => {
						allText += `\n『 ${sec.title} 』\n`;
						sec.rows.forEach(r => { allText += `▣ ${r.title} - ${r.id}\n`; });
					});
					await Reply(allText);

				} else if (menuStyle === 'v6') {
					await yonz.sendMessage(m.chat, {
						image: { url: global.image.reply },
						caption: infoText,
						contextInfo: {
							mentionedJid: [m.sender]
						},
						buttons: [
							{ buttonId: 'action', buttonText: { displayText: '🛍️ Buka Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: 'Product Menu', sections: sectionsMain }) } }
						]
					}, { quoted: m });

				} else if (menuStyle === 'v7') {
					const btn = new yonz.ButtonV2(yonz);
					btn.setBody(infoText)
					   .setFooter(`${global.botname} • ${new Date().getFullYear()}`)
					   .addRawButton({
						   buttonText: { displayText: '📋 Menu' },
						   buttonId: 'menu_list',
						   type: 1,
						   nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: 'Menu', sections: sectionsMain }) }
					   });
					await btn.send(m.chat);

				} else if (menuStyle === 'v8') {
					const hasVideo = fs.existsSync(videoPath);
					await yonz.sendMessage(m.chat, {
						...(hasVideo ? { video: fs.readFileSync(videoPath), gifPlayback: true } : { image: { url: thumb } }),
						caption: infoText,
						footer: global.botname,
						buttons: [
							{ buttonId: 'action', buttonText: { displayText: 'Buka Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: 'Menu', sections: sectionsMain }) } }
						]
					}, { quoted: m });

				} else {
					await menureply('', true);
				}
			} catch (e) {
				console.log('Menu style error:', e);
				await menureply('', true);
			}
		}

		const pluginsLoader = async (directory) => {
			let plugins = []
			const folders = fs.readdirSync(directory)
			folders.forEach(file => {
				const filePath = path.join(directory, file)
				if (filePath.endsWith(".js")) {
					try {
						const resolvedPath = require.resolve(filePath);
						if (require.cache[resolvedPath]) {
							delete require.cache[resolvedPath]
						}
						const plugin = require(filePath)
						plugins.push(plugin)
					} catch (error) {
						console.log(`Error loading plugin at ${filePath}:`, error)
					}}
			})
			return plugins
		}

		let pluginsDisable = true
		const plugins = await pluginsLoader(path.resolve(__dirname, "plugins"))
		const clutchzodev = { yonz, toIDR, isCreator, Reply, command, isPremium, capital, isCmd, example, text, runtime, qtext, qlocJpm, qmsg, mime, sleep, botNumber, addLimitUsage, getUserMaxLimit, getUsedToday }
		for (let plugin of plugins) {
			if (plugin.command.find(e => e == command.toLowerCase())) {
				pluginsDisable = false
				if (typeof plugin !== "function") return
				await plugin(m, clutchzodev)
			}
		}
		if (!pluginsDisable) return

if (global.game && global.game[m.chat] && !isCmd) {
  const jawabanUser = body.toLowerCase().trim()
  const dataGame = global.game[m.chat]

  if (dataGame.type === 'family100') {
    const idx = dataGame.jawabanList.findIndex((j, i) => j === jawabanUser && !dataGame.found.includes(i))
    if (idx !== -1) {
      dataGame.found.push(idx)
      const sisa = dataGame.jawabanList.length - dataGame.found.length
      if (sisa === 0) {
        clearTimeout(dataGame.timeout)
        delete global.game[m.chat]
        yonz.sendMessage(m.chat, { text: `🎉 Semua jawaban ketebak! Game selesai.` }, { quoted: m })
      } else {
        yonz.sendMessage(m.chat, { text: `✅ Benar! *${dataGame.jawabanAsli[idx]}*\nSisa ${sisa} jawaban lagi.` }, { quoted: m })
      }
    } else if (jawabanUser.length > 0) {
      yonz.sendMessage(m.chat, { text: `❌ Jawaban salah / sudah disebut!` }, { quoted: m })
    }
  } else {
    if (jawabanUser === dataGame.jawaban) {
      clearTimeout(dataGame.timeout)
      delete global.game[m.chat]
      yonz.sendMessage(m.chat, { text: `✅ Benar! Jawabannya adalah *${dataGame.jawabanAsli || dataGame.jawaban}*${dataGame.deskripsi ? `\nKeterangan: ${dataGame.deskripsi}` : ''}` }, { quoted: m })
    } else if (jawabanUser.length > 0) {
      yonz.sendMessage(m.chat, { text: `❌ Jawaban salah!` }, { quoted: m })
    }
  }
}

if (!isCmd && m.isGroup && body && typeof body === 'string' && body.trim().length > 0 && !m.isBaileys) {
  const chatId = m.chat;
  let listDb = loadLists();
  let listGrup = listDb[chatId] || [];

  if (listGrup.length > 0) {
    const searchText = body.toLowerCase().trim();
    
    let cari = listGrup.find(item => 
      item.name.toLowerCase() === searchText
    );
    
    if (cari) {
      if (cari.hasImage && cari.image && fs.existsSync(cari.image)) {
        await yonz.sendMessage(m.chat, {
          image: fs.readFileSync(cari.image),
          caption: cari.desc
        }, { quoted: m });
      } else {
        yonz.sendMessage(m.chat, {
          text: cari.desc
        }, { quoted: m });
      }
    }
  }
}

if (!isCmd && body && typeof body === 'string' && !m.isBaileys && !m.key.fromMe && (!m.isGroup || isCreator || isGroupSewa(m.chat))) {
  const adSetting = m.isGroup
    ? global.db.groups?.[m.chat]?.autodownload
    : global.db.users?.[m.sender]?.autodownload;

  if (adSetting) {
    const ttMatch = body.match(AUTODL_TIKTOK_REGEX);
    const igMatch = !ttMatch ? body.match(AUTODL_IG_REGEX) : null;
    const linkUrl = ttMatch?.[1] || igMatch?.[1];

    if (linkUrl) {
      try {
        await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const data = await autoDownloadAIO(linkUrl);
        const label = ttMatch ? 'TikTok' : 'Instagram';
        const emoji = ttMatch ? '🎵' : '📸';

        if (!data || (!data.video && data.images.length === 0)) {
          await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        } else {
          if (data.video) {
            await yonz.sendMessage(m.chat, {
              video: { url: data.video },
              caption: `*${emoji} Auto Download ${label}*\n\n${data.title || ''}`
            }, { quoted: m });
            if (data.audio) {
              await yonz.sendMessage(m.chat, {
                audio: { url: data.audio },
                mimetype: 'audio/mpeg',
                fileName: 'audio.mp3'
              }, { quoted: m });
            }
          } else if (data.images.length > 0) {
            for (const imgUrl of data.images) {
              await yonz.sendMessage(m.chat, {
                image: { url: imgUrl },
                caption: `*${emoji} Auto Download ${label}*\n\n${data.title || ''}`
              }, { quoted: m });
            }
          }
          await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        }
      } catch (e) {
        console.log('AutoDownload error:', e);
        await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
      }
    }
  }
}

switch (command) {

case "setaudiomenu":
case "setaudio": {
    if (!isCreator) return Reply(mess.owner);
    
    if (!m.quoted || !/audio/.test((m.quoted.msg || m.quoted).mimetype || '')) {
        return Reply("❌ Reply audio yang ingin dijadikan sebagai audio menu!");
    }
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        const quotedMsg = m.quoted;
        const audioBuffer = await quotedMsg.download();
        
        if (!audioBuffer || audioBuffer.length < 1000) {
            return Reply("❌ Gagal mendownload audio. Coba lagi nanti.");
        }
        
        const audioPath = path.join(__dirname, 'media', 'yonz.mp3');
        const mediaDir = path.join(__dirname, 'media');
        
        if (!fs.existsSync(mediaDir)) {
            fs.mkdirSync(mediaDir, { recursive: true });
        }
        
        fs.writeFileSync(audioPath, audioBuffer);
        
        await yonz.sendMessage(m.chat, {
            audio: fs.readFileSync(audioPath),
            mimetype: 'audio/mp4',
            ptt: false
        }, { quoted: m });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        Reply("✅ Berhasil mengganti audio menu!\n\nAudio akan diputar saat membuka menu.");
        
    } catch (error) {
        console.error('[SETAUDIO ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break

case 'autoai': {
    if (!isCreator) return Reply(mess.owner);

    if (typeof global.db.settings.autoai !== 'string') global.db.settings.autoai = 'off';

    if (!text) {
        const mode = global.db.settings.autoai;
        const status = mode === 'off' ? '❌ NONAKTIF' : mode === 'all' ? '✅ AKTIF (Grup + Pribadi)' : '✅ AKTIF (Grup saja)';
        return Reply(
            `╼ ׅ ֹ𔖰᷼𔖮 *AUTO AI SETTINGS* ⚙️
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Status : ${status}
┆𖢷 ׁ 𖹭₊ Cara kerja : Bot otomatis menjawab kalau pesannya me-reply chat bot
┆𖢷 ׁ 𖹭₊
┆𖢷 ׁ 𖹭₊ Gunakan:
┆𖢷 ׁ 𖹭₊ .autoai on      → Aktifkan (grup saja)
┆𖢷 ׁ 𖹭₊ .autoai on all  → Aktifkan (grup + pribadi)
┆𖢷 ׁ 𖹭₊ .autoai off     → Nonaktifkan
╰─╼𔕬─┈───┈───┈`
        );
    }

    const args2 = text.toLowerCase().trim().split(/\s+/);
    const action = args2[0];
    const scope = args2[1];

    if (action === 'on') {
        if (scope === 'all') {
            global.db.settings.autoai = 'all';
            return Reply(`✅ *Auto AI diaktifkan!*\nBerlaku di *grup & chat pribadi*. Bot akan otomatis mengetik & menjawab kalau pesannya me-reply chat bot.`);
        } else {
            global.db.settings.autoai = 'group';
            return Reply(`✅ *Auto AI diaktifkan!*\nBerlaku di *seluruh grup* saja. Bot akan otomatis mengetik & menjawab kalau pesannya me-reply chat bot.\n\nMau termasuk chat pribadi? Gunakan: .autoai on all`);
        }
    } else if (action === 'off') {
        global.db.settings.autoai = 'off';
        return Reply(`❌ *Auto AI dinonaktifkan!*`);
    } else {
        return Reply('❌ Gunakan: .autoai on / .autoai on all / .autoai off');
    }
}
break;

case 'autoread': {
    if (!isCreator) return Reply(mess.owner);

    if (typeof global.db.settings.autoread !== 'boolean') global.db.settings.autoread = true;

    if (!text) {
        const status = global.db.settings.autoread ? '✅ AKTIF' : '❌ NONAKTIF';
        return Reply(
            `╼ ׅ ֹ𔖰᷼𔖮 *AUTOREAD SETTINGS* ⚙️
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Status : ${status}
┆𖢷 ׁ 𖹭₊ Berlaku untuk : Semua chat (grup & pribadi)
┆𖢷 ׁ 𖹭₊
┆𖢷 ׁ 𖹭₊ Gunakan:
┆𖢷 ׁ 𖹭₊ .autoread on  → Aktifkan
┆𖢷 ׁ 𖹭₊ .autoread off → Nonaktifkan
╰─╼𔕬─┈───┈───┈`
        );
    }

    const action = text.toLowerCase().trim();
    if (action === 'on') {
        global.db.settings.autoread = true;
        return Reply(`✅ *Autoread diaktifkan!*\nBot akan otomatis membaca (centang biru) semua pesan masuk, di grup maupun chat pribadi.`);
    } else if (action === 'off') {
        global.db.settings.autoread = false;
        return Reply(`❌ *Autoread dinonaktifkan!*\nBot tidak akan lagi otomatis membaca pesan masuk.`);
    } else {
        return Reply('❌ Gunakan: .autoread on / .autoread off');
    }
}
break;

case 'setprefix': {
    if (!isCreator2) return Reply(global.mess.creator);

    const pathNoPfxConfig = './library/database/nopfx_config.json';
    if (!fs.existsSync(pathNoPfxConfig)) {
        fs.writeFileSync(pathNoPfxConfig, JSON.stringify({ enabled: true }, null, 2));
    }

    const config = JSON.parse(fs.readFileSync(pathNoPfxConfig));

    if (!text) {
        const status = config.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
        return Reply(
            `╼ ׅ ֹ𔖰᷼𔖮 *NO-PREFIX SETTINGS* ⚙️
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Status : ${status}
┆𖢷 ׁ 𖹭₊ 
┆𖢷 ׁ 𖹭₊ Gunakan:
┆𖢷 ׁ 𖹭₊ .setprefix on  → Aktifkan
┆𖢷 ׁ 𖹭₊ .setprefix off → Nonaktifkan
╰─╼𔕬─┈───┈───┈`
        );
    }

    const action = text.toLowerCase().trim();
    if (action === 'on') {
        config.enabled = true;
        fs.writeFileSync(pathNoPfxConfig, JSON.stringify(config, null, 2));
        return Reply(`✅ *No-Prefix diaktifkan!*\nSekarang command bisa digunakan tanpa prefix.`);
    } else if (action === 'off') {
        config.enabled = false;
        fs.writeFileSync(pathNoPfxConfig, JSON.stringify(config, null, 2));
        return Reply(`❌ *No-Prefix dinonaktifkan!*\nCommand harus menggunakan prefix (titik/!/dll).`);
    } else {
        return Reply('❌ Gunakan: on / off');
    }
}
break;

case "setimg":
case "setimage": {
    if (!isCreator) return Reply(mess.owner);
    
    let type = args[0]?.toLowerCase();
    if (!type || (type !== "menu" && type !== "reply")) {
        return Reply(`❌ Contoh penggunaan:\n${prefix}setimg menu\n${prefix}setimg reply\n\nKemudian reply gambar yang ingin dijadikan sebagai gambar menu/reply.`);
    }
    
    const quotedMsg = m.quoted || m;
    const mimeType = (quotedMsg.msg || quotedMsg).mimetype || '';
    
    if (!m.quoted || !/image/.test(mimeType)) {
        return Reply("❌ Reply gambar yang ingin dijadikan sebagai gambar!");
    }
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        let mediaPath = await yonz.downloadAndSaveMediaMessage(quotedMsg);
        let imageBuffer = fs.readFileSync(mediaPath);
        
        const { ImageUploadService } = require('node-upload-images');
        const service = new ImageUploadService('pixhost.to');
        const { directLink } = await service.uploadFromBinary(imageBuffer, `image_${Date.now()}.jpg`);
        
        if (!directLink) {
            await fs.unlinkSync(mediaPath);
            return Reply("❌ Gagal upload gambar ke server. Coba lagi nanti.");
        }
        
        let settingsPath = path.join(__dirname, 'settings.js');
        let settingsContent = fs.readFileSync(settingsPath, 'utf8');
        
        if (type === "menu") {
            settingsContent = settingsContent.replace(
                /menu:\s*["'][^"']*["']/,
                `menu: "${directLink}"`
            );
        } else if (type === "reply") {
            settingsContent = settingsContent.replace(
                /reply:\s*["'][^"']*["']/,
                `reply: "${directLink}"`
            );
        }
        
        fs.writeFileSync(settingsPath, settingsContent, 'utf8');
        
        await fs.unlinkSync(mediaPath);
        
        await yonz.sendMessage(m.chat, {
            image: { url: directLink },
            caption: `✅ Berhasil mengubah gambar *${type}*!\n\nURL: ${directLink}`
        }, { quoted: m });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (error) {
        console.error('[SETIMG ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break


case "kimiai": {
    if (!text) return Reply(example("hallo"));
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        const apiUrl = `https://api.nexray.web.id/ai/kimi?text=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;
        
        if (!data.status) return Reply("❌ Gagal mendapatkan respons dari AI.");
        
        const resultText = data.result || "Tidak ada respons";
        
        await yonz.sendMessage(m.chat, {
            text: `📝 *Kimi AI:*\n${resultText}`
        }, { quoted: m });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[KIMI ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break

case "openai":
case "chatgpt": {
    if (!text) return Reply(example("hallo"));
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        const apiUrl = `https://api.nexray.web.id/ai/chatgpt?text=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;
        
        if (!data.status) return Reply("❌ Gagal mendapatkan respons dari AI.");
        
        const resultText = data.result || "Tidak ada respons";
        
        await yonz.sendMessage(m.chat, {
            text: `📝 *Chat Gpt:*\n${resultText}`
        }, { quoted: m });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[AI ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break
		
case "gemini": {
    if (!text) return Reply(example("hallo"));
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        const apiUrl = `https://api.nexray.web.id/ai/gemini?text=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;
        
        if (!data.status) return Reply("❌ Gagal mendapatkan respons dari AI.");
        
        const resultText = data.result || "Tidak ada respons";
        
        await yonz.sendMessage(m.chat, {
            text: `📝 *Gemini AI:*\n${resultText}`
        }, { quoted: m });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error('[GEMINI ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break
		
case "hd":
case "remini":
case "upscale": {
    if (!/image/.test(mime) && !m.quoted) 
        return Reply("❌ Kirim/reply gambar dengan caption *.hd* / *.remini* / *.upscale*");
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        let mediaPath = await yonz.downloadAndSaveMediaMessage(qmsg);
        let imageBuffer = fs.readFileSync(mediaPath);
        
        const { ImageUploadService } = require('node-upload-images');
        const service = new ImageUploadService('pixhost.to');
        const { directLink } = await service.uploadFromBinary(imageBuffer, `remini_${Date.now()}.jpg`);
        
        if (!directLink) {
            await fs.unlinkSync(mediaPath);
            return Reply("❌ Gagal upload gambar ke server. Coba lagi nanti.");
        }
        
        const apiUrl = `${global.apialip}/imagecreator/remini?apikey=${global.apikeyalip}&url=${encodeURIComponent(directLink)}`;
        
        const resultBuffer = await getBuffer(apiUrl);
        
        if (!resultBuffer || resultBuffer.length < 1000) {
            await fs.unlinkSync(mediaPath);
            return Reply("❌ Gagal meningkatkan kualitas gambar. Coba lagi nanti.");
        }
        
        await yonz.sendMessage(m.chat, {
            image: resultBuffer,
            caption: `✅ *${command.toUpperCase()}* - Kualitas gambar berhasil ditingkatkan!`
        }, { quoted: m });
        
        await fs.unlinkSync(mediaPath);
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error(`[${command.toUpperCase()} ERROR]`, error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break
		
case "qc": {
    if (!text) return Reply("❌ Contoh penggunaan: .qc hitam, hallo dunia\nAtau: .qc putih, hai guys");
    
    let bgColor = "#000000";
    let quoteText = text;
    
    if (text.toLowerCase().startsWith("hitam,")) {
        bgColor = "#000000";
        quoteText = text.slice(6).trim();
    } else if (text.toLowerCase().startsWith("putih,")) {
        bgColor = "#FFFFFF";
        quoteText = text.slice(6).trim();
    }
    
    if (!quoteText) return Reply("❌ Masukkan teks quote!\nContoh: .qc hitam, hallo dunia");
    
    await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    Reply(mess.wait);
    
    try {
        const profileUrl = "https://raw.githubusercontent.com/RahmadPasker/dat3/main/uploads/alip-clutch-1772780169524.jpg";
        const username = m.pushName || m.sender.split("@")[0];
        const encodedText = encodeURIComponent(quoteText);
        const encodedProfile = encodeURIComponent(profileUrl);
        const encodedUsername = encodeURIComponent(username);
        const encodedBg = encodeURIComponent(bgColor);
        
        const apiUrl = `${global.apialip}/imagecreator/quoted?apikey=${global.apikeyalip}&username=${encodedUsername}&profile=${encodedProfile}&text=${encodedText}&bg=${encodedBg}`;
        
        const imageBuffer = await getBuffer(apiUrl);
        
        if (!imageBuffer || imageBuffer.length < 1000) {
            return Reply("❌ Gagal membuat gambar quote. Coba lagi nanti.");
        }
        
        await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
        
        await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('[QC ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break
		
case 'setlist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text) {
        return Reply(
`*Variabel tersedia:*

@name - Nama user
@group - Nama grup
@time - Waktu
@date - Tanggal
@fulldate - Full tanggal
@daytime - Waktu hari
@x - List keyword
@prefix teks - Format item

*Contoh penggunaan:*

.setlist 
╭─❏ List Produk @group
│▣ Customer : @name
│▣ Waktu : @time
│▣ Tanggal : @date
╰──────────❏
╭─❏ List Produk
@x
╰──────────❏
@prefix │▣
`
        )
    }
    
    const settings = loadListSettings();
    if (!settings[m.chat]) settings[m.chat] = {};
    
    const prefixMatch = text.match(/@prefix\s+([^\n]+)/i);
    if (prefixMatch && prefixMatch[1]) {
        settings[m.chat].prefix = prefixMatch[1].trim();
    } else {
        delete settings[m.chat].prefix;
    }
    
    settings[m.chat].template = text;
    
    if (m.type === 'imageMessage') {
        try {
            const media = await downloadAndSaveMediaList(m, 'image');
            settings[m.chat].media = media;
            settings[m.chat].mediaType = 'image';
        } catch (e) {}
    } else if (m.quoted && m.quoted.type === 'imageMessage') {
        try {
            const media = await downloadAndSaveMediaList(m.quoted, 'image');
            settings[m.chat].media = media;
            settings[m.chat].mediaType = 'image';
        } catch (e) {}
    } else {
        delete settings[m.chat].media;
        delete settings[m.chat].mediaType;
    }
    
    saveListSettings(settings);
    
    Reply(`✅ Template list berhasil disimpan!`);
}
break;

case 'addlist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text || !text.includes('|')) return Reply(example("Burger|Burger dengan keju melt"));
    
    let parts = text.split('|');
    if (parts.length < 2) return Reply(example("Burger|Burger dengan keju melt"));
    
    const nama = parts[0].trim();
    const deskripsi = parts.slice(1).join('|').trim();
    
    const chatId = m.chat;
    let listDb = loadLists();
    
    if (!listDb[chatId]) {
        listDb[chatId] = [];
    }
    
    const newItem = {
        name: nama,
        desc: deskripsi,
        addedBy: m.sender,
        addedAt: Date.now()
    };
    
    if (m.type === 'imageMessage') {
        try {
            const mediaPath = await downloadAndSaveMediaList(m, 'image');
            newItem.image = mediaPath;
            newItem.hasImage = true;
        } catch (e) {}
    } else if (m.quoted && m.quoted.type === 'imageMessage') {
        try {
            const mediaPath = await downloadAndSaveMediaList(m.quoted, 'image');
            newItem.image = mediaPath;
            newItem.hasImage = true;
        } catch (e) {}
    }
    
    listDb[chatId].push(newItem);
    saveLists(listDb);
    
    Reply(`✅ Item "${nama}" berhasil ditambahkan!`);
}
break;

case 'list': {
    if (!m.isGroup) return Reply(mess.group);
    
    const chatId = m.chat;
    const listDb = loadLists();
    const listGrup = listDb[chatId] || [];
    
    if (listGrup.length === 0) {
        return Reply(
            `╭─❏ List
│▣ Status : Belum ada item
│▣ Tambah : .addlist nama|deskripsi
╰──────────❏`
        )
    }
    
    try {
        const groupMetadata = m.isGroup ? await yonz.groupMetadata(chatId) : null;
        const groupName = groupMetadata ? groupMetadata.subject : 'Grup Ini';
        const userName = m.pushName || m.sender.split('@')[0];
        
        const listText = getListWithTemplate(chatId, userName, groupName, listGrup);
        
        const settings = loadListSettings();
        const chatSettings = settings[chatId];
        
        if (chatSettings && chatSettings.media && fs.existsSync(chatSettings.media)) {
            await yonz.sendMessage(chatId, {
                image: fs.readFileSync(chatSettings.media),
                caption: listText
            }, { quoted: m });
        } else {
            await yonz.sendMessage(chatId, {
                text: listText
            }, { quoted: m });
        }
        
    } catch (e) {
        Reply(mess.error);
    }
}
break;

case 'updatelist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text || !text.includes('|')) return Reply(example("Burger|Dengan daging wagyu"));
    
    let parts = text.split('|');
    if (parts.length < 2) return Reply(example("Burger|Dengan daging wagyu"));
    
    const keyword = parts[0].trim();
    const deskripsiBaru = parts.slice(1).join('|').trim();
    
    const chatId = m.chat;
    const listDb = loadLists();
    let listGrup = listDb[chatId] || [];
    
    if (listGrup.length === 0) return Reply("❌ Tidak ada item di list");
    
    let itemIndex = listGrup.findIndex(item => 
        item.name.toLowerCase() === keyword.toLowerCase() ||
        item.name.toLowerCase().includes(keyword.toLowerCase())
    );
    
    if (itemIndex === -1) return Reply(`❌ Item "${keyword}" tidak ditemukan`);
    
    const itemLama = listGrup[itemIndex];
    listGrup[itemIndex].desc = deskripsiBaru;
    
    if (m.type === 'imageMessage') {
        try {
            if (itemLama.hasImage && itemLama.image && fs.existsSync(itemLama.image)) {
                fs.unlinkSync(itemLama.image);
            }
            const mediaPath = await downloadAndSaveMediaList(m, 'image');
            listGrup[itemIndex].image = mediaPath;
            listGrup[itemIndex].hasImage = true;
        } catch (e) {}
    } else if (m.quoted && m.quoted.type === 'imageMessage') {
        try {
            if (itemLama.hasImage && itemLama.image && fs.existsSync(itemLama.image)) {
                fs.unlinkSync(itemLama.image);
            }
            const mediaPath = await downloadAndSaveMediaList(m.quoted, 'image');
            listGrup[itemIndex].image = mediaPath;
            listGrup[itemIndex].hasImage = true;
        } catch (e) {}
    }
    
    listDb[chatId] = listGrup;
    saveLists(listDb);
    
    Reply(`✅ Item "${itemLama.name}" berhasil diperbarui!`);
}
break;

case 'dellist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text) return Reply(example("Burger"));
    
    const chatId = m.chat;
    const listDb = loadLists();
    let listGrup = listDb[chatId] || [];
    
    if (listGrup.length === 0) return Reply("❌ Tidak ada item di list");
    
    let itemDihapus = null;
    let index = -1;
    
    if (!isNaN(text)) {
        index = parseInt(text) - 1;
        if (index >= 0 && index < listGrup.length) {
            itemDihapus = listGrup[index];
        }
    } else {
        const keyword = text.toLowerCase();
        index = listGrup.findIndex(item => 
            item.name.toLowerCase() === keyword ||
            item.name.toLowerCase().includes(keyword)
        );
        if (index !== -1) {
            itemDihapus = listGrup[index];
        }
    }
    
    if (!itemDihapus) return Reply(`❌ Item "${text}" tidak ditemukan`);
    
    if (itemDihapus.hasImage && itemDihapus.image && fs.existsSync(itemDihapus.image)) {
        try {
            fs.unlinkSync(itemDihapus.image);
        } catch (e) {}
    }
    
    listGrup.splice(index, 1);
    listDb[chatId] = listGrup;
    saveLists(listDb);
    
    Reply(`✅ Item "${itemDihapus.name}" berhasil dihapus!`);
}
break;

case 'resetlist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    const settings = loadListSettings();
    
    if (settings[m.chat]) {
        if (settings[m.chat].media && fs.existsSync(settings[m.chat].media)) {
            try {
                fs.unlinkSync(settings[m.chat].media);
            } catch (e) {}
        }
        delete settings[m.chat];
        saveListSettings(settings);
    }
    
    Reply(`✅ Template list berhasil direset ke default!`);
}
break;

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await yonz.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break
		
case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break
		
case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await yonz.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');

let teks = directLink.toString()
await yonz.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break
		
case 'playmusik':
case 'ytmp3': {
    if (!isRegistered(m.sender) && !isCreator) return;
    if (!text) return Reply('Masukin link YouTube');
    if (!text.includes('youtube.com') && !text.includes('youtu.be')) return Reply('Link YouTube tidak valid');

    const url = text.trim();
    const apiUrl = `https://api.theresav.biz.id/download/ytmp3?url=${encodeURIComponent(url)}&format=mp3&bitrate=128k&apikey=Yonz`;

    await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const response = await axios.get(apiUrl, { timeout: 300000 });
        const data = response.data;

        if (!data.status) {
            await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return Reply(data.message || 'Gagal memproses data');
        }

        await yonz.sendMessage(m.chat, {
            audio: { url: data.download_url },
            mimetype: data.mimetype || 'audio/mpeg',
            ptt: false,
            fileName: `${data.title}.mp3`
        }, { quoted: m });

        await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[PLAYMUSIK ERROR]', e);
        await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        Reply('Error saat memproses audio dari server');
    }
}
break

case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await yonz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await ytdl.ytmp4(`${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await yonz.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await yonz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
		
case "playvid": {
    if (!text) return Reply(example("jj luser"));

    await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    Reply(mess.wait);

    try {
        const apiUrl = `${global.apialip}/search/tiktok?apikey=${global.apikeyalip}&q=${encodeURIComponent(text)}`;
        const response = await axios.get(apiUrl, { timeout: 30000 });
        const data = response.data;

        if (!data.status || !data.result || data.result.length === 0) {
            return Reply(`❌ Video dengan keyword "${text}" tidak ditemukan`);
        }

        const firstVideo = data.result[0];
        const videoUrl = firstVideo.play;
        const audioUrl = firstVideo.music;
        const title = firstVideo.title || 'Tidak ada judul';
        const duration = firstVideo.duration || 0;
        const playCount = firstVideo.play_count || 0;
        const diggCount = firstVideo.digg_count || 0;
        const author = firstVideo.author?.nickname || 'Tidak diketahui';

        const caption = `╭─❏ *TikTok Play*
│▣ Judul : ${title.substring(0, 50)}${title.length > 50 ? '...' : ''}
│▣ Author : ${author}
│▣ Durasi : ${duration} detik
│▣ Views : ${playCount.toLocaleString()}
│▣ Likes : ${diggCount.toLocaleString()}
╰──────────❏`;

        await yonz.sendMessage(m.chat, {
            video: { url: videoUrl },
            mimetype: 'video/mp4',
            caption: caption
        }, { quoted: m });

        await yonz.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted: m });

        await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[PLAYVID ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        
        if (error.code === 'ECONNABORTED') {
            Reply('⏱️ Timeout, coba lagi nanti');
        } else if (error.response?.status === 404) {
            Reply('❌ API tidak ditemukan');
        } else {
            Reply(mess.error);
        }
    }
}
break


		

		
case "swgc": {
    if (!isCreator) return Reply(mess.owner);
    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    const caption = m.body.replace(/^\.swgc\s*/i, "").trim();

    try {
        if (/image|video|audio/.test(mime)) {
            const buffer = await quoted.download();
            global.swgcBuffer = global.swgcBuffer || {};
            global.swgcBuffer[m.sender] = { buffer, mime, caption };
        } else if (caption) {
            global.swgcBuffer = global.swgcBuffer || {};
            global.swgcBuffer[m.sender] = { buffer: null, mime: "text", caption };
        } else {
            return Reply(`⚠️ _Kirim/Balas gambar/video dengan caption *${prefix}swgc*_`);
        }

        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

        const allGroups = await yonz.groupFetchAllParticipating();
        const groupList = Object.values(allGroups);

        if (groupList.length === 0) return Reply("❌ Bot tidak berada di dalam grup manapun.");

        const rows = groupList.map(g => ({
            title: g.subject,
            description: `Anggota: ${g.participants.length} | Status: ${g.announce == false ? "Terbuka" : "Hanya Admin"}`,
            id: `${prefix}swgc_process ${g.id}`
        }));

        await yonz.sendMessage(m.chat, {
            image: { url: global.image.menu },
            caption: `📲 *PILIH GRUP UNTUK SWGC*`,
            footer: `Total Grup: ${groupList.length}`,
            buttons: [
                {
                    buttonId: 'swgc_pilih',
                    buttonText: { displayText: '📥 Pilih Grup' },
                    type: 4,
                    nativeFlowInfo: {
                        name: 'single_select',
                        paramsJson: JSON.stringify({
                            title: 'SWGC',
                            sections: [
                                {
                                    title: 'Daftar Grup Bot',
                                    rows: rows
                                }
                            ]
                        })
                    }
                }
            ],
            headerType: 4,
            viewOnce: true,
            contextInfo: {
                isForwarded: false,
                mentionedJid: [m.sender]
            }
        }, { quoted: m });

    } catch (error) {
        console.error('[SWGC ERROR]', error);
        Reply("❌ Gagal menampilkan daftar grup.");
    }
}
break;

case "swgc_process": {
    if (!isCreator && !m.isAdmin) return Reply(mess.admin);
    if (!text) return Reply("❌ Data tidak lengkap.");
    const groupId = text.split("|")[0];

    const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
    if (!data) return Reply("❌ Media tidak tersedia, reply dulu media yang mau dikirim!");
    await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    try {
        if (/image/.test(data.mime)) {
            await yonz.sendMessage(groupId, { groupStatusMessage: { image: data.buffer, caption: data.caption } });
        } else if (/video/.test(data.mime)) {
            await yonz.sendMessage(groupId, { groupStatusMessage: { video: data.buffer, caption: data.caption } });
        } else if (/audio/.test(data.mime)) {
            await yonz.sendMessage(groupId, { groupStatusMessage: { audio: data.buffer } });
        } else if (data.mime === "text" && data.caption) {
            await yonz.sendMessage(groupId, { groupStatusMessage: { text: data.caption } });
        } else {
            return Reply(`⚠️ _Kirim/Balas gambar/video dengan caption *${prefix}swgc*_`);
        }

        delete global.swgcBuffer[m.sender];
        await Reply(`✅ Berhasil mengirim status ke grup: ${groupId}`);
    } catch (error) {
        console.error('[SWGC PROCESS ERROR]', error);
        Reply("❌ Gagal mengirim status ke grup.");
    }
}
break;

case "brat": {
    if (!text) return Reply("❌ Contoh penggunaan: .brat hello world");
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        const encodedText = encodeURIComponent(text);
        const apiUrl = `${global.apialip}/imagecreator/bratv?apikey=${global.apikeyalip}&text=${encodedText}`;
        
        const imageBuffer = await getBuffer(apiUrl);
        
        if (!imageBuffer || imageBuffer.length < 1000) {
            return Reply(mess.error);
        }
        
        await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
    } catch (error) {
        console.error("Error di .brat:", error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break;

case "s": case "sticker": case "stiker": {
    if (!/image|video/gi.test(mime)) 
        return Reply(example("dengan kirim media"));
    if (/video/gi.test(mime) && qmsg.seconds > 15) 
        return Reply("❌ Durasi video maksimal 15 detik!");
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    var image = await yonz.downloadAndSaveMediaMessage(qmsg);
    await yonz.sendAsSticker(m.chat, image, m, { packname: global.packname });
    await fs.unlinkSync(image);
    await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
}
break;

case "menu": {
    if (!isRegistered(m.sender) && !isCreator)
        return daftar(global.mess.verifikasi);

    const reacts = [
        '🚀',
        '✅'
    ];

    for (const emoji of reacts) {
        await yonz.sendMessage(m.chat, {
            react: { text: emoji, key: m.key }
        });

        await new Promise(r => setTimeout(r, 10));
    }

    await sendMenuVersion(getMenuStyle());

    await yonz.sendMessage(m.chat, {
        audio: { url: './media/yonz.mp3' },
        mimetype: 'audio/mp4',
        ptt: false
    });
}
break;

case 'setmenu': {
    if (!isCreator) return Reply('❌ Hanya owner bot yang bisa mengubah menu style!');
    if (!text) return Reply(`Format: ${prefix}setmenu <v1/v2/v3/v4/v5/v6/v7/v8>\nContoh: ${prefix}setmenu v2`);

    // Cari pola v1-v8 di mana pun posisinya di dalam input, biar kebal dari token tambahan/nyasar
    const rawInput = text.toLowerCase();
    const found = rawInput.match(/\bv[1-8]\b/);
    const version = found ? found[0] : '';
    if (!version) {
        return Reply(`❌ Versi tidak valid! Gunakan v1, v2, v3, v4, v5, v6, v7, atau v8\n\n_Terdeteksi input: "${text}"_`);
    }

    setMenuStyle(version);

    const names = {
        'v1': 'Interactive Message',
        'v2': 'Elaina Menu',
        'v3': 'Button Menu',
        'v4': 'Document Menu',
        'v5': 'Simple Text Menu',
        'v6': 'Product Card Menu',
        'v7': 'Simple Button Menu',
        'v8': 'Video Button Menu'
    };
    return Reply(`✅ Menu style berhasil diubah ke *${names[version]}*`);
}
break;

case "allmenu":
case "menu-ai":
case "menu-stk":
case "menu-enc":
case "menu-owner":
case "menu-maker":
case "menu-potoanime":
case "menu-shop":
case "menu-group":
case "menu-store":
case "menu-anime":
case "menu-nsfw":
case "menu-panel":
case "menu-cecan":
case "menu-islami":
case "menu-ehpoto":
case "menu-rpg":
case "menu-game":
case "menu-search":
case "menu-download":
case "menu-fun":
case "menu-tools":
case "menu-primbon":
case "menu-stickers": {

    if (!isRegistered(m.sender) && !isCreator)
        return daftar(global.mess.verifikasi);

    const reacts = ['🚀','✅️'];

    for (const emoji of reacts) {
        await yonz.sendMessage(m.chat, {
            react: { text: emoji, key: m.key }
        });
        await new Promise(r => setTimeout(r, 10));
    }

    const menus = {
        "allmenu": global.allmenu,
        "menu-ai": global.menuai,
        "menu-stk": global.menustk,
        "menu-enc": global.menuenc,
        "menu-owner": global.menuowner,
        "menu-maker": global.menumaker,
        "menu-potoanime": global.potoanime,
        "menu-shop": global.menustore,
        "menu-store": global.menustore,
        "menu-group": global.menugroup,
        "menu-anime": global.menuanime,
        "menu-nsfw": global.menunsfw,
        "menu-panel": global.menupanel,
        "menu-cecan": global.menucecan,
        "menu-islami": global.menuislam,
        "menu-ehpoto": global.menuephoto,
        "menu-rpg": global.menurpg,
        "menu-game": global.menugame,
        "menu-search": global.menusearch,
        "menu-download": global.menudownload,
        "menu-fun": global.menufun,
        "menu-tools": global.menutools,
        "menu-primbon": global.menuprimbon,
        "menu-stickers": global.menusticker
    }

    const textMenu = menus[command] || global.allmenu || "Menu tidak tersedia."

    await sendMenuVersion(getMenuStyle(), textMenu)

    await yonz.sendMessage(m.chat, {
        audio: { url: './media/yonz.mp3' },
        mimetype: 'audio/mp4',
        ptt: false
    })
}
break;



case "leave": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)
    await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
    await sleep(4000)
    await yonz.groupLeave(m.chat)
}
break

case "resetlinkgc": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    await yonz.groupRevokeInvite(m.chat)
    m.reply("Berhasil mereset link grup ✅")
}
break

case "tagall": {
    if (!m.isGroup) return Reply(mess.group)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text) return m.reply(example("pesannya"))
    let teks = text+"\n\n"
    let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
    await member.forEach((e) => {
        teks += `@${e.split("@")[0]}\n`
    })
    await yonz.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

case "linkgc": {
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    const urlGrup = "https://chat.whatsapp.com/" + await yonz.groupInviteCode(m.chat)
    var teks = `${urlGrup}`
    await yonz.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

case "ht": 
case "hidetag": {
    if (!m.isGroup) return Reply(mess.group)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text) return m.reply(example("pesannya"))
    let member = m.metadata.participants.map(v => v.id)
    await yonz.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

case "joingc": 
case "join": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return m.reply(example("linkgcnya"))
    if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
    let result = text.split('https://chat.whatsapp.com/')[1]
    let id = await yonz.groupAcceptInvite(result)
    m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

case "get": 
case "g": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return m.reply(example("https://example.com"))
    let data = await fetchJson(text)
    m.reply(JSON.stringify(data, null, 2))
}
break

case "on":
case "off": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)

    let gc = Object.keys(db.groups[m.chat])

    if (!text || isNaN(text)) {
        let teks = `\n🔥 *GROUP SETTINGS LIST*\n\n`
        gc.forEach((i, e) => {
            teks += `• *${e + 1}. ${capital(i)}* → ${db.groups[m.chat][i] ? "✅ Aktif" : "❌ Mati"}\n`
        })
        teks += `\n⚠ Cara pakai yang bener:\n   *.${command}* <nomor>\n   Contoh: *.${command} 1*\n`
        return m.reply(teks)
    }

    const num = Number(text)
    let total = gc.length
    if (num > total) return

    const event = gc[num - 1]
    global.db.groups[m.chat][event] = command === "on"

    return m.reply(`✔ *Berhasil*\nStatus *${event}* sekarang: ${command === "on" ? "⚡ AKTIF" : "🛑 NONAKTIF"}`)
}
break

case "closegc": 
case "close": 
case "opengc": 
case "open": {
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (/open|opengc/.test(command)) {
        if (m.metadata.announce == false) return 
        await yonz.groupSettingUpdate(m.chat, 'not_announcement')
    } else if (/closegc|close/.test(command)) {
        if (m.metadata.announce == true) return 
        await yonz.groupSettingUpdate(m.chat, 'announcement')
    } else {}
}
break

case "demote":
case "promote": {
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (m.quoted || text) {
        var action
        let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
        if (/demote/.test(command)) action = "Demote"
        if (/promote/.test(command)) action = "Promote"
        await yonz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
            await yonz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
        })
    } else {
        return m.reply(example("@tag/6285###"))
    }
}
break

case 'addcase': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh: .addcase *casenya*`);

    // Bersihkan kata "addcase" kalau ikut kebawa di awal text
    const cleanText = text.replace(/^addcase\s+/i, '').trim();
    if (!cleanText) return Reply(`Contoh: .addcase *casenya*`);

    const namaFile = path.join(__dirname, 'yonz-cmd.js');
    const caseBaru = `${cleanText}\n\n`;

    const tambahCase = (data, caseBaru) => {
        const posisiDefault = data.lastIndexOf("default:");
        if (posisiDefault !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
            return { success: true, kodeBaruLengkap };
        } else {
            return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
        }
    };

    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err);
            return Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
        }
        const result = tambahCase(data, caseBaru);
        if (result.success) {
            fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Terjadi kesalahan saat menulis file:', err);
                    return Reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
                } else {
                    console.log('Sukses menambahkan case baru:');
                    console.log(caseBaru);
                    return Reply('Sukses menambahkan case!');
                }
            });
        } else {
            console.error(result.message);
            return Reply(result.message);
        }
    });
}
break

case 'delcase': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh: .delcase nama_case`);

    const fs = require('fs').promises;

    async function removeCase(filePath, caseNameToRemove) {
        try {
            let data = await fs.readFile(filePath, 'utf8');
            const regex = new RegExp(`case\\s+['"\`]${caseNameToRemove}['"\`]:[\\s\\S]*?break;?`, 'g');
            
            const modifiedData = data.replace(regex, '');

            if (data === modifiedData) {
                return Reply(`❌ Case "${caseNameToRemove}" tidak ditemukan.\n\nPastikan penulisan sudah benar dan tidak ada typo.`);
            }

            await fs.writeFile(filePath, modifiedData, 'utf8');
            Reply(`✅ Sukses menghapus case: *${caseNameToRemove}*`);
        } catch (err) {
            Reply(`Terjadi kesalahan saat memproses file: ${err.message}`);
        }
    }
    removeCase(__dirname + '/yonz-cmd.js', text.trim().split(/\s+/).pop());
}
break;

case "addprem":
case "addpremium": {
    if (!isCreator) return Reply(mess.owner);
    if (!text && !m.mentionedJid.length) return Reply(`Contoh:\n${prefix}addprem 6285xxxx 30 atau ${prefix}addprem @tag 30`);
    
    let users = []
    if (m.isGroup) {
        if (m.mentionedJid.length) {
            users = m.mentionedJid.map(id => {
                if (id.endsWith('@lid')) {
                    let p = m.metadata.participants.find(x => x.id === id || x.lid === id)
                    return p ? p.jid : null
                } else {
                    return id
                }
            }).filter(Boolean)
        } else {
            users = [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net']
        }
    } else {
        users = [args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net']
    }
    
    let days = Number(args[args.length - 1])
    if (isNaN(days) || days <= 0) days = 30
    if (days > 365) return Reply('Maksimal 365 hari!')
    
    const ms = days * 24 * 60 * 60 * 1000
    const expired = Date.now() + ms
    
    for (let jid of users) {
        const user = prem.find(u => u.jid === jid)
        if (user) {
            user.expired = expired
            user.addedBy = m.sender
            user.addedAt = Date.now()
        } else {
            prem.push({ 
                jid, 
                expired,
                addedBy: m.sender,
                addedAt: Date.now()
            })
        }
    }
    
    fs.writeFileSync("./library/database/premium.json", JSON.stringify(prem, null, 2));
    Reply(`✅ Premium ${users.map(j => '@' + j.split('@')[0]).join(', ')} ditambahkan selama ${days} hari`, users);
}
break

case "listprem": {
    if (!isCreator) return Reply(mess.owner);
    
    if (prem.length < 1) return Reply("📭 Tidak ada user premium");
    
    let teks = `╭─❏ *LIST PREMIUM USER*\n`;
    const now = Date.now();
    let no = 1;
    
    for (let user of prem) {
        let jid = user.jid?.split("@")[0] || "-";
        let expired = user.expired || 0;
        let status = expired > now ? "✅ AKTIF" : "❌ EXPIRED";
        let expiredDate = new Date(expired).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
        
        teks += `│▣ ${no++}. ${jid}\n│   Status: ${status}\n│   Exp: ${expiredDate}\n│\n`;
    }
    teks += `╰──────────❏\n\n📊 *Total: ${prem.length} user*`;
    
    let mentions = prem.map(u => u.jid).filter(Boolean);
    yonz.sendMessage(m.chat, { text: teks, mentions: mentions }, { quoted: m });
}
break

case "cekprem": {
    if (!isCreator) return Reply(mess.owner);
    
    let users = [];
    if (m.isGroup) {
        if (m.mentionedJid.length) {
            users = m.mentionedJid.map(id => {
                if (id.endsWith('@lid')) {
                    let p = m.metadata.participants.find(x => x.id === id || x.lid === id);
                    return p ? p.jid : null;
                } else {
                    return id;
                }
            }).filter(Boolean);
        } else if (text) {
            users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'];
        } else {
            return Reply(example('6285xxxx / @mention'));
        }
    } else {
        if (!text) return Reply(example('6285xxxx'));
        users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'];
    }
    
    for (let jid of users) {
        const num = jid.split('@')[0];
        const user = prem.find(v => v.jid === jid);
        
        if (!user) {
            Reply(`❌ ${num} bukan premium.`);
            continue;
        }
        
        const sisa = user.expired - Date.now();
        if (sisa <= 0) {
            prem = prem.filter(v => v.jid !== jid);
            fs.writeFileSync("./library/database/premium.json", JSON.stringify(prem, null, 2));
            Reply(`⚠️ Masa premium ${num} sudah habis.`);
            continue;
        }
        
        const days = Math.floor(sisa / (1000 * 60 * 60 * 24));
        const hours = Math.floor((sisa % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        
        Reply(`✅ *Premium Aktif*\n• Nomor: ${num}\n• Sisa: ${days} hari ${hours} jam`);
    }
}
break

case "clearprem": {
    if (!isCreator) return Reply(mess.owner);
    
    const now = Date.now();
    const sebelum = prem.length;
    
    prem = prem.filter(u => u.expired > now);
    
    const sesudah = prem.length;
    const dihapus = sebelum - sesudah;
    
    fs.writeFileSync("./library/database/premium.json", JSON.stringify(prem, null, 2));
    Reply(`🧹 *Pembersihan Selesai!*\n\n📌 Total yang dihapus: *${dihapus}*\n📦 Sisa user premium aktif: *${sesudah}*`);
}
break

case "delprem": {
    if (!isCreator) return Reply(mess.owner);
    if (!text && !m.mentionedJid.length) return Reply(`Contoh:\n${prefix}delprem 6285xxxx atau ${prefix}delprem @tag`);
    
    let users = [];
    if (m.isGroup) {
        if (m.mentionedJid.length) {
            users = m.mentionedJid.map(id => {
                if (id.endsWith('@lid')) {
                    let p = m.metadata.participants.find(x => x.id === id || x.lid === id);
                    return p ? p.jid : null;
                } else {
                    return id;
                }
            }).filter(Boolean);
        } else {
            users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'];
        }
    } else {
        users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'];
    }
    
    let removed = [];
    for (let jid of users) {
        const idx = prem.findIndex(u => u.jid === jid);
        if (idx !== -1) {
            prem.splice(idx, 1);
            removed.push(jid);
        }
    }
    
    fs.writeFileSync("./library/database/premium.json", JSON.stringify(prem, null, 2));
    
    if (removed.length === 0) {
        return Reply(`❌ ${users.map(j => j.split('@')[0]).join(', ')} bukan premium.`);
    }
    
    Reply(`✅ Premium ${removed.map(j => '@' + j.split('@')[0]).join(', ')} berhasil dihapus.`, removed);
}
break

case "jpm": {
    if (!isCreator) return Reply(mess.owner)
    if (!q) return m.reply(example("teksnya"))
    let allgrup = await yonz.groupFetchAllParticipating()
    let res = await Object.keys(allgrup)
    let count = 0
    const jid = m.chat
    const teks = text
    await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
    for (let i of res) {
        if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
        try {
            await yonz.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
            count += 1
        } catch {}
        await sleep(global.delayJpm)
    }
    await yonz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break



case "self": {
    if (!isCreator) return
    yonz.public = false
    global.db.settings.isPublic = false
    m.reply("Berhasil mengganti ke mode *self*")
}
break


case "ganticase": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh pemakaian:\n${prefix}ganticase playmusik\ncase 'playmusik':\ncase 'ytmp3': {\n  ... kode baru ...\n}\nbreak;`);

    const lines = text.split('\n');
    // ambil kata terakhir di baris pertama, biar aman walau text ikut membawa nama command
    const caseName = lines[0].trim().split(/\s+/).pop();
    const newCode = lines.slice(1).join('\n').trim();

    if (!caseName) return Reply('❌ Nama case tidak boleh kosong');
    if (!newCode) return Reply('❌ Kode baru tidak boleh kosong (baris ke-2 dst harus diisi kode penggantinya)');

    try {
        const filePath = __dirname + '/yonz-cmd.js';
        let fileContent = fs.readFileSync(filePath, 'utf8');

        const caseRegex = new RegExp(`case\\s+['"\`]${caseName}['"\`]\\s*:[\\s\\S]*?\\n\\s*break;?`);

        if (!caseRegex.test(fileContent)) {
            return Reply(`❌ Case '${caseName}' tidak ditemukan di file`);
        }

        const backupPath = filePath + `.backup-${Date.now()}`;
        fs.writeFileSync(backupPath, fileContent, 'utf8');

        fileContent = fileContent.replace(caseRegex, newCode);
        fs.writeFileSync(filePath, fileContent, 'utf8');

        await Reply(`✅ Case '${caseName}' berhasil diganti.\n📦 Backup disimpan: ${require('path').basename(backupPath)}\n⚠️ Restart bot agar perubahan diterapkan.`);

    } catch (e) {
        console.error('[GANTICASE ERROR]', e);
        Reply('❌ Gagal mengganti case: ' + e.message);
    }
}
break

case "ping":
case "uptime": {
 const timestamp = performance.now();

 const disk = await nou.drive.info();
 const latensi = performance.now() - timestamp;

 const cpu = os.cpus();
 const cpuModel = cpu[0].model;
 const cpuCount = cpu.length;
 const cpuSpeed = (cpu[0].speed / 1000).toFixed(2);

 const platform = nou.os.type();

 const ramTotal = formatp(os.totalmem());
 const ramUsed = formatp(os.totalmem() - os.freemem());
 const ramUsage = ((1 - os.freemem() / os.totalmem()) * 100).toFixed(1);

 const diskUsage = ((disk.usedGb / disk.totalGb) * 100).toFixed(1);

 const now = moment().tz('Asia/Jakarta');
 const tanggal = now.format('dddd, DD MMMM YYYY');
 const jam = now.format('HH:mm:ss');

 const userName = m.pushName || 'User';
 const isPremiumUser = global.isPrem(m.sender);
 const isOwnerUser = isCreator || areJidsSameUser(global.owner + '@s.whatsapp.net', m.sender);
 let userStatus = '👤 Free User';
 if (isOwnerUser) userStatus = '👑 Owner';
 else if (isPremiumUser) userStatus = '💎 Premium';

 let teks = `╼ ׅ ֹ𔖰᷼𔖮 *${global.botname.toUpperCase()} SERVER* 🚀
╭╼─┈───┈──⏣╼
┆𖢷 *User* : ${userName}
┆𖢷 *Status* : ${userStatus}
┆𖢷 *Tanggal* : ${tanggal}
┆𖢷 *Jam* : ${jam} WIB
┆𖢷 *Platform* : ${platform}
╰─╼𔕬─┈───┈───┈

╼ ׅ ֹ𔖰᷼𔖮 *PERFORMA SISTEM*
╭╼─┈───┈──⏣╼
┆𖹭 *CPU* : ${cpuModel}
┆𖹭 *Core* : ${cpuCount} Core @ ${cpuSpeed}GHz
┆𖹭 *Response* : ${Math.round(latensi)} ms
┆𖹭 *RAM* : ${ramUsed} / ${ramTotal} (${ramUsage}%)
┆𖹭 *Disk* : ${disk.usedGb} / ${disk.totalGb} GB (${diskUsage}%)
╰─╼𔕬─┈───┈───┈

╼ ׅ ֹ𔖰᷼𔖮 *UPTIME*
╭╼─┈───┈──⏣╼
┆𖹭 *Server* : ${runtime(os.uptime())}
┆𖹭 *Bot* : ${runtime(process.uptime())}
╰─╼𔕬─┈───┈───┈`;

 const btn = new yonz.ButtonV2(yonz);
 btn.setBody(teks)
 .setFooter(`╼ ׅ ֹ𔖰᷼𔖮  ${global.botname} • ${new Date().getFullYear()}`)
 .setThumbnail(global.image.menu)
 .addRawButton({
 buttonText: { displayText: '╼ ׅ ֹ𔖰᷼𔖮 ᴍᴇɴᴜ' },
 buttonId: '╼ ׅ ֹ𔖰᷼𔖮 ʀɴᴢᴅᴢʏ',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '╼ ׅ ֹ𔖰᷼𔖮 ɴᴀᴠɪɢᴀᴛɪᴏɴ',
 sections: [
 {
 title: '╼ ׅ ֹ𔖰᷼𔖮 ᴍᴇɴᴜ ᴜᴛᴀᴍᴀ',
 rows: [
 { title: '╼ ׅ ֹ𔖰᷼𔖮 ᴀʟʟᴍᴇɴᴜ', description: 'Lihat semua perintah bot', id: `${prefix}allmenu` },
 { title: '╼ ׅ ֹ𔖰᷼𔖮 ᴍᴇɴᴜ', description: 'Kembali ke menu utama', id: `${prefix}menu` }
 ]
 },
 {
 title: '╼ ׅ ֹ𔖰᷼𔖮 ʀᴇғʀᴇsʜ ᴘɪɴɢ',
 rows: [
 { title: '╼ ׅ ֹ𔖰᷼𔖮 ʀᴇғʀᴇsʜ', description: 'Perbarui status server', id: `${prefix}ping` }
 ]
 }
 ]
 })
 }
 });

 await btn.send(m.chat);
}
break;

case "public": {
    if (!isCreator) return
    yonz.public = true
    global.db.settings.isPublic = true
    m.reply("Berhasil mengganti ke mode *public*")
}
break



case "resetdb": 
case "rstdb": {
    if (!isCreator) return Reply(mess.owner)
    for (let i of Object.keys(global.db)) {
        global.db[i] = {}
    }
    m.reply("Berhasil mereset database ✅")
}
break

case "setppbot": {
    if (!isCreator) return Reply(mess.owner)
    if (/image/g.test(mime)) {
        var medis = await yonz.downloadAndSaveMediaMessage(qmsg)
        if (args[0] && args[0] == "panjang") {
            const { img } = await generateProfilePicture(medis)
            await yonz.query({
                tag: 'iq',
                attrs: {
                    to: botNumber,
                    type:'set',
                    xmlns: 'w:profile:picture'
                },
                content: [
                    {
                        tag: 'picture',
                        attrs: { type: 'image' },
                        content: img
                    }
                ]
            })
            await fs.unlinkSync(medis)
            m.reply("Berhasil mengganti foto profil bot ✅")
        } else {
            await yonz.updateProfilePicture(botNumber, {content: medis})
            await fs.unlinkSync(medis)
            m.reply("Berhasil mengganti foto profil bot ✅")
        }
    } else return m.reply(example('dengan mengirim foto'))
}
break

case "clearchat": 
case "clc": {
    if (!isCreator) return Reply(mess.owner)
    yonz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

case "listowner": 
case "listown": {
    if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
    let teks = `\n *乂 List all owner tambahan*\n`
    for (let i of owners) {
        teks += `\n* ${i.split("@")[0]}\n* *Tag :* @${i.split("@")[0]}\n`
    }
    yonz.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

case "delowner": 
case "delown": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.quoted && !text) return m.reply(example("6285###"))
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    const input2 = input.split("@")[0]
    if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
    if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
    let posi = owners.indexOf(input)
    await owners.splice(posi, 1)
    await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
    m.reply(`Berhasil menghapus owner ✅`)
}
break

case "addowner": 
case "addown": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.quoted && !text) return m.reply(example("6285###"))
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    const input2 = input.split("@")[0]
    if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
    owners.push(input)
    await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
    m.reply(`Berhasil menambah owner ✅`)
}
break

case 'addcase': {
    if (!isOwner) return Reply('❌ Hanya owner!')

    const fs = require('fs')
    const path = require('path')

    const namaFile = path.join(__dirname, 'yonz-cmd.js')

    let caseBaru = ''

    if (m.quoted) {

        caseBaru =
            m.quoted.text ||
            m.quoted.caption ||
            m.quoted.description ||
            ''

    }

    if (!caseBaru && text) {
        caseBaru = text
    }

    if (!caseBaru) {
        return Reply(`
Contoh penggunaan:

1. Manual
.addcase case 'test': {
 Reply('ok')
}
break

2. Reply pesan case lalu ketik
.addcase
`)
    }

    caseBaru = caseBaru.trim() + '\n\n'

    const tambahCase = (data, caseBaru) => {

        const posisiDefault = data.lastIndexOf('default:')

        if (posisiDefault === -1) {
            return {
                success: false,
                message: 'Tidak menemukan default:'
            }
        }

        const kodeBaruLengkap =
            data.slice(0, posisiDefault) +
            caseBaru +
            data.slice(posisiDefault)

        return {
            success: true,
            kodeBaruLengkap
        }
    }

    fs.readFile(namaFile, 'utf8', (err, data) => {

        if (err) {
            console.error(err)
            return Reply(`❌ Error membaca file\n${err.message}`)
        }

        const result = tambahCase(data, caseBaru)

        if (!result.success) {
            return Reply(result.message)
        }

        fs.writeFile(
            namaFile,
            result.kodeBaruLengkap,
            'utf8',
            (err) => {

                if (err) {
                    console.error(err)
                    return Reply(`❌ Error menulis file\n${err.message}`)
                }

                console.log('[ ADDCASE ] sukses')
                console.log(caseBaru)

                Reply('✅ Sukses menambahkan case baru')
            }
        )
    })
}
break

case 'delcase': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) 
        return Reply(`Contoh: .delcase nama_case`);

    const fs = require('fs').promises;

    async function removeCase(filePath, caseNameToRemove) {
        try {
            let data = await fs.readFile(filePath, 'utf8');
            
            const regex = new RegExp(`case\\s+['"\`]${caseNameToRemove}['"\`]:[\\s\\S]*?break;?`, 'g');
            
            const modifiedData = data.replace(regex, '');

            if (data === modifiedData) {
                return Reply(`❌ Case "${caseNameToRemove}" tidak ditemukan.\n\nPastikan penulisan sudah benar dan tidak ada typo.`);
            }

            await fs.writeFile(filePath, modifiedData, 'utf8');
            Reply(`✅ Sukses menghapus case: *${caseNameToRemove}*`);
        } catch (err) {
            Reply(`Terjadi kesalahan saat memproses file: ${err.message}`);
        }
    }

    removeCase('./yonz-cmd.js', text.trim());
}
break;

case "play": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (!text) return Reply(example("melukis senja"));

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

 try {
 const ytsSearch = await yts(text);
 const videos = ytsSearch.videos.slice(0, 10);

 if (!videos.length) return Reply(`❌ Lagu "${text}" tidak ditemukan`);

 const video = videos[0];

 const laguList = videos.map((v, i) => ({
 title: v.title.length > 35 ? v.title.substring(0, 35) + '...' : v.title,
 duration: v.timestamp || 'Unknown',
 popularity: v.views ? v.views.toLocaleString() + ' views' : 'Unknown',
 url: v.url
 }));

 const caption = `╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Channel : ${video.author?.name || 'Unknown'}
┆𖢷 ׁ 𖹭₊ Durasi : ${video.timestamp || '-'}
┆𖢷 ׁ 𖹭₊ Views : ${video.views || '-'}
┆𖢷 ׁ 𖹭₊ Upload : ${video.ago || 'Unknown'}
╰─╼𔕬─┈───┈───┈`;

 await yonz.sendMessage(m.chat, {
 image: { url: video.thumbnail },
 caption: caption,
 footer: `*${global.botname}*`,
 buttons: [
 {
 buttonId: 'youtubePilih',
 buttonText: { displayText: 'Pilih Lagu' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'Hasil Pencarian YouTube',
 sections: [
 {
 title: 'Daftar Video',
 rows: laguList.map((lagu, i) => ({
 title: `${i + 1}. ${lagu.title}`,
 description: `Durasi: ${lagu.duration} | Views: ${lagu.popularity}`,
 id: `${prefix}playmusik ${lagu.url}`
 }))
 }
 ]
 })
 }
 }
 ],
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 }
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error('[PLAY ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break





case "kick":
case "kik": {
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 if (!m.isBotAdmin) return Reply(mess.botAdmin);
 let users = []
 if (m.isGroup) {
 if (m.mentionedJid.length) {
 users = m.mentionedJid.map(id => {
 if (id.endsWith('@lid')) {
 let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
 return p ? p.jid : null
 } else {
 return id
 }
 }).filter(Boolean)
 } else if (m.quoted) {
 users = [m.quoted.sender]
 } else if (text) {
 users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net']
 }
 }

 if (!users.length) return Reply(`❌ *Tag, reply, atau tulis nomor yang mau dikick!*\n\nContoh:\n${prefix}kick @tag\n${prefix}kick 628xxxx\n${prefix}kick (reply pesan orang)`);
 for (let user of users) {
 let onWa = await yonz.onWhatsApp(user.split("@")[0])
 if (!onWa?.length) {
 Reply(`⚠️ Nomor *${user.split("@")[0]}* tidak terdaftar di WhatsApp!`)
 continue
 }
 try {
 await yonz.groupParticipantsUpdate(m.chat, [user], 'remove')
 await sleep(800)
 await Reply(`✅ Berhasil mengeluarkan *@${user.split('@')[0]}*`, { mentions: [user] })
 } catch (e) {
 Reply(`❌ Gagal mengeluarkan *@${user.split('@')[0]}*`, { mentions: [user] })
 }
 }
}
break;

















case "addsticker": {
 if (!isCreator) return Reply(mess.creator);
 if (!m.quoted) return Reply("❌ Reply stiker yang ingin disimpan!");
 if (!text) return Reply(`Contoh:\n${prefix + command} bot`);

 const fs = require("fs");
 const path = require("path");

 // Hilangkan nama command dari text
 const name = text
 .replace(new RegExp(`^${command}\\s*`, "i"), "")
 .trim()
 .replace(/[^a-zA-Z0-9_-]/g, "");

 if (!name) return Reply("❌ Masukkan nama stiker!");

 const folder = "./source/media/sticker";

 if (!fs.existsSync(folder)) {
 fs.mkdirSync(folder, { recursive: true });
 }

 const filePath = path.join(folder, `${name}.webp`);

 try {
 const buffer = await m.quoted.download();

 if (!buffer) return Reply("❌ Gagal mengambil stiker!");

 fs.writeFileSync(filePath, buffer);

 Reply(`✅ Berhasil menyimpan stiker!

📁 File: ${name}.webp
📂 Lokasi: source/media/sticker/${name}.webp`);
 } catch (err) {
 console.error(err);
 Reply(`❌ Terjadi kesalahan:\n${err.message}`);
 }
}
break;







case "owner": {
 const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${global.namaOwner}
ORG:${global.botname2} Official
TEL;type=CELL;waid=${global.owner}:${global.owner}
EMAIL:developer@${global.botname2.toLowerCase().replace(/\s+/g,'')}.com
URL:${global.linkSaluran}
END:VCARD`;

 await yonz.sendMessage(m.chat, {
 contacts: {
 displayName: global.namaOwner,
 contacts: [{ vcard }]
 }
 }, { quoted: m });
}
break;



case "sch":
case "sendch":
case "kirmch": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require("fs");
 const path = require("path");
 const { exec } = require("child_process");
 const { promisify } = require("util");
 const execPromise = promisify(exec);

 try {
 const args = text.trim().split(/\s+/);
 const CH_LINK = args[0];
 const caption = args.slice(1).join(" ");

 const linkRegex = /https:\/\/whatsapp\.com\/channel\/([\w\-]+)/i;
 const match = CH_LINK ? CH_LINK.match(linkRegex) : null;

 if (!match) {
 return Reply(
`╭─➤ 𝗨𝗽𝗹𝗼𝗮𝗱 𝗖𝗵𝗮𝗻𝗻𝗲𝗹
│ Format : ${prefix + command} link_saluran teks
│ Contoh : ${prefix + command} https://whatsapp.com/channel/xxx Halo
╰──────────➤`
 );
 }

 const inviteCode = match[1];

 await yonz.sendMessage(m.chat, {
 react: { text: "⏳", key: m.key }
 });

 let CH_ID = null;

 // === FIX: amanin metadata channel ===
 try {
 if (typeof yonz.newsletterMetadata === "function") {
 const meta = await yonz.newsletterMetadata("invite", inviteCode);
 CH_ID = meta?.id;
 } else {
 throw new Error("newsletterMetadata not supported");
 }
 } catch (errMeta) {
 console.log("[SCH META ERROR]", errMeta);

 await yonz.sendMessage(m.chat, {
 react: { text: "❌", key: m.key }
 });

 return Reply(
`❌ Gagal ambil info channel.

Kemungkinan:
• Bot belum join channel
• Link invite tidak valid
• Fitur newsletterMetadata tidak support di versi Baileys kamu`
 );
 }

 if (!CH_ID) {
 return Reply("❌ Channel ID tidak ditemukan.");
 }

 const qmsg = m.quoted ? m.quoted : m;
 const mime = (qmsg.msg || qmsg).mimetype || "";

 // === TEXT ===
 if (!mime) {
 if (!caption) {
 return Reply("❌ Masukkan teks atau reply media.");
 }

 await yonz.sendMessage(CH_ID, { text: caption });

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Teks berhasil dikirim ke saluran");
 }

 const media = await qmsg.download();

 if (!media) {
 return Reply("❌ Gagal download media.");
 }

 // === IMAGE ===
 if (/image/.test(mime)) {
 await yonz.sendMessage(CH_ID, {
 image: media,
 caption: caption || ""
 });

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Foto berhasil dikirim ke saluran");
 }

 // === VIDEO ===
 if (/video/.test(mime)) {
 await yonz.sendMessage(CH_ID, {
 video: media,
 caption: caption || ""
 });

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Video berhasil dikirim ke saluran");
 }

 // === AUDIO ===
 if (/audio/.test(mime)) {
 const tmpDir = path.join(__dirname, "tmp");
 if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

 const fileName = Date.now();
 const inputPath = path.join(tmpDir, `audio_${fileName}`);
 const outputPath = path.join(tmpDir, `audio_${fileName}.opus`);

 fs.writeFileSync(inputPath, media);

 try {
 await execPromise(
 `ffmpeg -i "${inputPath}" -c:a libopus -b:a 32k -ar 48000 -ac 1 "${outputPath}" -y`
 );

 const buffer = fs.readFileSync(outputPath);

 if (caption) {
 await yonz.sendMessage(CH_ID, { text: caption });
 }

await yonz.sendMessage(CH_ID, {
  audio: buffer,
  mimetype: "audio/ogg; codecs=opus",
  ptt: true
});

 fs.unlinkSync(inputPath);
 fs.unlinkSync(outputPath);

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Audio berhasil dikirim ke saluran");

 } catch (err) {
 console.log("[AUDIO ERROR]", err);

 if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
 if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);

 return Reply("❌ Gagal proses audio ffmpeg");
 }
 }

 return Reply("❌ Format tidak didukung");

 } catch (e) {
 console.log("[SCH ERROR]", e);

 await yonz.sendMessage(m.chat, {
 react: { text: "❌", key: m.key }
 });

 return Reply("❌ Terjadi kesalahan saat kirim ke saluran");
 }
}
break;

case "rvo": case "readviewonce": {
if (!isRegistered(m.sender) && !isCreator)
 return Reply(global.mess.verifikasi);
if (!global.isPrem(m.sender) && !isCreator) 
 return Reply(mess.prem);
if (!m.quoted) return Reply(example("dengan reply pesannya"))
let msg = m.quoted.message
 let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return Reply("Pesan itu bukan viewonce!")
 let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }
 if (/video/.test(type)) {
 return yonz.sendMessage(m.chat, {video: buffer, caption: mess.done}, {quoted: m})
} else if (/image/.test(type)) {
 return yonz.sendMessage(m.chat, {image: buffer, caption: mess.done}, {quoted: m})
} else if (/audio/.test(type)) {
 return yonz.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: false}, {quoted: m})
 } 
}
break











case 'totalfitur': {
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 const fs = require('fs');
 const path = require('path');

 const caseFile = path.join(__dirname, './yonz-cmd.js');
 const pluginsDir = path.join(__dirname, './plugins');

 let totalCase = 0;
 let totalPlugin = 0;

 if (fs.existsSync(caseFile)) {
 const content = fs.readFileSync(caseFile, 'utf8');
 totalCase = (content.match(/case\s+['"`]/g) || []).length;
 }

 const countJsFiles = (dir) => {
 let count = 0;
 const files = fs.readdirSync(dir);
 for (const file of files) {
 const fullPath = path.join(dir, file);
 if (fs.statSync(fullPath).isDirectory()) {
 count += countJsFiles(fullPath);
 } else if (file.endsWith('.js')) {
 count++;
 }
 }
 return count;
 };

 if (fs.existsSync(pluginsDir)) {
 totalPlugin = countJsFiles(pluginsDir);
 }

 const totalFitur = totalCase + totalPlugin;
 const kanjiIcon = '╼ ׅ ֹ𔖰᷼𔖮';

 const bodyText =
`${kanjiIcon} *TOTAL FITUR ${global.botname2}*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ CASE : *${totalCase}*
┆𖢷 ׁ 𖹭₊ PLUGIN : *${totalPlugin}*
┆𖢷 ׁ 𖹭₊ TOTAL : *${totalFitur} Fitur*
╰─╼𔕬─┈───┈───┈`;

 try {
 const btnTotal = new yonz.ButtonV2(yonz);
 btnTotal.setBody(bodyText)
 .setFooter(`*Powered by ${global.namaOwner}*`)
 .setThumbnail(global.image.menu)
 .addRawButton({
 buttonText: { displayText: `📋 MENU` },
 buttonId: '.menu',
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: `👑 OWNER` },
 buttonId: 'totalfitur_owner',
 type: 1,
 nativeFlowInfo: {
 name: 'cta_url',
 paramsJson: JSON.stringify({
 display_text: '👑 Owner',
 url: global.linkOwner
 })
 }
 });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 await btnTotal.send(m.chat);
 } catch (err) {
 console.log('totalfitur buttonv2 error', err);
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(bodyText);
 }
}
break;

case "restart":
case "rst": {
if (!isCreator) return Reply(mess.owner)
await Reply("Memproses _restart server_ . . .")

try {
 var file = await fs.readdirSync("./session")
 var anu = await file.filter(i => i !== "creds.json")
 for (let t of anu) {
 try {
 await fs.unlinkSync(`./session/${t}`)
 } catch {}
 }
 
 if (typeof process.send === 'function') {
 await process.send('reset')
 } else {
 await Reply("✅ Session dibersihkan! Bot restart...")
 setTimeout(() => {
 process.exit(1)
 }, 2000)
 }
 
} catch (e) {
 await Reply(`❌ Error: ${e.message}`)
}
}
break


case 'getcase': {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(`Contoh: .getcase nama_case`);

 const cleanText = text.replace(/^getcase\s+/i, '').trim();
 if (!cleanText) return Reply(`Contoh: .getcase nama_case`);

 const fs = require('fs').promises;

 async function getCase(filePath, caseName) {
 try {
 let data = await fs.readFile(filePath, 'utf8');

 const regex = new RegExp(`case\\s+['"\`]${caseName}['"\`]:[\\s\\S]*?break;?`, 'i');
 const match = data.match(regex);

 if (!match) {
 return Reply(`❌ Case "${caseName}" tidak ditemukan.`);
 }

 const caseCode = match[0];

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `📋 *Case ${caseName}* berhasil ditemukan. Klik tombol di bawah untuk menyalin.`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by ${global.namaOwner}`
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: true,
 imageMessage: (await prepareWAMessageMedia(
 { image: { url: global.image.menu } },
 { upload: yonz.waUploadToServer }
 )).imageMessage
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: "Salin Case",
 copy_code: caseCode
 })
 }
 ]
 })
 })
 }
 }
 }, {});

 await yonz.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

 } catch (err) {
 Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
 }
 }

 getCase(path.join(__dirname, 'yonz-cmd.js'), cleanText);
}
break;



case 'addfile':
case 'upload':
case 'uploadfile':
case 'upfile': {
 if (!isOwner) return Reply(mess.creator);
 if (!m.quoted) return Reply(`📌 reply file yang mau di upload terus ketik foldernya`)
 if (!text) return Reply(`📌 contoh nya: *${prefix + command} library/database*\nketik ${prefix + command} *.* atau *root* buat upload ke folder utama`)
 try {
 const type = m.quoted.mtype || Object.keys(m.quoted.message || {})[0] || ''
 const msg = m.quoted.message?.[type] || m.quoted.msg || m.quoted
 let downloadType = 'document'
 let ext = '.bin'
 let [inputFolder, inputName] = text.split(' ')
 const folderTarget = inputFolder.trim()

 if (/image/i.test(type)) {
 downloadType = 'image'
 ext = '.jpg'
 if (inputName && !/\.(jpg|jpeg|png)$/i.test(inputName)) return Reply(`media ini jenis gambar, format harus .jpg/.jpeg/.png`)
 } else if (/video/i.test(type)) {
 downloadType = 'video'
 ext = '.mp4'
 if (inputName && !/\.(mp4)$/i.test(inputName)) return Reply(`media ini jenis video, format harus .mp4`)
 } else if (/audio/i.test(type)) {
 downloadType = 'audio'
 ext = '.mp3'
 if (inputName && !/\.(mp3|opus)$/i.test(inputName)) return Reply(`media ini jenis audio, format harus .mp3/.opus`)
 } else if (/document/i.test(type)) {
 downloadType = 'document'
 } else {
 return Reply(`❌ yang kamu reply harus type dokumen, gambar, audio, video`)
 }

 const fileName = inputName ? inputName : (msg.fileName || `upload_${Date.now()}${ext}`)
 const targetDir = (folderTarget === '.' || folderTarget === 'root') ? process.cwd() : path.join(process.cwd(), folderTarget)
 const fullPath = path.join(targetDir, fileName)

 if (!fs.existsSync(targetDir)) {
 fs.mkdirSync(targetDir, { recursive: true })
 }

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

 const stream = await downloadContentFromMessage(msg, downloadType)
 let buffer = Buffer.from([])
 for await (const chunk of stream) {
 buffer = Buffer.concat([buffer, chunk])
 }
 fs.writeFileSync(fullPath, buffer)

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

 Reply(`🚀 *Media Berhasil Di Upload*\n\n📁 *Folder:* ${folderTarget === '.' || folderTarget === 'root' ? 'Root (Utama)' : folderTarget}\n📄 *Nama:* ${fileName}\n📍 *Full Path:* ${fullPath}`)
 } catch (err) {
 console.error(err)
 Reply(`❌ gagal upload: ${err.message}`)
 }
}
break







case 'tiktok':
case 'tt':
 if (!text) return Reply(`Contoh: ${prefix + command} https://vt.tiktok.com/xxxxx`)
 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const data = await autoDownloadAIO(text)

 if (!data || !data.video) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil data, cek kembali link TikTok kamu.')
 }

 await yonz.sendMessage(m.chat, {
 video: { url: data.video },
 caption: `*TikTok Downloader*\n\n${data.title}`
 }, { quoted: m })

 if (data.audio) {
 await yonz.sendMessage(m.chat, {
 audio: { url: data.audio },
 mimetype: 'audio/mpeg',
 fileName: 'audio.mp3'
 }, { quoted: m })
 }

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break


case 'nova':
case 'ai':
 if (!text) return Reply(`Contoh: ${prefix + command} Halo, apa kabar?`)
 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/ai/nova?text=${encodeURIComponent(text)}&apikey=Yonz`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mendapatkan respon dari AI.')
 }

 Reply(json.result)
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break


case 'dana':
case 'fakedana': {
 if (!text) return Reply(`Contoh: ${prefix + command} 10000`)

 const saldo = text.replace(/[.,]/g, '')
 if (isNaN(saldo)) return Reply('Saldo harus berupa angka.')

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/canvas/dana?saldo=${saldo}&apikey=Yonz`

 await yonz.sendMessage(m.chat, {
 image: { url: apiUrl },
 caption: `💰 Saldo Dana: Rp${parseInt(saldo).toLocaleString('id-ID')}`
 }, { quoted: m })

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'asahotak':
case 'asotak': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/asahotak`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban } = json.result

 global.game[m.chat] = {
 type: 'single',
 soal,
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 penanya: m.sender,
 waktu: 60000
 }

 await Reply(`🧠 *ASAH OTAK*\n\n${soal}\n\n⏱️ Waktu: 60 detik\nJawab dengan mengetik jawabannya langsung.\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'tebakgambar':
case 'tebakgbr': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/tebakgambar`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { img, jawaban, deskripsi } = json.result

 global.game[m.chat] = {
 type: 'single',
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 deskripsi,
 penanya: m.sender,
 waktu: 60000
 }

 await yonz.sendMessage(m.chat, {
 image: { url: img },
 caption: `🖼️ *TEBAK GAMBAR*\n\nTebak gambar di atas!\n⏱️ Waktu: 60 detik\nMenyerah? Ketik *.nyerah*`
 }, { quoted: m })

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*${deskripsi ? `\nKeterangan: ${deskripsi}` : ''}` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'lengkapikalimat':
case 'lengkapi': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/lengkapikalimat`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban } = json.result

 global.game[m.chat] = {
 type: 'single',
 soal,
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 penanya: m.sender,
 waktu: 60000
 }

 await Reply(`✏️ *LENGKAPI KALIMAT*\n\n${soal}\n\n⏱️ Waktu: 60 detik\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'caklontong':
case 'cak': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/caklontong`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban, deskripsi } = json.result

 global.game[m.chat] = {
 type: 'single',
 soal,
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 deskripsi,
 penanya: m.sender,
 waktu: 60000
 }

 await Reply(`🤔 *CAK LONTONG*\n\n${soal}\n\n⏱️ Waktu: 60 detik\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*${deskripsi ? `\nKeterangan: ${deskripsi}` : ''}` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'family100':
case 'f100': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/family100`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban } = json.result
 const daftarJawaban = Array.isArray(jawaban) ? jawaban : [jawaban]

 global.game[m.chat] = {
 type: 'family100',
 soal,
 jawabanList: daftarJawaban.map(j => String(j).toLowerCase()),
 jawabanAsli: daftarJawaban,
 found: [],
 penanya: m.sender,
 waktu: 90000
 }

 await Reply(`👨‍👩‍👧‍👦 *FAMILY 100*\n\n${soal}\n\nAda *${daftarJawaban.length}* jawaban, sebutkan satu-satu!\n⏱️ Waktu: 90 detik\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 const sisa = global.game[m.chat].jawabanAsli.filter((_, i) => !global.game[m.chat].found.includes(i))
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis!\nJawaban yang belum ketebak:\n${sisa.map(j => `• ${j}`).join('\n')}` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'nyerah':
case 'give': {
 if (!global.game || !global.game[m.chat]) return Reply('Gak ada soal yang lagi aktif di chat ini.')

 const dataGame = global.game[m.chat]
 clearTimeout(dataGame.timeout)

 if (dataGame.type === 'family100') {
 const sisa = dataGame.jawabanAsli.filter((_, i) => !dataGame.found.includes(i))
 await Reply(`🏳️ Nyerah!\nJawaban yang belum ketebak:\n${sisa.map(j => `• ${j}`).join('\n')}`)
 } else {
 await Reply(`🏳️ Nyerah! Jawaban yang benar adalah *${dataGame.jawabanAsli}*${dataGame.deskripsi ? `\nKeterangan: ${dataGame.deskripsi}` : ''}`)
 }

 delete global.game[m.chat]
 break
}



case "h":
case "totag":
case "hidetag": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess?.verifikasi);
 if (checkLimit(m.sender, global.isPrem?.(m.sender), isCreator)) return Reply(global.mess?.limit || "Limit habis.");
 addLimit(m.sender, global.isPrem?.(m.sender), isCreator);
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);

 const members = m.metadata.participants.map(v => v.id);

 const cleanText = (input) => {
 if (!input) return '';
 let txt = input.trim();
 const regex = new RegExp(`^\\${prefix}(h|ht|hidetag)\\s*`, 'i');
 return txt.replace(regex, '').trim();
 };

 let mediaBuffer = null;
 let mimeType = '';
 let captionText = '';
 let fileName = 'file';

 if (m.message?.imageMessage) {
 try {
 const mediaStream = await downloadContentFromMessage(m.message.imageMessage, 'image');
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = m.message.imageMessage.mimetype;
 captionText = cleanText(m.message.imageMessage.caption || text || '');
 } catch (e) {}
 } else if (m.message?.videoMessage) {
 try {
 const mediaStream = await downloadContentFromMessage(m.message.videoMessage, 'video');
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = m.message.videoMessage.mimetype;
 captionText = cleanText(m.message.videoMessage.caption || text || '');
 } catch (e) {}
 } else if (m.message?.documentMessage || m.message?.documentWithCaptionMessage) {
 try {
 let docMsg = m.message.documentMessage || m.message.documentWithCaptionMessage?.message?.documentMessage;
 const mediaStream = await downloadContentFromMessage(docMsg, 'document');
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = docMsg.mimetype;
 fileName = docMsg.fileName || 'document';
 captionText = cleanText(docMsg.caption || text || '');
 } catch (e) {}
 }

 const quoted = m.quoted;
 if (quoted) {
 const quotedMsg = quoted.msg || quoted;
 const quotedMime = quotedMsg.mimetype || '';
 if (quotedMime) {
 let mediaType = 'document';
 if (quotedMime.includes('image')) mediaType = 'image';
 else if (quotedMime.includes('video')) mediaType = 'video';
 try {
 const mediaStream = await downloadContentFromMessage(quotedMsg, mediaType);
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = quotedMime;
 fileName = quotedMsg.fileName || 'file';
 captionText = cleanText(quotedMsg.caption || quoted.text || text || '');
 } catch (e) {}
 } else if (quoted.text) {
 captionText = cleanText(quoted.text || text || '');
 }
 }

 if (!captionText && !mediaBuffer) {
 captionText = cleanText(text || '');
 }

 if (mediaBuffer) {
 let messageOptions = {
 caption: captionText,
 mentions: members
 };
 if (mimeType.includes('image')) {
 messageOptions.image = mediaBuffer;
 } else if (mimeType.includes('video')) {
 messageOptions.video = mediaBuffer;
 } else {
 messageOptions.document = mediaBuffer;
 messageOptions.mimetype = mimeType;
 messageOptions.fileName = fileName;
 }
 await yonz.sendMessage(m.chat, messageOptions, { quoted: m });
 } else if (captionText) {
 await yonz.sendMessage(m.chat, {
 text: captionText,
 mentions: members
 }, { quoted: m });
 } else {
 return Reply("📌 masukkan teks, atau kirim/reply ke pesan/foto/video/dokumen yang ingin di-hidetag");
 }
}
break;

case "tqto": 
case "listbuyer": {
 await yonz.sendMessage(m.chat, {
 react: {
 text: "🌸",
 key: m.key
 }
 })

 const fs = require("fs")
 const tqtoPath = "./library/database/tqto.json"

 if (!fs.existsSync(tqtoPath)) {
 fs.writeFileSync(tqtoPath, JSON.stringify([]))
 }

 let tqtoData = JSON.parse(fs.readFileSync(tqtoPath))

 const developerData = {
 name: "Yonz Official",
 role: "Developer",
 number: "6285174301390"
 }

 const allData = [
 developerData,
 ...tqtoData.filter(v => v.number !== developerData.number)
 ]

 const {
 proto,
 prepareWAMessageMedia,
 generateWAMessageFromContent
 } = require("@whiskeysockets/baileys")

 const cards = []

 for (const x of allData) {
 let profileUrl = global.image.menu

 try {
 const pp = await yonz.profilePictureUrl(
 `${x.number}@s.whatsapp.net`,
 "image"
 ).catch(() => null)

 if (pp) profileUrl = pp
 } catch {}

 let titleText = `
╭╼─┈───┈──⏣
┆ 〔 ${global.botname} 〕
╰╼─┈───┈──⏣

╰ Nama : ${x.name}
╰ Posisi : ${x.role}

╭╼─┈───┈──⏣
┆ Powered By ${global.namaOwner}
┆ memiliki hak Resmi untuk menjual script √
╰╼─┈───┈──⏣
`.trim()

 cards.push({
 header: await prepareWAMessageMedia(
 {
 image: { url: profileUrl }
 },
 {
 upload: yonz.waUploadToServer
 }
 ),
 title: titleText,
 number: x.number
 })
 }

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "‎"
 }),

 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: cards.map(card => ({
 body: proto.Message.InteractiveMessage.Body.fromObject({}),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({}),

 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: card.title,
 hasMediaAttachment: true,
 ...card.header
 }),

 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: "Contact User",
 url: `https://wa.me/${card.number}`,
 merchant_url: `https://wa.me/${card.number}`
 })
 }
 ]
 })
 }))
 })
 })
 }
 }
 },
 {
 quoted: m,
 userJid: m.sender
 }
 )

 await yonz.relayMessage(
 m.chat,
 msg.message,
 {
 messageId: msg.key.id
 }
 )
}
break





addmenu











case 'addmenu':
case 'addfiturmenu':
case 'addfitur':
case 'delmenu':
case 'delfiturmenu':
case 'delfitur': {
 if (!isOwner) return Reply(mess.creator);

 let isDelete = ['delmenu', 'delfiturmenu', 'delfitur'].includes(command.toLowerCase())
 let cmdAliases = ['addmenu', 'addfiturmenu', 'addfitur', 'delmenu', 'delfiturmenu', 'delfitur']

 let cleanText = text ? text.trim() : ''
 let firstWord = cleanText.split(' ')[0]?.toLowerCase()
 if (cmdAliases.includes(firstWord)) {
 cleanText = cleanText.split(' ').slice(1).join(' ')
 }

 if (!cleanText) return Reply(`📌 ketik nama kategori dan fiturnya\ncontoh: *${prefix + command} owner addowner, delowner*`)
 let [kategori, ...rest] = cleanText.split(' ')
 let fiturInput = rest.join(' ')
 if (!kategori || !fiturInput) return Reply(`📌 format salah\ncontoh: *${prefix + command} owner addowner, delowner*`)

 const filePath = './menu-yonz.js'
 if (!fs.existsSync(filePath)) return Reply(`❌ file menu *${filePath}* ga ada didaftar menu`)

 try {
 let content = fs.readFileSync(filePath, 'utf8')
 let varName = `global.menu${kategori.toLowerCase()}`
 if (!content.includes(varName)) return Reply(`❌ kategori *${varName}* ga ada di file, coba cek lagi tulisannya!`)

 let regex = new RegExp(`(${varName}\\s*=\\s*\`[\\s\\S]*?)\``)
 let match = content.match(regex)
 if (!match) return Reply(`❌ gagal nemuin pola list menu *${varName}* nya`)
 let blockMenu = match[1]
 let fiturArray = fiturInput.split(',').map(v => v.trim().replace(/^\./, ''))

 if (isDelete) {
 // ==== MODE DELETE ====
 let notFound = []
 let updatedBlock = blockMenu
 for (let f of fiturArray) {
 let lineRegex = new RegExp(`\\n?┆𖢷 ׁ 𖹭₊ \\.${f}(?=\\n|$)`)
 if (lineRegex.test(updatedBlock)) {
 updatedBlock = updatedBlock.replace(lineRegex, '')
 } else {
 notFound.push(f)
 }
 }
 if (updatedBlock === blockMenu) return Reply(`❌ fitur *${fiturArray.join(', ')}* ga ketemu di kategori *${varName}*`)
 content = content.replace(blockMenu, updatedBlock)
 fs.writeFileSync(filePath, content)
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
 let berhasil = fiturArray.filter(f => !notFound.includes(f))
 Reply(`🚀 *Sukses Hapus Menu ${global.botname}*\n\n📂 *Kategori:* ${varName}\n🗑️ *Fitur Dihapus:* ${berhasil.join(', ') || '-'}${notFound.length ? `\n⚠️ *Ga Ketemu:* ${notFound.join(', ')}` : ''}`)

 } else {
 // ==== MODE ADD ====
 let footer = '╰➤-------------------------------'
 let newFeaturesBlock = fiturArray.map(f => `┆𖢷 ׁ 𖹭₊ .${f}`).join('\n')
 let updatedBlock
 if (blockMenu.includes(footer)) {
 updatedBlock = blockMenu.replace(footer, `${newFeaturesBlock}\n${footer}`)
 } else {
 updatedBlock = `${blockMenu}\n${newFeaturesBlock}`
 }
 content = content.replace(blockMenu, updatedBlock)
 fs.writeFileSync(filePath, content)
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
 Reply(`🚀 *Sukses Update Menu ${global.botname}*\n\n📂 *Kategori:* ${varName}\n✨ *Fitur Baru:* ${fiturArray.join(', ')}\n📍 *Status:* ${fiturArray.length} fitur berhasil disisipkan di atas footer`)
 }

 } catch (err) {
 console.error(err)
 Reply(`❌ gagal proses menu: ${err.message}`)
 }}
break

case "cekotak":
case "otakcek":
case "cekotak": {
 let target = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : m.sender)

 const hasil = [
 "🧠 Berdasarkan hasil pemindaian AI, otak @user memiliki tingkat kecerdasan yang sangat tinggi. Cara berpikirnya cepat, logis, mudah memahami hal baru, dan cocok menjadi orang yang memimpin dalam berbagai situasi. Skor kecerdasan: *100%* 🌟",
 
 "🧠 Hasil analisis menunjukkan bahwa @user memiliki otak seorang profesor. Suka berpikir sebelum bertindak, mampu menyelesaikan masalah dengan tenang, dan memiliki wawasan yang luas. Skor kecerdasan: *98%* 🎓",
 
 "🧠 Sistem mendeteksi bahwa @user memiliki pola pikir kreatif dan inovatif. Ide-idenya sering di luar dugaan dan mampu membuat orang lain kagum. Skor kecerdasan: *95%* 💡",
 
 "🧠 Setelah dilakukan pemeriksaan, ternyata @user mempunyai otak seorang programmer. Sabar mencari solusi, teliti, dan tidak mudah menyerah ketika menghadapi masalah. Skor kecerdasan: *92%* 💻",
 
 "🧠 AI mendeteksi bahwa @user mempunyai kemampuan berpikir layaknya seorang detektif. Jeli melihat detail kecil, mudah menemukan petunjuk, dan sulit dibohongi. Skor kecerdasan: *90%* 🕵️",
 
 "🧠 Hasil scan menunjukkan bahwa @user memiliki otak seorang strategist. Selalu memikirkan langkah berikutnya sebelum mengambil keputusan sehingga jarang melakukan kesalahan besar. Skor kecerdasan: *88%* ♟️",
 
 "🧠 Dari seluruh data yang dianalisis, @user termasuk orang yang cepat belajar, mudah beradaptasi, dan memiliki rasa ingin tahu yang tinggi. Skor kecerdasan: *85%* 📚",
 
 "🧠 Pemeriksaan selesai! Otak @user sebenarnya cukup cerdas, hanya saja terkadang lebih memilih rebahan daripada menggunakan seluruh kemampuannya. Skor kecerdasan: *80%* 😴",
 
 "🧠 AI sempat mengalami error saat memindai otak @user karena isinya terlalu banyak meme, candaan, dan pikiran random. Meski begitu tetap memiliki potensi besar. Skor kecerdasan: *75%* 😂",
 
 "🧠 Proses scan selesai! Sistem menyimpulkan bahwa otak @user unik dan sulit diprediksi. Kadang terlihat seperti ilmuwan, kadang seperti NPC, namun justru itulah yang membuatnya berbeda dari yang lain. Skor kecerdasan: *99%* 🤖"
 ]

 let random = hasil[Math.floor(Math.random() * hasil.length)]
 .replace(/@user/g, `@${target.split("@")[0]}`)

 await yonz.sendMessage(m.chat, {
 text: `╭───〔 🧠 *CEK OTAK* 🧠 〕───⬣

${random}

╰────────────────⬣`,
 mentions: [target]
 }, { quoted: m })
}
break



case "cekpasangan":
case "cekjodoh": {
 if (!m.mentionedJid[0]) return Reply(`Tag seseorang!\n\nContoh: ${prefix + command} @628xxxx`)

 let target = m.mentionedJid[0]
 if (target === m.sender) return Reply("❌ Tidak bisa mengecek kecocokan dengan diri sendiri!")

 let nama1 = `@${m.sender.split("@")[0]}`
 let nama2 = `@${target.split("@")[0]}`

 let persen = Math.floor(Math.random() * 101)

 const hasil = [
 "💖 Kalian memang ditakdirkan bersama. Jangan saling menyakiti ya!",
 "🥰 Chemistry kalian sangat kuat. Banyak yang iri melihatnya.",
 "💕 Kalian pasangan yang serasi. Tinggal saling percaya dan menjaga.",
 "😍 Cocok banget! Semoga cepat naik pelaminan. 🤲",
 "💞 Hubungan ini punya peluang besar untuk bertahan lama.",
 "😊 Lumayan cocok, tinggal perbaiki komunikasi saja.",
 "🤝 Kalian lebih cocok jadi sahabat daripada pasangan.",
 "😅 Masih butuh banyak usaha agar hubungan semakin baik.",
 "🙃 Kecocokan masih rendah, jangan menyerah kalau memang serius.",
 "💔 AI mendeteksi kalian kurang cocok, tapi semua kembali kepada usaha kalian."
 ]

 let random = hasil[Math.floor(Math.random() * hasil.length)]

 await yonz.sendMessage(
 m.chat,
 {
 text: `💘 *CEK KECOCOKAN PASANGAN* 💘

❤️ *Pasangan 1:* ${nama1}
💙 *Pasangan 2:* ${nama2}

💞 *Tingkat Kecocokan:* *${persen}%*

${random}`,
 mentions: [m.sender, target]
 },
 { quoted: m }
 )
}
break

case "cekjodoh":
case "jodoh":
case "carijodoh": {
 if (!m.isGroup) return Reply(mess.group)

 let members = participants
 .map(v => v.id)
 .filter(v => v !== botNumber && !v.endsWith("status@broadcast"))

 if (members.length < 2) return Reply("❌ Member grup tidak cukup!")

 let jodoh1 = members[Math.floor(Math.random() * members.length)]
 let jodoh2 = members[Math.floor(Math.random() * members.length)]

 while (jodoh1 === jodoh2) {
 jodoh2 = members[Math.floor(Math.random() * members.length)]
 }

 const persen = Math.floor(Math.random() * 101)

 const hasil = [
 "💖 Wah, kalian cocok banget! Semoga berjodoh sampai pelaminan.",
 "🥰 Chemistry kalian sangat kuat, jangan disia-siakan.",
 "💕 AI mendeteksi aura cinta yang sangat tinggi.",
 "😍 Banyak yang bilang kalian pasangan serasi.",
 "💞 Cocok! Tinggal saling menjaga dan memahami.",
 "😊 Lumayan cocok, tinggal lebih sering komunikasi.",
 "🤝 Kalian lebih cocok jadi partner hidup.",
 "😅 Masih butuh sedikit perjuangan agar makin cocok.",
 "🙃 Kecocokan masih rendah, tapi jodoh tidak ada yang tahu.",
 "💔 AI bilang kurang cocok... tapi takdir bisa berubah."
 ]

 const random = hasil[Math.floor(Math.random() * hasil.length)]

 await yonz.sendMessage(
 m.chat,
 {
 text: `💘 *CEK JODOH* 💘

👤 @${jodoh1.split("@")[0]}
 ❤️
👤 @${jodoh2.split("@")[0]}

💞 *Tingkat Kecocokan:* *${persen}%*

${random}`,
 mentions: [jodoh1, jodoh2]
 },
 { quoted: m }
 )
}
break



case "getpp": {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi)
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit)

 addLimit(m.sender, global.isPrem(m.sender), isCreator)

 let target

 if (m.mentionedJid.length) {
 target = m.mentionedJid[0]
 } else if (m.quoted) {
 target = m.quoted.sender
 } else if (text) {
 let number = text.replace(/[^0-9]/g, "")
 if (!number) return Reply(`Contoh:\n${prefix + command} 628xxxxxxxxxx`)
 target = number + "@s.whatsapp.net"
 } else {
 return Reply(`Contoh:
${prefix + command} @tag
${prefix + command} 628xxxxxxxxxx
atau reply pesan seseorang dengan ${prefix + command}`)
 }

 try {
 await yonz.sendMessage(m.chat, {
 react: {
 text: "⏳",
 key: m.key
 }
 })

 let pp

 try {
 pp = await yonz.profilePictureUrl(target, "image")
 } catch {
 pp = "https://telegra.ph/file/24fa902ead26340f3df2c.png"
 }

 await yonz.sendMessage(m.chat, {
 image: {
 url: pp
 },
 caption: `📸 *Foto Profil Berhasil Diambil*

👤 Target : @${target.split("@")[0]}`,
 mentions: [target]
 }, {
 quoted: m
 })

 await yonz.sendMessage(m.chat, {
 react: {
 text: "✅",
 key: m.key
 }
 })

 } catch (err) {
 console.log(err)

 await yonz.sendMessage(m.chat, {
 react: {
 text: "❌",
 key: m.key
 }
 })

 Reply("❌ Gagal mengambil foto profil.")
 }
}
break







case "me":
case "profile":
case "profil": {
 let pp

 try {
 pp = await yonz.profilePictureUrl(m.sender, "image")
 } catch {
 pp = "https://telegra.ph/file/24fa902ead26340f3df2c.png"
 }

 const nama = m.pushName || m.name || "Pengguna"
 const nomor = m.sender.split("@")[0]

 await yonz.sendMessage(m.chat, {
 image: { url: pp },
 caption: `╭━━━〔 👤 *MY PROFILE* 〕━━━⬣

🧑 Nama : ${nama}
📱 Nomor : ${nomor}
👑 Status : ${isCreator ? "Owner" : "User"}
⭐ Premium : ${global.isPrem(m.sender) ? "Ya" : "Tidak"}

Terima kasih telah menggunakan bot ❤️

╰━━━━━━━━━━━━━━━━━━⬣`
 }, {
 quoted: m
 })
}
break





case 'daftar':
case 'register': {
 if (isRegistered(m.sender)) {
 return Reply(
 `╭─⟡ *Registrasi* - Sudah Terdaftar
│✦ Status : Akun sudah aktif
│✦ Akses : Penuh
│✦ Cek : .profile
│✦ Hapus : .unreg
╰──────────⟡`
 )
 }

 if (!text || !text.includes(',')) {
 return Reply(example("Budi,18"))
 }

 const parts = text.split(',').map(p => p.trim());
 if (parts.length < 2) return Reply(example("Budi,18"))

 const nama = parts[0];
 const umurInput = parts[1];

 const umur = parseInt(umurInput);
 if (isNaN(umur)) return Reply("❌ Umur harus angka!")

 if (umur < 13) return Reply(`❌ Minimal 13 tahun! (Umur: ${umur} tahun)`)

 if (umur > 100) return Reply(`❌ Umur terlalu tua! (Umur: ${umur} tahun)`)

 if (!nama || nama.length < 2) return Reply("❌ Nama minimal 2 karakter!")

 await yonz.sendPresenceUpdate('composing', m.chat);
 await sleep(1500);

 const userId = m.sender.split('@')[0];
 const userName = m.pushName || 'Tanpa Nama';
 const isPremiumUser = global.isPrem(m.sender);
 const isOwnerUser = isCreator;
 const status = isOwnerUser ? 'OWNER' : isPremiumUser ? 'PREMIUM' : 'FREE';

 const dateNow = new Date();
 const tgl = dateNow.toLocaleDateString('id-ID', {
 weekday: 'long',
 year: 'numeric',
 month: 'long',
 day: 'numeric'
 });
 const jam = dateNow.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

 addRegisteredUser(m.sender, {
 jid: m.sender,
 nama: nama,
 umur: umur,
 pushname: userName,
 status,
 tanggal: tgl,
 jam: jam
 });

 const benefits = isOwnerUser ? [
 '│✦ Akses semua fitur tanpa batas',
 '│✦ Priority support 24/7',
 '│✦ Custom command request',
 '│✦ Developer privileges'
 ] : isPremiumUser ? [
 '│✦ Unlimited limit harian',
 '│✦ Akses fitur premium',
 '│✦ Fast response priority',
 '│✦ No ads interruption'
 ] : [
 '│✦ 15 limit harian (reset tiap hari)',
 '│✦ Akses fitur dasar',
 '│✦ Bisa claim extra limit',
 '│✦ Upgrade ke premium tersedia'
 ];

 const teks = `╭─⟡ *Registrasi Berhasil*
│✦ Nama : ${nama}
│✦ Umur : ${umur} tahun
│✦ Tag : @${userId}
│✦ Status : ${status}
│✦ Tanggal : ${tgl}
╰──────────⟡

╭─⟡ *Fitur Didapat:*
${benefits.map(b => `${b}`).join('\n')}
╰──────────⟡`;

 Reply(teks, [m.sender]);
}
break;

case 'unreg':
case 'unregister': {
    if (!global.db.users[m.sender] || !global.db.users[m.sender].registered) {
        return Reply('❌ Kamu belum terdaftar.')
    }
    global.db.users[m.sender].registered = false
    return Reply('✅ Berhasil menghapus pendaftaran kamu.\nKetik *.daftar* untuk daftar lagi.')
}
break;

case 'setdaftar': {
    if (!isCreator) return Reply(mess.owner)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        return Reply(example(`on/off\n\n` +
            `• *on*  = user wajib .daftar dulu sebelum bisa pakai fitur bot\n` +
            `• *off* = semua user langsung bisa pakai bot tanpa daftar`))
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.settings) global.db.settings = {}
    global.db.settings.wajibDaftar = status
    return Reply(
        `✅ Fitur *wajib daftar* sekarang *${status ? 'ON' : 'OFF'}*\n` +
        (status
            ? '➜ User harus *.daftar* dulu sebelum bisa pakai bot.'
            : '➜ Semua user bisa langsung pakai bot tanpa daftar.')
    )
}
break;

case 'addsewagc': {
    if (!isCreator) return Reply(mess.owner)

    let targetGc = m.chat
    let hari = null

    if (args[0]) {
        if (/^\d{10,}(@g\.us)?$/.test(args[0])) {
            targetGc = args[0].includes('@g.us') ? args[0] : args[0] + '@g.us'
            if (args[1] && !isNaN(args[1])) hari = parseInt(args[1])
        } else if (!isNaN(args[0])) {
            hari = parseInt(args[0])
        }
    }

    if (!targetGc || !targetGc.endsWith('@g.us')) {
        return Reply(example(
            `\n` +
            `• .addsewagc → sewakan grup ini (permanent)\n` +
            `• .addsewagc 30 → sewakan grup ini 30 hari\n` +
            `• .addsewagc 120363xxxxx@g.us → sewakan grup lain\n` +
            `• .addsewagc 120363xxxxx@g.us 30 → sewakan grup lain 30 hari`
        ))
    }

    let groupName = targetGc
    try {
        const meta = await yonz.groupMetadata(targetGc)
        groupName = meta.subject
    } catch (e) {}

    const sewaDb = loadSewaGc()
    sewaDb[targetGc] = {
        nama: groupName,
        addedBy: m.sender,
        tanggal: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
        expired: hari ? Date.now() + hari * 24 * 60 * 60 * 1000 : null
    }
    saveSewaGc(sewaDb)

    return Reply(
        `✅ *Berhasil menambahkan grup sewa!*\n\n` +
        `➜ Nama: ${groupName}\n` +
        `➜ ID: ${targetGc}\n` +
        `➜ Masa aktif: ${hari ? hari + ' hari' : 'Permanent'}`
    )
}
break;

case 'delsewagc': {
    if (!isCreator) return Reply(mess.owner)

    let targetGc = m.chat
    if (args[0] && /^\d{10,}(@g\.us)?$/.test(args[0])) {
        targetGc = args[0].includes('@g.us') ? args[0] : args[0] + '@g.us'
    }

    if (!targetGc || !targetGc.endsWith('@g.us')) {
        return Reply(example(`\n• .delsewagc → hapus sewa grup ini\n• .delsewagc 120363xxxxx@g.us → hapus sewa grup lain`))
    }

    const sewaDb = loadSewaGc()
    if (!sewaDb[targetGc]) return Reply('❌ Grup tersebut belum terdaftar sewa.')

    const namaGc = sewaDb[targetGc].nama || targetGc
    delete sewaDb[targetGc]
    saveSewaGc(sewaDb)

    return Reply(`✅ Berhasil menghapus sewa grup *${namaGc}*`)
}
break;

case 'listsewagc': {
    if (!isCreator) return Reply(mess.owner)

    const sewaDb = loadSewaGc()
    const ids = Object.keys(sewaDb)
    if (ids.length === 0) return Reply('📋 Belum ada grup yang sewa.')

    let teks = `📋 *DAFTAR GRUP SEWA* (${ids.length})\n\n`
    ids.forEach((id, i) => {
        const g = sewaDb[id]
        const status = g.expired
            ? (g.expired > Date.now() ? `Aktif s/d ${new Date(g.expired).toLocaleDateString('id-ID')}` : '⛔ Expired')
            : 'Permanent'
        teks += `${i + 1}. ${g.nama || id}\n   ID: ${id}\n   Status: ${status}\n   Ditambahkan: ${g.tanggal || '-'}\n\n`
    })

    return Reply(teks.trim())
}
break;

case 'autodownload':
case 'autodl': {
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        return Reply(example(
            `on/off\n\n` +
            `Fitur ini akan otomatis mendownload link *TikTok* dan *Instagram* yang dikirim di chat ini, tanpa perlu command.`
        ))
    }
    const status = text.toLowerCase() === 'on'

    if (m.isGroup) {
        if (!isCreator && !m.isAdmin) return Reply(mess.admin)
        if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
        global.db.groups[m.chat].autodownload = status
    } else {
        if (!global.db.users[m.sender]) global.db.users[m.sender] = {}
        global.db.users[m.sender].autodownload = status
    }

    return Reply(
        `✅ *Auto Download* sekarang *${status ? 'ON' : 'OFF'}* di chat ini.\n` +
        (status
            ? '➜ Kirim link TikTok/Instagram, bot akan otomatis download.'
            : '➜ Bot tidak akan lagi auto download link TikTok/Instagram di chat ini.')
    )
}
break;



case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *乂 List all group chat*\n`
let a = await yonz.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return Reply(teks)
}
break

case "mute": {
 // Ambil semua ID grup dari text (support banyak baris/spasi)
 let rawText = text ? text.trim() : ''
 let lines = rawText.split(/\s+/).filter(v => v)

 // Deteksi action (on/off) kalau ada di antara input
 let actionKeywords = ['on', 'off']
 let action = ''
 let idList = []

 for (let v of lines) {
 let low = v.toLowerCase()
 if (actionKeywords.includes(low)) {
 action = low
 } else if (/^\d{5,}(-\d+)?(@g\.us)?$/.test(v)) {
 idList.push(v.includes('@g.us') ? v : v + '@g.us')
 }
 }

 let remoteTarget = idList.length > 0
 let targetGroups = remoteTarget ? idList : [m.chat]

 if (remoteTarget) {
 if (!isCreator) return Reply(mess.owner)
 } else {
 if (!m.isGroup) return Reply(mess.group)
 if (!isCreator && !m.isAdmin) return Reply(mess.admin)
 }

 const muteDb = loadMuteGc()

 // Kalau tidak ada action, tampilkan status semua target
 if (!action) {
 let statusText = `🔇 *MUTE GROUP*\n\n`
 for (let gc of targetGroups) {
 if (!muteDb[gc]) muteDb[gc] = { mute: false }
 let status = muteDb[gc].mute ? "🟢 Aktif" : "🔴 Nonaktif"
 statusText += `🆔 ${gc}\n📊 Status : ${status}\n\n`
 }
 statusText += `Gunakan:\n• ${prefix + command} on\n• ${prefix + command} off\n• ${prefix + command} idgrup1 idgrup2 ... on/off`
 return Reply(statusText)
 }

 let hasil = []
 for (let gc of targetGroups) {
 if (!muteDb[gc]) muteDb[gc] = { mute: false }

 if (action === "on") {
 if (muteDb[gc].mute) {
 hasil.push(`✅ ${gc} sudah mute.`)
 continue
 }
 muteDb[gc].mute = true
 hasil.push(`🔇 ${gc} berhasil di-mute.`)
 } else if (action === "off") {
 if (!muteDb[gc].mute) {
 hasil.push(`✅ ${gc} sudah tidak mute.`)
 continue
 }
 muteDb[gc].mute = false
 hasil.push(`🔊 ${gc} berhasil di-unmute.`)
 }
 }

 saveMuteGc(muteDb)
 return Reply(hasil.join('\n'))
}
break

case "listmute": {
 if (!isCreator) return Reply(mess.owner)

 const muteDb = loadMuteGc()
 let mutedList = Object.keys(muteDb).filter(gc => muteDb[gc]?.mute === true)

 if (mutedList.length === 0) {
 return Reply("✅ Tidak ada grup yang sedang di-mute saat ini.")
 }

 let teks = `🔇 *LIST GROUP MUTE*\n\n`
 teks += `Total : ${mutedList.length} grup\n\n`

 for (let gc of mutedList) {
 let id = gc.includes('@g.us') ? gc : gc + '@g.us'
 let nama = "❌ Bot sudah tidak ada di grup ini"
 try {
 let meta = await yonz.groupMetadata(id)
 nama = meta?.subject || "(Tanpa nama)"
 } catch (e) {
 console.log(`Gagal ambil metadata grup ${id}:`, e?.message || e)
 }
 teks += `🆔 *ID :* ${id}\n📛 *Nama :* ${nama}\n\n`
 await new Promise(res => setTimeout(res, 300))
 }

 return Reply(teks)
}
break

case 'typo':
case 'autocorrect': {
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const status = isAutoCorrect(m.chat) ? '🟢 Aktif' : '🔴 Nonaktif'
        return Reply(example(
            `on/off\n\n` +
            `Status saat ini di chat ini : ${status}\n` +
            `Fitur ini akan otomatis mendeteksi command yang salah ketik (typo) dan memberi saran command yang benar.`
        ))
    }
    const status = text.toLowerCase() === 'on'
    const acDb = loadAutoCorrect()
    acDb[m.chat] = status
    saveAutoCorrect(acDb)
    return Reply(`✅ *Auto Correct* sekarang *${status ? 'ON' : 'OFF'}* di chat ini.`)
}
break;

1

case 'deploy':
case 'deployweb': {
	if (!isCreator) return m.reply(global.mess.owner)

	const AdmZip = require('adm-zip')
	const fetch = require('node-fetch')
	const vercelToken = "vcp_3MGcSP3janbixGPxVGh1geiOeEOTSV6A2vh2ZOF8zmfJcD0lnN0TMZr9"
	const headers = { 
		'Authorization': `Bearer ${vercelToken}`, 
		'Content-Type': 'application/json' 
	}

	if (args[0] === 'list') {
		try {
			const res = await fetch('https://api.vercel.com/v6/deployments', { headers })
			const data = await res.json()
			if (!data.projects || data.projects.length === 0) return m.reply('Tidak ada project di akun Vercel')
			
			let teks = 'DAFTAR PROJECT VERCEL\n\n'
			data.projects.forEach((p, i) => {
				teks += `${i + 1}. Nama: ${p.name}\nURL: https://${p.name}.vercel.app\n\n`
			})
			return m.reply(teks)
		} catch (e) {
			return m.reply('Gagal mengambil daftar project')
		}
	}

	if (args[0] === 'delete') {
		if (!args[1]) return m.reply('Gunakan: .vweb delete nama-web')
		try {
			const res = await fetch(`https://api.vercel.com/v6/deployments?teamId=${teamId}`, {
				method: 'DELETE',
				headers
			})
			if (res.status === 204 || res.status === 200) {
				return m.reply(`Berhasil menghapus project: ${args[1]}`)
			} else {
				const err = await res.json()
				return m.reply(`Gagal menghapus: ${err.error?.message || 'Project tidak ditemukan'}`)
			}
		} catch (e) {
			return m.reply('Terjadi kesalahan saat menghapus project')
		}
	}

	const qmsg = m.quoted || (m.msg && m.msg.contextInfo && m.msg.contextInfo.quotedMessage)
	if (!qmsg) return m.reply('Reply file .html atau .zip')

	const mime = qmsg.mimetype || (qmsg.documentMessage && qmsg.documentMessage.mimetype) || ''
	if (!text) return m.reply(`Gunakan: .${command} nama-web`)
	const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '')

	m.reply(global.mess.wait)
	
	let media
	try {
		media = await yonz.downloadMediaMessage(m.quoted)
	} catch (err) {
		return m.reply('Gagal mendownload file')
	}

	let filesToUpload = []
	if (mime.includes('zip')) {
		const zip = new AdmZip(media)
		const entries = zip.getEntries()
		let hasIndex = false
		entries.forEach(entry => {
			if (entry.isDirectory) return
			if (entry.entryName.toLowerCase().endsWith('index.html')) hasIndex = true
			filesToUpload.push({
				file: entry.entryName.replace(/\\/g, '/'),
				data: entry.getData().toString('base64'),
				encoding: 'base64'
			})
		})
		if (!hasIndex) return m.reply('File index.html tidak ditemukan dalam ZIP')
	} else if (mime.includes('html')) {
		filesToUpload.push({
			file: 'index.html',
			data: Buffer.from(media).toString('base64'),
			encoding: 'base64'
		})
	} else {
		return m.reply('Hanya mendukung .zip atau .html')
	}

	try {
		await fetch('https://api.vercel.com/v9/projects', {
			method: 'POST',
			headers,
			body: JSON.stringify({ name: webName })
		}).catch(() => {})

		const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
			method: 'POST',
			headers,
			body: JSON.stringify({ 
				name: webName, 
				project: webName, 
				files: filesToUpload, 
				projectSettings: { framework: null } 
			})
		})

		const deployData = await deployRes.json().catch(() => null)
		if (!deployData || deployData.error) return m.reply(`Gagal: ${deployData?.error?.message}`)

		let teks = `BERHASIL DEPLOY VERCEL\n\n`
		teks += `URL: https://${webName}.vercel.app\n`
		teks += `Nama: ${webName}\n\n`
		teks += `${global.botname}`

		await yonz.sendMessage(m.chat, { text: teks }, { quoted: m })

	} catch (err) {
		m.reply(`Kesalahan: ${err.message}`)
	}
}
break

case 'delweb': {
 if (!isCreator) return m.reply(global.mess.owner)

 const fetch = require('node-fetch')
 const vercelToken = "vcp_3MGcSP3janbixGPxVGh1geiOeEOTSV6A2vh2ZOF8zmfJcD0lnN0TMZr9"
 const teamId = ""

 const headers = {
 Authorization: `Bearer ${vercelToken}`,
 'Content-Type': 'application/json'
 }

 if (!text) return m.reply('Contoh: .delweb https://yonz-market-v6.vercel.app')

 function ambilNamaProject(input) {
 input = input.trim().toLowerCase()

 if (input.startsWith('http')) {
 try {
 const url = new URL(input)
 return url.hostname.replace('.vercel.app', '').split('.')[0]
 } catch {
 return null
 }
 }

 return input
 .replace('.vercel.app', '')
 .replace(/[^a-z0-9-_]/g, '')
 }

 const projectName = ambilNamaProject(text)

 if (!projectName) return m.reply('Nama website tidak valid')

 const url = teamId
 ? `https://api.vercel.com/v9/projects/${projectName}?teamId=${teamId}`
 : `https://api.vercel.com/v9/projects/${projectName}`

 try {
 const res = await fetch(url, {
 method: 'DELETE',
 headers
 })

 if (res.status === 200 || res.status === 204) {
 return m.reply(`Berhasil menghapus website:\nhttps://${projectName}.vercel.app`)
 }

 const err = await res.json().catch(() => null)
 return m.reply(`Gagal menghapus website:\n${err?.error?.message || 'Project tidak ditemukan'}`)
 } catch (e) {
 m.reply(`Terjadi kesalahan saat menghapus website:\n${e.message}`)
 }
}
break

case 'listweb': {
 if (!isCreator) return m.reply(global.mess.owner)

 const fetch = require('node-fetch')
 const vercelToken = "vcp_3MGcSP3janbixGPxVGh1geiOeEOTSV6A2vh2ZOF8zmfJcD0lnN0TMZr9"
 const teamId = ""

 const headers = {
 Authorization: `Bearer ${vercelToken}`,
 'Content-Type': 'application/json'
 }

 const url = teamId
 ? `https://api.vercel.com/v9/projects?teamId=${teamId}`
 : `https://api.vercel.com/v9/projects`

 try {
 const res = await fetch(url, { headers })
 const data = await res.json()

 if (!data.projects || data.projects.length === 0) {
 return m.reply('Belum ada website yang di deploy')
 }

 let teks = 'DAFTAR WEBSITE VERCEL\n\n'

 data.projects.forEach((p, i) => {
 teks += `${i + 1}. Nama: ${p.name}\n`
 teks += `URL: https://${p.name}.vercel.app\n\n`
 })

 m.reply(teks)
 } catch (e) {
 m.reply('Gagal mengambil daftar website')
 }
}
break

case "luma":
case "img2video":
case "image2video": {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi);

 if (!global.isPrem(m.sender) && !isCreator)
 return Reply(mess.prem);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";

 if (!/image\//i.test(mime)) {
 return Reply(`❌ Reply gambar dengan caption ${prefix + command}`);
 }

 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);

 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 const imageBuffer = await q.download();
 if (!imageBuffer) throw new Error('Gagal download gambar');

 const prompt = m.text?.trim() || "Gerakan foto ini";

 const FormData = require('form-data');

 const buildForm = () => {
 const form = new FormData();
 form.append('apikey', 'Yonz');
 form.append('prompt', prompt);
 form.append('duration', '10');
 form.append('image', imageBuffer, {
 filename: 'image.jpg',
 contentType: 'image/jpeg'
 });
 return form;
 };

 // Retry logic maksimal 3x
 let submitData = null;
 const maxRetry = 3;

 for (let i = 1; i <= maxRetry; i++) {
 try {
 console.log(`[IMG2VID] Percobaan ke-${i}...`);
 const form = buildForm();

 const submitRes = await axios.post(
 `https://api.theresav.biz.id/ai/img2vid`,
 form,
 {
 headers: { ...form.getHeaders() },
 timeout: 300000 // 5 menit
 }
 );

 submitData = submitRes.data;
 console.log('[IMG2VID RESPONSE]', JSON.stringify(submitData, null, 2));
 break; // Sukses, keluar loop

 } catch (retryErr) {
 const status = retryErr.response?.status;
 console.warn(`[IMG2VID] Percobaan ${i} gagal, status: ${status}`);

 if (i === maxRetry) throw retryErr; // Lempar error setelah retry habis

 // Tunggu 30 detik sebelum retry jika 504
 if (status === 504 || status === 502 || status === 503) {
 console.log(`[IMG2VID] Tunggu 30 detik sebelum retry...`);
 await new Promise(r => setTimeout(r, 30000));
 } else {
 throw retryErr; // Error lain langsung lempar
 }
 }
 }

 if (!submitData) throw new Error('Response kosong dari API');
 if (submitData.status === false) throw new Error(submitData?.message || submitData?.error || 'API error');

 const videoUrl =
 submitData?.result?.video_url ||
 submitData?.result?.url ||
 submitData?.result?.videoUrl ||
 submitData?.video_url ||
 submitData?.videoUrl ||
 submitData?.url ||
 submitData?.data?.url ||
 submitData?.data?.video_url ||
 submitData?.output ||
 null;

 if (!videoUrl) throw new Error(`Tidak ada video URL: ${JSON.stringify(submitData)}`);

 await yonz.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: mess.done
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 const errMsg = error.response?.data
 ? JSON.stringify(error.response.data)
 : error.message;
 console.error('[LUMA ERROR]', errMsg);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Gagal: ${errMsg}`);
 }
}
break









case 'pin':
case 'pinterest':
 if (!text) return Reply(`Contoh: ${prefix + command} bebek`)
 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const { data } = await axios.get(`${global.there}/search/pinterest?query=${encodeURIComponent(text)}&type=image&apikey=Yonz`)

 if (!data || !data.status || !data.result || data.result.length === 0) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil data, coba keyword lain.')
 }

 const medias = data.result
 .filter(item => item.directLink)
 .slice(0, 10)
 .map(item => ({ image: { url: item.directLink } }))

 if (medias.length === 0) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Tidak ada foto yang bisa ditampilkan.')
 }

 if (medias.length < 2) {
 await yonz.sendMessage(m.chat, {
 image: { url: medias[0].image.url }
 }, { quoted: m })
 } else {
 const { generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys')
 const crypto = require('crypto')

 const album = generateWAMessageFromContent(m.chat, {
 messageContextInfo: {
 messageSecret: crypto.randomBytes(32)
 },
 albumMessage: {
 expectedImageCount: medias.length,
 expectedVideoCount: 0
 }
 }, { quoted: m })

 await yonz.relayMessage(m.chat, album.message, { messageId: album.key.id })

 for (const media of medias) {
 const prepared = await prepareWAMessageMedia(
 { image: media.image },
 { upload: yonz.waUploadToServer }
 )

 const content = generateWAMessageFromContent(m.chat, {
 imageMessage: prepared.imageMessage,
 messageContextInfo: {
 messageAssociation: {
 associationType: 1,
 parentMessageKey: album.key
 }
 }
 }, {})

 await yonz.relayMessage(m.chat, content.message, { messageId: content.key.id })
 }
 }

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break

case "getsc": {
 if (!isCreator) return Reply(mess.owner)
 let dir = fs.readdirSync("./library/database/sampah")
 if (dir.length >= 2) {
 let res = dir.filter(e => e !== "A")
 for (let i of res) {
 fs.unlinkSync(`./library/database/sampah/${i}`)
 }
 }
 await m.reply("Memproses backup script bot")

 var name = global.botname.replace(/[^a-zA-Z0-9 _-]/g, "").trim()
 var zipName = `${name}.zip`

 const ls = execSync("ls")
 .toString()
 .split("\n")
 .filter(
 (pe) =>
 pe != "node_modules" &&
 pe != "session" &&
 pe != "package-lock.json" &&
 pe != "yarn.lock" &&
 pe != ""
 )

 try {
 execSync(`zip -r "${zipName}" ${ls.map(f => `"${f}"`).join(" ")}`)

 await yonz.sendMessage(
 global.idgrup,
 {
 document: fs.readFileSync(`./${zipName}`),
 fileName: zipName,
 mimetype: "application/zip"
 },
 { quoted: m }
 )

 execSync(`rm -f "${zipName}"`)

 return m.reply("Script bot berhasil dikirim ke grup")
 } catch (e) {
 console.log(e)
 return m.reply("Gagal membuat/mengirim backup script:\n" + e.message)
 }
}
break



case 'idgc': {
 if (!m.isGroup) return Reply('Command ini hanya bisa digunakan di dalam grup.')

 try {
 const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys')
 const groupId = m.chat

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `*Group ID*\n\n${groupId}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: global.botname || 'Bot'
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'cta_copy',
 buttonParamsJson: JSON.stringify({
 display_text: 'Salin ID',
 id: 'copy_id',
 copy_code: groupId
 })
 }
 ]
 })
 })
 }
 }
 }, { quoted: m })

 await yonz.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
 } catch (e) {
 console.log(e)
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
}
break

default:
    if (isCmd && command && isAutoCorrect(m.chat) && !getValidCommands().has(command.toLowerCase())) {
        const allCommands = [...getValidCommands()];
        let bestMatch = null;
        let minDistance = Infinity;
        const typoThreshold = 2;

        for (const cmd of allCommands) {
            if (cmd === command.toLowerCase()) continue; // skip diri sendiri, jaga-jaga
            const distance = levenshtein(command, cmd);
            if (distance < minDistance) {
                minDistance = distance;
                bestMatch = cmd;
            }
        }

        if (bestMatch && minDistance <= typoThreshold && minDistance > 0) {
            const similarity = Math.max(0, Math.min(100, Math.round(((command.length - minDistance) / command.length) * 100)));
            const teks = `\n*🍀 ᴄᴏᴍᴍᴀɴᴅ ʏᴀɴɢ ᴋᴀᴍᴜ ᴋᴇᴛɪᴋ ᴛɪᴅᴀᴋ ᴛᴇʀsᴇᴅɪᴀ ᴅɪ ʙᴏᴛ, ʏᴀɴɢ ᴋᴀᴍᴜ ᴍᴀᴋꜱᴜᴅ:*
        
┏━ ⊑ *MUNGKIN INI* ⊒
│ ⤷ Command : ${prefix}${bestMatch}
│ ⤷ Kemiripan : ${similarity}% 
╰──────────────\n`;

            const thumbPath = "./source/media/foto/imgdokumen.jpg";

            if (fs.existsSync(thumbPath)) {
                try {
                    const img = await jimp.read(thumbPath);
                    if (img.bitmap.width !== 300 || img.bitmap.height !== 300) {
                        img.cover(300, 300);
                        await img.writeAsync(thumbPath);
                    }
                } catch (e) {}
            }

            await yonz.sendMessage(m.chat, {
                document: fs.readFileSync("./package.json"),
                fileName: global.botname,
                mimetype: "image/png",
                fileLength: 999000000000,
                pageCount: 100,
                headerType: 1,
                viewOnce: true,
                jpegThumbnail: (typeof global.pathThumbHeader === 'string' && global.pathThumbHeader && fs.existsSync(global.pathThumbHeader)) ? fs.readFileSync(global.pathThumbHeader) : (fs.existsSync(thumbPath) ? fs.readFileSync(thumbPath) : undefined),
                caption: teks,
                buttons: [
                    {
                        buttonId: `${prefix}${bestMatch}`,
                        buttonText: { displayText: `${prefix}${bestMatch}` },
                        type: 1
                    }
                ],
                contextInfo: {
                    mentionedJid: [m.sender],
                    isForwarded: true,
                    forwardingScore: 9999,
                    businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" },
                    forwardedNewsletterMessageInfo: {
                        newsletterName: global.namaSaluran,
                        newsletterJid: global.idSaluran
                    }
                }
            }, { quoted: m });
            return;
        }
    }

    if (budy.startsWith('>')) {
        if (!isCreator) return
        try {
            let evaled = await eval(budy.slice(2))
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
            await m.reply(evaled)
        } catch (err) {
            await m.reply(String(err))
        }}

//================================================================================

if ([global.botname.toLowerCase(), global.botname2.toLowerCase(), "bot"].includes(m.text.toLowerCase())) {
    return yonz.sendMessage(
        m.chat,
        {
            sticker: {
                url: "./source/media/sticker/bot.webp"
            }
        },
        {
            quoted: m
        }
    );
}
//================================================================================
if (budy.startsWith('=>')) {
if (!isCreator2) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await Reply(evaled)
} catch (err) {
await Reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator2) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return Reply(`${err}`)
if (stdout) return Reply(stdout)
})
}

//================================================================================
}
} catch (err) {
    console.log(util.format(err));
    let Obj = global.owner
    yonz.sendMessage(Obj + "@s.whatsapp.net", { 
        text: `
*ERROR TERDETEKSI :*\n\n` + util.format(err), 
        contextInfo: { isForwarded: false } 
    }, { quoted: m })
}}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
});