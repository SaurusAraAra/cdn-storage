const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.owner = '6285174301390'
global.versi = version
global.namaOwner = "Yonz official"
global.packname = 'New Script By Yonz'
global.botname = 'Yonz New Base'
global.botname2 = 'Yonz New Base'
global.custompairing = "YONZOFFC";
global.adm4 = "31.71.03.1001"

global.apialip = "https://docs-alip.clutch.web.id"
global.there = "https://api.theresav.biz.id"
global.apikeyalip = "alipaiapikeybaru"
global.apikeythere = "Yonz"
global.tempatDB = 'database.json'
global.pairing_code = true

// Settings gif welcome / left
global.gifWelcome = 'https://rahmad-elaina.my.id/file/0dcc693bdc.mp4'
global.audioWelcome = 'https://rahmad-elaina.my.id/file/2b622482eb.mp3'

global.gifLeft = 'https://d.uguu.se/XoggFCMb.mp4'
global.audioLeft = 'https://rahmad-elaina.my.id/file/dd7639989b.mp3'

global.linkOwner = "https://wa.me/6285174301390"
global.linkowner = global.linkOwner
global.linkGrup = "https://chat.whatsapp.com/Di0qSfAsE4AH0o31J2hkti"
global.idgrup = "120363405834908609@g.us"

global.linkSaluran = "https://whatsapp.com/channel/0029Vb7LAXcLY6cxZmasdh43"
global.idSaluran = "120363426234538573@newsletter"
global.namaSaluran = "✦ ──『 𝐘𝐨𝐧𝐳 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 』── ✦"

//Setting limit harian 
global.limitFree = 15
global.limitPremium = 1000

// Delay
global.delayJpm = 3000

// Settings Image Url
global.image = {
	menu: "https://img2.pixhost.to/images/9041/745365248_image_1782976745234.jpg",
	reply: "https://img2.pixhost.to/images/9039/745341096_image_1782971950599.jpg",
    menuv3: "https://img2.pixhost.to/images/9041/745365248_image_1782976745234.jpg"
}

// Message Command
global.mess = {
	owner: `💌 *AKSES DITOLAK*\nFitur ini hanya bisa digunakan oleh *Owner Bot*.`,
	admin: `💌 *AKSES DITOLAK*\nFitur ini khusus untuk *Admin Grup*.`,
	botAdmin: `💌 *AKSES DITOLAK*\nBot harus menjadi *Admin Grup* terlebih dahulu.`,
	group: `💌 *AKSES DITOLAK*\nFitur ini hanya dapat digunakan di *dalam grup*.`,
	wait: `⏳ *Mohon tunggu...*\nPermintaan kamu sedang diproses.`,
	error: `❌ *Terjadi kesalahan!*\nSilakan coba lagi nanti.`,
	done: `✅ *Berhasil!*\nProses telah selesai dengan sukses.`,
	verifikasi: `💌 *AKSES DITOLAK*\nKamu belum terdaftar. Silakan hubungi Owner untuk melakukan pendaftaran.`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})