const fs = require('fs')
const path = require('path')

const DB_PATH = path.join(__dirname, '../library/database/premium.json')

function loadPremium() {
    if (!fs.existsSync(DB_PATH)) {
        fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
        fs.writeFileSync(DB_PATH, '[]', 'utf-8')
        return []
    }
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) }
    catch { return [] }
}

function savePremium(data) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8')
}

function isPrem(jid) {
    const now = Date.now()
    return loadPremium().some(u => u.jid === jid && u.expired > now)
}

function addPrem(jid, hari = 30, addedBy = 'system') {
    const list = loadPremium()
    const now = Date.now()
    const entry = {
        jid,
        expired: now + hari * 24 * 60 * 60 * 1000,
        addedBy,
        addedAt: now
    }
    const idx = list.findIndex(u => u.jid === jid)
    if (idx !== -1) list[idx] = entry
    else list.push(entry)
    savePremium(list)
    return entry
}

function delPrem(jid) {
    const list = loadPremium()
    const newList = list.filter(u => u.jid !== jid)
    savePremium(newList)
    return newList.length < list.length
}

function getPremList() {
    const now = Date.now()
    return loadPremium().filter(u => u.expired > now)
}

let handler = async (m, { yonz, text, isOwner }) => {

    if (text && text.startsWith('addprem ') && isOwner) {
        const target = text.split(' ')[1]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        const hari   = parseInt(text.split(' ')[2]) || 30
        const result = addPrem(target, hari, m.sender)
        const exp    = new Date(result.expired).toLocaleString('id-ID')
        return m.reply(`✅ Berhasil tambah premium!\n📱 JID: ${target}\n⏳ Expired: ${exp}\n📅 Durasi: ${hari} hari`)
    }

    if (text && text.startsWith('delprem ') && isOwner) {
        const target = text.split(' ')[1]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        const ok = delPrem(target)
        return m.reply(ok ? `✅ Premium ${target} berhasil dihapus!` : `❌ User tidak ditemukan di list premium.`)
    }

    if (text && text === 'listprem' && isOwner) {
        const list = getPremList()
        if (!list.length) return m.reply('📋 Tidak ada user premium aktif.')
        const teks = list.map((u, i) => {
            const exp = new Date(u.expired).toLocaleString('id-ID')
            return `${i + 1}. ${u.jid}\n   ⏳ Expired: ${exp}`
        }).join('\n\n')
        return m.reply(`👑 *List Premium Aktif*\n\n${teks}`)
    }

    if (!isPrem(m.sender)) {
        return m.reply(global.mess.prem)
    }

    const q    = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!text) {
        return m.reply('Contoh:\n.yonzedit ubah menjadi anime')
    }

    if (!mime.startsWith('image/')) {
        return m.reply('❌ Reply image dulu!')
    }

    await m.reply(global.mess.wait)

    try {
        const image = await q.download()
        const blob  = new Blob([image], { type: mime })
        const form  = new FormData()
        form.append('image', blob, 'image.jpg')
        form.append('prompt', text)
        form.append('apikey', 'Yonz')

        const res = await fetch('https://api.theresav.biz.id/ai/deepai/edit', {
            method: 'POST',
            body: form
        })

        if (!res.ok) throw await res.text()

        const buffer = Buffer.from(await res.arrayBuffer())

        await yonz.sendMessage(m.chat, {
            image: buffer,
            caption: `${global.mess.done}\n\n🖊️ Prompt: ${text}`
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply(global.mess.error)
    }
}

handler.help    = ['editimg <prompt>']
handler.tags    = ['ai']
handler.command = ['yonzedit']
handler.premium = true
handler.limit   = true

module.exports = handler
