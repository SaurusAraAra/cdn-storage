// ====================================================
// JAVASCRIPT: STARSOUND LOGIC
// ====================================================

const searchInput = document.getElementById('search-input');
const audio = document.getElementById('audio-player');

// Element Status (Banner)
const bannerTitle = document.getElementById('banner-title');
const bannerDesc = document.getElementById('banner-desc');
const bannerIcon = document.getElementById('banner-icon');
const homeBanner = document.getElementById('home-banner');
const toast = document.getElementById('toast');

// Elements Player UI
const miniPlayer = document.getElementById('player');
const fullPlayer = document.getElementById('fp');

// Fullscreen Player Elements
const fpThumb = document.getElementById('fp-thumb');
const fpTitle = document.getElementById('fp-title');
const fpArtist = document.getElementById('fp-artist');
const fpBgImg = document.getElementById('fp-bg-img');
const fpPlayBtn = document.getElementById('fp-play-btn');
const fpPlayIcon = fpPlayBtn.querySelector('i');

// Mini Player Elements
const plThumb = document.getElementById('pl-thumb');
const plTitle = document.getElementById('pl-title');
const plArtist = document.getElementById('pl-artist');
const plPlayBtn = document.getElementById('pl-play-btn');
const plPlayIcon = plPlayBtn.querySelector('i');

// Progress Control
const progressBar = document.getElementById('progress-bar');
const currentTimeEl = document.getElementById('current-time');
const totalTimeEl = document.getElementById('total-time');

let isDraggingProgress = false;

// Buka / Tutup Fullscreen Player
function openFullscreenPlayer() {
    fullPlayer.classList.add('on');
}

function closeFullscreenPlayer() {
    fullPlayer.classList.remove('on');
}

// Tampilkan Toast Message
function showToast(message) {
    toast.innerText = message;
    toast.style.display = 'block';
    toast.style.animation = 'none';
    setTimeout(() => (toast.style.animation = ''), 10);
    setTimeout(() => (toast.style.display = 'none'), 3000);
}

// --- Helper: Format Waktu ---
function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// --- Helper: Update Range Progress Color ---
function updateRangeBackground(val, max) {
    const percentage = max ? (val / max) * 100 : 0;
    progressBar.style.background = `linear-gradient(to right, var(--gr) ${percentage}%, rgba(255,255,255,0.15) ${percentage}%)`;
}

// Tampilkan State Loading
function showLoading(query) {
    audio.pause();
    audio.src = '';

    // Set Icon to Play
    setPlayIcon(true);
    progressBar.value = 0;
    currentTimeEl.innerText = '0:00';
    updateRangeBackground(0, 100);

    // Update Banner
    homeBanner.style.borderColor = 'rgba(34,197,94,0.4)';
    bannerIcon.innerHTML = '<div class="spinner"></div>';
    bannerTitle.innerText = 'Mencari Lagu...';
    bannerDesc.innerText = `Menyelaraskan "${query}" dari server.`;

    // Set Dummy info to players
    const dummyTxt = 'Mencari...';
    fpTitle.innerText = dummyTxt;
    fpArtist.innerText = query;
    plTitle.innerText = dummyTxt;
    plArtist.innerText = query;
}

// --- Update UI saat lagu ketemu ---
function updateUI(title, artist, coverUrl, durationStr) {
    // Update Fullscreen Player
    fpTitle.innerText = title;
    fpArtist.innerText = artist;
    fpThumb.src = coverUrl;
    fpBgImg.style.backgroundImage = `url('${coverUrl}')`;
    fpBgImg.classList.add('loaded');

    // Update Mini Player
    plTitle.innerText = title;
    plArtist.innerText = artist;
    plThumb.src = coverUrl;

    // Update Time
    totalTimeEl.innerText = durationStr || '0:00';

    // Update Banner Status
    homeBanner.style.borderColor = 'rgba(34,197,94,0.15)';
    bannerIcon.innerHTML = '<i class="fas fa-play"></i>';
    bannerTitle.innerText = 'Sedang Memutar';
    bannerDesc.innerText = `${title} - ${artist}`;

    // Tampilkan Mini Player jika masih tersembunyi
    miniPlayer.classList.add('on');
}

function showError(message) {
    bannerIcon.innerHTML =
        '<i class="fas fa-exclamation-triangle" style="color:#e74c3c"></i>';
    bannerTitle.innerText = 'Gagal';
    bannerDesc.innerText = message;
    showToast(message);
}

// --- Fetch API ---
async function fetchAndPlayMusic(query) {
    if (!query.trim()) return;

    showLoading(query);

    try {
        const url = `https://api-faa.my.id/faa/ytplay?query=${encodeURIComponent(query)}`;
        const response = await fetch(url);
        const data = await response.json();

        if (data.status === true && data.result) {
            const { title, author, thumbnail, mp3, duration_timestamp } = data.result;

            updateUI(title, author, thumbnail, duration_timestamp);
            audio.src = mp3;

            try {
                await audio.play();
            } catch (err) {
                showToast('Ketuk tombol putar untuk memulai audio.');
            }
        } else {
            showError('Lagu tidak ditemukan. Coba judul lain.');
        }
    } catch (error) {
        showError('Gagal memuat lagu. Cek koneksi Anda.');
    }
}

// --- Trigger Cari ---
function triggerSearch() {
    if (searchInput.value) {
        fetchAndPlayMusic(searchInput.value);
        searchInput.blur();
    }
}

searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        triggerSearch();
    }
});

// --- Tombol Play/Pause Global ---
function togglePlayPause() {
    if (!audio.src) return;
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
    }
}

function setPlayIcon(isPaused) {
    const iconClass = isPaused ? 'fas fa-play' : 'fas fa-pause';
    const margin = isPaused ? '4px' : '0';

    fpPlayIcon.className = iconClass;
    fpPlayIcon.style.marginLeft = margin;

    plPlayIcon.className = iconClass;
    plPlayIcon.style.marginLeft = margin;
}

audio.addEventListener('play', () => setPlayIcon(false));
audio.addEventListener('pause', () => setPlayIcon(true));

// --- Event Audio Waktu ---
audio.addEventListener('loadedmetadata', () => {
    progressBar.max = Math.floor(audio.duration);
    totalTimeEl.innerText = formatTime(audio.duration);
});

audio.addEventListener('timeupdate', () => {
    if (!isDraggingProgress) {
        progressBar.value = Math.floor(audio.currentTime);
        currentTimeEl.innerText = formatTime(audio.currentTime);
        updateRangeBackground(audio.currentTime, audio.duration);
    }
});

audio.addEventListener('ended', () => {
    setPlayIcon(true);
    progressBar.value = 0;
    currentTimeEl.innerText = '0:00';
    updateRangeBackground(0, audio.duration);
});

// --- Event Progress Bar ---
progressBar.addEventListener('mousedown', () => (isDraggingProgress = true));
progressBar.addEventListener('touchstart', () => (isDraggingProgress = true));

progressBar.addEventListener('input', (e) => {
    currentTimeEl.innerText = formatTime(e.target.value);
    updateRangeBackground(e.target.value, audio.duration || 100);
});

progressBar.addEventListener('mouseup', (e) => {
    isDraggingProgress = false;
    if (audio.src) audio.currentTime = e.target.value;
});

progressBar.addEventListener('touchend', (e) => {
    isDraggingProgress = false;
    if (audio.src) audio.currentTime = e.target.value;
});

// --- Muat Lagu Pertama ---
window.addEventListener('DOMContentLoaded', () => {
    const initialSong = '';
    searchInput.value = initialSong;
    fetchAndPlayMusic(initialSong);
});