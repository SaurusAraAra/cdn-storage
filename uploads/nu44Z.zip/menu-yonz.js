require('./settings');
require('./yonz-cmd');
const fs = require('fs');
const chalk = require('chalk');


global.menufun = `
╭➤-----「 MENU FUN 」
┆𖢷 ׁ 𖹭₊ .sticker
┆𖢷 ׁ 𖹭₊ .brat
┆𖢷 ׁ 𖹭₊ .qc
┆𖢷 ׁ 𖹭₊ .dana
╰➤-------------------------------`

global.menuenc = `
╭➤-----「 MENU ENC 」
┆𖢷 ׁ 𖹭₊ .enccustom
┆𖢷 ׁ 𖹭₊ .enc-custom
┆𖢷 ׁ 𖹭₊ .customenc
┆𖢷 ׁ 𖹭₊ .encrypt-custom
┆𖢷 ׁ 𖹭₊ .enccustomjs
┆𖢷 ׁ 𖹭₊ .encryptcustomjs
┆𖢷 ׁ 𖹭₊ .customjsen
┆𖢷 ׁ 𖹭₊ .jscustomenc
┆𖢷 ׁ 𖹭₊ .encsiu
┆𖢷 ׁ 𖹭₊ .encryptsiu
┆𖢷 ׁ 𖹭₊ .encrypt-siu
┆𖢷 ׁ 𖹭₊ .siuenc
┆𖢷 ׁ 𖹭₊ .siu-encrypt
┆𖢷 ׁ 𖹭₊ .enc-siu
┆𖢷 ׁ 𖹭₊ .encsiujs
┆𖢷 ׁ 𖹭₊ .jssiienc
┆𖢷 ׁ 𖹭₊ .siujsen
┆𖢷 ׁ 𖹭₊ .encstrong
┆𖢷 ׁ 𖹭₊ .encryptstrong
┆𖢷 ׁ 𖹭₊ .encrypt-strong
┆𖢷 ׁ 𖹭₊ .strong
┆𖢷 ׁ 𖹭₊ .strongenc
┆𖢷 ׁ 𖹭₊ .strong-encrypt
┆𖢷 ׁ 𖹭₊ .enc-strong
┆𖢷 ׁ 𖹭₊ .encstrongjs
┆𖢷 ׁ 𖹭₊ .jsstrongenc
┆𖢷 ׁ 𖹭₊ .strongjsen
┆𖢷 ׁ 𖹭₊ .encultra
┆𖢷 ׁ 𖹭₊ .encryptultra
┆𖢷 ׁ 𖹭₊ .encrypt-ultra
┆𖢷 ׁ 𖹭₊ .ultraenc
┆𖢷 ׁ 𖹭₊ .ultra-encrypt
┆𖢷 ׁ 𖹭₊ .enc-ultra
┆𖢷 ׁ 𖹭₊ .encultrajs
┆𖢷 ׁ 𖹭₊ .jsultraenc
┆𖢷 ׁ 𖹭₊ .ultrajsen
╰➤-------------------------------`

global.menunsfw = `
╭➤-----「 MENU NSFW 」
┆𖢷 ׁ 𖹭₊ .nsfwass
┆𖢷 ׁ 𖹭₊ .nsfwhentai
┆𖢷 ׁ 𖹭₊ .nsfwgangbang
┆𖢷 ׁ 𖹭₊ .nsfwkasedaiki
┆𖢷 ׁ 𖹭₊ .nsfwmanstrubation
╰➤-------------------------------`

global.menusearch = `
╭➤-----「 MENU SEARCH 」
┆𖢷 ׁ 𖹭₊ .pin
┆𖢷 ׁ 𖹭₊ .pinterest
┆𖢷 ׁ 𖹭₊ .bstation
┆𖢷 ׁ 𖹭₊ .bstation1 
┆𖢷 ׁ 𖹭₊ .animesearch
┆𖢷 ׁ 𖹭₊ .playtiktok
╰➤-------------------------------`

global.menuanime = `
╭➤-----「 MENU ANIME 」
┆𖢷 ׁ 𖹭₊ .acdb
┆𖢷 ׁ 𖹭₊ .animechars
┆𖢷 ׁ 𖹭₊ .animedetail
┆𖢷 ׁ 𖹭₊ .animeinfo
┆𖢷 ׁ 𖹭₊ .birthdays
┆𖢷 ׁ 𖹭₊ .acdbbirthday
┆𖢷 ׁ 𖹭₊ .acdbbirthday2
┆𖢷 ׁ 𖹭₊ .char
┆𖢷 ׁ 𖹭₊ .character
┆𖢷 ׁ 𖹭₊ .acdbchar
┆𖢷 ׁ 𖹭₊ .chargallery
┆𖢷 ׁ 𖹭₊ .height
┆𖢷 ׁ 𖹭₊ .acheight
┆𖢷 ׁ 𖹭₊ .charheight
┆𖢷 ׁ 𖹭₊ .al
┆𖢷 ׁ 𖹭₊ .anilatest
┆𖢷 ׁ 𖹭₊ .anichinlatest
┆𖢷 ׁ 𖹭₊ .apop
┆𖢷 ׁ 𖹭₊ .apopular
┆𖢷 ׁ 𖹭₊ .anichinpopular
╰➤-------------------------------`

global.menutools = `
╭➤-----「 MENU TOOLS 」
┆𖢷 ׁ 𖹭₊ .hd
┆𖢷 ׁ 𖹭₊ .totalfitur
┆𖢷 ׁ 𖹭₊ .shortlink
┆𖢷 ׁ 𖹭₊ .tourl
┆𖢷 ׁ 𖹭₊ .tomp3
┆𖢷 ׁ 𖹭₊ .ssweb
┆𖢷 ׁ 𖹭₊ .getpp
┆𖢷 ׁ 𖹭₊ .me
┆𖢷 ׁ 𖹭₊ .profil
╰➤-------------------------------`

global.menumaker = `
╭➤-----「 MENU MAKER 」
┆𖢷 ׁ 𖹭₊ .s
┆𖢷 ׁ 𖹭₊ .brat
┆𖢷 ׁ 𖹭₊ .luma
┆𖢷 ׁ 𖹭₊ .img2video 
┆𖢷 ׁ 𖹭₊ .fakedev
┆𖢷 ׁ 𖹭₊ .bratcewe
┆𖢷 ׁ 𖹭₊ .bratanime
┆𖢷 ׁ 𖹭₊ .bratanime2
┆𖢷 ׁ 𖹭₊ .bratpatrick
┆𖢷 ׁ 𖹭₊ .bratkobato
┆𖢷 ׁ 𖹭₊ .bratqiqi
┆𖢷 ׁ 𖹭₊ .bratvid
┆𖢷 ׁ 𖹭₊ .bratgif
┆𖢷 ׁ 𖹭₊ .bratumaru
┆𖢷 ׁ 𖹭₊ .bratruromiya
┆𖢷 ׁ 𖹭₊ .fakestory
┆𖢷 ׁ 𖹭₊ .fakewa
┆𖢷 ׁ 𖹭₊ .fakewafat
┆𖢷 ׁ 𖹭₊ .quotes
┆𖢷 ׁ 𖹭₊ .fakeml
┆𖢷 ׁ 𖹭₊ .fakektp
┆𖢷 ׁ 𖹭₊ .fakengl
┆𖢷 ׁ 𖹭₊ .tofigure
┆𖢷 ׁ 𖹭₊ .toalt
┆𖢷 ׁ 𖹭₊ .toalbino
┆𖢷 ׁ 𖹭₊ .toamethyst
┆𖢷 ׁ 𖹭₊ .toalternate
╰➤-------------------------------`

global.menudownload = `
╭➤-----「 MENU DOWNLOADER 」
┆𖢷 ׁ 𖹭₊ .Ig
┆𖢷 ׁ 𖹭₊ .fb
┆𖢷 ׁ 𖹭₊ .cc
┆𖢷 ׁ 𖹭₊ .tt
┆𖢷 ׁ 𖹭₊ .yt
┆𖢷 ׁ 𖹭₊ .tiktok
┆𖢷 ׁ 𖹭₊ .ytmp4
┆𖢷 ׁ 𖹭₊ .tomp3
┆𖢷 ׁ 𖹭₊ .youtube
╰➤-------------------------------`

global.menuai = `
╭➤-----「 MENU AI 」
┆𖢷 ׁ 𖹭₊ .ai
┆𖢷 ׁ 𖹭₊ .kimiai
┆𖢷 ׁ 𖹭₊ .gemini 
┆𖢷 ׁ 𖹭₊ .chatgpt
┆𖢷 ׁ 𖹭₊ .Nova
┆𖢷 ׁ 𖹭₊ .yonzedit
┆𖢷 ׁ 𖹭₊ .aiedit
┆𖢷 ׁ 𖹭₊ .nano
╰➤-------------------------------`

global.menustore = `
╭➤-----「 MENU STORE 」
┆𖢷 ׁ 𖹭₊ .list
┆𖢷 ׁ 𖹭₊ .addlist
┆𖢷 ׁ 𖹭₊ .dellist
┆𖢷 ׁ 𖹭₊ .clearlist
┆𖢷 ׁ 𖹭₊ .jpm
╰➤-------------------------------`

global.menurpg = `
╭➤--「 RPG GAME MENU 」
┆𖢷 ׁ 𖹭₊ .rpgstart
┆𖢷 ׁ 𖹭₊ .warrior
┆𖢷 ׁ 𖹭₊ .mage
┆𖢷 ׁ 𖹭₊ .archer
┆𖢷 ׁ 𖹭₊ .rpgstats
┆𖢷 ׁ 𖹭₊ .rpghelp
┆𖢷 ׁ 𖹭₊ .info
┆𖢷 ׁ 𖹭₊ .rpgexplore
┆𖢷 ׁ 𖹭₊ .attack
┆𖢷 ׁ 𖹭₊ .skill
┆𖢷 ׁ 𖹭₊ .heal
┆𖢷 ׁ 𖹭₊ .mana
┆𖢷 ׁ 𖹭₊ .flee
┆𖢷 ׁ 𖹭₊ .rpgmove
┆𖢷 ׁ 𖹭₊ .dungeon
┆𖢷 ׁ 𖹭₊ .pvp
┆𖢷 ׁ 𖹭₊ .rpginv
┆𖢷 ׁ 𖹭₊ .rpginventory
┆𖢷 ׁ 𖹭₊ .item
┆𖢷 ׁ 𖹭₊ .use
┆𖢷 ׁ 𖹭₊ .equip
┆𖢷 ׁ 𖹭₊ .unequip
┆𖢷 ׁ 𖹭₊ .drop
┆𖢷 ׁ 𖹭₊ .buang
┆𖢷 ׁ 𖹭₊ .give
┆𖢷 ׁ 𖹭₊ .berikan
┆𖢷 ׁ 𖹭₊ .rpgshop
┆𖢷 ׁ 𖹭₊ .buy
┆𖢷 ׁ 𖹭₊ .sell
┆𖢷 ׁ 𖹭₊ .craft
┆𖢷 ׁ 𖹭₊ .meramu
┆𖢷 ׁ 𖹭₊ .shopfood
┆𖢷 ׁ 𖹭₊ .shoprod
┆𖢷 ׁ 𖹭₊ .shopbomber
┆𖢷 ׁ 𖹭₊ .cekuang
┆𖢷 ׁ 𖹭₊ .topgold
┆𖢷 ׁ 𖹭₊ .topkaya
┆𖢷 ׁ 𖹭₊ .bank
┆𖢷 ׁ 𖹭₊ .setor
┆𖢷 ׁ 𖹭₊ .tarik
┆𖢷 ׁ 𖹭₊ .topbank
┆𖢷 ׁ 𖹭₊ .tfuang
┆𖢷 ׁ 𖹭₊ .pasifincome
┆𖢷 ׁ 𖹭₊ .simpanaset
┆𖢷 ׁ 𖹭₊ .tarikaset
┆𖢷 ׁ 𖹭₊ .market
┆𖢷 ׁ 𖹭₊ .beli
┆𖢷 ׁ 𖹭₊ .ceksaham
┆𖢷 ׁ 𖹭₊ .portofolio
┆𖢷 ׁ 𖹭₊ .jualsaham
┆𖢷 ׁ 𖹭₊ .jualaset
┆𖢷 ׁ 𖹭₊ .jualasetbot
┆𖢷 ׁ 𖹭₊ .batallisting
┆𖢷 ׁ 𖹭₊ .kerja
┆𖢷 ׁ 𖹭₊ .jobkerja
┆𖢷 ׁ 𖹭₊ .listkerja
┆𖢷 ׁ 𖹭₊ .kerjalist
┆𖢷 ׁ 𖹭₊ .pekerjaan
┆𖢷 ׁ 𖹭₊ .listpekerjaan
┆𖢷 ׁ 𖹭₊ .ambilkerja
┆𖢷 ׁ 𖹭₊ .pilihkerja
┆𖢷 ׁ 𖹭₊ .daftarkerja
┆𖢷 ׁ 𖹭₊ .misikerja
┆𖢷 ׁ 𖹭₊ .kerjamisi
┆𖢷 ׁ 𖹭₊ .misipekerjaan
┆𖢷 ׁ 𖹭₊ .misi
┆𖢷 ׁ 𖹭₊ .kerjakanmisi
┆𖢷 ׁ 𖹭₊ .belajarkerja
┆𖢷 ׁ 𖹭₊ .pelajarikerja
┆𖢷 ׁ 𖹭₊ .skillkerja
┆𖢷 ׁ 𖹭₊ .infokerja
┆𖢷 ׁ 𖹭₊ .berhentikerja
┆𖢷 ׁ 𖹭₊ .keluarkerja
┆𖢷 ׁ 𖹭₊ .resignkerja
┆𖢷 ׁ 𖹭₊ .gajian
┆𖢷 ׁ 𖹭₊ .ngojek
┆𖢷 ׁ 𖹭₊ .ngaji
┆𖢷 ׁ 𖹭₊ .berkebun
┆𖢷 ׁ 𖹭₊ .daily
┆𖢷 ׁ 𖹭₊ .quest
┆𖢷 ׁ 𖹭₊ .sawit
┆𖢷 ׁ 𖹭₊ .tanamsawit
┆𖢷 ׁ 𖹭₊ .panensawit
┆𖢷 ׁ 𖹭₊ .jualsawit
┆𖢷 ׁ 𖹭₊ .topsawit
┆𖢷 ׁ 𖹭₊ .topuangsawit
┆𖢷 ׁ 𖹭₊ .bajaksawit
┆𖢷 ׁ 𖹭₊ .tambang
┆𖢷 ׁ 𖹭₊ .mining
┆𖢷 ׁ 𖹭₊ .besi
┆𖢷 ׁ 𖹭₊ .nikel
┆𖢷 ׁ 𖹭₊ .emas
┆𖢷 ׁ 𖹭₊ .berlian
┆𖢷 ׁ 𖹭₊ .foraging
┆𖢷 ׁ 𖹭₊ .mancingstart
┆𖢷 ׁ 𖹭₊ .mancing
┆𖢷 ׁ 𖹭₊ .tasikan
┆𖢷 ׁ 𖹭₊ .topmancing
┆𖢷 ׁ 𖹭₊ .jualikanbot
┆𖢷 ׁ 𖹭₊ .jualikan
┆𖢷 ׁ 𖹭₊ .pasarikan
┆𖢷 ׁ 𖹭₊ .setujuikan
┆𖢷 ׁ 𖹭₊ .tolakikan
┆𖢷 ׁ 𖹭₊ .tawarikan
┆𖢷 ׁ 𖹭₊ .batalkanikan
┆𖢷 ׁ 𖹭₊ .nelayan
┆𖢷 ׁ 𖹭₊ .beliperahu
┆𖢷 ׁ 𖹭₊ .listperahu
┆𖢷 ׁ 𖹭₊ .gantiperahu
┆𖢷 ׁ 𖹭₊ .nelayanstart
┆𖢷 ׁ 𖹭₊ .turunkanjaring
┆𖢷 ׁ 𖹭₊ .naikanjaring
┆𖢷 ׁ 𖹭₊ .masukanikan
┆𖢷 ׁ 𖹭₊ .jualikannelayan
┆𖢷 ׁ 𖹭₊ .adopsipet
┆𖢷 ׁ 𖹭₊ .adoptpet
┆𖢷 ׁ 𖹭₊ .infopet
┆𖢷 ׁ 𖹭₊ .petinfo
┆𖢷 ׁ 𖹭₊ .akuarium
┆𖢷 ׁ 𖹭₊ .peliharaikan
┆𖢷 ׁ 𖹭₊ .makankanikan
┆𖢷 ׁ 𖹭₊ .lepaskan
┆𖢷 ׁ 𖹭₊ .aduikan
┆𖢷 ׁ 𖹭₊ .infoaduikan
┆𖢷 ׁ 𖹭₊ .begal
┆𖢷 ׁ 𖹭₊ .maling
┆𖢷 ׁ 𖹭₊ .jualbot
┆𖢷 ׁ 𖹭₊ .slot
┆𖢷 ׁ 𖹭₊ .slots
┆𖢷 ׁ 𖹭₊ .buatclan
┆𖢷 ׁ 𖹭₊ .listclan
┆𖢷 ׁ 𖹭₊ .gabukclan
┆𖢷 ׁ 𖹭₊ .keluarclan
┆𖢷 ׁ 𖹭₊ .infoclan
┆𖢷 ׁ 𖹭₊ .renameclan
┆𖢷 ׁ 𖹭₊ .kickclan
┆𖢷 ׁ 𖹭₊ .transferclan
┆𖢷 ׁ 𖹭₊ .depositclan
┆𖢷 ׁ 𖹭₊ .serangclan
┆𖢷 ׁ 𖹭₊ .rampokclan
┆𖢷 ׁ 𖹭₊ .tokoclan
┆𖢷 ׁ 𖹭₊ .beliclan
┆𖢷 ׁ 𖹭₊ .clanhelp
┆𖢷 ׁ 𖹭₊ .lamar
┆𖢷 ׁ 𖹭₊ .terima
┆𖢷 ׁ 𖹭₊ .tolak
┆𖢷 ׁ 𖹭₊ .cerai
┆𖢷 ׁ 𖹭₊ .infopasangan
┆𖢷 ׁ 𖹭₊ .kencan
┆𖢷 ׁ 𖹭₊ .harmoni
┆𖢷 ׁ 𖹭₊ .cekharmoni
┆𖢷 ׁ 𖹭₊ .kadoanniversary
┆𖢷 ׁ 𖹭₊ .buatanak
┆𖢷 ׁ 𖹭₊ .rawatanak
┆𖢷 ׁ 𖹭₊ .belimakanan
┆𖢷 ׁ 𖹭₊ .nafkah
┆𖢷 ׁ 𖹭₊ .infoanak
┆𖢷 ׁ 𖹭₊ .kerjaanak
┆𖢷 ׁ 𖹭₊ .sekolahkan
┆𖢷 ׁ 𖹭₊ .rapotanak
┆𖢷 ׁ 𖹭₊ .kadoanak
┆𖢷 ׁ 𖹭₊ .buanganak
┆𖢷 ׁ 𖹭₊ .hapusanak
┆𖢷 ׁ 𖹭₊ .makanbersama
┆𖢷 ׁ 𖹭₊ .liburankeluarga
┆𖢷 ׁ 𖹭₊ .fotobersama
┆𖢷 ׁ 𖹭₊ .statkeluarga
┆𖢷 ׁ 𖹭₊ .topkeluarga
┆𖢷 ׁ 𖹭₊ .cekevent
┆𖢷 ׁ 𖹭₊ .lifehelp
┆𖢷 ׁ 𖹭₊ .hargasimulator
┆𖢷 ׁ 𖹭₊ .simulatorhelp
┆𖢷 ׁ 𖹭₊ .belirumahtinggal
┆𖢷 ׁ 𖹭₊ .renovasirumah
┆𖢷 ׁ 𖹭₊ .inforumah
┆𖢷 ׁ 𖹭₊ .pantiasuhan
┆𖢷 ׁ 𖹭₊ .leaderboardrpg
┆𖢷 ׁ 𖹭₊ .lb_rpg
┆𖢷 ׁ 𖹭₊ .adduang
┆𖢷 ׁ 𖹭₊ .kuranguang
┆𖢷 ׁ 𖹭₊ .resetuang
┆𖢷 ׁ 𖹭₊ .resetuangall
┆𖢷 ׁ 𖹭₊ .editgold
┆𖢷 ׁ 𖹭₊ .editbank
┆𖢷 ׁ 𖹭₊ .resetgoldall
┆𖢷 ׁ 𖹭₊ .resetgolduser
┆𖢷 ׁ 𖹭₊ .resetbankall
┆𖢷 ׁ 𖹭₊ .resetasetall
┆𖢷 ׁ 𖹭₊ .resetkeluargaall
┆𖢷 ׁ 𖹭₊ .resetkeluargauser
┆𖢷 ׁ 𖹭₊ .resetpanti
╰➤-------------------------------`

global.menugame = `
╭➤-----「 MENU GAME 」
┆𖢷 ׁ 𖹭₊ .asahotak 
┆𖢷 ׁ 𖹭₊ .lengkapikalimat
┆𖢷 ׁ 𖹭₊ .tebakgambar 
┆𖢷 ׁ 𖹭₊ .family100
┆𖢷 ׁ 𖹭₊ .ceklontong
┆𖢷 ׁ 𖹭₊ .cekotak
┆𖢷 ׁ 𖹭₊ .cekpasangan
┆𖢷 ׁ 𖹭₊ .cekjodoh
╰➤-----------------------------`

global.menugroup = `
╭➤-----「 MENU GROUP 」
┆𖢷 ׁ 𖹭₊ .on
┆𖢷 ׁ 𖹭₊ .off
┆𖢷 ׁ 𖹭₊ .addlist
┆𖢷 ׁ 𖹭₊ .dellist
┆𖢷 ׁ 𖹭₊ .setlist
┆𖢷 ׁ 𖹭₊ .updatelist
┆𖢷 ׁ 𖹭₊ .resetlist
┆𖢷 ׁ 𖹭₊ .list
┆𖢷 ׁ 𖹭₊ .swgc
┆𖢷 ׁ 𖹭₊ .kick
┆𖢷 ׁ 𖹭₊ .promote
┆𖢷 ׁ 𖹭₊ .demote
┆𖢷 ׁ 𖹭₊ .tagall
┆𖢷 ׁ 𖹭₊ .hidetag
┆𖢷 ׁ 𖹭₊ .linkgc
┆𖢷 ׁ 𖹭₊ .resetlinkgc
┆𖢷 ׁ 𖹭₊ .opengc
┆𖢷 ׁ 𖹭₊ .closegc
┆𖢷 ׁ 𖹭₊ .leave
┆𖢷 ׁ 𖹭₊ .join
┆𖢷 ׁ 𖹭₊ .listgc
┆𖢷 ׁ 𖹭₊ .autocorrect
┆𖢷 ׁ 𖹭₊ .typo
┆𖢷 ׁ 𖹭₊ .idgc
┆𖢷 ׁ 𖹭₊ .getnumber
┆𖢷 ׁ 𖹭₊ .antifoto
┆𖢷 ׁ 𖹭₊ .antipromosi
┆𖢷 ׁ 𖹭₊ .antilinkgrup
┆𖢷 ׁ 𖹭₊ .antihidetag
┆𖢷 ׁ 𖹭₊ .wm
┆𖢷 ׁ 𖹭₊ .swm
┆𖢷 ׁ 𖹭₊ .stickerwm
┆𖢷 ׁ 𖹭₊ .stikerwm
╰➤-------------------------------`

global.menupanel = `
╭➤-----「 MENU PANEL 」
┆𖢷 ׁ 𖹭₊ .1gb
┆𖢷 ׁ 𖹭₊ .2gb
┆𖢷 ׁ 𖹭₊ .3gb
┆𖢷 ׁ 𖹭₊ .4gb
┆𖢷 ׁ 𖹭₊ .5gb
┆𖢷 ׁ 𖹭₊ .6gb
┆𖢷 ׁ 𖹭₊ .7gb
┆𖢷 ׁ 𖹭₊ .8gb
┆𖢷 ׁ 𖹭₊ .9gb
┆𖢷 ׁ 𖹭₊ .10gb
┆𖢷 ׁ 𖹭₊ .11gb
┆𖢷 ׁ 𖹭₊ .12gb
┆𖢷 ׁ 𖹭₊ .13gb
┆𖢷 ׁ 𖹭₊ .14gb
┆𖢷 ׁ 𖹭₊ .15gb
┆𖢷 ׁ 𖹭₊ .mypanel
┆𖢷 ׁ 𖹭₊ .listpanel
┆𖢷 ׁ 𖹭₊ .renew
┆𖢷 ׁ 𖹭₊ .renewserver
┆𖢷 ׁ 𖹭₊ .delsrv
┆𖢷 ׁ 𖹭₊ .deluser
┆𖢷 ׁ 𖹭₊ .notif
┆𖢷 ׁ 𖹭₊ .listuser
┆𖢷 ׁ 𖹭₊ .resource
╰➤-------------------------------`
global.menuowner = `
╭➤-----「 MENU OWNER 」
┆𖢷 ׁ 𖹭₊ .setaudiomenu
┆𖢷 ׁ 𖹭₊ .setimg
┆𖢷 ׁ 𖹭₊ .autoread
┆𖢷 ׁ 𖹭₊ .autoai
┆𖢷 ׁ 𖹭₊ .self
┆𖢷 ׁ 𖹭₊ .public
┆𖢷 ׁ 𖹭₊ .getsc
┆𖢷 ׁ 𖹭₊ .resetdb
┆𖢷 ׁ 𖹭₊ .setppbot
┆𖢷 ׁ 𖹭₊ .clearchat
┆𖢷 ׁ 𖹭₊ .addowner
┆𖢷 ׁ 𖹭₊ .delowner
┆𖢷 ׁ 𖹭₊ .listowner
┆𖢷 ׁ 𖹭₊ .addprem
┆𖢷 ׁ 𖹭₊ .delprem
┆𖢷 ׁ 𖹭₊ .listprem
┆𖢷 ׁ 𖹭₊ .cekprem
┆𖢷 ׁ 𖹭₊ .clearprem
┆𖢷 ׁ 𖹭₊ .addcase
┆𖢷 ׁ 𖹭₊ .delcase
┆𖢷 ׁ 𖹭₊ .addmenu
┆𖢷 ׁ 𖹭₊ .delmenu
┆𖢷 ׁ 𖹭₊ .addsewagc
┆𖢷 ׁ 𖹭₊ .listsewagc
┆𖢷 ׁ 𖹭₊ .delsewagc
┆𖢷 ׁ 𖹭₊ .setdaftar
┆𖢷 ׁ 𖹭₊ .setprefix
┆𖢷 ׁ 𖹭₊ .mute
┆𖢷 ׁ 𖹭₊ .listmute
┆𖢷 ׁ 𖹭₊ .renamebot
┆𖢷 ׁ 𖹭₊ .sch
┆𖢷 ׁ 𖹭₊ .sendch
╰➤-------------------------------`

global.allmenu = `
${global.menutools}\n${global.menumaker}\n${global.menugame}\n${global.menuanime}\n${global.menudownload}\n${global.menusearch}\n${global.menustore}\n${global.menunsfw}${global.menuai}\n${global.menufun}\n${global.menurpg}\n${global.menugroup}\n${global.menuenc}\n${global.menupanel}\n${global.menuowner}`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});