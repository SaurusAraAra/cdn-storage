// ©yonzofficial wa : wa.me/6285174301390
//jangan hapus credit!!!!

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
require('./menu-yonz')
if (!global.game) global.game = {}
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const FormData = require('form-data');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts");
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const webpmux = require('node-webpmux');
const { exec, spawn, execSync } = require('child_process');
const { ImageUploadService } = require('node-upload-images');
const ffmpeg = require('fluent-ffmpeg');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./source/message');
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
let prem = []
if (fs.existsSync("./library/database/premium.json")) {
    const data = fs.readFileSync("./library/database/premium.json", "utf8")
    if (data.trim()) {
        try {
            prem = JSON.parse(data)
            if (!Array.isArray(prem)) prem = []
            prem = prem.filter(u => u && typeof u === 'object' && u.jid)
        } catch (e) {
            prem = []
        }
    }
}
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

const pathList = './library/database/lists.json';
if (!fs.existsSync(pathList)) {
  fs.writeFileSync(pathList, JSON.stringify({}));
}
function loadLists() {
  try {
    return JSON.parse(fs.readFileSync(pathList));
  } catch (e) {
    fs.writeFileSync(pathList, JSON.stringify({}));
    return {};
  }
}

function saveLists(data) {
  fs.writeFileSync(pathList, JSON.stringify(data, null, 2));
}

if (!global.db) global.db = {};
if (!global.db.users) global.db.users = {};
if (!global.db.groups) global.db.groups = {};

function isRegistered(sender) {
    return true; 
}

function addRegisteredUser(sender, data = {}) {
    if (!global.db.users) global.db.users = {}
    global.db.users[sender] = {
        ...(global.db.users[sender] || {}),
        ...data,
        registered: true
    }
    return global.db.users[sender]
}

function checkLimit(sender, isPrem, isCreator) {
    if (isCreator || isPrem) return false;
    if (!global.db.users[sender]) {
        global.db.users[sender] = { limit: 25 };
    }
    return global.db.users[sender].limit <= 0;
}

function addLimit(sender, isPrem, isCreator) {
    if (isCreator || isPrem) return;
    if (!global.db.users[sender]) {
        global.db.users[sender] = { limit: 25 };
    }
    global.db.users[sender].limit -= 1;
}

const listSettingsPath = './library/database/list_settings.json';

function loadListSettings() {
    try {
        if (fs.existsSync(listSettingsPath)) {
            return JSON.parse(fs.readFileSync(listSettingsPath, 'utf8'));
        }
        return {};
    } catch (e) {
        return {};
    }
}

function saveListSettings(data) {
    fs.writeFileSync(listSettingsPath, JSON.stringify(data, null, 2));
}

function getListWithTemplate(chatId, userName, groupName, listItems) {
    const settings = loadListSettings();
    const chatSettings = settings[chatId];
    const sortedItems = [...listItems].sort((a, b) => {
        return a.name.localeCompare(b.name, 'id', { sensitivity: 'base' });
    });
    
    if (!chatSettings || !chatSettings.template) {
    let defaultText = `DAFTAR LIST\n\n`;
    sortedItems.forEach((item, index) => {
        defaultText += `${chatSettings?.prefix || "▣ "} ${item.name}\n`;
    });
    defaultText += `\nKetik nama item untuk melihat detail`;
    return defaultText;
}
    
    const now = moment().tz('Asia/Jakarta');
    const hour = now.hour();
    let waktuHari = '';
    
    if (hour >= 0 && hour < 5) waktuHari = 'Dini Hari';
    else if (hour >= 5 && hour < 10) waktuHari = 'Pagi';
    else if (hour >= 10 && hour < 15) waktuHari = 'Siang';
    else if (hour >= 15 && hour < 18) waktuHari = 'Sore';
    else if (hour >= 18 && hour < 24) waktuHari = 'Malam';
    
    const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const monthNames = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    const tanggalLengkap = `${dayNames[now.day()]}, ${now.date()} ${monthNames[now.month()]} ${now.year()}`;
    
    let template = chatSettings.template;
    template = template
        .replace(/@name/g, userName || 'User')
        .replace(/@group/g, groupName || 'Grup')
        .replace(/@time/g, now.format('HH:mm:ss'))
        .replace(/@date/g, now.format('DD/MM/YYYY'))
        .replace(/@fulldate/g, tanggalLengkap)
        .replace(/@daytime/g, waktuHari)
        .replace(/@x/g, sortedItems.map((item) => `${chatSettings?.prefix || "▣ "}${item.name}`).join('\n'))
        .replace(/@prefix\s+[^\n]+/gi, '');
    
    return template.trim();
}


async function downloadAndSaveMediaList(msg, type = 'image') {
    try {
        const mediaBuffer = await msg.download();
        const mediaDir = './library/media/list/';
        if (!fs.existsSync(mediaDir)) {
            fs.mkdirSync(mediaDir, { recursive: true });
        }
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(7);
        const filename = `${timestamp}_${random}.jpg`;
        const filepath = path.join(mediaDir, filename);
        fs.writeFileSync(filepath, mediaBuffer);
        return filepath;
    } catch (error) {
        throw error;
    }
}

const menuStylePath = './library/database/menustyle.json';
function getMenuStyle() {
    try {
        if (fs.existsSync(menuStylePath)) {
            const data = JSON.parse(fs.readFileSync(menuStylePath, 'utf8'));
            if (data && data.style) return data.style;
        }
    } catch (e) {}
    return 'v1';
}
function setMenuStyle(style) {
    try {
        const dir = path.dirname(menuStylePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(menuStylePath, JSON.stringify({ style }, null, 2));
        return true;
    } catch (e) {
        return false;
    }
}

// ================= Helper: Menu Info (cuaca, RAM, limit bar, total user, dll) =================
function safeReadJSON(filePath, fallback = []) {
    try {
        if (!fs.existsSync(filePath)) return fallback;
        const raw = fs.readFileSync(filePath, 'utf8');
        if (!raw || !raw.trim()) return fallback;
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed.filter(v => v !== null && v !== undefined);
        return parsed;
    } catch (e) {
        return fallback;
    }
}

function safeWriteJSON(filePath, data) {
    try {
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        return true;
    } catch (e) {
        return false;
    }
}

// ================= Levenshtein Distance (buat deteksi typo command) =================
function levenshtein(a, b) {
    a = String(a); b = String(b);
    const m = a.length, n = b.length;
    if (m === 0) return n;
    if (n === 0) return m;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,      // hapus
                dp[i][j - 1] + 1,      // tambah
                dp[i - 1][j - 1] + cost // ganti
            );
        }
    }
    return dp[m][n];
}

// ================= Auto Correct Command (deteksi typo) =================
const autoCorrectPath = './library/database/autocorrect.json';
function loadAutoCorrect() {
    return safeReadJSON(autoCorrectPath, {});
}
function saveAutoCorrect(data) {
    return safeWriteJSON(autoCorrectPath, data);
}
// Default AKTIF, kecuali sudah pernah dimatikan khusus untuk chat tsb atau secara global.
function isAutoCorrect(chatId) {
    const db = loadAutoCorrect();
    if (db[chatId] === false) return false;
    if (db[chatId] === undefined && db._global === false) return false;
    return true;
}

// ================= Sewa Grup (Rented Groups) =================
const sewaGcPath = './library/database/sewagc.json';
function loadSewaGc() {
    return safeReadJSON(sewaGcPath, {});
}
function saveSewaGc(data) {
    return safeWriteJSON(sewaGcPath, data);
}
function isGroupSewa(chatId) {
    const sewaDb = loadSewaGc();
    const g = sewaDb[chatId];
    if (!g) return false;
    if (g.expired && g.expired < Date.now()) return false;
    return true;
}

// ================= Daftar Command Valid (anti false-trigger "Belum Sewa") =================
// Dipakai supaya notifikasi "Grup Belum Sewa" hanya muncul saat user benar-benar
// memakai command yang terdaftar (case di switch), bukan setiap chat biasa yang
// ikut terhitung isCmd karena mode no-prefix global sedang aktif.
let _validCommandsCache = null;
function getValidCommands() {
    if (_validCommandsCache) return _validCommandsCache;
    const set = new Set();
    try {
        const src = fs.readFileSync(__filename, 'utf8');
        const regex = /case\s+["']([^"']+)["']\s*:/g;
        let match;
        while ((match = regex.exec(src)) !== null) {
            set.add(match[1].toLowerCase());
        }
    } catch (e) {}

    try {
        const pluginsPath = path.join(__dirname, 'plugins');
        if (fs.existsSync(pluginsPath)) {
            const files = fs.readdirSync(pluginsPath);
            for (const file of files) {
                if (!file.endsWith('.js')) continue;
                try {
                    const content = fs.readFileSync(path.join(pluginsPath, file), 'utf8');
                    const cmdArrayMatches = content.match(/command\s*:\s*\[([^\]]+)\]/gi) || [];
                    for (const m of cmdArrayMatches) {
                        const names = m.match(/["']([^"']+)["']/g) || [];
                        for (const n of names) set.add(n.replace(/["']/g, '').toLowerCase());
                    }
                } catch (e) {}
            }
        }
    } catch (e) {}

    _validCommandsCache = set;
    return _validCommandsCache;
}

// ================= Mute Grup (persist ke mutegc.json, support mute by ID) =================
const muteGcPath = './library/database/mutegc.json';
function loadMuteGc() {
    return safeReadJSON(muteGcPath, {});
}
function saveMuteGc(data) {
    return safeWriteJSON(muteGcPath, data);
}
function isGroupMuted(chatId) {
    const muteDb = loadMuteGc();
    return !!(muteDb[chatId] && muteDb[chatId].mute === true);
}

const AUTODL_TIKTOK_REGEX = /(https?:\/\/(?:vt|vm|www)\.?tiktok\.com\/[^\s]+)/i;
const AUTODL_IG_REGEX = /(https?:\/\/(?:www\.)?instagram\.com\/(?:p|reel|reels|tv|stories)\/[^\s]+)/i;

async function autoDownloadAIO(url) {
    try {
        const apiUrl = `${global.there}/download/aio?url=${encodeURIComponent(url)}&apikey=Yonz`;
        const res = await fetch(apiUrl);
        const json = await res.json();
        if (!json || json.status !== true) return null;

        const result = json.result || {};
        const medias = Array.isArray(result.medias) ? result.medias : [];

        const video = medias.find(md => md.type === 'video' && md.quality === 'hd_no_watermark')
            || medias.find(md => md.type === 'video' && md.quality === 'no_watermark')
            || medias.find(md => md.type === 'video');
        const audio = medias.find(md => md.type === 'audio');
        const images = medias.filter(md => md.type === 'image');

        return {
            title: result.title || '',
            platform: result.platform || '',
            video: video?.url || null,
            audio: audio?.url || null,
            images: images.map(im => im.url).filter(Boolean),
            medias
        };
    } catch (e) {
        console.log('autoDownloadAIO error:', e.message);
        return null;
    }
}

function getWIBTime() {
    return moment().tz('Asia/Jakarta').toDate();
}

function getTodayWIB() {
    return moment().tz('Asia/Jakarta').format('YYYY-MM-DD');
}

const limitUsagePath = './library/database/limitusage.json';
const dbPremPath = './library/database/premium.json';

// Cek apakah jid adalah premium yang masih aktif (baca langsung dari premium.json biar selalu fresh)
global.isPrem = (jid) => {
    const premDB = safeReadJSON(dbPremPath, []);
    return premDB.some(v => v && v.jid === jid && v.expired > Date.now());
};

function getPremiumDaysLeft(jid) {
    const premDB = safeReadJSON(dbPremPath, []);
    const user = premDB.find(v => v && v.jid === jid && v.expired > Date.now());
    if (!user) return 0;
    return Math.max(0, Math.ceil((user.expired - Date.now()) / (1000 * 60 * 60 * 24)));
}

function getUserMaxLimit(jid) {
    return global.isPrem(jid) ? (global.limitPremium || 100) : (global.limitFree || 15);
}

function getUsedToday(jid) {
    const usageDB = safeReadJSON(limitUsagePath, []);
    const today = getTodayWIB();
    const entry = usageDB.find(v => v && v.jid === jid);
    return (entry && entry.date === today) ? (entry.count || 0) : 0;
}

// Tambah pemakaian limit harian user. Panggil ini di command yang mau dibatasi limitnya.
function addLimitUsage(jid, amount = 1) {
    const usageDB = safeReadJSON(limitUsagePath, []);
    const today = getTodayWIB();
    let entry = usageDB.find(v => v && v.jid === jid);
    if (!entry) {
        entry = { jid, date: today, count: 0 };
        usageDB.push(entry);
    }
    if (entry.date !== today) {
        entry.date = today;
        entry.count = 0;
    }
    entry.count += amount;
    safeWriteJSON(limitUsagePath, usageDB);
    return entry.count;
}

function buildLimitBar(used, max, length = 10) {
    if (!isFinite(max) || max <= 0) return '█'.repeat(length);
    const filled = Math.min(Math.round((used / max) * length), length);
    const empty = length - filled;
    return '█'.repeat(Math.max(0, filled)) + '░'.repeat(Math.max(0, empty));
}

function getTotalRegisteredUsers() {
    try { return Object.keys(global.db?.users || {}).length; } catch (e) { return 0; }
}

function getTotalActiveSewa() {
    try { return Object.keys(global.db?.groups || {}).length; } catch (e) { return 0; }
}

// Ambil info cuaca dari BMKG berdasarkan kode wilayah (global.adm4)
async function getCuacaMenu(adm4 = global.adm4) {
    const fallback = { cuaca: 'Tidak diketahui', suhu: '-', emoji: '🌥️', kotkab: '-' };
    try {
        if (!adm4) return fallback;
        const res = await fetch(`https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=${adm4}`, { timeout: 8000 });
        const json = await res.json();
        const cuacaHariIni = json?.data?.[0]?.cuaca?.[0]?.[0];
        if (!cuacaHariIni) return fallback;
        const weather = cuacaHariIni.weather_desc || fallback.cuaca;
        const suhu = cuacaHariIni.t ?? fallback.suhu;
        let emoji = '🌥️';
        if (/cerah/i.test(weather)) emoji = '☀️';
        else if (/berawan/i.test(weather)) emoji = '☁️';
        else if (/hujan/i.test(weather)) emoji = '🌧️';
        else if (/petir/i.test(weather)) emoji = '⛈️';
        else if (/kabut/i.test(weather)) emoji = '🌫️';
        return { cuaca: weather, suhu, emoji, kotkab: json?.lokasi?.kotkab || fallback.kotkab };
    } catch (e) {
        return fallback;
    }
}

function getRamInfo() {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    return {
        used: formatp(usedMem),
        total: formatp(totalMem),
        percent: ((usedMem / totalMem) * 100).toFixed(1)
    };
}
// ================= End Helper Menu Info =================

module.exports = yonz = async (yonz, m, chatUpdate, store) => {
    try {
        await LoadDataBase(yonz, m)
const botNumber = await yonz.decodeJid(yonz.user.id)
const db = global.db
const mess = global.mess
const owner = global.owner
const botname = global.botname
const versi = global.versi
		const body = ((m.type === 'conversation') ? m.message.conversation :
		(m.type == 'imageMessage') ? m.message.imageMessage.caption :
		(m.type == 'videoMessage') ? m.message.videoMessage.caption :
		(m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text :
		(m.type == 'reactionMessage') ? m.message.reactionMessage.text :
		(m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId :
		(m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
		(m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId :
		(m.type == 'interactiveResponseMessage'  && m.quoted) ? (m.message.interactiveResponseMessage?.nativeFlowResponseMessage ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : '') :
		(m.type == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || '') :
		(m.type == 'editedMessage') ? (m.message.editedMessage?.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text || m.message.editedMessage?.message?.protocolMessage?.editedMessage?.conversation || '') :
		(m.type == 'protocolMessage') ? (m.message.protocolMessage?.editedMessage?.extendedTextMessage?.text || m.message.protocolMessage?.editedMessage?.conversation || m.message.protocolMessage?.editedMessage?.imageMessage?.caption || m.message.protocolMessage?.editedMessage?.videoMessage?.caption || '') : '') || '';
		const budy = (typeof m.text == 'string' ? m.text : '')

		let usedPrefix;
		const multiPrefix = ['.'];
		const processedText = body;

		const noPfxDBPath = './library/database/noprefix.json';
		const noPfxConfigPath = './library/database/nopfx_config.json';

		// Fungsi untuk cek status no-prefix
		function isNoPrefixEnabled() {
		    try {
		        if (!fs.existsSync(noPfxConfigPath)) {
		            fs.writeFileSync(noPfxConfigPath, JSON.stringify({ enabled: true }, null, 2));
		        }
		        const config = JSON.parse(fs.readFileSync(noPfxConfigPath));
		        return config.enabled === true;
		    } catch (e) {
		        return true; // default aktif
		    }
		}

		function loadNoPfx() {
		    try {
		        if (!fs.existsSync(noPfxDBPath)) {
		            fs.writeFileSync(noPfxDBPath, JSON.stringify({ global: [], groups: {} }, null, 2));
		        }
		        return JSON.parse(fs.readFileSync(noPfxDBPath));
		    } catch (e) {
		        return { global: [], groups: {} };
		    }
		}

		function saveNoPfx(data) {
		    try { fs.writeFileSync(noPfxDBPath, JSON.stringify(data, null, 2)); } catch(e) {}
		}

		function getNoPfxList(chatId) {
		    const db = loadNoPfx();
		    const globalList = Array.isArray(db.global) ? db.global : [];
		    const groupList = chatId && db.groups && Array.isArray(db.groups[chatId]) ? db.groups[chatId] : [];
		    return [...new Set([...globalList, ...groupList])];
		}

		// ========== CEK STATUS NO-PREFIX ==========
		const noPrefixEnabled = isNoPrefixEnabled();

		// Cek apakah pesan ini merupakan no-prefix command (hanya jika enabled)
		const _rawText = typeof processedText === 'string' ? processedText.trim() : '';
		const _firstWord = _rawText.split(/ +/)[0].toLowerCase();
		const _noPfxList = noPrefixEnabled ? getNoPfxList(m.chat) : [];
		// Jika no-prefix diaktifkan (on), SEMUA fitur/command bisa dipakai tanpa prefix.
		// Whitelist (_noPfxList) tetap dipakai sebagai fallback kalau suatu saat mode global dimatikan
		// tapi ada command tertentu yang tetap ingin bebas prefix.
		// Pesan yang berupa link (http/https) jangan dianggap sebagai no-prefix command,
		// supaya fitur autodownload (yang butuh isCmd === false) tetap bisa jalan.
		const _isPlainUrl = /^https?:\/\//i.test(_rawText);
		const _isNoPfxCmd = !_isPlainUrl && !multiPrefix.some(p => _rawText.startsWith(p)) && _rawText.length > 0 && (noPrefixEnabled || _noPfxList.includes(_firstWord));

		// Jika no-prefix command, perlakukan seolah pakai prefix '.'
		let _syntheticPrefix = '';
		if (_isNoPfxCmd) {
		    _syntheticPrefix = '.';
		    usedPrefix = '.';
		}

		const isCmd = (typeof processedText === 'string' && processedText.length > 0 && multiPrefix.some(p => processedText.startsWith(p))) || _isNoPfxCmd;
		const prefix = usedPrefix || '.';

		const args = _isNoPfxCmd
		    ? _rawText.split(/ +/).slice(1)
		    : (isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : body.trim().split(/ +/).slice(1));

		const getQuoted = (m.quoted || m)
		const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m

		const command = _isNoPfxCmd
		    ? _firstWord
		    : (isCmd ? processedText.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : '');
		const isPremium = prem.some(user => user && user.jid === m.sender && user.expired > Date.now())
		const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
		const isCreator2 = isCreator
		const text = q = args.join(' ')
		const mime = (quoted.msg || quoted).mimetype || ''
		const qmsg = (quoted.msg || quoted)

		const autoresponPath = "./library/database/autorespon/"
		if (!fs.existsSync(autoresponPath)) fs.mkdirSync(autoresponPath, { recursive: true })
		
		const mediaPath = "./library/database/media/"
		if (!fs.existsSync(mediaPath)) fs.mkdirSync(mediaPath, { recursive: true })
		
		const getCurrentTime = () => moment.tz("Asia/Jakarta").format("HH:mm")
		const getCurrentDate = () => moment.tz("Asia/Jakarta").format("DD/MM/YYYY")
		const getHari = () => {
			const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
			return days[moment.tz("Asia/Jakarta").day()]
		}
		const getGreeting = () => {
			const hour = moment.tz("Asia/Jakarta").hour()
			if (hour < 12) return "Pagi"
			if (hour < 15) return "Siang"
			if (hour < 18) return "Sore"
			return "Malam"
		}
		
		const downloadMediaFile = async (msg) => {
			try {
				if (!msg || !msg.message) return null
				const buffer = await yonz.downloadMediaMessage(msg)
				if (!buffer) return null
				const filename = `media_${Date.now()}_${Math.random().toString(36).substring(7)}.${mime.split('/')[1] || 'jpg'}`
				const filepath = path.join(mediaPath, filename)
				fs.writeFileSync(filepath, buffer)
				return filename
			} catch (e) {
				return null
			}
		}

		const getGroupAdminsList = async (chatId) => {
			try {
				const groupMetadata = await yonz.groupMetadata(chatId)
				const admins = []
				for (const p of groupMetadata.participants) {
					if (p.admin) {
						if (p.jid) admins.push(p.jid)
						if (p.id) admins.push(p.id)
						if (p.lid) admins.push(p.lid)
					}
				}
				return admins
			} catch (e) {
				return []
			}
		}

		const jidMatchesList = (jid, list) => {
			if (!jid) return false
			return list.some(x =>
				x === jid ||
				(jid.endsWith('@s.whatsapp.net') && x === jid.replace('@s.whatsapp.net', '@lid')) ||
				(jid.endsWith('@lid') && x === jid.replace('@lid', '@s.whatsapp.net'))
			)
		}

		const isUserAdminGroup = async (chatId, userId) => {
			try {
				const admins = await getGroupAdminsList(chatId)
				return admins.includes(userId)
			} catch (e) {
				return false
			}
		}

		if (m.isGroup && isGroupMuted(m.chat) && !isCreator) return

if (isCmd) {
    console.log(
        chalk.rgb(255, 0, 0).bold(`╭─〔 ★ `) +
        chalk.rgb(255, 165, 0).bold(`Yonz`) +
        chalk.rgb(255, 255, 0).bold(` official `) +
        chalk.rgb(0, 255, 0).bold(`${global.botname}`) +
        chalk.rgb(0, 255, 255).bold(`  ★  〕`) +
        chalk.rgb(0, 0, 255).bold(`\n│ ❀ Name     : `) +
        chalk.rgb(139, 0, 255).italic(m.pushName || 'Unknown') +
        chalk.rgb(255, 0, 255).bold(`\n│ ✧ From     : `) +
        chalk.rgb(255, 20, 147).italic(m.isGroup ? `Group - ${m.sender.split("@")[0]}` : m.sender.split("@")[0]) +
        chalk.rgb(255, 69, 0).bold(`\n│ ⟡ Command  : `) +
        chalk.rgb(50, 205, 50).italic(`${prefix + command}`) +
        chalk.rgb(0, 206, 209).bold(`\n╰─〔 ★ `) +
        chalk.rgb(30, 144, 255).bold(`Magic found`) +
        chalk.rgb(147, 112, 219).bold(` in every `) +
        chalk.rgb(255, 105, 180).bold(`journey`) +
        chalk.rgb(255, 215, 0).bold(` ★  〕\n\n`)
    )
}

		const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

		const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `clutch sigma`,jpegThumbnail: ""}}}

		if (m.isGroup && isGroupMuted(m.chat) && !isCreator) return

		let antiFeatureActive = m.isGroup && db.groups[m.chat] && (
			db.groups[m.chat].antilink == true ||
			db.groups[m.chat].antilink2 == true ||
			db.groups[m.chat].antihidetag == 'delete' || db.groups[m.chat].antihidetag == 'kick' ||
			db.groups[m.chat].antifoto == true ||
			db.groups[m.chat].antipromosi == true
		)
		let freshAdmins = []
		let senderIsAdmin = false
		let botIsAdmin = false
		if (antiFeatureActive && !isCreator && !m.fromMe) {
			freshAdmins = await getGroupAdminsList(m.chat)
			senderIsAdmin = jidMatchesList(m.sender, freshAdmins)
			botIsAdmin = jidMatchesList(botNumber, freshAdmins)
			if (!botIsAdmin) {
				console.log(chalk.yellow(`[ANTI-FITUR] Bot bukan admin di ${m.chat}, aksi hapus/kick dilewati.`))
				global.antiFeatureWarned = global.antiFeatureWarned || {}
				const lastWarned = global.antiFeatureWarned[m.chat] || 0
				if (Date.now() - lastWarned > 10 * 60 * 1000) {
					global.antiFeatureWarned[m.chat] = Date.now()
					await yonz.sendMessage(m.chat, {
						text: `⚠️ *Fitur Anti-Link/Hidetag/Foto/Promosi aktif tapi TIDAK BISA JALAN* karena bot belum dijadikan *admin* di grup ini.\n\nSilahkan jadikan bot sebagai admin grup agar fitur ini bisa menghapus pesan/mengeluarkan anggota.`
					}).catch(() => {})
				}
			}
		}
		
		
if (global.antilinkgrup?.[m.chat]?.status) {
    const messageText = m.body || '';
    const linkPatterns = [
        /https?:\/\/[^\s]+/i,
        /www\.[^\s]+/i,
        /chat\.whatsapp\.com/i,
        /wa\.me/i
    ];
    
    const isLink = linkPatterns.some(pattern => pattern.test(messageText));
    
    if (isLink && !m.isAdmin && !isCreator) {
        const setting = global.antilinkgrup[m.chat];
        try {
            if (setting.delete) {
                await yonz.sendMessage(m.chat, { delete: m.key });
            }

            if (setting.kick) {
                await yonz.groupParticipantsUpdate(m.chat, [m.sender], "remove");
                await yonz.sendMessage(m.chat, {
                    text: `🚫 @${m.sender.split('@')[0]} telah dikeluarkan karena mengirim link!`,
                    mentions: [m.sender]
                });
            }

            if (!setting.delete && !setting.kick) {
                await yonz.sendMessage(m.chat, {
                    text: `⚠️ @${m.sender.split('@')[0]} dilarang mengirim link!`,
                    mentions: [m.sender]
                });
            }
        } catch (e) {
            console.log(chalk.red(`[ANTILINK GRUP] Gagal hapus/kick di ${m.chat}: ${e?.message || e}`))
            if (!m.isBotAdmin) {
                await yonz.sendMessage(m.chat, { text: `⚠️ Anti Link Grup aktif tapi bot bukan admin, jadi tidak bisa hapus/kick.` }).catch(() => {})
            }
        }
        return;
    }
}

		if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
			var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
			if (link.test(m.text) && !isCreator && !senderIsAdmin && botIsAdmin && !m.fromMe) {
				var gclink = (`https://chat.whatsapp.com/` + await yonz.groupInviteCode(m.chat))
				var isLinkThisGc = new RegExp(gclink, 'i')
				var isgclink = isLinkThisGc.test(m.text)
				if (isgclink) return
				let delet = m.key.participant
				let bang = m.key.id
				try {
					await yonz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
					await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
					await sleep(1000)
					await yonz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
				} catch (e) {
					console.log(chalk.red(`[ANTILINK] Gagal hapus/kick di ${m.chat}: ${e?.message || e}`))
				}
			}}

		if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
			var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
			if (link.test(m.text) && !isCreator && !senderIsAdmin && botIsAdmin && !m.fromMe) {
				var gclink = (`https://chat.whatsapp.com/` + await yonz.groupInviteCode(m.chat))
				var isLinkThisGc = new RegExp(gclink, 'i')
				var isgclink = isLinkThisGc.test(m.text)
				if (isgclink) return
				let delet = m.key.participant
				let bang = m.key.id
				try {
					await yonz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
					await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
				} catch (e) {
					console.log(chalk.red(`[ANTILINK2] Gagal hapus di ${m.chat}: ${e?.message || e}`))
				}
			}}

		if (m.isGroup && db.groups[m.chat] && (db.groups[m.chat].antihidetag == 'delete' || db.groups[m.chat].antihidetag == 'kick')) {
			let jumlahTag = (m.mentionedJid && m.mentionedJid.length) || 0
			let modeHidetag = db.groups[m.chat].antihidetag
			if (jumlahTag >= 5 && !isCreator && !senderIsAdmin && botIsAdmin && !m.fromMe) {
				let delet = m.key.participant
				let bang = m.key.id
				try {
					if (modeHidetag === 'kick') {
						await yonz.sendMessage(m.chat, {text: `*乂 [ Hidetag Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antihidetag grup ini!`, mentions: [m.sender]}, {quoted: m})
						await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
						await sleep(1000)
						await yonz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
					} else {
						await yonz.sendMessage(m.chat, {text: `*乂 [ Hidetag Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antihidetag grup ini!`, mentions: [m.sender]}, {quoted: m})
						await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
					}
				} catch (e) {
					console.log(chalk.red(`[ANTIHIDETAG] Gagal hapus/kick di ${m.chat}: ${e?.message || e}`))
				}
			}}

		if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antifoto == true) {
			if (m.type === 'imageMessage' && !isCreator && !senderIsAdmin && botIsAdmin && !m.fromMe) {
				let delet = m.key.participant
				let bang = m.key.id
				try {
					await yonz.sendMessage(m.chat, {text: `*乂 [ Foto Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf foto kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antifoto grup ini!`, mentions: [m.sender]}, {quoted: m})
					await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
				} catch (e) {
					console.log(chalk.red(`[ANTIFOTO] Gagal hapus di ${m.chat}: ${e?.message || e}`))
				}
			}}

		if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antipromosi == true) {
			var promoRegex = /(wa\.me\/|api\.whatsapp\.com|whatsapp\.com\/channel|shopee\.co\.id|tokopedia\.com|lynk\.id|bit\.ly|s\.id|linktr\.ee|\bopen po\b|\bopenpo\b|\bpromo\b|\bdiskon\b|\bjual\b|\bjualan\b|\bcod\b|\bgaransi\b|\border\s?wa\b)/gi
			if (promoRegex.test(m.text) && !isCreator && !senderIsAdmin && botIsAdmin && !m.fromMe) {
				let delet = m.key.participant
				let bang = m.key.id
				try {
					await yonz.sendMessage(m.chat, {text: `*乂 [ Promosi Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antipromosi grup ini!`, mentions: [m.sender]}, {quoted: m})
					await yonz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
					await sleep(1000)
					await yonz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
				} catch (e) {
					console.log(chalk.red(`[ANTIPROMOSI] Gagal hapus/kick di ${m.chat}: ${e?.message || e}`))
				}
			}}

		const example = (teks) => {
			return `\n *Contoh penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
		}

		const Reply = async (teks, mentions = []) => {
			return yonz.sendReplyThumbnail(m.chat, teks, null, {
				mentions,
				contextInfo: {
					isForwarded: true,
					forwardingScore: 9999,
					businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" },
					forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }
				}
			})
		}

		const SEWA_EXEMPT_CMD = ['addsewagc', 'delsewagc', 'listsewagc']
		const isKnownCmd = isCmd && command && getValidCommands().has(command.toLowerCase())
		if (isKnownCmd && m.isGroup && !isCreator && !SEWA_EXEMPT_CMD.includes(command) && !isGroupSewa(m.chat)) {
			return Reply(
				`💌 *Grup Belum Sewa*\n` +
				`Hubungi Owner untuk sewa\n\n` +
				`➜ Owner: ${global.namaOwner}\n` +
				`➜ Link: ${global.linkowner || global.linkOwner}`
			)
		}

		const isRegistered = (sender) => {
			if (global.db.settings?.wajibDaftar === false) return true
			return !!(global.db?.users?.[sender]?.registered)
		}

		const daftar = async (teks) => {
			return Reply(teks)
		}

		const buildMainMenuText = () => {
			const userStatus = isCreator ? "Owner" : isPremium ? "Premium" : "Free User";

			let totalFitur = 0;
			try {
				const commandJsPath = path.join(__dirname, 'yonz-cmd.js');
				if (fs.existsSync(commandJsPath)) {
					const commandJsContent = fs.readFileSync(commandJsPath, 'utf8');
					const caseMatches = commandJsContent.match(/case\s+["']([^"']+)["']\s*:/gi);
					if (caseMatches) totalFitur = caseMatches.length;
				}
				const pluginsPath = path.join(__dirname, 'plugins');
				if (fs.existsSync(pluginsPath)) {
					const files = fs.readdirSync(pluginsPath);
					for (const file of files) {
						if (file.endsWith('.js')) {
							const pluginContent = fs.readFileSync(path.join(pluginsPath, file), 'utf8');
							const pluginCaseMatches = pluginContent.match(/command\s*[:=]\s*\[([^\]]+)\]/gi);
							if (pluginCaseMatches) {
								for (const match of pluginCaseMatches) {
									const commands = match.match(/["']([^"']+)["']/g);
									if (commands) totalFitur += commands.length;
								}
							}
						}
					}
				}
			} catch (e) {
				totalFitur = "?";
			}

			const userName = m.pushName || m.sender.split('@')[0];
			const limitInfo = isCreator ? "Unlimited" : isPremium ? "Unlimited" : (global.db?.users?.[m.sender]?.limit ?? "-");

			return `╭━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${versi}
│ 火  Waktu  : ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━〔 𝗦𝗨𝗣𝗣𝗢𝗥𝗧 〕━━━⬣
│ ➜ Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣`;
		}

		const menureply = async (teks, isMain = false) => {
			const caption = isMain ? buildMainMenuText() : teks;
			try {
				const videoPath = './media/menu.mp4';
				if (fs.existsSync(videoPath)) {
					await yonz.sendMessage(m.chat, {
						video: fs.readFileSync(videoPath),
						caption,
						gifPlayback: true,
						mimetype: 'video/mp4'
					}, { quoted: m });
				} else {
					await yonz.sendMessage(m.chat, { text: caption }, { quoted: m });
				}
			} catch (e) {
				console.log(e);
				await yonz.sendMessage(m.chat, { text: caption }, { quoted: m });
			}
		}

		const sendMenuVersion = async (menuStyle, teks = '') => {
			const userName = m.pushName || m.sender.split('@')[0];

			let totalFitur = 0;
			try {
				const commandJsContent = fs.readFileSync(path.join(__dirname, 'yonz-cmd.js'), 'utf8');
				const caseMatches = commandJsContent.match(/case\s+["']([^"']+)["']\s*:/gi);
				if (caseMatches) totalFitur = caseMatches.length;

				const pluginsPath = path.join(__dirname, 'plugins');
				if (fs.existsSync(pluginsPath)) {
					const files = fs.readdirSync(pluginsPath);
					for (const file of files) {
						if (file.endsWith('.js')) {
							totalFitur += 1;
						}
					}
				}
			} catch (e) {
				totalFitur = "?";
			}

			const now = moment().tz('Asia/Jakarta');
			const tanggal = now.format('dddd, DD MMMM YYYY');
			const hariini = tanggal;
			const jam = now.format('HH:mm:ss');

			// ===== Cuaca (BMKG) =====
			const cuacaData = await getCuacaMenu(global.adm4);

			// ===== RAM =====
			const ram = getRamInfo();

			// ===== Status & Limit =====
			let userStatus, limitInfo, limitBar;
			const maxLimit = getUserMaxLimit(m.sender);
			const usedToday = getUsedToday(m.sender);
			const remainingLimit = Math.max(0, maxLimit - usedToday);
			if (isCreator) {
				userStatus = "👑 Owner";
				limitInfo = "∞ Unlimited";
				limitBar = '█'.repeat(10);
			} else if (global.isPrem(m.sender)) {
				const daysLeft = getPremiumDaysLeft(m.sender);
				userStatus = `💎 Premium (${daysLeft} hari lagi)`;
				limitBar = buildLimitBar(usedToday, maxLimit);
				limitInfo = `${usedToday}/${maxLimit} • Sisa: ${remainingLimit}`;
			} else {
				userStatus = "👤 Free User";
				limitBar = buildLimitBar(usedToday, maxLimit);
				limitInfo = `${usedToday}/${maxLimit} • Sisa: ${remainingLimit}`;
			}

			// ===== Statistik Bot =====
			const totalPengguna = getTotalRegisteredUsers();
			const totalSewaBotCount = getTotalActiveSewa();

			// ===== Gold RPG (kalau user sudah main RPG) =====
			let rpgGold = 0;
			try {
				const rpgDBPath = './library/database/rpg.json';
				if (fs.existsSync(rpgDBPath)) {
					const rpgData = JSON.parse(fs.readFileSync(rpgDBPath));
					if (rpgData.players && rpgData.players[m.sender]) {
						rpgGold = rpgData.players[m.sender].gold || 0;
					}
				}
			} catch (e) {
				console.log('Error reading RPG gold:', e);
			}

			const infoText = `╭━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
│ 水  [${limitBar}]
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${global.versi}
│ 火  Waktu  : ${jam} WIB
│ 風  Cuaca  : ${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C
│ 地  RAM    : ${ram.used} / ${ram.total} (${ram.percent}%)
│ 人  Pengguna : ${totalPengguna}
│ 群  Sewa Aktif : ${totalSewaBotCount} Group
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━ 〔 𝗕𝗢𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 〕━━━⬣
│ 炎  Bot WhatsApp Premium
│ 光  Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣${teks ? `\n${teks}` : ''}`;

			const sectionsMain = [
				{
					title: "✨ MENU UTAMA",
					highlight_label: "POPULAR",
					rows: [
						{ title: "📜 SEMUA FITUR", description: "Menampilkan seluruh list perintah bot", id: `${prefix}allmenu` },
						{ title: "🛒 STORE MENU", description: "Daftar produk dan layanan digital", id: `${prefix}menu-store` },
						{ title: "👑 MENU OWNER", description: "Perintah khusus untuk pemilik bot", id: `${prefix}menu-owner` },
						{ title: `🪪 OWNER ${global.botname}`, description: "Informasi kontak pengembang bot", id: `${prefix}owner` }
					]
				},
				{
					title: "📂 KATEGORI FITUR",
					rows: [
						{ title: "🎨 STICKERS", description: "Menu membuat dan mencari stiker", id: `${prefix}menu-stickers` },
						{ title: "🖼️ MAKER", description: "Membuat logo dan efek gambar", id: `${prefix}menu-maker` },
						{ title: "⬇️ DOWNLOADER", description: "Unduh video, musik, dan media", id: `${prefix}menu-download` },
						{ title: "🔍 SEARCH", description: "Pencarian informasi secara global", id: `${prefix}menu-search` },
						{ title: "🎮 GAME", description: "Kumpulan permainan seru", id: `${prefix}menu-game` },
						{ title: "🤖 AI", description: "Fitur kecerdasan buatan", id: `${prefix}menu-ai` },
						{ title: "🔐 ENCRYPT", description: "Kunci atau privasi file", id: `${prefix}menu-enc` },
						{ title: "📜 SERTIFIKAT", description: "Membuat sertifikat otomatis", id: `${prefix}menu-stk` },
						{ title: "⚔️ RPG GAMES", description: "Petualangan RPG dan level up", id: `${prefix}menu-rpg` },
						{ title: "🖥️ PANEL", description: "Kontrol server dan panel bot", id: `${prefix}menu-panel` },
						{ title: "👥 GROUP", description: "Fitur khusus administrasi grup", id: `${prefix}menu-group` },
						{ title: "🖌️ POTOANIME", description: "Edit foto menjadi gaya anime", id: `${prefix}menu-potoanime` },
						{ title: "⛩️ ANIME", description: "Informasi dan update seputar anime", id: `${prefix}menu-anime` },
						{ title: "🔞 NSFW", description: "Konten dewasa (18+)", id: `${prefix}menu-nsfw` },
						{ title: "💃 CECAN", description: "Koleksi foto wanita cantik", id: `${prefix}menu-cecan` },
						{ title: "🕌 ISLAMI", description: "Fitur religi dan edukasi Islam", id: `${prefix}menu-islami` },
						{ title: "📸 EHPOTO", description: "Berbagai efek foto menarik", id: `${prefix}menu-ehpoto` },
						{ title: "😂 FUN", description: "Fitur hiburan dan lelucon", id: `${prefix}menu-fun` },
						{ title: "🔮 PRIMBON", description: "Ramalan, zodiak, dan mitos", id: `${prefix}menu-primbon` },
						{ title: "🛠️ TOOLS", description: "Kumpulan tools serbaguna", id: `${prefix}menu-tools` }
					]
				}
			];

			const sectionsSupport = [
				{
					title: "Memberi support dan berdonasi",
					highlight_label: global.namaOwner,
					rows: [
						{ title: "Owner / Dev", description: `➜ ${global.botname}`, id: `${prefix}owner` },
						{ title: "Grup Chat", description: `➜ ${global.botname}`, id: `${prefix}gcbot` }
					]
				}
			];

			// Sections v1 -- persis sesuai referensi
			const sectionsV1 = [
				{
					title: "✨ MENU UTAMA",
					highlight_label: "POPULAR",
					rows: [
						{ title: " SEMUA FITUR", description: "Menampilkan seluruh list perintah bot", id: `${prefix}allmenu` },
						{ title: " STORE MENU", description: "Daftar produk dan layanan digital", id: `${prefix}menu-store` },
						{ title: " MENU OWNER", description: "Perintah khusus untuk pemilik bot", id: `${prefix}menu-owner` },
						{ title: `🪪 OWNER ${global.botname}`, description: "Informasi kontak pengembang bot", id: `${prefix}owner` }
					]
				},
				{
					title: " KATEGORI FITUR",
					rows: [
						{ title: " STICKERS", description: "Menu membuat dan mencari stiker", id: `${prefix}menu-stickers` },
						{ title: " MAKER", description: "Membuat logo dan efek gambar", id: `${prefix}menu-maker` },
						{ title: "DOWNLOADER", description: "Unduh video, musik, dan media", id: `${prefix}menu-download` },
						{ title: " SEARCH", description: "Pencarian informasi secara global", id: `${prefix}menu-search` },
						{ title: "GAME", description: "Kumpulan permainan seru", id: `${prefix}menu-game` },
						{ title: " SERTIFIKAT", description: "Membuat sertifikat otomatis", id: `${prefix}menu-stk` },
						{ title: "⚔️ RPG GAMES", description: "Petualangan RPG dan level up", id: `${prefix}menu-rpg` },
						{ title: " PANEL", description: "Kontrol server dan panel bot", id: `${prefix}menu-panel` },
						{ title: " GROUP", description: "Fitur khusus administrasi grup", id: `${prefix}menu-group` },
						{ title: " POTOANIME", description: "Edit foto menjadi gaya anime", id: `${prefix}menu-potoanime` },
						{ title: "⛩️ ANIME", description: "Informasi dan update seputar anime", id: `${prefix}menu-anime` },
						{ title: " NSFW", description: "Konten dewasa (18+)", id: `${prefix}menu-nsfw` },
						{ title: "CECAN", description: "Koleksi foto wanita cantik", id: `${prefix}menu-cecan` },
						{ title: " ISLAMI", description: "Fitur religi dan edukasi Islam", id: `${prefix}menu-islami` },
						{ title: " EHPOTO", description: "Berbagai efek foto menarik", id: `${prefix}menu-ehpoto` },
						{ title: "FUN", description: "Fitur hiburan dan lelucon", id: `${prefix}menu-fun` },
						{ title: " PRIMBON", description: "Ramalan, zodiak, dan mitos", id: `${prefix}menu-primbon` },
						{ title: " ENCRYPT", description: "Kunci atau privasi file", id: `${prefix}menu-enc` }
					]
				}
			];
			const noInfoOkOkLhV1 = [];

			// Sections v2 -- persis sesuai referensi (small caps)
			const sectionsV2 = [
				{
					title: 'Menu Utama',
					highlight_label: 'Rekomendasi',
					rows: [
						{ title: 'sᴇᴍᴜᴀ ꜰɪᴛᴜʀ', description: `➜ ${global.botname}`, id: `${prefix}allmenu` },
						{ title: 'sᴛᴏʀᴇ ᴍᴇɴᴜ', description: `➜ ${global.botname}`, id: `${prefix}menu-store` },
						{ title: 'ᴍᴇɴᴜ ᴏᴡɴᴇʀ', description: `➜ ${global.botname}`, id: `${prefix}menu-owner` },
						{ title: 'ᴏᴡɴᴇʀ / ᴅᴇᴠ', description: `➜ ${global.botname}`, id: `${prefix}owner` }
					]
				},
				{
					title: "ᴋᴀᴛᴇɢᴏʀɪ ᴍᴇɴᴜ ʟᴀɪɴ",
					rows: [
						{ title: 'ᴍᴇɴᴜ sᴛɪᴄᴋᴇʀs', description: `➜ ${global.botname}`, id: `${prefix}menu-stickers` },
						{ title: 'ᴍᴇɴᴜ ᴍᴀᴋᴇʀ', description: `➜ ${global.botname}`, id: `${prefix}menu-maker` },
						{ title: 'ᴍᴇɴᴜ ᴅᴏᴡɴʟᴏᴀᴅ', description: `➜ ${global.botname}`, id: `${prefix}menu-download` },
						{ title: 'ᴍᴇɴᴜ sᴇᴀʀᴄʜ', description: `➜ ${global.botname}`, id: `${prefix}menu-search` },
						{ title: 'ᴍᴇɴᴜ ɢᴀᴍᴇ', description: `➜ ${global.botname}`, id: `${prefix}menu-game` },
						{ title: 'ᴍᴇɴᴜ ᴀɪ', description: `➜ ${global.botname}`, id: `${prefix}menu-ai` },
						{ title: 'ᴍᴇɴᴜ ᴇɴᴄ', description: `➜ ${global.botname}`, id: `${prefix}menu-enc` },
						{ title: 'ᴍᴇɴᴜ sᴇʀᴛɪꜰɪᴋᴀᴛ', description: `➜ ${global.botname}`, id: `${prefix}menu-stk` },
						{ title: 'ᴍᴇɴᴜ ʀᴘɢ', description: `➜ ${global.botname}`, id: `${prefix}menu-rpg` },
						{ title: 'ᴍᴇɴᴜ ᴘᴀɴᴇʟ', description: `➜ ${global.botname}`, id: `${prefix}menu-panel` },
						{ title: 'ᴍᴇɴᴜ ɢʀᴏᴜᴘ', description: `➜ ${global.botname}`, id: `${prefix}menu-group` },
						{ title: 'ᴍᴇɴᴜ ᴘᴏᴛᴏᴀɴɪᴍᴇ', description: `➜ ${global.botname}`, id: `${prefix}menu-potoanime` },
						{ title: 'ᴍᴇɴᴜ ᴀɴɪᴍᴇ', description: `➜ ${global.botname}`, id: `${prefix}menu-anime` },
						{ title: 'ᴍᴇɴᴜ ɴsꜰᴡ', description: `➜ ${global.botname}`, id: `${prefix}menu-nsfw` },
						{ title: 'ᴍᴇɴᴜ ᴄᴇᴄᴀɴ', description: `➜ ${global.botname}`, id: `${prefix}menu-cecan` },
						{ title: 'ᴍᴇɴᴜ ɪsʟᴀᴍɪ', description: `➜ ${global.botname}`, id: `${prefix}menu-islami` },
						{ title: 'ᴍᴇɴᴜ ᴇʜᴘᴏᴛᴏ', description: `➜ ${global.botname}`, id: `${prefix}menu-ehpoto` },
						{ title: 'ᴍᴇɴᴜ ꜰᴜɴ', description: `➜ ${global.botname}`, id: `${prefix}menu-fun` },
						{ title: 'ᴍᴇɴᴜ ᴘʀɪᴍʙᴏɴ', description: `➜ ${global.botname}`, id: `${prefix}menu-primbon` }
					]
				}
			];
			const noInfoOkOkLhV2 = [
				{
					title: "𝙈𝙚𝙢𝙗𝙚𝙧𝙞 𝙨𝙪𝙥𝙥𝙤𝙧𝙩 𝙙𝙖𝙣 𝙗𝙚𝙧𝙙𝙤𝙣𝙖𝙨𝙞",
					highlight_label: global.namaOwner,
					rows: [
						{ title: 'ᴏᴡɴᴇʀ / ᴅᴇᴠ', description: `➜ ${global.botname}`, id: `${prefix}owner` },
						{ title: 'ᴅᴏɴᴀsɪ & sᴜᴘᴘᴏʀᴛ', description: `➜ ${global.botname}`, id: `${prefix}donasi` },
						{ title: 'sᴇᴡᴀ ʙᴏᴛ', description: `➜ ${global.botname}`, id: `${prefix}sewa` },
						{ title: 'ᴜᴘɢʀᴀᴅᴇ ᴘʀᴇᴍɪᴜᴍ', description: `➜ ${global.botname}`, id: `${prefix}prem` },
						{ title: 'ɢʀᴜᴘ ᴄʜᴀᴛ', description: `➜ ${global.botname}`, id: `${prefix}gcbot` },
						{ title: 'sᴄʀɪᴘᴛ ʙᴏᴛ', description: `➜ ${global.botname}`, id: `${prefix}script` }
					]
				}
			];

			// Sections v3/v4 -- persis sesuai referensi (Title Case)
			const sectionsV3 = [
				{
					title: 'Menu Utama',
					highlight_label: 'Rekomendasi',
					rows: [
						{ title: 'Semua Fitur', description: `➜ ${global.botname}`, id: `${prefix}allmenu` },
						{ title: 'Store Menu', description: `➜ ${global.botname}`, id: `${prefix}menu-store` },
						{ title: 'Menu Owner', description: `➜ ${global.botname}`, id: `${prefix}menu-owner` },
						{ title: 'Owner / Dev', description: `➜ ${global.botname}`, id: `${prefix}owner` }
					]
				},
				{
					title: "Kategori Menu Lain",
					rows: [
						{ title: 'Menu Stickers', description: `➜ ${global.botname}`, id: `${prefix}menu-stickers` },
						{ title: 'Menu Maker', description: `➜ ${global.botname}`, id: `${prefix}menu-maker` },
						{ title: 'Menu Download', description: `➜ ${global.botname}`, id: `${prefix}menu-download` },
						{ title: 'Menu Search', description: `➜ ${global.botname}`, id: `${prefix}menu-search` },
						{ title: 'Menu Game', description: `➜ ${global.botname}`, id: `${prefix}menu-game` },
						{ title: "Menu AI", description: `➜ ${global.botname}`, id: `${prefix}menu-ai` },
						{ title: "Menu Enc", description: `➜ ${global.botname}`, id: `${prefix}menu-enc` },
						{ title: 'Menu Sertifikat', description: `➜ ${global.botname}`, id: `${prefix}menu-stk` },
						{ title: 'Menu Rpg', description: `➜ ${global.botname}`, id: `${prefix}menu-rpg` },
						{ title: 'Menu Panel', description: `➜ ${global.botname}`, id: `${prefix}menu-panel` },
						{ title: 'Menu Group', description: `➜ ${global.botname}`, id: `${prefix}menu-group` },
						{ title: 'Menu Potoanime', description: `➜ ${global.botname}`, id: `${prefix}menu-potoanime` },
						{ title: 'Menu Anime', description: `➜ ${global.botname}`, id: `${prefix}menu-anime` },
						{ title: 'Menu Nsfw', description: `➜ ${global.botname}`, id: `${prefix}menu-nsfw` },
						{ title: 'Menu Cecan', description: `➜ ${global.botname}`, id: `${prefix}menu-cecan` },
						{ title: 'Menu Islami', description: `➜ ${global.botname}`, id: `${prefix}menu-islami` },
						{ title: 'Menu Ehpoto', description: `➜ ${global.botname}`, id: `${prefix}menu-ehpoto` },
						{ title: 'Menu Fun', description: `➜ ${global.botname}`, id: `${prefix}menu-fun` },
						{ title: 'Menu Primbon', description: `➜ ${global.botname}`, id: `${prefix}menu-primbon` }
					]
				}
			];

			let totalSewaBot = 0;
			try { totalSewaBot = Object.keys(global.db?.groups || {}).length; } catch (e) {}

			const thumb = global.image.menu;
			const videoPath = './media/menu.mp4';

			try {
				if (menuStyle === 'v1') {
					let menuBody = `
╭━━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
│ 水  [${limitBar}]
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur}
│ 炎  Versi  : ${global.versi}
│ 火  Waktu  : ${jam} WIB
│ 風  Cuaca  : ${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C
│ 地  RAM    : ${ram.used} / ${ram.total} (${ram.percent}%)
│ 人  Pengguna : ${totalPengguna}
│ 群  Sewa Aktif : ${totalSewaBotCount} Group
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━ 〔 𝗕𝗢𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 〕━━━⬣
│ 炎  Bot WhatsApp Premium
│ 光  Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣
${teks}`;

					let media = null;
					try {
						if (fs.existsSync(videoPath)) {
							media = await prepareWAMessageMedia({ video: { url: videoPath }, gifPlayback: true }, { upload: yonz.waUploadToServer });
						}
					} catch (e) {}

					const headerContent = media ? { hasMediaAttachment: true, videoMessage: media.videoMessage } : { hasMediaAttachment: false };

					let msg = generateWAMessageFromContent(m.chat, {
						viewOnceMessage: {
							message: {
								interactiveMessage: proto.Message.InteractiveMessage.create({
									body: proto.Message.InteractiveMessage.Body.create({ text: `> Hai Saya  ${global.botname2} yang siap nemenin kamu kapanpun dan dimanapun` }),
									footer: proto.Message.InteractiveMessage.Footer.create({ text: menuBody }),
									header: proto.Message.InteractiveMessage.Header.create({ title: "", ...headerContent }),
									nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
										buttons: [
											{ name: "single_select", buttonParamsJson: JSON.stringify({ title: `Buka Menu ${global.botname2}`, sections: sectionsV1, icon: "DEFAULT" }) },
											{ name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: `Saluran ${global.botname}`, url: global.linkSaluran, merchant_url: global.linkSaluran }) }
										],
										messageParamsJson: JSON.stringify({
											limited_time_offer: {
												text: `📅 ${hariini}`,
												url: global.linkSaluran
											}
										})
									}),
									contextInfo: { mentionedJid: [m.sender] }
								})
							}
						}
					}, { quoted: m });
					await yonz.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

				} else if (menuStyle === 'v2') {
					let menuBody = `
╭━━━〔 𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥 〕━━━⬣
│ 士  Nama   : ${userName}
│ 光  Status : ${userStatus}
│ 火  Limit  : ${limitInfo}
╰━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 𝗦𝗬𝗦𝗧𝗘𝗠 𝗕𝗢𝗧 〕━━━⬣
│ 士  Nama   : ${global.botname2}
│ 乂  Fitur  : ${totalFitur} 
│ 炎  Versi  : ${global.versi}
│ 火  Waktu  : ${jam} WIB
│ 人  Pengguna : ${totalPengguna}
│ 群  Sewa Aktif : ${totalSewaBotCount} Group
╰━━━━━━━━━━━━━━━━━━━━⬣

╭━━ 〔 𝗕𝗢𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 〕━━━⬣
│ 炎  Bot WhatsApp Premium
│ 光  Owner : ${global.namaOwner}
╰━━━━━━━━━━━━━━━━━━━━⬣
${teks}`;

					let thumbBuffer = null;
					try {
						const got = require('got');
						thumbBuffer = (await got(global.image.menu, { responseType: 'buffer' })).body;
					} catch (e) {}

					const btn = new yonz.ButtonV2(yonz);
					btn.setBody(`> *Haii ${m.pushName} Saya ${global.botname}, Asisten kamu di Tahun 2026 Yang siap bantu kamu kapanpun dan dimanapun Silahkan pilih menu di bawah ya*`)
					   .setFooter(menuBody)
					   .setThumbnail(thumbBuffer || global.image.menu)
					   .addRawButton({
						   buttonText: { displayText: 'ʟɪsᴛ ᴍᴇɴᴜ' },
						   buttonId: 'menu_list',
						   type: 1,
						   nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: '🍀 ʟɪsᴛ ᴍᴇɴᴜ', sections: sectionsV2 }) }
					   })
					   .addRawButton({
						   buttonText: { displayText: ' sᴜᴘᴘᴏʀᴛ' },
						   buttonId: 'support_list',
						   type: 1,
						   nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: '💎 sᴜᴘᴘᴏʀᴛ', sections: noInfoOkOkLhV2 }) }
					   });
					await btn.send(m.chat);

				} else if (menuStyle === 'v3') {
					let menuText = `╼ ׅ ֹ𔖰᷼𔖮 *Info User*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ User : *${m.pushName}*
┆𖢷 ׁ 𖹭₊ Status : *${userStatus}*
┆𖢷 ׁ 𖹭₊ Limit : *${limitInfo}* [${limitBar}]
┆𖢷 ׁ 𖹭₊ Gold RPG : *${rpgGold}* 🪙
╰─╼𔕬─┈───┈───┈

╼ ׅ ֹ𔖰᷼𔖮 *Info Bot*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Bot Name : *${global.botname} v${global.versi}*
┆𖢷 ׁ 𖹭₊ Total Fitur : *${totalFitur}*
┆𖢷 ׁ 𖹭₊ Total Sewa : *${totalSewaBot} Group*
┆𖢷 ׁ 𖹭₊ Total Pengguna : *${totalPengguna}*
┆𖢷 ׁ 𖹭₊ Cuaca : *${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C*
┆𖢷 ׁ 𖹭₊ RAM : *${ram.used}/${ram.total} (${ram.percent}%)*
╰─╼𔕬─┈───┈───┈
 ${teks}`;

					const thumbPath = "./source/media/foto/imgdokumen.jpg";
					if (fs.existsSync(thumbPath)) {
						try {
							const jimp = require('jimp');
							const img = await jimp.read(thumbPath);
							if (img.bitmap.width !== 300 || img.bitmap.height !== 300) {
								img.cover(300, 300);
								await img.writeAsync(thumbPath);
							}
						} catch (e) {}
					}

					try {
						await yonz.sendMessage(m.chat, {
							buttons: [
								{ buttonId: 'action', buttonText: { displayText: 'Lihat Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: `Select menu`, sections: sectionsV3 }) } }
							],
							headerType: 1,
							viewOnce: true,
							image: { url: global.image.menuv3 },
							caption: menuText,
							contextInfo: {
								mentionedJid: [m.sender],
								isForwarded: true,
								forwardingScore: 9999,
								businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" },
								forwardedNewsletterMessageInfo: {
									newsletterName: global.namaSaluran,
									newsletterJid: global.idSaluran
								}
							}
						}, { quoted: m });
					} catch (err) {
						console.log('menu v3 error', err);
						await yonz.sendMessage(m.chat, {
							image: { url: global.image.reply },
							caption: menuText,
							contextInfo: {
								mentionedJid: [m.sender]
							}
						}, { quoted: m });
					}

				} else if (menuStyle === 'v4') {
					let menuText = `╼ ׅ ֹ𔖰᷼𔖮 *Info User*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ User : *${m.pushName}*
┆𖢷 ׁ 𖹭₊ Status : *${userStatus}*
┆𖢷 ׁ 𖹭₊ Limit : *${limitInfo}* [${limitBar}]
┆𖢷 ׁ 𖹭₊ Gold RPG : *${rpgGold}* 🪙
╰─╼𔕬─┈───┈───┈

╼ ׅ ֹ𔖰᷼𔖮 *Info Bot*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Bot Name : *${global.botname} v${global.versi}*
┆𖢷 ׁ 𖹭₊ Total Fitur : *${totalFitur}*
┆𖢷 ׁ 𖹭₊ Total Sewa : *${totalSewaBot} Group*
┆𖢷 ׁ 𖹭₊ Total Pengguna : *${totalPengguna}*
┆𖢷 ׁ 𖹭₊ Cuaca : *${cuacaData.emoji} ${cuacaData.cuaca}, ${cuacaData.suhu}°C*
┆𖢷 ׁ 𖹭₊ RAM : *${ram.used}/${ram.total} (${ram.percent}%)*
╰─╼𔕬─┈───┈───┈
 ${teks}`;

					await yonz.sendMessage(m.chat, {
						footer: '',
						image: { url: global.image.reply },
						caption: menuText,
						buttons: [
							{ buttonId: 'action', buttonText: { displayText: 'Lihat Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: `Select menu`, sections: sectionsV3 }) } }
						],
						contextInfo: {
							mentionedJid: [m.sender]
						}
					}, { quoted: m });

				} else if (menuStyle === 'v5') {
					let allText = `${infoText}\n`;
					sectionsMain.forEach(sec => {
						allText += `\n『 ${sec.title} 』\n`;
						sec.rows.forEach(r => { allText += `▣ ${r.title} - ${r.id}\n`; });
					});
					await Reply(allText);

				} else if (menuStyle === 'v6') {
					await yonz.sendMessage(m.chat, {
						image: { url: global.image.reply },
						caption: infoText,
						contextInfo: {
							mentionedJid: [m.sender]
						},
						buttons: [
							{ buttonId: 'action', buttonText: { displayText: '🛍️ Buka Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: 'Product Menu', sections: sectionsMain }) } }
						]
					}, { quoted: m });

				} else if (menuStyle === 'v7') {
					const btn = new yonz.ButtonV2(yonz);
					btn.setBody(infoText)
					   .setFooter(`${global.botname} • ${new Date().getFullYear()}`)
					   .addRawButton({
						   buttonText: { displayText: '📋 Menu' },
						   buttonId: 'menu_list',
						   type: 1,
						   nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: 'Menu', sections: sectionsMain }) }
					   });
					await btn.send(m.chat);

				} else if (menuStyle === 'v8') {
					const hasVideo = fs.existsSync(videoPath);
					await yonz.sendMessage(m.chat, {
						...(hasVideo ? { video: fs.readFileSync(videoPath), gifPlayback: true } : { image: { url: thumb } }),
						caption: infoText,
						footer: global.botname,
						buttons: [
							{ buttonId: 'action', buttonText: { displayText: 'Buka Menu' }, type: 4, nativeFlowInfo: { name: 'single_select', paramsJson: JSON.stringify({ title: 'Menu', sections: sectionsMain }) } }
						]
					}, { quoted: m });

				} else {
					await menureply('', true);
				}
			} catch (e) {
				console.log('Menu style error:', e);
				await menureply('', true);
			}
		}

		const pluginsLoader = async (directory) => {
			let plugins = []
			const folders = fs.readdirSync(directory)
			folders.forEach(file => {
				const filePath = path.join(directory, file)
				if (filePath.endsWith(".js")) {
					try {
						const resolvedPath = require.resolve(filePath);
						if (require.cache[resolvedPath]) {
							delete require.cache[resolvedPath]
						}
						const plugin = require(filePath)
						plugins.push(plugin)
					} catch (error) {
						console.log(`Error loading plugin at ${filePath}:`, error)
					}}
			})
			return plugins
		}

		let pluginsDisable = true
		const plugins = await pluginsLoader(path.resolve(__dirname, "plugins"))
		const clutchzodev = { yonz, toIDR, isCreator, Reply, command, isPremium, capital, isCmd, example, text, runtime, qtext, qlocJpm, qmsg, mime, sleep, botNumber, addLimitUsage, getUserMaxLimit, getUsedToday }
		for (let plugin of plugins) {
			if (plugin.command.find(e => e == command.toLowerCase())) {
				pluginsDisable = false
				if (typeof plugin !== "function") return
				await plugin(m, clutchzodev)
			}
		}
		if (!pluginsDisable) return

if (global.game && global.game[m.chat] && !isCmd) {
  const jawabanUser = body.toLowerCase().trim()
  const dataGame = global.game[m.chat]

  if (dataGame.type === 'family100') {
    const idx = dataGame.jawabanList.findIndex((j, i) => j === jawabanUser && !dataGame.found.includes(i))
    if (idx !== -1) {
      dataGame.found.push(idx)
      const sisa = dataGame.jawabanList.length - dataGame.found.length
      if (sisa === 0) {
        clearTimeout(dataGame.timeout)
        delete global.game[m.chat]
        yonz.sendMessage(m.chat, { text: `🎉 Semua jawaban ketebak! Game selesai.` }, { quoted: m })
      } else {
        yonz.sendMessage(m.chat, { text: `✅ Benar! *${dataGame.jawabanAsli[idx]}*\nSisa ${sisa} jawaban lagi.` }, { quoted: m })
      }
    } else if (jawabanUser.length > 0) {
      yonz.sendMessage(m.chat, { text: `❌ Jawaban salah / sudah disebut!` }, { quoted: m })
    }
  } else {
    if (jawabanUser === dataGame.jawaban) {
      clearTimeout(dataGame.timeout)
      delete global.game[m.chat]
      yonz.sendMessage(m.chat, { text: `✅ Benar! Jawabannya adalah *${dataGame.jawabanAsli || dataGame.jawaban}*${dataGame.deskripsi ? `\nKeterangan: ${dataGame.deskripsi}` : ''}` }, { quoted: m })
    } else if (jawabanUser.length > 0) {
      yonz.sendMessage(m.chat, { text: `❌ Jawaban salah!` }, { quoted: m })
    }
  }
}

if (!isCmd && m.isGroup && body && typeof body === 'string' && body.trim().length > 0 && !m.isBaileys) {
  const chatId = m.chat;
  let listDb = loadLists();
  let listGrup = listDb[chatId] || [];

  if (listGrup.length > 0) {
    const searchText = body.toLowerCase().trim();
    
    let cari = listGrup.find(item => 
      item.name.toLowerCase() === searchText
    );
    
    if (cari) {
      if (cari.hasImage && cari.image && fs.existsSync(cari.image)) {
        await yonz.sendMessage(m.chat, {
          image: fs.readFileSync(cari.image),
          caption: cari.message
        }, { quoted: m });
      } else {
        yonz.sendMessage(m.chat, {
          text: cari.message
        }, { quoted: m });
      }
    }
  }
}

if (!isCmd && body && typeof body === 'string' && !m.isBaileys && !m.key.fromMe && (!m.isGroup || isCreator || isGroupSewa(m.chat))) {
  const adSetting = m.isGroup
    ? global.db.groups?.[m.chat]?.autodownload
    : global.db.users?.[m.sender]?.autodownload;

  if (adSetting) {
    const ttMatch = body.match(AUTODL_TIKTOK_REGEX);
    const igMatch = !ttMatch ? body.match(AUTODL_IG_REGEX) : null;
    const linkUrl = ttMatch?.[1] || igMatch?.[1];

    if (linkUrl) {
      try {
        await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const data = await autoDownloadAIO(linkUrl);
        const label = ttMatch ? 'TikTok' : 'Instagram';
        const emoji = ttMatch ? '🎵' : '📸';

        if (!data || (!data.video && data.images.length === 0)) {
          await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        } else {
          if (data.video) {
            await yonz.sendMessage(m.chat, {
              video: { url: data.video },
              caption: `*${emoji} Auto Download ${label}*\n\n${data.title || ''}`
            }, { quoted: m });
            if (data.audio) {
              await yonz.sendMessage(m.chat, {
                audio: { url: data.audio },
                mimetype: 'audio/mpeg',
                fileName: 'audio.mp3'
              }, { quoted: m });
            }
          } else if (data.images.length > 0) {
            for (const imgUrl of data.images) {
              await yonz.sendMessage(m.chat, {
                image: { url: imgUrl },
                caption: `*${emoji} Auto Download ${label}*\n\n${data.title || ''}`
              }, { quoted: m });
            }
          }
          await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        }
      } catch (e) {
        console.log('AutoDownload error:', e);
        await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
      }
    }
  }
}
    
switch (command) {

case "setaudiomenu":
case "setaudio": {
    if (!isCreator) return Reply(mess.owner);
    
    if (!m.quoted || !/audio/.test((m.quoted.msg || m.quoted).mimetype || '')) {
        return Reply("❌ Reply audio yang ingin dijadikan sebagai audio menu!");
    }
    
    await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(mess.wait);
    
    try {
        const quotedMsg = m.quoted;
        const audioBuffer = await quotedMsg.download();
        
        if (!audioBuffer || audioBuffer.length < 1000) {
            return Reply("❌ Gagal mendownload audio. Coba lagi nanti.");
        }
        
        const audioPath = path.join(__dirname, 'media', 'yonz.mp3');
        const mediaDir = path.join(__dirname, 'media');
        
        if (!fs.existsSync(mediaDir)) {
            fs.mkdirSync(mediaDir, { recursive: true });
        }
        
        fs.writeFileSync(audioPath, audioBuffer);
        
        await yonz.sendMessage(m.chat, {
            audio: fs.readFileSync(audioPath),
            mimetype: 'audio/mp4',
            ptt: false
        }, { quoted: m });
        
        await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        Reply("✅ Berhasil mengganti audio menu!\n\nAudio akan diputar saat membuka menu.");
        
    } catch (error) {
        console.error('[SETAUDIO ERROR]', error);
        await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(mess.error);
    }
}
break

case 'autoai': {
    if (!isCreator) return Reply(mess.owner);

    if (typeof global.db.settings.autoai !== 'string') global.db.settings.autoai = 'off';

    if (!text) {
        const mode = global.db.settings.autoai;
        const status = mode === 'off' ? '❌ NONAKTIF' : mode === 'all' ? '✅ AKTIF (Grup + Pribadi)' : '✅ AKTIF (Grup saja)';
        return Reply(
            `╼ ׅ ֹ𔖰᷼𔖮 *AUTO AI SETTINGS* ⚙️
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Status : ${status}
┆𖢷 ׁ 𖹭₊ Cara kerja : Bot otomatis menjawab kalau pesannya me-reply chat bot
┆𖢷 ׁ 𖹭₊
┆𖢷 ׁ 𖹭₊ Gunakan:
┆𖢷 ׁ 𖹭₊ .autoai on      → Aktifkan (grup saja)
┆𖢷 ׁ 𖹭₊ .autoai on all  → Aktifkan (grup + pribadi)
┆𖢷 ׁ 𖹭₊ .autoai off     → Nonaktifkan
╰─╼𔕬─┈───┈───┈`
        );
    }

    const args2 = text.toLowerCase().trim().split(/\s+/);
    const action = args2[0];
    const scope = args2[1];

    if (action === 'on') {
        if (scope === 'all') {
            global.db.settings.autoai = 'all';
            return Reply(`✅ *Auto AI diaktifkan!*\nBerlaku di *grup & chat pribadi*. Bot akan otomatis mengetik & menjawab kalau pesannya me-reply chat bot.`);
        } else {
            global.db.settings.autoai = 'group';
            return Reply(`✅ *Auto AI diaktifkan!*\nBerlaku di *seluruh grup* saja. Bot akan otomatis mengetik & menjawab kalau pesannya me-reply chat bot.\n\nMau termasuk chat pribadi? Gunakan: .autoai on all`);
        }
    } else if (action === 'off') {
        global.db.settings.autoai = 'off';
        return Reply(`❌ *Auto AI dinonaktifkan!*`);
    } else {
        return Reply('❌ Gunakan: .autoai on / .autoai on all / .autoai off');
    }
}
break;

case 'autoread': {
    if (!isCreator) return Reply(mess.owner);

    if (typeof global.db.settings.autoread !== 'boolean') global.db.settings.autoread = true;

    if (!text) {
        const status = global.db.settings.autoread ? '✅ AKTIF' : '❌ NONAKTIF';
        return Reply(
            `╼ ׅ ֹ𔖰᷼𔖮 *AUTOREAD SETTINGS* ⚙️
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Status : ${status}
┆𖢷 ׁ 𖹭₊ Berlaku untuk : Semua chat (grup & pribadi)
┆𖢷 ׁ 𖹭₊
┆𖢷 ׁ 𖹭₊ Gunakan:
┆𖢷 ׁ 𖹭₊ .autoread on  → Aktifkan
┆𖢷 ׁ 𖹭₊ .autoread off → Nonaktifkan
╰─╼𔕬─┈───┈───┈`
        );
    }

    const action = text.toLowerCase().trim();
    if (action === 'on') {
        global.db.settings.autoread = true;
        return Reply(`✅ *Autoread diaktifkan!*\nBot akan otomatis membaca (centang biru) semua pesan masuk, di grup maupun chat pribadi.`);
    } else if (action === 'off') {
        global.db.settings.autoread = false;
        return Reply(`❌ *Autoread dinonaktifkan!*\nBot tidak akan lagi otomatis membaca pesan masuk.`);
    } else {
        return Reply('❌ Gunakan: .autoread on / .autoread off');
    }
}
break;

case 'setprefix': {
    if (!isCreator2) return Reply(global.mess.creator);

    const pathNoPfxConfig = './library/database/nopfx_config.json';
    if (!fs.existsSync(pathNoPfxConfig)) {
        fs.writeFileSync(pathNoPfxConfig, JSON.stringify({ enabled: true }, null, 2));
    }

    const config = JSON.parse(fs.readFileSync(pathNoPfxConfig));

    if (!text) {
        const status = config.enabled ? '✅ AKTIF' : '❌ NONAKTIF';
        return Reply(
            `╼ ׅ ֹ𔖰᷼𔖮 *NO-PREFIX SETTINGS* ⚙️
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Status : ${status}
┆𖢷 ׁ 𖹭₊ 
┆𖢷 ׁ 𖹭₊ Gunakan:
┆𖢷 ׁ 𖹭₊ .setprefix on  → Aktifkan
┆𖢷 ׁ 𖹭₊ .setprefix off → Nonaktifkan
╰─╼𔕬─┈───┈───┈`
        );
    }

    const action = text.toLowerCase().trim();
    if (action === 'on') {
        config.enabled = true;
        fs.writeFileSync(pathNoPfxConfig, JSON.stringify(config, null, 2));
        return Reply(`✅ *No-Prefix diaktifkan!*\nSekarang command bisa digunakan tanpa prefix.`);
    } else if (action === 'off') {
        config.enabled = false;
        fs.writeFileSync(pathNoPfxConfig, JSON.stringify(config, null, 2));
        return Reply(`❌ *No-Prefix dinonaktifkan!*\nCommand harus menggunakan prefix (titik/!/dll).`);
    } else {
        return Reply('❌ Gunakan: on / off');
    }
}
break;



case 'updatelist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text || !text.includes('|')) return Reply(example("Burger|Dengan daging wagyu"));
    
    let parts = text.split('|');
    if (parts.length < 2) return Reply(example("Burger|Dengan daging wagyu"));
    
    const keyword = parts[0].trim();
    const deskripsiBaru = parts.slice(1).join('|').trim();
    
    const chatId = m.chat;
    const listDb = loadLists();
    let listGrup = listDb[chatId] || [];
    
    if (listGrup.length === 0) return Reply("❌ Tidak ada item di list");
    
    let itemIndex = listGrup.findIndex(item => 
        item.name.toLowerCase() === keyword.toLowerCase() ||
        item.name.toLowerCase().includes(keyword.toLowerCase())
    );
    
    if (itemIndex === -1) return Reply(`❌ Item "${keyword}" tidak ditemukan`);
    
    const itemLama = listGrup[itemIndex];
    listGrup[itemIndex].message = deskripsiBaru;
    
    if (m.type === 'imageMessage') {
        try {
            if (itemLama.hasImage && itemLama.image && fs.existsSync(itemLama.image)) {
                fs.unlinkSync(itemLama.image);
            }
            const mediaPath = await downloadAndSaveMediaList(m, 'image');
            listGrup[itemIndex].image = mediaPath;
            listGrup[itemIndex].hasImage = true;
        } catch (e) {}
    } else if (m.quoted && m.quoted.type === 'imageMessage') {
        try {
            if (itemLama.hasImage && itemLama.image && fs.existsSync(itemLama.image)) {
                fs.unlinkSync(itemLama.image);
            }
            const mediaPath = await downloadAndSaveMediaList(m.quoted, 'image');
            listGrup[itemIndex].image = mediaPath;
            listGrup[itemIndex].hasImage = true;
        } catch (e) {}
    }
    
    listDb[chatId] = listGrup;
    saveLists(listDb);
    
    Reply(`✅ Item "${itemLama.name}" berhasil diperbarui!`);
}
break;

case 'resetlist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    const settings = loadListSettings();
    
    if (settings[m.chat]) {
        if (settings[m.chat].media && fs.existsSync(settings[m.chat].media)) {
            try {
                fs.unlinkSync(settings[m.chat].media);
            } catch (e) {}
        }
        delete settings[m.chat];
        saveListSettings(settings);
    }
    
    Reply(`✅ Template list berhasil direset ke default!`);
}
break;

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await yonz.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break
		
case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break
		








case "menu": {
    if (!isRegistered(m.sender) && !isCreator)
        return daftar(global.mess.verifikasi);

    const reacts = [
        '🚀',
        '✅'
    ];

    for (const emoji of reacts) {
        await yonz.sendMessage(m.chat, {
            react: { text: emoji, key: m.key }
        });

        await new Promise(r => setTimeout(r, 10));
    }

    await sendMenuVersion(getMenuStyle());

    await yonz.sendMessage(m.chat, {
        audio: { url: './media/yonz.mp3' },
        mimetype: 'audio/mp4',
        ptt: false
    });
}
break;

case 'setmenu': {
    if (!isCreator) return Reply('❌ Hanya owner bot yang bisa mengubah menu style!');
    if (!text) return Reply(`Format: ${prefix}setmenu <v1/v2/v3/v4/v5/v6/v7/v8>\nContoh: ${prefix}setmenu v2`);

    // Cari pola v1-v8 di mana pun posisinya di dalam input, biar kebal dari token tambahan/nyasar
    const rawInput = text.toLowerCase();
    const found = rawInput.match(/\bv[1-8]\b/);
    const version = found ? found[0] : '';
    if (!version) {
        return Reply(`❌ Versi tidak valid! Gunakan v1, v2, v3, v4, v5, v6, v7, atau v8\n\n_Terdeteksi input: "${text}"_`);
    }

    setMenuStyle(version);

    const names = {
        'v1': 'Interactive Message',
        'v2': 'Elaina Menu',
        'v3': 'Button Menu',
        'v4': 'Document Menu',
        'v5': 'Simple Text Menu',
        'v6': 'Product Card Menu',
        'v7': 'Simple Button Menu',
        'v8': 'Video Button Menu'
    };
    return Reply(`✅ Menu style berhasil diubah ke *${names[version]}*`);
}
break;

case "allmenu":
case "menu-ai":
case "menu-stk":
case "menu-enc":
case "menu-owner":
case "menu-maker":
case "menu-potoanime":
case "menu-shop":
case "menu-group":
case "menu-store":
case "menu-anime":
case "menu-nsfw":
case "menu-panel":
case "menu-cecan":
case "menu-islami":
case "menu-ehpoto":
case "menu-rpg":
case "menu-game":
case "menu-search":
case "menu-download":
case "menu-fun":
case "menu-tools":
case "menu-primbon":
case "menu-stickers": {

    if (!isRegistered(m.sender) && !isCreator)
        return daftar(global.mess.verifikasi);

    const reacts = ['🚀','✅️'];

    for (const emoji of reacts) {
        await yonz.sendMessage(m.chat, {
            react: { text: emoji, key: m.key }
        });
        await new Promise(r => setTimeout(r, 10));
    }

    const menus = {
        "allmenu": global.allmenu,
        "menu-ai": global.menuai,
        "menu-stk": global.menustk,
        "menu-enc": global.menuenc,
        "menu-owner": global.menuowner,
        "menu-maker": global.menumaker,
        "menu-potoanime": global.potoanime,
        "menu-shop": global.menustore,
        "menu-store": global.menustore,
        "menu-group": global.menugroup,
        "menu-anime": global.menuanime,
        "menu-nsfw": global.menunsfw,
        "menu-panel": global.menupanel,
        "menu-cecan": global.menucecan,
        "menu-islami": global.menuislam,
        "menu-ehpoto": global.menuephoto,
        "menu-rpg": global.menurpg,
        "menu-game": global.menugame,
        "menu-search": global.menusearch,
        "menu-download": global.menudownload,
        "menu-fun": global.menufun,
        "menu-tools": global.menutools,
        "menu-primbon": global.menuprimbon,
        "menu-stickers": global.menusticker
    }

    const textMenu = menus[command] || global.allmenu || "Menu tidak tersedia."

    await sendMenuVersion(getMenuStyle(), textMenu)

    await yonz.sendMessage(m.chat, {
        audio: { url: './media/yonz.mp3' },
        mimetype: 'audio/mp4',
        ptt: false
    })
}
break;



case "leave": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)
    await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
    await sleep(4000)
    await yonz.groupLeave(m.chat)
}
break

case "resetlinkgc": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    await yonz.groupRevokeInvite(m.chat)
    m.reply("Berhasil mereset link grup ✅")
}
break

case "tagall": {
    if (!m.isGroup) return Reply(mess.group)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text) return m.reply(example("pesannya"))
    let teks = text+"\n\n"
    let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
    await member.forEach((e) => {
        teks += `@${e.split("@")[0]}\n`
    })
    await yonz.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

case "linkgc": {
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    const urlGrup = "https://chat.whatsapp.com/" + await yonz.groupInviteCode(m.chat)
    var teks = `${urlGrup}`
    await yonz.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

case "ht": 
case "hidetag": {
    if (!m.isGroup) return Reply(mess.group)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text) return m.reply(example("pesannya"))
    let member = m.metadata.participants.map(v => v.id)
    await yonz.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

case "joingc": 
case "join": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return m.reply(example("linkgcnya"))
    if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
    let result = text.split('https://chat.whatsapp.com/')[1]
    let id = await yonz.groupAcceptInvite(result)
    m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

case "get": 
case "g": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return m.reply(example("https://example.com"))
    let data = await fetchJson(text)
    m.reply(JSON.stringify(data, null, 2))
}
break



case "closegc": 
case "close": 
case "opengc": 
case "open": {
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (/open|opengc/.test(command)) {
        if (m.metadata.announce == false) return 
        await yonz.groupSettingUpdate(m.chat, 'not_announcement')
    } else if (/closegc|close/.test(command)) {
        if (m.metadata.announce == true) return 
        await yonz.groupSettingUpdate(m.chat, 'announcement')
    } else {}
}
break

case "demote":
case "promote": {
    if (!m.isGroup) return Reply(mess.group)
    if (!m.isBotAdmin) return Reply(mess.botAdmin)
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (m.quoted || text) {
        var action
        let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
        if (/demote/.test(command)) action = "Demote"
        if (/promote/.test(command)) action = "Promote"
        await yonz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
            await yonz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
        })
    } else {
        return m.reply(example("@tag/6285###"))
    }
}
break

case 'addcase': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh: .addcase *casenya*`);

    // Bersihkan kata "addcase" kalau ikut kebawa di awal text
    const cleanText = text.replace(/^addcase\s+/i, '').trim();
    if (!cleanText) return Reply(`Contoh: .addcase *casenya*`);

    const namaFile = path.join(__dirname, 'yonz-cmd.js');
    const caseBaru = `${cleanText}\n\n`;

    const tambahCase = (data, caseBaru) => {
        const posisiDefault = data.lastIndexOf("default:");
        if (posisiDefault !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
            return { success: true, kodeBaruLengkap };
        } else {
            return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
        }
    };

    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err);
            return Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
        }
        const result = tambahCase(data, caseBaru);
        if (result.success) {
            fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Terjadi kesalahan saat menulis file:', err);
                    return Reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
                } else {
                    console.log('Sukses menambahkan case baru:');
                    console.log(caseBaru);
                    return Reply('Sukses menambahkan case!');
                }
            });
        } else {
            console.error(result.message);
            return Reply(result.message);
        }
    });
}
break

case 'delcase': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh: .delcase nama_case`);

    const fs = require('fs').promises;

    async function removeCase(filePath, caseNameToRemove) {
        try {
            let data = await fs.readFile(filePath, 'utf8');
            const regex = new RegExp(`case\\s+['"\`]${caseNameToRemove}['"\`]:[\\s\\S]*?break;?`, 'g');
            
            const modifiedData = data.replace(regex, '');

            if (data === modifiedData) {
                return Reply(`❌ Case "${caseNameToRemove}" tidak ditemukan.\n\nPastikan penulisan sudah benar dan tidak ada typo.`);
            }

            await fs.writeFile(filePath, modifiedData, 'utf8');
            Reply(`✅ Sukses menghapus case: *${caseNameToRemove}*`);
        } catch (err) {
            Reply(`Terjadi kesalahan saat memproses file: ${err.message}`);
        }
    }
    removeCase(__dirname + '/yonz-cmd.js', text.trim().split(/\s+/).pop());
}
break;

case 'addprem':
case 'addpremium': {
 if (!isCreator) return Reply(mess.owner);

 let days = Number(args[args.length - 1]);
 if (isNaN(days) || days <= 0) days = 30;
 if (days > 365) return Reply('❌ Maksimal 365 hari!');

 let users = [];

 if (m.isGroup) {
 if (m.mentionedJid.length) {
 users = m.mentionedJid.map(id => {
 if (id.endsWith('@lid')) {
 let p = m.metadata.participants?.find(x => x.id === id || x.lid === id);
 return p ? p.jid : null;
 }
 return id;
 }).filter(Boolean);
 } else if (m.quoted) {
 users = [m.quoted.sender];
 } else {
 let nomor = args[0]?.replace(/[^0-9]/g, '');
 if (!nomor) return Reply(`Contoh:\n${prefix}addprem 6285xxxx 30 atau ${prefix}addprem @tag 30\nAtau reply pesan target.`);
 users = [nomor + '@s.whatsapp.net'];
 }
 } else {
 if (m.quoted) {
 users = [m.quoted.sender];
 } else {
 let nomor = args[0]?.replace(/[^0-9]/g, '');
 if (!nomor) return Reply(`Contoh:\n${prefix}addprem 6285xxxx 30`);
 users = [nomor + '@s.whatsapp.net'];
 }
 }

 if (!users.length) return Reply('❌ Tidak ada pengguna yang valid.');

 const ms = days * 24 * 60 * 60 * 1000;
 const expired = Date.now() + ms;

 let prem = [];
 try {
 const data = fs.readFileSync("./library/database/premium.json");
 prem = JSON.parse(data);
 } catch (e) {
 prem = [];
 }

 for (let jid of users) {
 const user = prem.find(u => u && u.jid === jid);
 const number = jid.split('@')[0];
 if (user) {
 user.expired = expired;
 user.addedBy = m.sender;
 user.addedAt = Date.now();
 // Tambahkan number jika belum ada (untuk kompatibilitas data lama)
 if (!user.number) user.number = number;
 } else {
 prem.push({
 jid,
 number,
 expired,
 addedBy: m.sender,
 addedAt: Date.now()
 });
 }
 }

 fs.writeFileSync("./library/database/premium.json", JSON.stringify(prem, null, 2));

 // Tampilkan hanya nomor, tanpa tag/mention
 const listNomor = users.map(j => j.split('@')[0]).join(', ');
 Reply(`✅ Premium ${listNomor} ditambahkan selama ${days} hari.`);
}
break;

case "public": {
    if (!isCreator) return
    yonz.public = true
    global.db.settings.isPublic = true
    m.reply("Berhasil mengganti ke mode *public*")
}
break



case "resetdb": 
case "rstdb": {
    if (!isCreator) return Reply(mess.owner)
    for (let i of Object.keys(global.db)) {
        global.db[i] = {}
    }
    m.reply("Berhasil mereset database ✅")
}
break

case "setppbot": {
    if (!isCreator) return Reply(mess.owner)
    if (/image/g.test(mime)) {
        var medis = await yonz.downloadAndSaveMediaMessage(qmsg)
        if (args[0] && args[0] == "panjang") {
            const { img } = await generateProfilePicture(medis)
            await yonz.query({
                tag: 'iq',
                attrs: {
                    to: botNumber,
                    type:'set',
                    xmlns: 'w:profile:picture'
                },
                content: [
                    {
                        tag: 'picture',
                        attrs: { type: 'image' },
                        content: img
                    }
                ]
            })
            await fs.unlinkSync(medis)
            m.reply("Berhasil mengganti foto profil bot ✅")
        } else {
            await yonz.updateProfilePicture(botNumber, {content: medis})
            await fs.unlinkSync(medis)
            m.reply("Berhasil mengganti foto profil bot ✅")
        }
    } else return m.reply(example('dengan mengirim foto'))
}
break

case "clearchat": 
case "clc": {
    if (!isCreator) return Reply(mess.owner)
    yonz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

case "listowner": 
case "listown": {
    if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
    let teks = `\n *乂 List all owner tambahan*\n`
    for (let i of owners) {
        teks += `\n* ${i.split("@")[0]}\n* *Tag :* @${i.split("@")[0]}\n`
    }
    yonz.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

case "delowner": 
case "delown": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.quoted && !text) return m.reply(example("6285###"))
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    const input2 = input.split("@")[0]
    if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
    if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
    let posi = owners.indexOf(input)
    await owners.splice(posi, 1)
    await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
    m.reply(`Berhasil menghapus owner ✅`)
}
break

case "addowner": 
case "addown": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.quoted && !text) return m.reply(example("6285###"))
    const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    const input2 = input.split("@")[0]
    if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
    owners.push(input)
    await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
    m.reply(`Berhasil menambah owner ✅`)
}
break

case 'addcase': {
    if (!isOwner) return Reply('❌ Hanya owner!')

    const fs = require('fs')
    const path = require('path')

    const namaFile = path.join(__dirname, 'yonz-cmd.js')

    let caseBaru = ''

    if (m.quoted) {

        caseBaru =
            m.quoted.text ||
            m.quoted.caption ||
            m.quoted.description ||
            ''

    }

    if (!caseBaru && text) {
        caseBaru = text
    }

    if (!caseBaru) {
        return Reply(`
Contoh penggunaan:

1. Manual
.addcase case 'test': {
 Reply('ok')
}
break

2. Reply pesan case lalu ketik
.addcase
`)
    }

    caseBaru = caseBaru.trim() + '\n\n'

    const tambahCase = (data, caseBaru) => {

        const posisiDefault = data.lastIndexOf('default:')

        if (posisiDefault === -1) {
            return {
                success: false,
                message: 'Tidak menemukan default:'
            }
        }

        const kodeBaruLengkap =
            data.slice(0, posisiDefault) +
            caseBaru +
            data.slice(posisiDefault)

        return {
            success: true,
            kodeBaruLengkap
        }
    }

    fs.readFile(namaFile, 'utf8', (err, data) => {

        if (err) {
            console.error(err)
            return Reply(`❌ Error membaca file\n${err.message}`)
        }

        const result = tambahCase(data, caseBaru)

        if (!result.success) {
            return Reply(result.message)
        }

        fs.writeFile(
            namaFile,
            result.kodeBaruLengkap,
            'utf8',
            (err) => {

                if (err) {
                    console.error(err)
                    return Reply(`❌ Error menulis file\n${err.message}`)
                }

                console.log('[ ADDCASE ] sukses')
                console.log(caseBaru)

                Reply('✅ Sukses menambahkan case baru')
            }
        )
    })
}
break

case 'delcase': {
    if (!isCreator) return Reply(mess.owner);
    if (!text) 
        return Reply(`Contoh: .delcase nama_case`);

    const fs = require('fs').promises;

    async function removeCase(filePath, caseNameToRemove) {
        try {
            let data = await fs.readFile(filePath, 'utf8');
            
            const regex = new RegExp(`case\\s+['"\`]${caseNameToRemove}['"\`]:[\\s\\S]*?break;?`, 'g');
            
            const modifiedData = data.replace(regex, '');

            if (data === modifiedData) {
                return Reply(`❌ Case "${caseNameToRemove}" tidak ditemukan.\n\nPastikan penulisan sudah benar dan tidak ada typo.`);
            }

            await fs.writeFile(filePath, modifiedData, 'utf8');
            Reply(`✅ Sukses menghapus case: *${caseNameToRemove}*`);
        } catch (err) {
            Reply(`Terjadi kesalahan saat memproses file: ${err.message}`);
        }
    }

    removeCase('./yonz-cmd.js', text.trim());
}
break;

case "play": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (!text) return Reply(example("melukis senja"));

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

 try {
 const ytsSearch = await yts(text);
 const videos = ytsSearch.videos.slice(0, 10);

 if (!videos.length) return Reply(`❌ Lagu "${text}" tidak ditemukan`);

 const video = videos[0];

 const laguList = videos.map((v, i) => ({
 title: v.title.length > 35 ? v.title.substring(0, 35) + '...' : v.title,
 duration: v.timestamp || 'Unknown',
 popularity: v.views ? v.views.toLocaleString() + ' views' : 'Unknown',
 url: v.url
 }));

 const caption = `╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ Channel : ${video.author?.name || 'Unknown'}
┆𖢷 ׁ 𖹭₊ Durasi : ${video.timestamp || '-'}
┆𖢷 ׁ 𖹭₊ Views : ${video.views || '-'}
┆𖢷 ׁ 𖹭₊ Upload : ${video.ago || 'Unknown'}
╰─╼𔕬─┈───┈───┈`;

 await yonz.sendMessage(m.chat, {
 image: { url: video.thumbnail },
 caption: caption,
 footer: `*${global.botname}*`,
 buttons: [
 {
 buttonId: 'youtubePilih',
 buttonText: { displayText: 'Pilih Lagu' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'Hasil Pencarian YouTube',
 sections: [
 {
 title: 'Daftar Video',
 rows: laguList.map((lagu, i) => ({
 title: `${i + 1}. ${lagu.title}`,
 description: `Durasi: ${lagu.duration} | Views: ${lagu.popularity}`,
 id: `${prefix}playmusik ${lagu.url}`
 }))
 }
 ]
 })
 }
 }
 ],
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 }
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error('[PLAY ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break





case "kick":
case "kik": {
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 if (!m.isBotAdmin) return Reply(mess.botAdmin);
 let users = []
 if (m.isGroup) {
 if (m.mentionedJid.length) {
 users = m.mentionedJid.map(id => {
 if (id.endsWith('@lid')) {
 let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
 return p ? p.jid : null
 } else {
 return id
 }
 }).filter(Boolean)
 } else if (m.quoted) {
 users = [m.quoted.sender]
 } else if (text) {
 users = [text.replace(/[^0-9]/g, '') + '@s.whatsapp.net']
 }
 }

 if (!users.length) return Reply(`❌ *Tag, reply, atau tulis nomor yang mau dikick!*\n\nContoh:\n${prefix}kick @tag\n${prefix}kick 628xxxx\n${prefix}kick (reply pesan orang)`);
 for (let user of users) {
 let onWa = await yonz.onWhatsApp(user.split("@")[0])
 if (!onWa?.length) {
 Reply(`⚠️ Nomor *${user.split("@")[0]}* tidak terdaftar di WhatsApp!`)
 continue
 }
 try {
 await yonz.groupParticipantsUpdate(m.chat, [user], 'remove')
 await sleep(800)
 await Reply(`✅ Berhasil mengeluarkan *@${user.split('@')[0]}*`, { mentions: [user] })
 } catch (e) {
 Reply(`❌ Gagal mengeluarkan *@${user.split('@')[0]}*`, { mentions: [user] })
 }
 }
}
break;

















case "addsticker": {
 if (!isCreator) return Reply(mess.creator);
 if (!m.quoted) return Reply("❌ Reply stiker yang ingin disimpan!");
 if (!text) return Reply(`Contoh:\n${prefix + command} bot`);

 const fs = require("fs");
 const path = require("path");

 // Hilangkan nama command dari text
 const name = text
 .replace(new RegExp(`^${command}\\s*`, "i"), "")
 .trim()
 .replace(/[^a-zA-Z0-9_-]/g, "");

 if (!name) return Reply("❌ Masukkan nama stiker!");

 const folder = "./source/media/sticker";

 if (!fs.existsSync(folder)) {
 fs.mkdirSync(folder, { recursive: true });
 }

 const filePath = path.join(folder, `${name}.webp`);

 try {
 const buffer = await m.quoted.download();

 if (!buffer) return Reply("❌ Gagal mengambil stiker!");

 fs.writeFileSync(filePath, buffer);

 Reply(`✅ Berhasil menyimpan stiker!

📁 File: ${name}.webp
📂 Lokasi: source/media/sticker/${name}.webp`);
 } catch (err) {
 console.error(err);
 Reply(`❌ Terjadi kesalahan:\n${err.message}`);
 }
}
break;







case "owner": {
 const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${global.namaOwner}
ORG:${global.botname2} Official
TEL;type=CELL;waid=${global.owner}:${global.owner}
EMAIL:developer@${global.botname2.toLowerCase().replace(/\s+/g,'')}.com
URL:${global.linkSaluran}
END:VCARD`;

 await yonz.sendMessage(m.chat, {
 contacts: {
 displayName: global.namaOwner,
 contacts: [{ vcard }]
 }
 }, { quoted: m });
}
break;



case "sch":
case "sendch":
case "kirmch": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require("fs");
 const path = require("path");
 const { exec } = require("child_process");
 const { promisify } = require("util");
 const execPromise = promisify(exec);

 try {
 const args = text.trim().split(/\s+/);
 const CH_LINK = args[0];
 const caption = args.slice(1).join(" ");

 const linkRegex = /https:\/\/whatsapp\.com\/channel\/([\w\-]+)/i;
 const match = CH_LINK ? CH_LINK.match(linkRegex) : null;

 if (!match) {
 return Reply(
`╭─➤ 𝗨𝗽𝗹𝗼𝗮𝗱 𝗖𝗵𝗮𝗻𝗻𝗲𝗹
│ Format : ${prefix + command} link_saluran teks
│ Contoh : ${prefix + command} https://whatsapp.com/channel/xxx Halo
╰──────────➤`
 );
 }

 const inviteCode = match[1];

 await yonz.sendMessage(m.chat, {
 react: { text: "⏳", key: m.key }
 });

 let CH_ID = null;

 // === FIX: amanin metadata channel ===
 try {
 if (typeof yonz.newsletterMetadata === "function") {
 const meta = await yonz.newsletterMetadata("invite", inviteCode);
 CH_ID = meta?.id;
 } else {
 throw new Error("newsletterMetadata not supported");
 }
 } catch (errMeta) {
 console.log("[SCH META ERROR]", errMeta);

 await yonz.sendMessage(m.chat, {
 react: { text: "❌", key: m.key }
 });

 return Reply(
`❌ Gagal ambil info channel.

Kemungkinan:
• Bot belum join channel
• Link invite tidak valid
• Fitur newsletterMetadata tidak support di versi Baileys kamu`
 );
 }

 if (!CH_ID) {
 return Reply("❌ Channel ID tidak ditemukan.");
 }

 const qmsg = m.quoted ? m.quoted : m;
 const mime = (qmsg.msg || qmsg).mimetype || "";

 // === TEXT ===
 if (!mime) {
 if (!caption) {
 return Reply("❌ Masukkan teks atau reply media.");
 }

 await yonz.sendMessage(CH_ID, { text: caption });

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Teks berhasil dikirim ke saluran");
 }

 const media = await qmsg.download();

 if (!media) {
 return Reply("❌ Gagal download media.");
 }

 // === IMAGE ===
 if (/image/.test(mime)) {
 await yonz.sendMessage(CH_ID, {
 image: media,
 caption: caption || ""
 });

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Foto berhasil dikirim ke saluran");
 }

 // === VIDEO ===
 if (/video/.test(mime)) {
 await yonz.sendMessage(CH_ID, {
 video: media,
 caption: caption || ""
 });

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Video berhasil dikirim ke saluran");
 }

 // === AUDIO ===
 if (/audio/.test(mime)) {
 const tmpDir = path.join(__dirname, "tmp");
 if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

 const fileName = Date.now();
 const inputPath = path.join(tmpDir, `audio_${fileName}`);
 const outputPath = path.join(tmpDir, `audio_${fileName}.opus`);

 fs.writeFileSync(inputPath, media);

 try {
 await execPromise(
 `ffmpeg -i "${inputPath}" -c:a libopus -b:a 32k -ar 48000 -ac 1 "${outputPath}" -y`
 );

 const buffer = fs.readFileSync(outputPath);

 if (caption) {
 await yonz.sendMessage(CH_ID, { text: caption });
 }

await yonz.sendMessage(CH_ID, {
 audio: buffer,
 mimetype: "audio/ogg; codecs=opus",
 ptt: false
});

 fs.unlinkSync(inputPath);
 fs.unlinkSync(outputPath);

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });

 return Reply("✅ Audio berhasil dikirim ke saluran");

 } catch (err) {
 console.log("[AUDIO ERROR]", err);

 if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
 if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);

 return Reply("❌ Gagal proses audio ffmpeg");
 }
 }

 return Reply("❌ Format tidak didukung");

 } catch (e) {
 console.log("[SCH ERROR]", e);

 await yonz.sendMessage(m.chat, {
 react: { text: "❌", key: m.key }
 });

 return Reply("❌ Terjadi kesalahan saat kirim ke saluran");
 }
}
break;

case "rvo": case "readviewonce": {
if (!isRegistered(m.sender) && !isCreator)
 return Reply(global.mess.verifikasi);
if (!global.isPrem(m.sender) && !isCreator) 
 return Reply(mess.prem);
if (!m.quoted) return Reply(example("dengan reply pesannya"))
let msg = m.quoted.message
 let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return Reply("Pesan itu bukan viewonce!")
 let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }
 if (/video/.test(type)) {
 return yonz.sendMessage(m.chat, {video: buffer, caption: mess.done}, {quoted: m})
} else if (/image/.test(type)) {
 return yonz.sendMessage(m.chat, {image: buffer, caption: mess.done}, {quoted: m})
} else if (/audio/.test(type)) {
 return yonz.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: false}, {quoted: m})
 } 
}
break











case 'totalfitur': {
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 const fs = require('fs');
 const path = require('path');

 const caseFile = path.join(__dirname, './yonz-cmd.js');
 const pluginsDir = path.join(__dirname, './plugins');

 let totalCase = 0;
 let totalPlugin = 0;

 if (fs.existsSync(caseFile)) {
 const content = fs.readFileSync(caseFile, 'utf8');
 totalCase = (content.match(/case\s+['"`]/g) || []).length;
 }

 const countJsFiles = (dir) => {
 let count = 0;
 const files = fs.readdirSync(dir);
 for (const file of files) {
 const fullPath = path.join(dir, file);
 if (fs.statSync(fullPath).isDirectory()) {
 count += countJsFiles(fullPath);
 } else if (file.endsWith('.js')) {
 count++;
 }
 }
 return count;
 };

 if (fs.existsSync(pluginsDir)) {
 totalPlugin = countJsFiles(pluginsDir);
 }

 const totalFitur = totalCase + totalPlugin;
 const kanjiIcon = '╼ ׅ ֹ𔖰᷼𔖮';

 const bodyText =
`${kanjiIcon} *TOTAL FITUR ${global.botname2}*
╭╼─┈───┈──⏣╼
┆𖢷 ׁ 𖹭₊ CASE : *${totalCase}*
┆𖢷 ׁ 𖹭₊ PLUGIN : *${totalPlugin}*
┆𖢷 ׁ 𖹭₊ TOTAL : *${totalFitur} Fitur*
╰─╼𔕬─┈───┈───┈`;

 try {
 const btnTotal = new yonz.ButtonV2(yonz);
 btnTotal.setBody(bodyText)
 .setFooter(`*Powered by ${global.namaOwner}*`)
 .setThumbnail(global.image.menu)
 .addRawButton({
 buttonText: { displayText: `📋 MENU` },
 buttonId: '.menu',
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: `👑 OWNER` },
 buttonId: 'totalfitur_owner',
 type: 1,
 nativeFlowInfo: {
 name: 'cta_url',
 paramsJson: JSON.stringify({
 display_text: '👑 Owner',
 url: global.linkOwner
 })
 }
 });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 await btnTotal.send(m.chat);
 } catch (err) {
 console.log('totalfitur buttonv2 error', err);
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(bodyText);
 }
}
break;

case "restart":
case "rst": {
if (!isCreator) return Reply(mess.owner)
await Reply("Memproses _restart server_ . . .")

try {
 var file = await fs.readdirSync("./session")
 var anu = await file.filter(i => i !== "creds.json")
 for (let t of anu) {
 try {
 await fs.unlinkSync(`./session/${t}`)
 } catch {}
 }
 
 if (typeof process.send === 'function') {
 await process.send('reset')
 } else {
 await Reply("✅ Session dibersihkan! Bot restart...")
 setTimeout(() => {
 process.exit(1)
 }, 2000)
 }
 
} catch (e) {
 await Reply(`❌ Error: ${e.message}`)
}
}
break


case 'getcase': {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(`Contoh: .getcase nama_case`);

 const cleanText = text.replace(/^getcase\s+/i, '').trim();
 if (!cleanText) return Reply(`Contoh: .getcase nama_case`);

 const fs = require('fs').promises;

 async function getCase(filePath, caseName) {
 try {
 let data = await fs.readFile(filePath, 'utf8');

 const regex = new RegExp(`case\\s+['"\`]${caseName}['"\`]:[\\s\\S]*?break;?`, 'i');
 const match = data.match(regex);

 if (!match) {
 return Reply(`❌ Case "${caseName}" tidak ditemukan.`);
 }

 const caseCode = match[0];

 const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `📋 *Case ${caseName}* berhasil ditemukan. Klik tombol di bawah untuk menyalin.`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered by ${global.namaOwner}`
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: true,
 imageMessage: (await prepareWAMessageMedia(
 { image: { url: global.image.menu } },
 { upload: yonz.waUploadToServer }
 )).imageMessage
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: "Salin Case",
 copy_code: caseCode
 })
 }
 ]
 })
 })
 }
 }
 }, {});

 await yonz.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

 } catch (err) {
 Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
 }
 }

 getCase(path.join(__dirname, 'yonz-cmd.js'), cleanText);
}
break;



case 'addfile':
case 'upload':
case 'uploadfile':
case 'upfile': {
 if (!isOwner) return Reply(mess.creator);
 if (!m.quoted) return Reply(`📌 reply file yang mau di upload terus ketik foldernya`)
 if (!text) return Reply(`📌 contoh nya: *${prefix + command} library/database*\nketik ${prefix + command} *.* atau *root* buat upload ke folder utama`)
 try {
 const type = m.quoted.mtype || Object.keys(m.quoted.message || {})[0] || ''
 const msg = m.quoted.message?.[type] || m.quoted.msg || m.quoted
 let downloadType = 'document'
 let ext = '.bin'
 let [inputFolder, inputName] = text.split(' ')
 const folderTarget = inputFolder.trim()

 if (/image/i.test(type)) {
 downloadType = 'image'
 ext = '.jpg'
 if (inputName && !/\.(jpg|jpeg|png)$/i.test(inputName)) return Reply(`media ini jenis gambar, format harus .jpg/.jpeg/.png`)
 } else if (/video/i.test(type)) {
 downloadType = 'video'
 ext = '.mp4'
 if (inputName && !/\.(mp4)$/i.test(inputName)) return Reply(`media ini jenis video, format harus .mp4`)
 } else if (/audio/i.test(type)) {
 downloadType = 'audio'
 ext = '.mp3'
 if (inputName && !/\.(mp3|opus)$/i.test(inputName)) return Reply(`media ini jenis audio, format harus .mp3/.opus`)
 } else if (/document/i.test(type)) {
 downloadType = 'document'
 } else {
 return Reply(`❌ yang kamu reply harus type dokumen, gambar, audio, video`)
 }

 const fileName = inputName ? inputName : (msg.fileName || `upload_${Date.now()}${ext}`)
 const targetDir = (folderTarget === '.' || folderTarget === 'root') ? process.cwd() : path.join(process.cwd(), folderTarget)
 const fullPath = path.join(targetDir, fileName)

 if (!fs.existsSync(targetDir)) {
 fs.mkdirSync(targetDir, { recursive: true })
 }

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

 const stream = await downloadContentFromMessage(msg, downloadType)
 let buffer = Buffer.from([])
 for await (const chunk of stream) {
 buffer = Buffer.concat([buffer, chunk])
 }
 fs.writeFileSync(fullPath, buffer)

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

 Reply(`🚀 *Media Berhasil Di Upload*\n\n📁 *Folder:* ${folderTarget === '.' || folderTarget === 'root' ? 'Root (Utama)' : folderTarget}\n📄 *Nama:* ${fileName}\n📍 *Full Path:* ${fullPath}`)
 } catch (err) {
 console.error(err)
 Reply(`❌ gagal upload: ${err.message}`)
 }
}
break










case 'dana':
case 'fakedana': {
 if (!text) return Reply(`Contoh: ${prefix + command} 10000`)

 const saldo = text.replace(/[.,]/g, '')
 if (isNaN(saldo)) return Reply('Saldo harus berupa angka.')

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/canvas/dana?saldo=${saldo}&apikey=Yonz`

 await yonz.sendMessage(m.chat, {
 image: { url: apiUrl },
 caption: `💰 Saldo Dana: Rp${parseInt(saldo).toLocaleString('id-ID')}`
 }, { quoted: m })

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'asahotak':
case 'asotak': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/asahotak`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban } = json.result

 global.game[m.chat] = {
 type: 'single',
 soal,
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 penanya: m.sender,
 waktu: 60000
 }

 await Reply(`🧠 *ASAH OTAK*\n\n${soal}\n\n⏱️ Waktu: 60 detik\nJawab dengan mengetik jawabannya langsung.\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'tebakgambar':
case 'tebakgbr': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/tebakgambar`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { img, jawaban, deskripsi } = json.result

 global.game[m.chat] = {
 type: 'single',
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 deskripsi,
 penanya: m.sender,
 waktu: 60000
 }

 await yonz.sendMessage(m.chat, {
 image: { url: img },
 caption: `🖼️ *TEBAK GAMBAR*\n\nTebak gambar di atas!\n⏱️ Waktu: 60 detik\nMenyerah? Ketik *.nyerah*`
 }, { quoted: m })

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*${deskripsi ? `\nKeterangan: ${deskripsi}` : ''}` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'lengkapikalimat':
case 'lengkapi': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/lengkapikalimat`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban } = json.result

 global.game[m.chat] = {
 type: 'single',
 soal,
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 penanya: m.sender,
 waktu: 60000
 }

 await Reply(`✏️ *LENGKAPI KALIMAT*\n\n${soal}\n\n⏱️ Waktu: 60 detik\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'caklontong':
case 'cak': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/caklontong`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban, deskripsi } = json.result

 global.game[m.chat] = {
 type: 'single',
 soal,
 jawaban: String(jawaban).toLowerCase(),
 jawabanAsli: jawaban,
 deskripsi,
 penanya: m.sender,
 waktu: 60000
 }

 await Reply(`🤔 *CAK LONTONG*\n\n${soal}\n\n⏱️ Waktu: 60 detik\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis! Jawaban yang benar: *${jawaban}*${deskripsi ? `\nKeterangan: ${deskripsi}` : ''}` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'family100':
case 'f100': {
 try {
 if (!global.game) global.game = {}
 if (global.game[m.chat]) return Reply('Masih ada soal yang belum dijawab di chat ini! Ketik *.nyerah* untuk menyerah.')

 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const apiUrl = `${global.there}/game/family100`
 const res = await fetch(apiUrl)
 const json = await res.json()

 if (!json.status) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil soal.')
 }

 const { soal, jawaban } = json.result
 const daftarJawaban = Array.isArray(jawaban) ? jawaban : [jawaban]

 global.game[m.chat] = {
 type: 'family100',
 soal,
 jawabanList: daftarJawaban.map(j => String(j).toLowerCase()),
 jawabanAsli: daftarJawaban,
 found: [],
 penanya: m.sender,
 waktu: 90000
 }

 await Reply(`👨‍👩‍👧‍👦 *FAMILY 100*\n\n${soal}\n\nAda *${daftarJawaban.length}* jawaban, sebutkan satu-satu!\n⏱️ Waktu: 90 detik\nMenyerah? Ketik *.nyerah*`)

 global.game[m.chat].timeout = setTimeout(() => {
 if (global.game[m.chat]) {
 const sisa = global.game[m.chat].jawabanAsli.filter((_, i) => !global.game[m.chat].found.includes(i))
 yonz.sendMessage(m.chat, { text: `⏰ Waktu habis!\nJawaban yang belum ketebak:\n${sisa.map(j => `• ${j}`).join('\n')}` })
 delete global.game[m.chat]
 }
 }, global.game[m.chat].waktu)

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.log(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
 break
}

case 'nyerah':
case 'give': {
 if (!global.game || !global.game[m.chat]) return Reply('Gak ada soal yang lagi aktif di chat ini.')

 const dataGame = global.game[m.chat]
 clearTimeout(dataGame.timeout)

 if (dataGame.type === 'family100') {
 const sisa = dataGame.jawabanAsli.filter((_, i) => !dataGame.found.includes(i))
 await Reply(`🏳️ Nyerah!\nJawaban yang belum ketebak:\n${sisa.map(j => `• ${j}`).join('\n')}`)
 } else {
 await Reply(`🏳️ Nyerah! Jawaban yang benar adalah *${dataGame.jawabanAsli}*${dataGame.deskripsi ? `\nKeterangan: ${dataGame.deskripsi}` : ''}`)
 }

 delete global.game[m.chat]
 break
}



case "h":
case "totag":
case "hidetag": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess?.verifikasi);
 if (checkLimit(m.sender, global.isPrem?.(m.sender), isCreator)) return Reply(global.mess?.limit || "Limit habis.");
 addLimit(m.sender, global.isPrem?.(m.sender), isCreator);
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);

 const members = m.metadata.participants.map(v => v.id);

 const cleanText = (input) => {
 if (!input) return '';
 let txt = input.trim();
 const regex = new RegExp(`^\\${prefix}(h|ht|hidetag)\\s*`, 'i');
 return txt.replace(regex, '').trim();
 };

 let mediaBuffer = null;
 let mimeType = '';
 let captionText = '';
 let fileName = 'file';

 if (m.message?.imageMessage) {
 try {
 const mediaStream = await downloadContentFromMessage(m.message.imageMessage, 'image');
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = m.message.imageMessage.mimetype;
 captionText = cleanText(m.message.imageMessage.caption || text || '');
 } catch (e) {}
 } else if (m.message?.videoMessage) {
 try {
 const mediaStream = await downloadContentFromMessage(m.message.videoMessage, 'video');
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = m.message.videoMessage.mimetype;
 captionText = cleanText(m.message.videoMessage.caption || text || '');
 } catch (e) {}
 } else if (m.message?.documentMessage || m.message?.documentWithCaptionMessage) {
 try {
 let docMsg = m.message.documentMessage || m.message.documentWithCaptionMessage?.message?.documentMessage;
 const mediaStream = await downloadContentFromMessage(docMsg, 'document');
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = docMsg.mimetype;
 fileName = docMsg.fileName || 'document';
 captionText = cleanText(docMsg.caption || text || '');
 } catch (e) {}
 }

 const quoted = m.quoted;
 if (quoted) {
 const quotedMsg = quoted.msg || quoted;
 const quotedMime = quotedMsg.mimetype || '';
 if (quotedMime) {
 let mediaType = 'document';
 if (quotedMime.includes('image')) mediaType = 'image';
 else if (quotedMime.includes('video')) mediaType = 'video';
 try {
 const mediaStream = await downloadContentFromMessage(quotedMsg, mediaType);
 const chunks = [];
 for await (const chunk of mediaStream) chunks.push(chunk);
 mediaBuffer = Buffer.concat(chunks);
 mimeType = quotedMime;
 fileName = quotedMsg.fileName || 'file';
 captionText = cleanText(quotedMsg.caption || quoted.text || text || '');
 } catch (e) {}
 } else if (quoted.text) {
 captionText = cleanText(quoted.text || text || '');
 }
 }

 if (!captionText && !mediaBuffer) {
 captionText = cleanText(text || '');
 }

 if (mediaBuffer) {
 let messageOptions = {
 caption: captionText,
 mentions: members
 };
 if (mimeType.includes('image')) {
 messageOptions.image = mediaBuffer;
 } else if (mimeType.includes('video')) {
 messageOptions.video = mediaBuffer;
 } else {
 messageOptions.document = mediaBuffer;
 messageOptions.mimetype = mimeType;
 messageOptions.fileName = fileName;
 }
 await yonz.sendMessage(m.chat, messageOptions, { quoted: m });
 } else if (captionText) {
 await yonz.sendMessage(m.chat, {
 text: captionText,
 mentions: members
 }, { quoted: m });
 } else {
 return Reply("📌 masukkan teks, atau kirim/reply ke pesan/foto/video/dokumen yang ingin di-hidetag");
 }
}
break;

case "tqto": 
case "listbuyer": {
 await yonz.sendMessage(m.chat, {
 react: {
 text: "🌸",
 key: m.key
 }
 })

 const fs = require("fs")
 const tqtoPath = "./library/database/tqto.json"

 if (!fs.existsSync(tqtoPath)) {
 fs.writeFileSync(tqtoPath, JSON.stringify([]))
 }

 let tqtoData = JSON.parse(fs.readFileSync(tqtoPath))

 const developerData = {
 name: "Yonz Official",
 role: "Developer",
 number: "6285174301390"
 }

 const allData = [
 developerData,
 ...tqtoData.filter(v => v.number !== developerData.number)
 ]

 const {
 proto,
 prepareWAMessageMedia,
 generateWAMessageFromContent
 } = require("@whiskeysockets/baileys")

 const cards = []

 for (const x of allData) {
 let profileUrl = global.image.menu

 try {
 const pp = await yonz.profilePictureUrl(
 `${x.number}@s.whatsapp.net`,
 "image"
 ).catch(() => null)

 if (pp) profileUrl = pp
 } catch {}

 let titleText = `
╭╼─┈───┈──⏣
┆ 〔 ${global.botname} 〕
╰╼─┈───┈──⏣

╰ Nama : ${x.name}
╰ Posisi : ${x.role}

╭╼─┈───┈──⏣
┆ Powered By ${global.namaOwner}
┆ memiliki hak Resmi untuk menjual script √
╰╼─┈───┈──⏣
`.trim()

 cards.push({
 header: await prepareWAMessageMedia(
 {
 image: { url: profileUrl }
 },
 {
 upload: yonz.waUploadToServer
 }
 ),
 title: titleText,
 number: x.number
 })
 }

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "‎"
 }),

 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: cards.map(card => ({
 body: proto.Message.InteractiveMessage.Body.fromObject({}),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({}),

 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: card.title,
 hasMediaAttachment: true,
 ...card.header
 }),

 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: "Contact User",
 url: `https://wa.me/${card.number}`,
 merchant_url: `https://wa.me/${card.number}`
 })
 }
 ]
 })
 }))
 })
 })
 }
 }
 },
 {
 quoted: m,
 userJid: m.sender
 }
 )

 await yonz.relayMessage(
 m.chat,
 msg.message,
 {
 messageId: msg.key.id
 }
 )
}
break





addmenu











case 'addmenu':
case 'addfiturmenu':
case 'addfitur':
case 'delmenu':
case 'delfiturmenu':
case 'delfitur': {
 if (!isOwner) return Reply(mess.creator);

 let isDelete = ['delmenu', 'delfiturmenu', 'delfitur'].includes(command.toLowerCase())
 let cmdAliases = ['addmenu', 'addfiturmenu', 'addfitur', 'delmenu', 'delfiturmenu', 'delfitur']

 let cleanText = text ? text.trim() : ''
 let firstWord = cleanText.split(' ')[0]?.toLowerCase()
 if (cmdAliases.includes(firstWord)) {
 cleanText = cleanText.split(' ').slice(1).join(' ')
 }

 if (!cleanText) return Reply(`📌 ketik nama kategori dan fiturnya\ncontoh: *${prefix + command} owner addowner, delowner*`)
 let [kategori, ...rest] = cleanText.split(' ')
 let fiturInput = rest.join(' ')
 if (!kategori || !fiturInput) return Reply(`📌 format salah\ncontoh: *${prefix + command} owner addowner, delowner*`)

 const filePath = './menu-yonz.js'
 if (!fs.existsSync(filePath)) return Reply(`❌ file menu *${filePath}* ga ada didaftar menu`)

 try {
 let content = fs.readFileSync(filePath, 'utf8')
 let varName = `global.menu${kategori.toLowerCase()}`
 if (!content.includes(varName)) return Reply(`❌ kategori *${varName}* ga ada di file, coba cek lagi tulisannya!`)

 let regex = new RegExp(`(${varName}\\s*=\\s*\`[\\s\\S]*?)\``)
 let match = content.match(regex)
 if (!match) return Reply(`❌ gagal nemuin pola list menu *${varName}* nya`)
 let blockMenu = match[1]
 let fiturArray = fiturInput.split(',').map(v => v.trim().replace(/^\./, ''))

 if (isDelete) {
 // ==== MODE DELETE ====
 let notFound = []
 let updatedBlock = blockMenu
 for (let f of fiturArray) {
 let lineRegex = new RegExp(`\\n?┆𖢷 ׁ 𖹭₊ \\.${f}(?=\\n|$)`)
 if (lineRegex.test(updatedBlock)) {
 updatedBlock = updatedBlock.replace(lineRegex, '')
 } else {
 notFound.push(f)
 }
 }
 if (updatedBlock === blockMenu) return Reply(`❌ fitur *${fiturArray.join(', ')}* ga ketemu di kategori *${varName}*`)
 content = content.replace(blockMenu, updatedBlock)
 fs.writeFileSync(filePath, content)
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
 let berhasil = fiturArray.filter(f => !notFound.includes(f))
 Reply(`🚀 *Sukses Hapus Menu ${global.botname}*\n\n📂 *Kategori:* ${varName}\n🗑️ *Fitur Dihapus:* ${berhasil.join(', ') || '-'}${notFound.length ? `\n⚠️ *Ga Ketemu:* ${notFound.join(', ')}` : ''}`)

 } else {
 // ==== MODE ADD ====
 let footer = '╰➤-------------------------------'
 let newFeaturesBlock = fiturArray.map(f => `┆𖢷 ׁ 𖹭₊ .${f}`).join('\n')
 let updatedBlock
 if (blockMenu.includes(footer)) {
 updatedBlock = blockMenu.replace(footer, `${newFeaturesBlock}\n${footer}`)
 } else {
 updatedBlock = `${blockMenu}\n${newFeaturesBlock}`
 }
 content = content.replace(blockMenu, updatedBlock)
 fs.writeFileSync(filePath, content)
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
 Reply(`🚀 *Sukses Update Menu ${global.botname}*\n\n📂 *Kategori:* ${varName}\n✨ *Fitur Baru:* ${fiturArray.join(', ')}\n📍 *Status:* ${fiturArray.length} fitur berhasil disisipkan di atas footer`)
 }

 } catch (err) {
 console.error(err)
 Reply(`❌ gagal proses menu: ${err.message}`)
 }}
break

case "cekotak":
case "otakcek":
case "cekotak": {
 let target = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : m.sender)

 const hasil = [
 "🧠 Berdasarkan hasil pemindaian AI, otak @user memiliki tingkat kecerdasan yang sangat tinggi. Cara berpikirnya cepat, logis, mudah memahami hal baru, dan cocok menjadi orang yang memimpin dalam berbagai situasi. Skor kecerdasan: *100%* 🌟",
 
 "🧠 Hasil analisis menunjukkan bahwa @user memiliki otak seorang profesor. Suka berpikir sebelum bertindak, mampu menyelesaikan masalah dengan tenang, dan memiliki wawasan yang luas. Skor kecerdasan: *98%* 🎓",
 
 "🧠 Sistem mendeteksi bahwa @user memiliki pola pikir kreatif dan inovatif. Ide-idenya sering di luar dugaan dan mampu membuat orang lain kagum. Skor kecerdasan: *95%* 💡",
 
 "🧠 Setelah dilakukan pemeriksaan, ternyata @user mempunyai otak seorang programmer. Sabar mencari solusi, teliti, dan tidak mudah menyerah ketika menghadapi masalah. Skor kecerdasan: *92%* 💻",
 
 "🧠 AI mendeteksi bahwa @user mempunyai kemampuan berpikir layaknya seorang detektif. Jeli melihat detail kecil, mudah menemukan petunjuk, dan sulit dibohongi. Skor kecerdasan: *90%* 🕵️",
 
 "🧠 Hasil scan menunjukkan bahwa @user memiliki otak seorang strategist. Selalu memikirkan langkah berikutnya sebelum mengambil keputusan sehingga jarang melakukan kesalahan besar. Skor kecerdasan: *88%* ♟️",
 
 "🧠 Dari seluruh data yang dianalisis, @user termasuk orang yang cepat belajar, mudah beradaptasi, dan memiliki rasa ingin tahu yang tinggi. Skor kecerdasan: *85%* 📚",
 
 "🧠 Pemeriksaan selesai! Otak @user sebenarnya cukup cerdas, hanya saja terkadang lebih memilih rebahan daripada menggunakan seluruh kemampuannya. Skor kecerdasan: *80%* 😴",
 
 "🧠 AI sempat mengalami error saat memindai otak @user karena isinya terlalu banyak meme, candaan, dan pikiran random. Meski begitu tetap memiliki potensi besar. Skor kecerdasan: *75%* 😂",
 
 "🧠 Proses scan selesai! Sistem menyimpulkan bahwa otak @user unik dan sulit diprediksi. Kadang terlihat seperti ilmuwan, kadang seperti NPC, namun justru itulah yang membuatnya berbeda dari yang lain. Skor kecerdasan: *99%* 🤖"
 ]

 let random = hasil[Math.floor(Math.random() * hasil.length)]
 .replace(/@user/g, `@${target.split("@")[0]}`)

 await yonz.sendMessage(m.chat, {
 text: `╭───〔 🧠 *CEK OTAK* 🧠 〕───⬣

${random}

╰────────────────⬣`,
 mentions: [target]
 }, { quoted: m })
}
break



case "cekpasangan":
case "cekjodoh": {
 if (!m.mentionedJid[0]) return Reply(`Tag seseorang!\n\nContoh: ${prefix + command} @628xxxx`)

 let target = m.mentionedJid[0]
 if (target === m.sender) return Reply("❌ Tidak bisa mengecek kecocokan dengan diri sendiri!")

 let nama1 = `@${m.sender.split("@")[0]}`
 let nama2 = `@${target.split("@")[0]}`

 let persen = Math.floor(Math.random() * 101)

 const hasil = [
 "💖 Kalian memang ditakdirkan bersama. Jangan saling menyakiti ya!",
 "🥰 Chemistry kalian sangat kuat. Banyak yang iri melihatnya.",
 "💕 Kalian pasangan yang serasi. Tinggal saling percaya dan menjaga.",
 "😍 Cocok banget! Semoga cepat naik pelaminan. 🤲",
 "💞 Hubungan ini punya peluang besar untuk bertahan lama.",
 "😊 Lumayan cocok, tinggal perbaiki komunikasi saja.",
 "🤝 Kalian lebih cocok jadi sahabat daripada pasangan.",
 "😅 Masih butuh banyak usaha agar hubungan semakin baik.",
 "🙃 Kecocokan masih rendah, jangan menyerah kalau memang serius.",
 "💔 AI mendeteksi kalian kurang cocok, tapi semua kembali kepada usaha kalian."
 ]

 let random = hasil[Math.floor(Math.random() * hasil.length)]

 await yonz.sendMessage(
 m.chat,
 {
 text: `💘 *CEK KECOCOKAN PASANGAN* 💘

❤️ *Pasangan 1:* ${nama1}
💙 *Pasangan 2:* ${nama2}

💞 *Tingkat Kecocokan:* *${persen}%*

${random}`,
 mentions: [m.sender, target]
 },
 { quoted: m }
 )
}
break

case "cekjodoh":
case "jodoh":
case "carijodoh": {
 if (!m.isGroup) return Reply(mess.group)

 let members = participants
 .map(v => v.id)
 .filter(v => v !== botNumber && !v.endsWith("status@broadcast"))

 if (members.length < 2) return Reply("❌ Member grup tidak cukup!")

 let jodoh1 = members[Math.floor(Math.random() * members.length)]
 let jodoh2 = members[Math.floor(Math.random() * members.length)]

 while (jodoh1 === jodoh2) {
 jodoh2 = members[Math.floor(Math.random() * members.length)]
 }

 const persen = Math.floor(Math.random() * 101)

 const hasil = [
 "💖 Wah, kalian cocok banget! Semoga berjodoh sampai pelaminan.",
 "🥰 Chemistry kalian sangat kuat, jangan disia-siakan.",
 "💕 AI mendeteksi aura cinta yang sangat tinggi.",
 "😍 Banyak yang bilang kalian pasangan serasi.",
 "💞 Cocok! Tinggal saling menjaga dan memahami.",
 "😊 Lumayan cocok, tinggal lebih sering komunikasi.",
 "🤝 Kalian lebih cocok jadi partner hidup.",
 "😅 Masih butuh sedikit perjuangan agar makin cocok.",
 "🙃 Kecocokan masih rendah, tapi jodoh tidak ada yang tahu.",
 "💔 AI bilang kurang cocok... tapi takdir bisa berubah."
 ]

 const random = hasil[Math.floor(Math.random() * hasil.length)]

 await yonz.sendMessage(
 m.chat,
 {
 text: `💘 *CEK JODOH* 💘

👤 @${jodoh1.split("@")[0]}
 ❤️
👤 @${jodoh2.split("@")[0]}

💞 *Tingkat Kecocokan:* *${persen}%*

${random}`,
 mentions: [jodoh1, jodoh2]
 },
 { quoted: m }
 )
}
break



case "getpp": {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi)
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit)

 addLimit(m.sender, global.isPrem(m.sender), isCreator)

 let target

 if (m.mentionedJid.length) {
 target = m.mentionedJid[0]
 } else if (m.quoted) {
 target = m.quoted.sender
 } else if (text) {
 let number = text.replace(/[^0-9]/g, "")
 if (!number) return Reply(`Contoh:\n${prefix + command} 628xxxxxxxxxx`)
 target = number + "@s.whatsapp.net"
 } else {
 return Reply(`Contoh:
${prefix + command} @tag
${prefix + command} 628xxxxxxxxxx
atau reply pesan seseorang dengan ${prefix + command}`)
 }

 try {
 await yonz.sendMessage(m.chat, {
 react: {
 text: "⏳",
 key: m.key
 }
 })

 let pp

 try {
 pp = await yonz.profilePictureUrl(target, "image")
 } catch {
 pp = "https://telegra.ph/file/24fa902ead26340f3df2c.png"
 }

 await yonz.sendMessage(m.chat, {
 image: {
 url: pp
 },
 caption: `📸 *Foto Profil Berhasil Diambil*

👤 Target : @${target.split("@")[0]}`,
 mentions: [target]
 }, {
 quoted: m
 })

 await yonz.sendMessage(m.chat, {
 react: {
 text: "✅",
 key: m.key
 }
 })

 } catch (err) {
 console.log(err)

 await yonz.sendMessage(m.chat, {
 react: {
 text: "❌",
 key: m.key
 }
 })

 Reply("❌ Gagal mengambil foto profil.")
 }
}
break







case "me":
case "profile":
case "profil": {
 let pp;
 try {
 pp = await yonz.profilePictureUrl(m.sender, "image");
 } catch {
 pp = "https://telegra.ph/file/24fa902ead26340f3df2c.png";
 }

 const nama = m.pushName || m.name || "Pengguna";
 const nomor = m.sender.split("@")[0];
 const isPremium = global.isPrem ? global.isPrem(m.sender) : false;
 
 const statusText = isCreator ? "🌟 Owner" : isPremium ? "💎 Premium" : "🆓 Gratis";
 const premiumStatus = isPremium ? "✅ Aktif" : "❌ Tidak";
 
 const now = new Date();
 const waktu = now.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

 const caption = `
╔═══════════════
║ 👤 *PROFIL PENGGUNA* 
╠═══════════════
║ 🧑 Nama : ${nama}
║ 📱 Nomor : ${nomor}
║ 👑 Status : ${statusText}
║ ⭐ Premium : ${premiumStatus}
║ 🕐 Waktu : ${waktu}
╚═══════════════

✨ Terima kasih telah menggunakan bot ✨
`;

 await yonz.sendMessage(
 m.chat,
 {
 image: { url: pp },
 caption: caption,
 },
 { quoted: m }
 );
}
break;

case 'unreg':
case 'unregister': {
    if (!global.db.users[m.sender] || !global.db.users[m.sender].registered) {
        return Reply('❌ Kamu belum terdaftar.')
    }
    global.db.users[m.sender].registered = false
    return Reply('✅ Berhasil menghapus pendaftaran kamu.\nKetik *.daftar* untuk daftar lagi.')
}
break;

case 'setdaftar': {
    if (!isCreator) return Reply(mess.owner)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        return Reply(example(`on/off\n\n` +
            `• *on*  = user wajib .daftar dulu sebelum bisa pakai fitur bot\n` +
            `• *off* = semua user langsung bisa pakai bot tanpa daftar`))
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.settings) global.db.settings = {}
    global.db.settings.wajibDaftar = status
    return Reply(
        `✅ Fitur *wajib daftar* sekarang *${status ? 'ON' : 'OFF'}*\n` +
        (status
            ? '➜ User harus *.daftar* dulu sebelum bisa pakai bot.'
            : '➜ Semua user bisa langsung pakai bot tanpa daftar.')
    )
}
break;

case 'addsewagc': {
    if (!isCreator) return Reply(mess.owner)

    let targetGc = m.chat
    let hari = null

    if (args[0]) {
        if (/^\d{10,}(@g\.us)?$/.test(args[0])) {
            targetGc = args[0].includes('@g.us') ? args[0] : args[0] + '@g.us'
            if (args[1] && !isNaN(args[1])) hari = parseInt(args[1])
        } else if (!isNaN(args[0])) {
            hari = parseInt(args[0])
        }
    }

    if (!targetGc || !targetGc.endsWith('@g.us')) {
        return Reply(example(
            `\n` +
            `• .addsewagc → sewakan grup ini (permanent)\n` +
            `• .addsewagc 30 → sewakan grup ini 30 hari\n` +
            `• .addsewagc 120363xxxxx@g.us → sewakan grup lain\n` +
            `• .addsewagc 120363xxxxx@g.us 30 → sewakan grup lain 30 hari`
        ))
    }

    let groupName = targetGc
    try {
        const meta = await yonz.groupMetadata(targetGc)
        groupName = meta.subject
    } catch (e) {}

    const sewaDb = loadSewaGc()
    sewaDb[targetGc] = {
        nama: groupName,
        addedBy: m.sender,
        tanggal: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
        expired: hari ? Date.now() + hari * 24 * 60 * 60 * 1000 : null
    }
    saveSewaGc(sewaDb)

    return Reply(
        `✅ *Berhasil menambahkan grup sewa!*\n\n` +
        `➜ Nama: ${groupName}\n` +
        `➜ ID: ${targetGc}\n` +
        `➜ Masa aktif: ${hari ? hari + ' hari' : 'Permanent'}`
    )
}
break;

case 'delsewagc': {
    if (!isCreator) return Reply(mess.owner)

    let targetGc = m.chat
    if (args[0] && /^\d{10,}(@g\.us)?$/.test(args[0])) {
        targetGc = args[0].includes('@g.us') ? args[0] : args[0] + '@g.us'
    }

    if (!targetGc || !targetGc.endsWith('@g.us')) {
        return Reply(example(`\n• .delsewagc → hapus sewa grup ini\n• .delsewagc 120363xxxxx@g.us → hapus sewa grup lain`))
    }

    const sewaDb = loadSewaGc()
    if (!sewaDb[targetGc]) return Reply('❌ Grup tersebut belum terdaftar sewa.')

    const namaGc = sewaDb[targetGc].nama || targetGc
    delete sewaDb[targetGc]
    saveSewaGc(sewaDb)

    return Reply(`✅ Berhasil menghapus sewa grup *${namaGc}*`)
}
break;

case 'listsewagc': {
    if (!isCreator) return Reply(mess.owner)

    const sewaDb = loadSewaGc()
    const ids = Object.keys(sewaDb)
    if (ids.length === 0) return Reply('📋 Belum ada grup yang sewa.')

    let teks = `📋 *DAFTAR GRUP SEWA* (${ids.length})\n\n`
    ids.forEach((id, i) => {
        const g = sewaDb[id]
        const status = g.expired
            ? (g.expired > Date.now() ? `Aktif s/d ${new Date(g.expired).toLocaleDateString('id-ID')}` : '⛔ Expired')
            : 'Permanent'
        teks += `${i + 1}. ${g.nama || id}\n   ID: ${id}\n   Status: ${status}\n   Ditambahkan: ${g.tanggal || '-'}\n\n`
    })

    return Reply(teks.trim())
}
break;

case 'antihidetag': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    const modeInput = text ? text.toLowerCase() : ''
    if (!['delete', 'hapus', 'kick', 'off'].includes(modeInput)) {
        const curMode = db.groups[m.chat] && db.groups[m.chat].antihidetag
        const statusNow = curMode === 'kick' ? 'ON (Kick)' : curMode === 'delete' ? 'ON (Delete)' : 'OFF'
        const btnAntihidetag = new yonz.ButtonV2(yonz)
        btnAntihidetag.setThumbnail(global.image.menu)
            .setBody(`*🛡️ ANTI HIDETAG*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan bertindak terhadap pesan yang mengandung *hidetag/tag banyak orang sekaligus* (5 atau lebih) dari member biasa.\n\nSilahkan pilih mode di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '🗑️ Delete' },
                buttonId: `${prefix}antihidetag delete`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '⛔ Kick' },
                buttonId: `${prefix}antihidetag kick`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}antihidetag off`,
                type: 1
            })
        return await btnAntihidetag.send(m.chat)
    }
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    if (modeInput === 'off') {
        global.db.groups[m.chat].antihidetag = false
        return Reply(`✅ *Anti Hidetag* sekarang *OFF* di grup ini.`)
    }
    const mode = (modeInput === 'hapus') ? 'delete' : modeInput
    global.db.groups[m.chat].antihidetag = mode

    return Reply(`✅ *Anti Hidetag* sekarang *ON* dengan mode *${mode === 'kick' ? 'Kick (hapus & kick)' : 'Delete (hapus saja)'}* di grup ini.`)
}
break;

case 'antilink': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const statusNow = (db.groups[m.chat] && db.groups[m.chat].antilink == true) ? 'ON' : 'OFF'
        const btnAntilink = new yonz.ButtonV2(yonz)
        btnAntilink.setThumbnail(global.image.menu)
            .setBody(`*🛡️ ANTI LINK*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan otomatis meng-*kick* dan menghapus pesan yang berisi *link grup WhatsApp lain*.\n\nSilahkan pilih status di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '✅ Aktifkan (ON)' },
                buttonId: `${prefix}antilink on`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}antilink off`,
                type: 1
            })
        return await btnAntilink.send(m.chat)
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    global.db.groups[m.chat].antilink = status

    return Reply(`✅ *Anti Link* sekarang *${status ? 'ON' : 'OFF'}* di grup ini.`)
}
break;

case 'antilink2': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const statusNow = (db.groups[m.chat] && db.groups[m.chat].antilink2 == true) ? 'ON' : 'OFF'
        const btnAntilink2 = new yonz.ButtonV2(yonz)
        btnAntilink2.setThumbnail(global.image.menu)
            .setBody(`*🛡️ ANTI LINK 2*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan otomatis menghapus (tanpa kick) pesan yang berisi *link grup WhatsApp lain*.\n\nSilahkan pilih status di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '✅ Aktifkan (ON)' },
                buttonId: `${prefix}antilink2 on`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}antilink2 off`,
                type: 1
            })
        return await btnAntilink2.send(m.chat)
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    global.db.groups[m.chat].antilink2 = status

    return Reply(`✅ *Anti Link 2* sekarang *${status ? 'ON' : 'OFF'}* di grup ini.`)
}
break;

case 'antifoto': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const statusNow = (db.groups[m.chat] && db.groups[m.chat].antifoto == true) ? 'ON' : 'OFF'
        const btnAntifoto = new yonz.ButtonV2(yonz)
        btnAntifoto.setThumbnail(global.image.menu)
            .setBody(`*🛡️ ANTI FOTO*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan otomatis menghapus *foto/gambar* yang dikirim oleh member biasa di grup ini.\n\nSilahkan pilih status di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '✅ Aktifkan (ON)' },
                buttonId: `${prefix}antifoto on`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}antifoto off`,
                type: 1
            })
        return await btnAntifoto.send(m.chat)
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    global.db.groups[m.chat].antifoto = status

    return Reply(`✅ *Anti Foto* sekarang *${status ? 'ON' : 'OFF'}* di grup ini.`)
}
break;

case 'antipromosi':
case 'antipromo': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const statusNow = (db.groups[m.chat] && db.groups[m.chat].antipromosi == true) ? 'ON' : 'OFF'
        const btnAntipromosi = new yonz.ButtonV2(yonz)
        btnAntipromosi.setThumbnail(global.image.menu)
            .setBody(`*🛡️ ANTI PROMOSI*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan otomatis meng-*kick* dan menghapus pesan yang mengandung *promosi/jualan* (link toko, kata promo/diskon/jual/cod, dsb) dari member biasa.\n\nSilahkan pilih status di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '✅ Aktifkan (ON)' },
                buttonId: `${prefix}antipromosi on`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}antipromosi off`,
                type: 1
            })
        return await btnAntipromosi.send(m.chat)
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    global.db.groups[m.chat].antipromosi = status

    return Reply(`✅ *Anti Promosi* sekarang *${status ? 'ON' : 'OFF'}* di grup ini.`)
}
break;

case 'autodownload':
case 'autodl': {
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        return Reply(example(
            `on/off\n\n` +
            `Fitur ini akan otomatis mendownload link *TikTok* dan *Instagram* yang dikirim di chat ini, tanpa perlu command.`
        ))
    }
    const status = text.toLowerCase() === 'on'

    if (m.isGroup) {
        if (!isCreator && !m.isAdmin) return Reply(mess.admin)
        if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
        global.db.groups[m.chat].autodownload = status
    } else {
        if (!global.db.users[m.sender]) global.db.users[m.sender] = {}
        global.db.users[m.sender].autodownload = status
    }

    return Reply(
        `✅ *Auto Download* sekarang *${status ? 'ON' : 'OFF'}* di chat ini.\n` +
        (status
            ? '➜ Kirim link TikTok/Instagram, bot akan otomatis download.'
            : '➜ Bot tidak akan lagi auto download link TikTok/Instagram di chat ini.')
    )
}
break;



case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *乂 List all group chat*\n`
let a = await yonz.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return Reply(teks)
}
break

case "mute": {
 // Ambil semua ID grup dari text (support banyak baris/spasi)
 let rawText = text ? text.trim() : ''
 let lines = rawText.split(/\s+/).filter(v => v)

 // Deteksi action (on/off) kalau ada di antara input
 let actionKeywords = ['on', 'off']
 let action = ''
 let idList = []

 for (let v of lines) {
 let low = v.toLowerCase()
 if (actionKeywords.includes(low)) {
 action = low
 } else if (/^\d{5,}(-\d+)?(@g\.us)?$/.test(v)) {
 idList.push(v.includes('@g.us') ? v : v + '@g.us')
 }
 }

 let remoteTarget = idList.length > 0
 let targetGroups = remoteTarget ? idList : [m.chat]

 if (remoteTarget) {
 if (!isCreator) return Reply(mess.owner)
 } else {
 if (!m.isGroup) return Reply(mess.group)
 if (!isCreator && !m.isAdmin) return Reply(mess.admin)
 }

 const muteDb = loadMuteGc()

 // Kalau tidak ada action, tampilkan status semua target
 if (!action) {
 let statusText = `🔇 *MUTE GROUP*\n\n`
 for (let gc of targetGroups) {
 if (!muteDb[gc]) muteDb[gc] = { mute: false }
 let status = muteDb[gc].mute ? "🟢 Aktif" : "🔴 Nonaktif"
 statusText += `🆔 ${gc}\n📊 Status : ${status}\n\n`
 }
 if (!remoteTarget) {
 const btnMute = new yonz.ButtonV2(yonz)
 btnMute.setThumbnail(global.image.menu)
 .setBody(statusText.trim() + `\n\nSilahkan pilih status di bawah`)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '✅ Aktifkan (ON)' },
 buttonId: `${prefix}mute on`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '❌ Matikan (OFF)' },
 buttonId: `${prefix}mute off`,
 type: 1
 })
 return await btnMute.send(m.chat)
 }
 statusText += `Gunakan:\n• ${prefix + command} on\n• ${prefix + command} off\n• ${prefix + command} idgrup1 idgrup2 ... on/off`
 return Reply(statusText)
 }

 let hasil = []
 for (let gc of targetGroups) {
 if (!muteDb[gc]) muteDb[gc] = { mute: false }

 if (action === "on") {
 if (muteDb[gc].mute) {
 hasil.push(`✅ ${gc} sudah mute.`)
 continue
 }
 muteDb[gc].mute = true
 hasil.push(`🔇 ${gc} berhasil di-mute.`)
 } else if (action === "off") {
 if (!muteDb[gc].mute) {
 hasil.push(`✅ ${gc} sudah tidak mute.`)
 continue
 }
 muteDb[gc].mute = false
 hasil.push(`🔊 ${gc} berhasil di-unmute.`)
 }
 }

 saveMuteGc(muteDb)
 return Reply(hasil.join('\n'))
}
break

case 'welcome': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const statusNow = (db.groups[m.chat] && db.groups[m.chat].welcome == true) ? 'ON' : 'OFF'
        const btnWelcome = new yonz.ButtonV2(yonz)
        btnWelcome.setThumbnail(global.image.menu)
            .setBody(`*👋 WELCOME MESSAGE*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan otomatis mengirim pesan sambutan ketika ada member baru masuk ke grup ini.\n\nSilahkan pilih status di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '✅ Aktifkan (ON)' },
                buttonId: `${prefix}welcome on`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}welcome off`,
                type: 1
            })
        return await btnWelcome.send(m.chat)
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    global.db.groups[m.chat].welcome = status

    return Reply(`✅ *Welcome Message* sekarang *${status ? 'ON' : 'OFF'}* di grup ini.`)
}
break;

case 'left':
case 'bye': {
    if (!m.isGroup) return Reply(mess.group || 'Fitur ini hanya untuk grup!')
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const statusNow = (db.groups[m.chat] && db.groups[m.chat].left == true) ? 'ON' : 'OFF'
        const btnLeft = new yonz.ButtonV2(yonz)
        btnLeft.setThumbnail(global.image.menu)
            .setBody(`*👋 LEFT MESSAGE*\n\nStatus saat ini: *${statusNow}*\n\nFitur ini akan otomatis mengirim pesan perpisahan ketika ada member yang keluar dari grup ini.\n\nSilahkan pilih status di bawah`)
            .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
            .addRawButton({
                buttonText: { displayText: '✅ Aktifkan (ON)' },
                buttonId: `${prefix}left on`,
                type: 1
            })
            .addRawButton({
                buttonText: { displayText: '❌ Matikan (OFF)' },
                buttonId: `${prefix}left off`,
                type: 1
            })
        return await btnLeft.send(m.chat)
    }
    const status = text.toLowerCase() === 'on'
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {}
    global.db.groups[m.chat].left = status

    return Reply(`✅ *Left Message* sekarang *${status ? 'ON' : 'OFF'}* di grup ini.`)
}
break;

case "listmute": {
 if (!isCreator) return Reply(mess.owner)

 const muteDb = loadMuteGc()
 let mutedList = Object.keys(muteDb).filter(gc => muteDb[gc]?.mute === true)

 if (mutedList.length === 0) {
 return Reply("✅ Tidak ada grup yang sedang di-mute saat ini.")
 }

 let teks = `🔇 *LIST GROUP MUTE*\n\n`
 teks += `Total : ${mutedList.length} grup\n\n`

 for (let gc of mutedList) {
 let id = gc.includes('@g.us') ? gc : gc + '@g.us'
 let nama = "❌ Bot sudah tidak ada di grup ini"
 try {
 let meta = await yonz.groupMetadata(id)
 nama = meta?.subject || "(Tanpa nama)"
 } catch (e) {
 console.log(`Gagal ambil metadata grup ${id}:`, e?.message || e)
 }
 teks += `🆔 *ID :* ${id}\n📛 *Nama :* ${nama}\n\n`
 await new Promise(res => setTimeout(res, 300))
 }

 return Reply(teks)
}
break

case 'typo':
case 'autocorrect': {
    if (!isCreator && !m.isAdmin) return Reply(mess.admin)
    if (!text || !['on', 'off'].includes(text.toLowerCase())) {
        const status = isAutoCorrect(m.chat) ? '🟢 Aktif' : '🔴 Nonaktif'
        return Reply(example(
            `on/off\n\n` +
            `Status saat ini di chat ini : ${status}\n` +
            `Fitur ini akan otomatis mendeteksi command yang salah ketik (typo) dan memberi saran command yang benar.`
        ))
    }
    const status = text.toLowerCase() === 'on'
    const acDb = loadAutoCorrect()
    acDb[m.chat] = status
    saveAutoCorrect(acDb)
    return Reply(`✅ *Auto Correct* sekarang *${status ? 'ON' : 'OFF'}* di chat ini.`)
}
break;

1





case 'listweb': {
 if (!isCreator) return m.reply(global.mess.owner)

 const fetch = require('node-fetch')
 const vercelToken = "vcp_3MGcSP3janbixGPxVGh1geiOeEOTSV6A2vh2ZOF8zmfJcD0lnN0TMZr9"
 const teamId = ""

 const headers = {
 Authorization: `Bearer ${vercelToken}`,
 'Content-Type': 'application/json'
 }

 const url = teamId
 ? `https://api.vercel.com/v9/projects?teamId=${teamId}`
 : `https://api.vercel.com/v9/projects`

 try {
 const res = await fetch(url, { headers })
 const data = await res.json()

 if (!data.projects || data.projects.length === 0) {
 return m.reply('Belum ada website yang di deploy')
 }

 let teks = 'DAFTAR WEBSITE VERCEL\n\n'

 data.projects.forEach((p, i) => {
 teks += `${i + 1}. Nama: ${p.name}\n`
 teks += `URL: https://${p.name}.vercel.app\n\n`
 })

 m.reply(teks)
 } catch (e) {
 m.reply('Gagal mengambil daftar website')
 }
}
break

case "luma":
case "img2video":
case "image2video": {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi);

 if (!global.isPrem(m.sender) && !isCreator)
 return Reply(mess.prem);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";

 if (!/image\//i.test(mime)) {
 return Reply(`❌ Reply gambar dengan caption ${prefix + command}`);
 }

 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);

 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 const imageBuffer = await q.download();
 if (!imageBuffer) throw new Error('Gagal download gambar');

 const prompt = m.text?.trim() || "Gerakan foto ini";

 const FormData = require('form-data');

 const buildForm = () => {
 const form = new FormData();
 form.append('apikey', 'Yonz');
 form.append('prompt', prompt);
 form.append('duration', '10');
 form.append('image', imageBuffer, {
 filename: 'image.jpg',
 contentType: 'image/jpeg'
 });
 return form;
 };

 // Retry logic maksimal 3x
 let submitData = null;
 const maxRetry = 3;

 for (let i = 1; i <= maxRetry; i++) {
 try {
 console.log(`[IMG2VID] Percobaan ke-${i}...`);
 const form = buildForm();

 const submitRes = await axios.post(
 `https://api.theresav.biz.id/ai/img2vid`,
 form,
 {
 headers: { ...form.getHeaders() },
 timeout: 300000 // 5 menit
 }
 );

 submitData = submitRes.data;
 console.log('[IMG2VID RESPONSE]', JSON.stringify(submitData, null, 2));
 break; // Sukses, keluar loop

 } catch (retryErr) {
 const status = retryErr.response?.status;
 console.warn(`[IMG2VID] Percobaan ${i} gagal, status: ${status}`);

 if (i === maxRetry) throw retryErr; // Lempar error setelah retry habis

 // Tunggu 30 detik sebelum retry jika 504
 if (status === 504 || status === 502 || status === 503) {
 console.log(`[IMG2VID] Tunggu 30 detik sebelum retry...`);
 await new Promise(r => setTimeout(r, 30000));
 } else {
 throw retryErr; // Error lain langsung lempar
 }
 }
 }

 if (!submitData) throw new Error('Response kosong dari API');
 if (submitData.status === false) throw new Error(submitData?.message || submitData?.error || 'API error');

 const videoUrl =
 submitData?.result?.video_url ||
 submitData?.result?.url ||
 submitData?.result?.videoUrl ||
 submitData?.video_url ||
 submitData?.videoUrl ||
 submitData?.url ||
 submitData?.data?.url ||
 submitData?.data?.video_url ||
 submitData?.output ||
 null;

 if (!videoUrl) throw new Error(`Tidak ada video URL: ${JSON.stringify(submitData)}`);

 await yonz.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: mess.done
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 const errMsg = error.response?.data
 ? JSON.stringify(error.response.data)
 : error.message;
 console.error('[LUMA ERROR]', errMsg);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Gagal: ${errMsg}`);
 }
}
break











case "getsc": {
 const owner = global.owner + '@s.whatsapp.net';
 if (!areJidsSameUser(m.sender, owner)) return Reply(`Hanya ${global.namaOwner} yang bisa akses command ini.`);

 const target = text ? text.trim().toLowerCase() : '';

 const junkFolderNames = [
 'node_modules', '.git', '.github', '.vscode', '.idea',
 'sessions', 'session', 'sesi', 'auth', 'auth_info', 'auth_info_baileys', 'baileys_auth_info',
 'tmp', 'temp', 'cache', '.cache', '.npm',
 'logs', 'log', 'sampah', 'backup', 'backups',
 'store', 'stores', 'output', 'outputs', 'dist', 'build', 'coverage', '.next'
 ];

 const junkFileNames = [
 'package-lock.json', 'yarn.lock', 'pnpm-lock.yaml',
 '.ds_store', 'npm-debug.log', 'creds.json'
 ];

 const isBaileysSessionFile = (name) => /^(session-|app-state-sync-|pre-key-|sender-key-)/i.test(name);

 const bersihkanSampah = () => {
 const sampahDir = './library/database/sampah';
 if (!fs.existsSync(sampahDir)) {
 fs.mkdirSync(sampahDir, { recursive: true });
 return;
 }
 const dir = fs.readdirSync(sampahDir);
 if (dir.length >= 2) {
 const res = dir.filter(e => e !== "A");
 for (const i of res) {
 try { fs.unlinkSync(`${sampahDir}/${i}`); } catch (e) {}
 }
 }
 };

 const cariPathSampah = () => {
 const excludedRelPaths = new Set();
 const rootSkip = new Set(junkFolderNames.map(f => f.toLowerCase()));

 const walk = (dir, rel) => {
 let items;
 try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }

 const hasCreds = items.some(it => it.isFile() && it.name.toLowerCase() === 'creds.json');
 const sessionFileCount = items.filter(it => it.isFile() && isBaileysSessionFile(it.name)).length;
 if (hasCreds || sessionFileCount >= 3) {
 excludedRelPaths.add(rel);
 return;
 }

 for (const it of items) {
 const childRel = rel ? `${rel}/${it.name}` : it.name;
 if (it.isDirectory()) {
 if (rootSkip.has(it.name.toLowerCase())) {
 excludedRelPaths.add(childRel);
 continue;
 }
 walk(`${dir}/${it.name}`, childRel);
 }
 }
 };

 walk('.', '');
 return [...excludedRelPaths];
 };

 const buatBackupZip = () => {
 bersihkanSampah();
 const name = `${botname2}`;

 if (fs.existsSync(`./${name}.zip`)) {
 try { fs.unlinkSync(`./${name}.zip`); } catch (e) {}
 }

 const items = fs.readdirSync('.')
 .filter(pe => !junkFolderNames.some(ex => ex.toLowerCase() === pe.toLowerCase()))
 .filter(pe => !junkFileNames.some(ex => ex.toLowerCase() === pe.toLowerCase()))
 .filter(pe => !pe.toLowerCase().endsWith('.zip'))
 .filter(pe => !pe.toLowerCase().endsWith('.log'));

 if (items.length === 0) throw new Error('Tidak ada file/folder untuk di-backup');

 const quotedItems = items.map(i => `"${i.replace(/"/g, '\\"')}"`).join(' ');

 const staticExclude = [
 '*/node_modules/*', '*/.git/*',
 'library/database/sessions/*', 'library/database/pakasir_sessions/*',
 'library/database/sampah/*',
 '*.log', '*.zip'
 ];
 const dynamicExclude = cariPathSampah().map(p => `${p}/*`);
 const nestedExclude = [...new Set([...staticExclude, ...dynamicExclude])]
 .map(p => `-x "${p}"`).join(' ');

 try {
 execSync(`zip -r -q "${name}.zip" ${quotedItems} ${nestedExclude}`, { maxBuffer: 1024 * 1024 * 50 });
 } catch (e) {
 if (e.code === 'ENOENT' || /command not found/i.test(String(e.stderr || e.message))) {
 throw new Error('Perintah "zip" tidak ditemukan di server. Install dulu dengan "apt install zip" (Linux/VPS) atau "pkg install zip" (Termux).');
 }
 throw new Error(`Gagal menjalankan zip: ${e.message}`);
 }

 if (!fs.existsSync(`./${name}.zip`)) throw new Error('Gagal membuat file zip backup');
 return name;
 };

 const kirimKeWA = async (jid, name) => {
 await yonz.sendMessage(jid, {
 document: fs.readFileSync(`./${name}.zip`),
 fileName: `${name}.zip`,
 mimetype: "application/zip"
 }, { quoted: global.qtoko });
 };

 const getZipSizeMB = (name) => {
 const zipPath = `./${name}.zip`;
 if (!fs.existsSync(zipPath)) return 0;
 return fs.statSync(zipPath).size / (1024 * 1024);
 };

 const TELEGRAM_MAX_MB = 49;

 const kirimKeTelegram = async (name) => {
 const sizeMB = getZipSizeMB(name);
 if (sizeMB > TELEGRAM_MAX_MB) {
 const err = new Error(`Ukuran file backup (${sizeMB.toFixed(1)} MB) melebihi batas upload Telegram Bot API (${TELEGRAM_MAX_MB} MB). Gunakan tujuan "pribadi" atau "grup" (WhatsApp) yang batasnya lebih besar, atau kecilkan ukuran project dulu (hapus file/folder yang tidak perlu).`);
 err.isSizeLimit = true;
 throw err;
 }

 const form = new FormData();
 form.append('chat_id', global.idtele);
 form.append('document', fs.createReadStream(`./${name}.zip`), `${name}.zip`);
 
 const caption = `
💌 BACKUP SCRIPT BOT 💌
━━━━━━━━━━━━━━━━━━━━━━━━━

📦 File Backup
├─ Nama: ${name}.zip
├─ Ukuran: ${sizeMB.toFixed(2)} MB
└─ Tanggal: ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')} WIB

🛠️ Bot Information
├─ Bot Name: ${botname2}
├─ Owner: ${global.namaOwner}
└─ Status: ✅ Backup Berhasil

📋 File yang Dikecualikan:
├─ node_modules
├─ session/sesi
├─ .cache & .npm
├─ package-lock.json
└─ Folder sampah lainnya

⚠️ Keamanan:
• File sudah terenkripsi dengan zip
• Simpan di tempat yang aman
• Jangan share ke orang lain
• Backup ini sangat penting!

✨ Dibuat oleh Yonz official
`;

 form.append('caption', caption.trim());
 
 try {
 await axios.post(`https://api.telegram.org/bot${global.bottele}/sendDocument`, form, {
 headers: form.getHeaders(),
 maxBodyLength: Infinity,
 maxContentLength: Infinity,
 timeout: 180000
 });

 // Kirim audio file setelah dokumen selesai
 if (fs.existsSync('./media/yonz.mp3')) {
 const audioForm = new FormData();
 audioForm.append('chat_id', global.idtele);
 audioForm.append('audio', fs.createReadStream('./media/yonz.mp3'), `${global.namaOwner}`);
 
 await axios.post(`https://api.telegram.org/bot${global.bottele}/sendAudio`, audioForm, {
 headers: audioForm.getHeaders(),
 maxBodyLength: Infinity,
 maxContentLength: Infinity,
 timeout: 180000
 });
 }

 } catch (e) {
 if (e.response && e.response.status === 413) {
 const err = new Error(`Telegram menolak file (413 Request Entity Too Large). Ukuran file : ${sizeMB.toFixed(1)} MB. Coba tujuan "pribadi" atau "grup" (WhatsApp) sebagai alternatif.`);
 err.isSizeLimit = true;
 throw err;
 }
 throw e;
 }
 };

 const hapusZip = (name) => {
 try {
 const zipPath = `./${name}.zip`;
 if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
 } catch (e) {}
 };

 try {
 if (target === 'grup' || target === 'group') {
 if (!global.groupBackup) {
 return Reply(`Getsc Gagal\nPenyebab : global.groupBackup belum diatur\nSolusi : isi dulu ID grup di settings.js`);
 }
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 await m.reply(`Getsc Proses\nTujuan : Grup Terdaftar\nStatus : Sedang memproses...`);
 let name;
 try {
 name = buatBackupZip();
 const sizeMB = getZipSizeMB(name);
 await kirimKeWA(global.groupBackup, name);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 Reply(`Getsc Berhasil\nTujuan : Grup Terdaftar\nFile : ${name}.zip\nUkuran : ${sizeMB.toFixed(2)} MB`);
 } catch (e) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 throw e;
 } finally {
 if (name) hapusZip(name);
 }

 } else if (target === 'telegram' || target === 'tele' || target === 'tg') {
 if (!global.bottele) {
 return Reply(`Getsc Gagal\nPenyebab : global.bottele belum diatur\nSolusi : isi dulu token bot telegram di settings.js`);
 }
 if (!global.idtele) {
 return Reply(`Getsc Gagal\nPenyebab : global.idtele belum diatur\nSolusi : isi dulu ID telegram di settings.js`);
 }
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 await m.reply(`Getsc Proses\nTujuan : Telegram\nStatus : Sedang memproses...`);
 let name;
 try {
 name = buatBackupZip();
 const sizeMB = getZipSizeMB(name);
 await kirimKeTelegram(name);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 Reply(`Getsc Berhasil\nTujuan : Telegram\nFile : ${name}.zip\nUkuran : ${sizeMB.toFixed(2)} MB`);
 } catch (e) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 throw e;
 } finally {
 if (name) hapusZip(name);
 }

 } else if (target === 'pribadi' || target === 'private' || target === 'owner') {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 await m.reply(`Getsc Proses\nTujuan : Pribadi Owner\nStatus : Sedang memproses...`);
 let name;
 try {
 name = buatBackupZip();
 const sizeMB = getZipSizeMB(name);
 await kirimKeWA(owner, name);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 Reply(`Getsc Berhasil\nTujuan : Pribadi ${global.namaOwner}\nFile : ${name}.zip\nUkuran : ${sizeMB.toFixed(2)} MB`);
 } catch (e) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 throw e;
 } finally {
 if (name) hapusZip(name);
 }

 } else {
 const btn2 = new yonz.ButtonV2(yonz);
 btn2.setThumbnail(global.image.menu)
 .setBody(`Getsc - Backup Script Bot

Bot : ${botname2}
Owner : ${global.namaOwner}

Pilih tujuan backup di bawah`)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: 'PILIH TUJUAN BACKUP' },
 buttonId: 'getsc_pilihan',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'Tujuan Backup Script',
 sections: [{
 title: 'Pilih salah satu tujuan',
 rows: [
 {
 title: 'Kirim ke Telegram',
 description: 'Kirim file backup ke bot Telegram',
 id: `${prefix}getsc telegram`
 },
 {
 title: 'Kirim ke Pribadi Owner',
 description: 'Kirim file backup ke chat pribadi owner',
 id: `${prefix}getsc pribadi`
 },
 {
 title: 'Kirim ke Grup Terdaftar',
 description: 'Kirim file backup ke grup yang sudah diatur',
 id: `${prefix}getsc grup`
 }
 ]
 }]
 })
 }
 });

 await btn2.send(m.chat);
 }
 } catch (error) {
 console.error('[GETSC ERROR]', error?.isSizeLimit ? error.message : (error.message || error));
 if (error?.isSizeLimit) {
 Reply(`Getsc Gagal\nPenyebab : ${error.message}`);
 } else {
 Reply(`Getsc Error\nPesan : ${error.message}`);
 }
 }
}
break;

case "bratcewe": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratcewe?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratcewe:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "bratanime": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratanime?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratanime:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "bratanime2": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratanime2?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratanime2:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "bratpatrick": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratpatrick?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratpatrick:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "bratkobato": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratkobato?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratkobato:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "bratqiqi": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratqiqi?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratqiqi:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;





case "bratvidgif": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratvid?text=${encodedText}&format=gif`;

 const gifBuffer = await getBuffer(apiUrl);
 if (!gifBuffer || gifBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendMessage(m.chat, {
 video: gifBuffer,
 caption: `🎞️ Brat GIF: *${text}*`,
 gifPlayback: true
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratvidgif:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;



case "bratumaru": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratumaru?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratumaru:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "bratruromiya": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratruromiya?text=${encodedText}&apikey=Yonz`;

 const imageBuffer = await getBuffer(apiUrl);
 if (!imageBuffer || imageBuffer.length < 1000) {
 return Reply(mess.error);
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, { packname: global.packname, author: global.namaOwner });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratruromiya:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;





case "s": case "sticker": case "stiker": {
 if (!/image|video/.test(mime))
 return Reply(example("dengan kirim media (gambar/video)"));
 if (/video/.test(mime) && qmsg.seconds > 30)
 return Reply("❌ Durasi video maksimal 30 detik!");

 await yonz.sendMessage(m.chat, { react: { text: "💌", key: m.key } });

 try {
 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const isVideo = /video/.test(mime);
 const outputPath = media + ".webp";

 if (isVideo) {
 await new Promise((resolve, reject) => {
 exec(
 `ffmpeg -y -i "${media}" -vcodec libwebp -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse" -loop 0 -ss 0 -t 30 -preset default -an -vsync 0 "${outputPath}"`,
 (err) => (err ? reject(err) : resolve())
 );
 });
 } else {
 await new Promise((resolve, reject) => {
 exec(
 `ffmpeg -y -i "${media}" -vcodec libwebp -vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:-1:-1:color=#00000000" -lossless 1 -qscale 80 -preset default "${outputPath}"`,
 (err) => (err ? reject(err) : resolve())
 );
 });
 }

 const img = new webpmux.Image();
 const json = {
 "sticker-pack-id": "yonz-sticker",
 "sticker-pack-name": global.packname || "Sticker",
 "sticker-pack-publisher": global.author || "",
 };
 const exifAttr = Buffer.from([
 0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
 ]);
 const jsonBuffer = Buffer.from(JSON.stringify(json), "utf8");
 const exif = Buffer.concat([exifAttr, jsonBuffer]);
 exif.writeUIntLE(jsonBuffer.length, 14, 4);

 await img.load(outputPath);
 img.exif = exif;
 await img.save(outputPath);

 await yonz.sendMessage(
 m.chat,
 { sticker: fs.readFileSync(outputPath) },
 { quoted: m }
 );

 fs.unlinkSync(media);
 fs.unlinkSync(outputPath);

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } catch (e) {
 console.error(e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply("Gagal membuat sticker: " + e.message);
 }
}
break;

case "bratvid": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .brat <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 const apiUrl = `${global.there}/maker/bratvid?text=${encodedText}&format=mp4`;

 const videoBuffer = await getBuffer(apiUrl);
 if (!videoBuffer || videoBuffer.length < 1000) {
 return Reply(mess.error);
 }

 // simpan buffer ke file sementara
 const tmpDir = os.tmpdir();
 const inputPath = path.join(tmpDir, `bratvid_${Date.now()}.mp4`);
 const outputPath = inputPath + ".webp";
 fs.writeFileSync(inputPath, videoBuffer);

 // convert video ke webp animasi (sticker)
 await new Promise((resolve, reject) => {
 exec(
 `ffmpeg -y -i "${inputPath}" -vcodec libwebp -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse" -loop 0 -ss 0 -t 30 -preset default -an -vsync 0 "${outputPath}"`,
 (err) => (err ? reject(err) : resolve())
 );
 });

 // tambahkan exif packname
 const img = new webpmux.Image();
 const json = {
 "sticker-pack-id": "yonz-sticker",
 "sticker-pack-name": global.packname || "Sticker",
 "sticker-pack-publisher": global.author || "",
 };
 const exifAttr = Buffer.from([
 0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
 ]);
 const jsonBuffer = Buffer.from(JSON.stringify(json), "utf8");
 const exif = Buffer.concat([exifAttr, jsonBuffer]);
 exif.writeUIntLE(jsonBuffer.length, 14, 4);

 await img.load(outputPath);
 img.exif = exif;
 await img.save(outputPath);

 await yonz.sendMessage(
 m.chat,
 { sticker: fs.readFileSync(outputPath) },
 { quoted: m }
 );

 fs.unlinkSync(inputPath);
 fs.unlinkSync(outputPath);

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratvid:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case "brat": {
 if (!text) return Reply("❌ Contoh penggunaan: .brat hello world");

 const buttons = [
 { buttonId: `.bratgambar ${text}`, buttonText: { displayText: "🖼️ Brat Gambar" }, type: 1 },
 { buttonId: `.bratcewe ${text}`, buttonText: { displayText: "👧 Brat Cewe" }, type: 1 },
 { buttonId: `.bratanime ${text}`, buttonText: { displayText: "🎌 Brat Anime" }, type: 1 },
 { buttonId: `.bratanime2 ${text}`, buttonText: { displayText: "🎌 Brat Anime 2" }, type: 1 },
 { buttonId: `.bratpatrick ${text}`, buttonText: { displayText: "🩳 Brat Patrick" }, type: 1 },
 { buttonId: `.bratkobato ${text}`, buttonText: { displayText: "🐾 Brat Kobato" }, type: 1 },
 { buttonId: `.bratqiqi ${text}`, buttonText: { displayText: "✨ Brat Qiqi" }, type: 1 },
 { buttonId: `.bratvid ${text}`, buttonText: { displayText: "🎬 Brat Video" }, type: 1 },
 { buttonId: `.bratvidgif ${text}`, buttonText: { displayText: "🎞️ Brat GIF" }, type: 1 },
 { buttonId: `.bratumaru ${text}`, buttonText: { displayText: "😼 Brat Umaru" }, type: 1 },
 { buttonId: `.bratruromiya ${text}`, buttonText: { displayText: "🌸 Brat Ruromiya" }, type: 1 },
 ];

 await yonz.sendMessage(m.chat, {
 image: { url: global.image.menu },
 caption: `Pilih style brat untuk teks:\n*"${text}"*`,
 footer: global.packname || "Brat Maker",
 buttons,
 headerType: 4
 }, { quoted: m });
}
break;



















case "fakedev": {
 try {
 let urlfoto, text1, text2;
 const isQuotedImage = /image/.test(mime);

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (isQuotedImage) {
 // Mode reply gambar: .fakedev text1|text2
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakedev @yonzoffc|Yonz ganteng sekali\n(reply/kirim gambar)`);

 [text1, text2] = text.split("|").map(v => v?.trim());
 if (!text1 || !text2) return Reply(`❌ Format salah!\nGunakan tanda "|" untuk memisahkan text1 dan text2.\nContoh: .fakedev @yonzoffc|Yonz ganteng sekali`);

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);

 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');

 await fs.unlinkSync(media);

 urlfoto = directLink.toString();
 console.log("[fakedev] uploaded url:", urlfoto);

 if (!urlfoto || !/^https?:\/\//i.test(urlfoto)) {
 throw new Error("Gagal upload gambar ke pixhost");
 }

 } else {
 // Mode URL langsung: .fakedev url|text1|text2
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakedev https://c.top4top.io/p_3815w0ycy1.jpg|@yonzoffc|Yonz ganteng sekali\natau kirim/reply gambar dengan caption: .fakedev @yonzoffc|Yonz ganteng sekali`);

 [urlfoto, text1, text2] = text.split("|").map(v => v?.trim());
 if (!urlfoto || !text1 || !text2) return Reply(`❌ Format salah!\nGunakan tanda "|" untuk memisahkan url, text1, dan text2.\nContoh: .fakedev https://c.top4top.io/p_3815w0ycy1.jpg|@yonzoffc|Yonz ganteng sekali`);

 if (!/^https?:\/\//i.test(urlfoto)) return Reply("❌ URL foto tidak valid! Harus diawali http:// atau https://");

 await Reply(global.mess.wait);
 }

 const apiUrl = `${global.claude}/canvas/fakedev?urlfoto=${encodeURIComponent(urlfoto)}&text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;
 console.log("[fakedev] API URL:", apiUrl);

 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, {
 image: imgBuffer,
 caption: global.mess.done
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakedev] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case "fakestory": case "fakestory2": {
 try {
 let pp, nickname, textStory;
 const isQuotedImage = /image/.test(mime) && command === "fakestory";

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (isQuotedImage) {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakestory Yonz official|Haii haloo\n(reply/kirim foto profil)`);

 [nickname, textStory] = text.split("|").map(v => v?.trim());
 if (!nickname || !textStory) return Reply(`❌ Format salah!\nContoh: .fakestory Yonz official|Haii haloo`);

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');
 await fs.unlinkSync(media);

 pp = directLink.toString();
 if (!pp || !/^https?:\/\//i.test(pp)) throw new Error("Gagal upload foto profil");

 } else {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakestory2 Yonz official|Haii haloo|https://c.top4top.io/p_3815w0ycy1.jpg`);

 [nickname, textStory, pp] = text.split("|").map(v => v?.trim());
 if (!nickname || !textStory || !pp) return Reply(`❌ Format salah!\nContoh: .fakestory2 Yonz official|Haii haloo|https://c.top4top.io/p_3815w0ycy1.jpg`);
 if (!/^https?:\/\//i.test(pp)) return Reply("❌ URL foto profil tidak valid! Harus diawali http:// atau https://");

 await Reply(global.mess.wait);
 }

 const apiUrl = `https://api.synoxcloud.xyz/canvas/fakestory?nickname=${encodeURIComponent(nickname)}&text=${encodeURIComponent(textStory)}&pp=${encodeURIComponent(pp)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakestory] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

// ========== FAKEWA ==========
case "fakewa": case "fakewa2": {
 try {
 let foto, nama, bio, nomor;
 const isQuotedImage = /image/.test(mime) && command === "fakewa";

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (isQuotedImage) {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakewa Yonz official|Jangan berpatah hati|+62 812 3456 7890\n(reply/kirim foto profil)`);

 [nama, bio, nomor] = text.split("|").map(v => v?.trim());
 if (!nama || !bio || !nomor) return Reply(`❌ Format salah!\nContoh: .fakewa Yonz official|Jangan berpatah hati|+62 812 3456 7890`);

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');
 await fs.unlinkSync(media);

 foto = directLink.toString();
 if (!foto || !/^https?:\/\//i.test(foto)) throw new Error("Gagal upload foto profil");

 } else {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakewa2 Yonz official|Jangan berpatah hati|+62 812 3456 7890|https://c.top4top.io/p_3815w0ycy1.jpg`);

 [nama, bio, nomor, foto] = text.split("|").map(v => v?.trim());
 if (!nama || !bio || !nomor || !foto) return Reply(`❌ Format salah!\nContoh: .fakewa2 Yonz official|Jangan berpatah hati|+62 812 3456 7890|https://c.top4top.io/p_3815w0ycy1.jpg`);
 if (!/^https?:\/\//i.test(foto)) return Reply("❌ URL foto profil tidak valid! Harus diawali http:// atau https://");

 await Reply(global.mess.wait);
 }

 const apiUrl = `https://api.synoxcloud.xyz/canvas/fakewa?foto=${encodeURIComponent(foto)}&nama=${encodeURIComponent(nama)}&bio=${encodeURIComponent(bio)}&nomor=${encodeURIComponent(nomor)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakewa] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'fakewafat': case 'fakewafat2': {
 try {
 let fotourl, nama, lahir, wafat;
 const isURL = command === 'fakewafat2';

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (isURL) {
 // .fakewafat2 fotourl|nama|lahir|wafat
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakewafat2 https://b.top4top.io/p_38235zels1.jpg|Bwa bwa|2013|2022`);

 [fotourl, nama, lahir, wafat] = text.split("|").map(v => v?.trim());
 if (!fotourl || !nama || !lahir || !wafat) return Reply(`❌ Format salah!\nContoh: .fakewafat2 https://b.top4top.io/p_38235zels1.jpg|Bwa bwa|2013|2022`);
 if (!/^https?:\/\//i.test(fotourl)) return Reply("❌ URL foto tidak valid! Harus diawali http:// atau https://");

 await Reply(global.mess.wait);

 } else {
 // .fakewafat nama|lahir|wafat (reply gambar)
 if (!/image/.test(mime)) return Reply(`❌ Reply/kirim gambar dengan caption:\n.fakewafat Bwa bwa|2013|2022`);
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakewafat Bwa bwa|2013|2022\n(reply/kirim foto)`);

 [nama, lahir, wafat] = text.split("|").map(v => v?.trim());
 if (!nama || !lahir || !wafat) return Reply(`❌ Format salah!\nContoh: .fakewafat Bwa bwa|2013|2022`);

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');
 await fs.unlinkSync(media);

 fotourl = directLink.toString();
 if (!fotourl || !/^https?:\/\//i.test(fotourl)) throw new Error("Gagal upload gambar");
 }

 const apiUrl = `${global.claude}/canvas/fakewafat?fotourl=${encodeURIComponent(fotourl)}&nama=${encodeURIComponent(nama)}&lahir=${encodeURIComponent(lahir)}&wafat=${encodeURIComponent(wafat)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakewafat] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'quotes': {
 try {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.quotes Aku bisa melawan rasa malas, Tapi aku malas`);

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 await Reply(global.mess.wait);

 const apiUrl = `${global.claude}/canvas/quotes-v5?text=${encodeURIComponent(text)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[quotes] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;



case 'getnumber': {
 try {
 let target;

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (m.mentionedJid && m.mentionedJid.length > 0) {
 // Mode tag: .getnumber @user
 target = m.mentionedJid[0];
 } else if (m.quoted) {
 // Mode reply: reply pesan seseorang lalu .getnumber
 target = m.quoted.sender;
 } else {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(`❌ Tag atau reply pesan orangnya dulu!\n\nContoh:\n.getnumber @628123456789\natau reply pesan seseorang lalu ketik .getnumber`);
 }

 const nomor = target.split("@")[0];

 await Reply(nomor);
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[getnumber] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'fakeff': {
 try {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakeff Yonz|30`);

 const [username, lobby] = text.split("|").map(v => v?.trim());
 if (!username || !lobby) return Reply(`❌ Format salah!\nGunakan tanda "|" untuk memisahkan username dan lobby.\nContoh: .fakeff Yonz|30`);

 if (!/^\d+$/.test(lobby)) return Reply("❌ Lobby harus berupa angka!");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 await Reply(global.mess.wait);

 const apiUrl = `${global.claude}/canvas/fakeff?username=${encodeURIComponent(username)}&lobby=${encodeURIComponent(lobby)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakeff] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'fakeml': case 'fakeml2': {
 try {
 let avatar, username, rank, border;
 const isURL = command === 'fakeml2';

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (isURL) {
 // .fakeml2 avatar|username|rank|border
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakeml2 https://d.top4top.io/p_38200eohz1.jpg|Saurus|imo|16`);

 [avatar, username, rank, border] = text.split("|").map(v => v?.trim());
 if (!avatar || !username || !rank || !border) return Reply(`❌ Format salah!\nContoh: .fakeml2 https://d.top4top.io/p_38200eohz1.jpg|Saurus|imo|16`);
 if (!/^https?:\/\//i.test(avatar)) return Reply("❌ URL foto tidak valid! Harus diawali http:// atau https://");
 if (!/^\d+$/.test(border)) return Reply("❌ Border harus berupa angka!");

 await Reply(global.mess.wait);

 } else {
 // .fakeml username|rank|border (reply gambar)
 if (!/image/.test(mime)) return Reply(`❌ Reply/kirim gambar dengan caption:\n.fakeml Saurus|imo|16`);
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakeml Saurus|imo|16\n(reply/kirim foto avatar)`);

 [username, rank, border] = text.split("|").map(v => v?.trim());
 if (!username || !rank || !border) return Reply(`❌ Format salah!\nContoh: .fakeml Saurus|imo|16`);
 if (!/^\d+$/.test(border)) return Reply("❌ Border harus berupa angka!");

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');
 await fs.unlinkSync(media);

 avatar = directLink.toString();
 if (!avatar || !/^https?:\/\//i.test(avatar)) throw new Error("Gagal upload gambar");
 }

 const apiUrl = `${global.claude}/canvas/fakeml?avatar=${encodeURIComponent(avatar)}&username=${encodeURIComponent(username)}&rank=${encodeURIComponent(rank)}&border=${encodeURIComponent(border)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakeml] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'fakektp': case 'fakektp2': {
 try {
 const isURL = command === 'fakektp2';
 const fields = ['provinsi','kota','nik','nama','ttl','jenis_kelamin','golongan_darah','alamat','rt_rw','kel_desa','kecamatan','agama','status','pekerjaan','kewarganegaraan','masa_berlaku','terbuat'];

 const contohFormat = `provinsi|kota|nik|nama|ttl|jenis_kelamin|golongan_darah|alamat|rt_rw|kel_desa|kecamatan|agama|status|pekerjaan|kewarganegaraan|masa_berlaku|terbuat`;
 const contohIsi = `Prefektur Tokyo|Nerima|2112090309120001|Doraemon|Matsushiba, 03-09-2112|Laki-laki|Dorayaki|Rumah Keluarga Nobi No. 7|005/002|Nerima|Tsukimidai|Dorayakisme|Menikah dengan Michan|Robot Pembantu Masa Depan|WNA|Seumur Hidup|03-09-2112`;

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 let data = {};
 let pas_photo;

 if (isURL) {
 // .fakektp2 provinsi|kota|nik|...|terbuat|pas_photo
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakektp2 ${contohIsi}|https://k.top4top.io/p_3816oexr91.jpg\n\nUrutan:\n${contohFormat}|pas_photo`);

 const parts = text.split("|").map(v => v?.trim());
 pas_photo = parts.pop();
 if (parts.length !== fields.length) return Reply(`❌ Format salah! Data harus ${fields.length} bagian + foto.\n\nUrutan:\n${contohFormat}|pas_photo`);

 fields.forEach((key, i) => data[key] = parts[i]);
 if (!pas_photo || !/^https?:\/\//i.test(pas_photo)) return Reply("❌ URL foto tidak valid! Harus diawali http:// atau https://");

 await Reply(global.mess.wait);

 } else {
 // .fakektp provinsi|kota|nik|...|terbuat (reply foto)
 if (!/image/.test(mime)) return Reply(`❌ Reply/kirim foto (pas foto) dengan caption:\n.fakektp ${contohIsi}\n\nUrutan:\n${contohFormat}`);
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakektp ${contohIsi}\n(reply/kirim pas foto)\n\nUrutan:\n${contohFormat}`);

 const parts = text.split("|").map(v => v?.trim());
 if (parts.length !== fields.length) return Reply(`❌ Format salah! Data harus ${fields.length} bagian, dipisah "|".\n\nUrutan:\n${contohFormat}`);

 fields.forEach((key, i) => data[key] = parts[i]);

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');
 await fs.unlinkSync(media);

 pas_photo = directLink.toString();
 if (!pas_photo || !/^https?:\/\//i.test(pas_photo)) throw new Error("Gagal upload foto");
 }

 const params = new URLSearchParams({ ...data, pas_photo });
 const apiUrl = `${global.claude}/canvas/e-ktp?${params.toString()}`;

 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakektp] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'fakengl': {
 try {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakengl Gw tuh sebenarnya ultramen`);

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 await Reply(global.mess.wait);

 const apiUrl = `${global.claude}/canvas/fake-ngl?text=${encodeURIComponent(text)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakengl] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

case 'fakegopay': {
 try {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakegopay 890|159|0|Mei`);

 const [saldo, koin, terpakai, bulan] = text.split("|").map(v => v?.trim());
 if (!saldo || !koin || !terpakai || !bulan) return Reply(`❌ Format salah!\nGunakan tanda "|" untuk memisahkan saldo, koin, terpakai, dan bulan.\nContoh: .fakegopay 890|159|0|Mei`);

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 await Reply(global.mess.wait);

 const apiUrl = `${global.claude}/canvas/fake-gopay?saldo=${encodeURIComponent(saldo)}&koin=${encodeURIComponent(koin)}&terpakai=${encodeURIComponent(terpakai)}&bulan=${encodeURIComponent(bulan)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakegopay] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

// ========== FAKE OVO ==========
case 'fakeovo': {
 try {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakeovo 5000002828`);

 const amount = text.trim();
 if (!/^\d+$/.test(amount)) return Reply("❌ Amount harus berupa angka!");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 await Reply(global.mess.wait);

 const apiUrl = `${global.claude}/canvas/fake-ovo?amount=${encodeURIComponent(amount)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakeovo] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

// ========== FAKE CALL ==========
case 'fakecall': case 'fakecall2': {
 try {
 let pp, name, time;
 const isURL = command === 'fakecall2';

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 if (isURL) {
 // .fakecall2 name|time|pp
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakecall2 Ayank|00:00|https://c.top4top.io/p_3815w0ycy1.jpg`);

 [name, time, pp] = text.split("|").map(v => v?.trim());
 if (!name || !time || !pp) return Reply(`❌ Format salah!\nContoh: .fakecall2 Ayank|00:00|https://c.top4top.io/p_3815w0ycy1.jpg`);
 if (!/^https?:\/\//i.test(pp)) return Reply("❌ URL foto tidak valid! Harus diawali http:// atau https://");

 await Reply(global.mess.wait);

 } else {
 // .fakecall name|time (reply gambar)
 if (!/image/.test(mime)) return Reply(`❌ Reply/kirim foto dengan caption:\n.fakecall Ayank|00:00`);
 if (!text) return Reply(`❌ Contoh penggunaan:\n.fakecall Ayank|00:00\n(reply/kirim foto profil)`);

 [name, time] = text.split("|").map(v => v?.trim());
 if (!name || !time) return Reply(`❌ Format salah!\nContoh: .fakecall Ayank|00:00`);

 await Reply(global.mess.wait);

 const media = await yonz.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'media.png');
 await fs.unlinkSync(media);

 pp = directLink.toString();
 if (!pp || !/^https?:\/\//i.test(pp)) throw new Error("Gagal upload foto profil");
 }

 const apiUrl = `${global.claude}/canvas/fakecall?name=${encodeURIComponent(name)}&time=${encodeURIComponent(time)}&pp=${encodeURIComponent(pp)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[fakecall] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;

// ========== PAK USTADZ ==========
case 'pakustadz': {
 try {
 if (!text) return Reply(`❌ Contoh penggunaan:\n.pakustadz Pak ustad, apa hukumnya menyukai anime`);

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 await Reply(global.mess.wait);

 const apiUrl = `${global.claude}/canvas/pakustadz?teks=${encodeURIComponent(text)}`;
 const res = await fetch(apiUrl);
 if (!res.ok) throw new Error(`API status ${res.status}`);
 const imgBuffer = Buffer.from(await res.arrayBuffer());

 await yonz.sendMessage(m.chat, { image: imgBuffer, caption: global.mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[pakustadz] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;













case 'renamebot': {
 try {
 if (!isCreator) return Reply(global.mess.owner);

 const fieldMap = {
 owner: { key: 'owner', label: 'nomor owner' },
 namaowner: { key: 'namaOwner', label: 'nama owner' },
 linkowner: { key: 'linkOwner', label: 'link WhatsApp owner' },
 botname: { key: 'botname', label: 'nama bot' },
 botname2: { key: 'botname2', label: 'nama bot (versi 2)' },
 packname: { key: 'packname', label: 'nama pack/wm sticker' },
 linkgrup: { key: 'linkGrup', label: 'link grup WhatsApp' },
 idgrup: { key: 'groupBackup', label: 'ID grup WhatsApp' },
 linksaluran: { key: 'linkSaluran', label: 'link channel/saluran' },
 idsaluran: { key: 'idSaluran', label: 'ID channel/saluran' },
 namasaluran: { key: 'namaSaluran', label: 'nama channel/saluran' },
 gifleft: { key: 'gifLeft', label: 'GIF saat member keluar' },
 audioleft: { key: 'audioLeft', label: 'audio saat member keluar' },
 gifwelcome: { key: 'gifWelcome', label: 'GIF saat member masuk' },
 audiowelcome: { key: 'audioWelcome', label: 'audio saat member masuk' }
 };

 const daftarField = () => Object.entries(fieldMap)
 .map(([k, v]) => `• *${k}* — ${v.label}`)
 .join("\n");

 if (!text) {
 return Reply(`❌ Contoh penggunaan:\n.renamebot field nilai_baru\n\nContoh:\n.renamebot botname Yonz Official Bot\n.renamebot owner 6281234567890\nketik .idgc buat liat id group\n\n📋 Daftar field yang bisa diganti:\n${daftarField()}`);
 }

 const spaceIndex = text.indexOf(" ");
 if (spaceIndex === -1) return Reply(`❌ Format salah! Pisahkan field dan nilai dengan spasi.\nContoh: .renamebot botname Yonz Official`);

 const field = text.slice(0, spaceIndex).trim().toLowerCase();
 const value = text.slice(spaceIndex + 1).trim();

 if (!fieldMap[field]) {
 return Reply(`❌ Field "${field}" tidak dikenali!\n\n📋 Daftar field yang bisa diganti:\n${daftarField()}`);
 }
 if (!value) return Reply(`❌ Nilai baru tidak boleh kosong!`);

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 const { key, label } = fieldMap[field];
 const settingsPath = path.join(__dirname, 'settings.js');
 let content = fs.readFileSync(settingsPath, 'utf8');

 const regex = new RegExp(`(global\\.${key}\\s*=\\s*)(['"\`])(.*?)\\2`);
 if (!regex.test(content)) throw new Error(`Baris "global.${key}" tidak ditemukan di settings.js`);

 const escapedValue = value.replace(/'/g, "\\'");
 content = content.replace(regex, `$1'${escapedValue}'`);

 fs.writeFileSync(settingsPath, content);
 global[key] = value; // update langsung tanpa perlu restart

 await yonz.sendMessage(m.chat, {
 text: `✅ *Berhasil!*\n\n🔧 ${label}\n📌 Nilai baru: ${value}\n\n⚠️ Beberapa perubahan mungkin baru terlihat sepenuhnya setelah bot di-restart.`
 }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error("[renamebot] error:", e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${e.message}`);
 }
}
break;



















case 'getfile':
case 'download':
case 'downloadfile':
case 'ambilfile': {
 if (!isOwner) return Reply(mess.creator);

 try {
 // === MODE: AMBIL SEMUA FILE (ZIP) ===
 if (!text || text.trim() === '' || text.trim().toLowerCase() === 'all') {
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

 const { execSync } = require('child_process')
 const baseDir = process.cwd()
 const botName = (global.botname || 'Bot').replace(/[\/\\:*?"<>|]/g, '')
 const zipName = `${botName}.zip`
 const zipPath = path.join(baseDir, zipName)

 if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath)

 const excludes = [
 'session/*',
 'session',
 'node_modules/*',
 'node_modules',
 'package-lock.json',
 '.npm/*',
 '.npm',
 '.cache/*',
 '.cache',
 zipName
 ]

 const excludeArgs = excludes.map(e => `-x "${e}"`).join(' ')
 const cmd = `cd "${baseDir}" && zip -r "${zipName}" . ${excludeArgs}`

 execSync(cmd, { stdio: 'pipe' })

 if (!fs.existsSync(zipPath)) {
 return Reply(`❌ gagal membuat file zip`)
 }

 const zipStat = fs.statSync(zipPath)
 const sizeMB = (zipStat.size / (1024 * 1024)).toFixed(2)

 if (zipStat.size > 500 * 1024 * 1024) {
 fs.unlinkSync(zipPath)
 return Reply(`❌ ukuran zip terlalu besar (${sizeMB} MB), tidak bisa dikirim`)
 }

 const zipBuffer = fs.readFileSync(zipPath)

 await yonz.sendMessage(m.chat, {
 document: zipBuffer,
 fileName: zipName,
 mimetype: 'application/zip',
 caption: `📦 *Backup Seluruh File*\n\n🤖 Bot: ${global.botname || 'Bot'}\n📄 Nama File: ${zipName}\n📦 Ukuran: ${sizeMB} MB`
 }, { quoted: m })

 fs.unlinkSync(zipPath)

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
 return
 }

 // === MODE: AMBIL FILE SPESIFIK ===
 const baseDir = process.cwd()
 const targetPath = path.resolve(baseDir, text.trim())

 if (!targetPath.startsWith(baseDir)) {
 return Reply(`❌ akses di luar folder utama tidak diizinkan`)
 }
 if (!fs.existsSync(targetPath)) {
 return Reply(`❌ file tidak ditemukan di path:\n${targetPath}`)
 }

 const stat = fs.statSync(targetPath)
 if (stat.isDirectory()) {
 const list = fs.readdirSync(targetPath)
 return Reply(`📁 *${text}* adalah folder, isinya:\n\n` + (list.length ? list.map(f => `• ${f}`).join('\n') : '(kosong)'))
 }

 if (stat.size > 10 * 1024 * 1024) {
 return Reply(`❌ file terlalu besar (${(stat.size / (1024 * 1024)).toFixed(2)} MB)\nMaksimal ukuran file yang bisa diambil: 10 MB`)
 }

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

 const fileName = path.basename(targetPath)
 const ext = path.extname(fileName).toLowerCase()
 const buffer = fs.readFileSync(targetPath)

 const imageExt = ['.jpg', '.jpeg', '.png', '.webp']
 const videoExt = ['.mp4', '.mkv']
 const audioExt = ['.mp3', '.opus', '.ogg']

 const mimeMap = {
 '.pdf': 'application/pdf',
 '.zip': 'application/zip',
 '.rar': 'application/x-rar-compressed',
 '.txt': 'text/plain',
 '.json': 'application/json',
 '.js': 'text/javascript',
 '.html': 'text/html',
 '.apk': 'application/vnd.android.package-archive',
 '.doc': 'application/msword',
 '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 '.xls': 'application/vnd.ms-excel',
 '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 }
 const mimeType = mimeMap[ext] || 'application/octet-stream'

 let payload

 if (imageExt.includes(ext)) {
 payload = { image: buffer, caption: `📄 ${fileName}` }
 } else if (videoExt.includes(ext)) {
 payload = { video: buffer, caption: `📄 ${fileName}` }
 } else if (audioExt.includes(ext)) {
 payload = { audio: buffer, mimetype: 'audio/mpeg', ptt: false }
 } else {
 payload = {
 document: buffer,
 fileName,
 mimetype: mimeType
 }
 }

 await yonz.sendMessage(m.chat, payload, { quoted: m })
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

 } catch (err) {
 console.error(err)
 Reply(`❌ gagal ambil file: ${err.message}`)
 }
}
break


case 'ganticase':
case 'editcase':
case 'replacecase': {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(`📌 Contoh: *${prefix}ganticase nama_case|kode_case_baru*\n\natau reply pesan yang isi kode case baru terus ketik *${prefix}ganticase nama_case*`);

 let caseName = '';
 let newCode = '';

 if (text.includes('|')) {
 // === MODE: INLINE (nama_case|kode_baru) ===
 const idx = text.indexOf('|');
 caseName = text.slice(0, idx).trim();
 newCode = text.slice(idx + 1).trim();
 } else {
 // === MODE: REPLY ===
 caseName = text.trim().split(/\s+/)[0];
 if (!m.quoted) return Reply(`📌 reply pesan yang isinya kode case baru (lengkap dari *case '...':* sampai *break;*)\n\natau pakai format: *${prefix}ganticase nama_case|kode_case_baru*`);
 newCode = (m.quoted.text || m.quoted.body || '').trim();
 }

 if (!caseName) return Reply(`📌 Contoh: *${prefix}ganticase nama_case|kode_case_baru*`);
 if (!newCode) return Reply(`❌ kode case baru kosong / tidak ditemukan`);
 if (!/case\s+['"\`]/.test(newCode) || !/break\s*;?/.test(newCode)) {
 return Reply(`❌ kode case baru harus lengkap, minimal ada *case '...':* dan *break;*`);
 }

 const fsp = require('fs').promises;

 // 📌 sesuaikan daftar file yang mau dicari case-nya
 const targetFiles = [
 path.join(process.cwd(), 'index.js'),
 path.join(process.cwd(), 'yonz-cmd.js'),
 ];

 try {
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 let found = false;
 let editedFile = '';

 for (const filePath of targetFiles) {
 if (!fs.existsSync(filePath)) continue;

 let data = await fsp.readFile(filePath, 'utf8');
 const regex = new RegExp(`case\\s+['"\`]${caseName}['"\`]\\s*:[\\s\\S]*?break\\s*;`);

 if (regex.test(data)) {
 // backup dulu sebelum ditimpa
 const backupPath = filePath + `.backup${Date.now()}`;
 await fsp.writeFile(backupPath, data, 'utf8');

 data = data.replace(regex, newCode);
 await fsp.writeFile(filePath, data, 'utf8');

 found = true;
 editedFile = filePath;
 break;
 }
 }

 if (!found) {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(`❌ case *${caseName}* tidak ditemukan di file yang dicek:\n${targetFiles.map(f => `• ${f}`).join('\n')}`);
 }

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(`🚀 *Case Berhasil Diganti*\n\n📄 *Case Lama:* ${caseName}\n📍 *File:* ${editedFile}\n💾 *Backup otomatis dibuat sebelum diganti*\n\n⚠️ _Restart bot supaya perubahan berlaku._`);

 } catch (err) {
 console.error(err);
 Reply(`❌ gagal ganti case: ${err.message}`);
 }
}
break

case 'deploy':
case 'deployweb': {
	if (!isCreator) return m.reply(global.mess.owner)

	const AdmZip = require('adm-zip')
	const fetch = require('node-fetch')
	const vercelToken = "vcp_2USROGt1Ei7Ek7jZfGsNRxiTng3ZCxV8y7UcgadgKCcqfyu4Kv3jL6rK"
	const headers = { 
		'Authorization': `Bearer ${vercelToken}`, 
		'Content-Type': 'application/json' 
	}

	if (args[0] === 'list') {
		try {
			const res = await fetch('https://api.vercel.com/v6/deployments', { headers })
			const data = await res.json()
			if (!data.projects || data.projects.length === 0) return m.reply('Tidak ada project di akun Vercel')
			
			let teks = 'DAFTAR PROJECT VERCEL\n\n'
			data.projects.forEach((p, i) => {
				teks += `${i + 1}. Nama: ${p.name}\nURL: https://${p.name}.vercel.app\n\n`
			})
			return m.reply(teks)
		} catch (e) {
			return m.reply('Gagal mengambil daftar project')
		}
	}

	if (args[0] === 'delete') {
		if (!args[1]) return m.reply('Gunakan: .vweb delete nama-web')
		try {
			const res = await fetch(`https://api.vercel.com/v6/deployments?teamId=${teamId}`, {
				method: 'DELETE',
				headers
			})
			if (res.status === 204 || res.status === 200) {
				return m.reply(`Berhasil menghapus project: ${args[1]}`)
			} else {
				const err = await res.json()
				return m.reply(`Gagal menghapus: ${err.error?.message || 'Project tidak ditemukan'}`)
			}
		} catch (e) {
			return m.reply('Terjadi kesalahan saat menghapus project')
		}
	}

	const qmsg = m.quoted || (m.msg && m.msg.contextInfo && m.msg.contextInfo.quotedMessage)
	if (!qmsg) return m.reply('Reply file .html atau .zip')

	const mime = qmsg.mimetype || (qmsg.documentMessage && qmsg.documentMessage.mimetype) || ''
	if (!text) return m.reply(`Gunakan: .${command} nama-web`)
	const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '')

	m.reply(global.mess.wait)
	
	let media
	try {
		media = await yonz.downloadMediaMessage(m.quoted)
	} catch (err) {
		return m.reply('Gagal mendownload file')
	}

	let filesToUpload = []
	if (mime.includes('zip')) {
		const zip = new AdmZip(media)
		const entries = zip.getEntries()
		let hasIndex = false
		entries.forEach(entry => {
			if (entry.isDirectory) return
			if (entry.entryName.toLowerCase().endsWith('index.html')) hasIndex = true
			filesToUpload.push({
				file: entry.entryName.replace(/\\/g, '/'),
				data: entry.getData().toString('base64'),
				encoding: 'base64'
			})
		})
		if (!hasIndex) return m.reply('File index.html tidak ditemukan dalam ZIP')
	} else if (mime.includes('html')) {
		filesToUpload.push({
			file: 'index.html',
			data: Buffer.from(media).toString('base64'),
			encoding: 'base64'
		})
	} else {
		return m.reply('Hanya mendukung .zip atau .html')
	}

	try {
		await fetch('https://api.vercel.com/v9/projects', {
			method: 'POST',
			headers,
			body: JSON.stringify({ name: webName })
		}).catch(() => {})

		const deployRes = await fetch('https://api.vercel.com/v13/deployments', {
			method: 'POST',
			headers,
			body: JSON.stringify({ 
				name: webName, 
				project: webName, 
				files: filesToUpload, 
				projectSettings: { framework: null } 
			})
		})

		const deployData = await deployRes.json().catch(() => null)
		if (!deployData || deployData.error) return m.reply(`Gagal: ${deployData?.error?.message}`)

		let teks = `BERHASIL DEPLOY VERCEL\n\n`
		teks += `URL: https://${webName}.vercel.app\n`
		teks += `Nama: ${webName}\n\n`
		teks += `${global.botname}`

		await yonz.sendMessage(m.chat, { text: teks }, { quoted: m })

	} catch (err) {
		m.reply(`Kesalahan: ${err.message}`)
	}
}
break





















case "yonzedit":
case "aiedit":
case "nano": {
 // ===== CEK GAMBAR =====
 if (!/image/.test(mime)) {
 return m.reply(example("dengan reply gambar dan teks perintah\nContoh: .nano Ubah warna rambut menjadi biru"));
 }

 // ===== FUNGSI PEMBANTU =====
 const fs = require('fs');
 const path = require('path');

 const getNumber = (jid) => {
 if (!jid) return '';
 return jid.split('@')[0] || '';
 };

 const normalizeOwner = (owner) => {
 if (!owner) return [];
 if (Array.isArray(owner)) return owner.map(v => v.trim()).filter(v => v);
 if (typeof owner === 'string') {
 return owner.split(/[,;\s-]+/).filter(v => v.trim() !== '');
 }
 return [];
 };
 // ============================

 // ===== BACA PREMIUM.JSON =====
 const premPath = global.premiumPath || './library/database/premium.json';
 let premiumUsers = [];
 try {
 const premDir = path.dirname(premPath);
 if (!fs.existsSync(premDir)) fs.mkdirSync(premDir, { recursive: true });
 if (!fs.existsSync(premPath)) {
 fs.writeFileSync(premPath, JSON.stringify([], null, 2), 'utf8');
 }
 const data = fs.readFileSync(premPath, 'utf8');
 premiumUsers = JSON.parse(data);
 if (!Array.isArray(premiumUsers)) premiumUsers = [];
 } catch (_) {
 try {
 fs.writeFileSync(premPath, JSON.stringify([], null, 2), 'utf8');
 } catch (__) {}
 premiumUsers = [];
 }
 // =================================

 // ===== CEK OWNER / PREMIUM =====
 const sender = getNumber(m.sender);
 const owners = normalizeOwner(global.owner);
 const isOwner = owners.includes(sender);
 const isPremium = premiumUsers.includes(sender);

 if (!isOwner && !isPremium) {
 return Reply(global.mess.prem || '💎 Fitur premium, hubungi owner.');
 }

 // ===== CEK PROMPT =====
 const promptText = args.join(' ');
 if (!promptText) {
 return m.reply(`📝 *Masukkan perintah edit!*\nContoh: .${m.cmd} Ubah warna rambut menjadi biru`);
 }

 // ===== PERSIAPAN =====
 const FormData = require('form-data');
 const axios = require('axios');
 const tempDir = './library/database/sampah';
 if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(global.mess.wait || '⏳ Sedang diproses...');

 let media = null;

 try {
 // ===== 1. DOWNLOAD GAMBAR =====
 const qmsg = m.quoted ? m.quoted : m;
 media = await yonz.downloadAndSaveMediaMessage(qmsg);

 // ===== 2. UPLOAD KE SERVER =====
 const form = new FormData();
 form.append('file', fs.createReadStream(media));

 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });

 console.log('[UPLOAD RESPONSE]', upload.data);

 const imageUrl = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;

 if (!imageUrl || typeof imageUrl !== 'string') {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(`❌ Gagal upload gambar.\nRespon: ${JSON.stringify(upload.data)}`);
 }

 // ===== 3. PANGGIL API BANANA AI =====
 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.alipkey}&url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(promptText)}`;
 console.log('[API URL]', apiUrl);

 const response = await axios.get(apiUrl, {
 responseType: 'arraybuffer',
 timeout: 60000
 });

 // ===== 4. PROSES BUFFER =====
 const buffer = Buffer.from(response.data);
 const contentType = response.headers['content-type'] || 'image/jpeg';
 const size = buffer.length;

 if (size === 0) throw new Error('Buffer gambar kosong!');
 if (!contentType.startsWith('image/')) {
 throw new Error(`Tipe konten bukan gambar: ${contentType}`);
 }

 // Log buffer info (hanya di console, tidak dikirim ke user)
 console.log(`[Image Content Buffered Successfully]\nSize: ${size} bytes\nType: ${contentType}`);

 // ===== 5. KIRIM HASIL (caption tanpa buffer info) =====
 const caption = `✅ *Edit Berhasil!*\n📝 Prompt: ${promptText}`;

 try {
 await yonz.sendMessage(m.chat, {
 image: buffer,
 caption: caption
 }, { quoted: m });
 } catch (sendErr) {
 console.error('[SEND IMAGE FAILED]', sendErr);
 // Fallback kirim sebagai dokumen
 await yonz.sendMessage(m.chat, {
 document: buffer,
 mimetype: contentType,
 fileName: `edited_${Date.now()}.jpg`,
 caption: caption
 }, { quoted: m });
 }

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('[EDIT_IMAGE ERROR]', e);

 let errorMsg = '❌ *Terjadi kesalahan!*\n';
 if (e.response) {
 errorMsg += `Status: ${e.response.status}\n`;
 if (e.response.status === 404) {
 errorMsg += `Endpoint tidak ditemukan. URL yang dipanggil: ${apiUrl || '(tidak tersedia)'}`;
 } else if (e.response.data) {
 try {
 const errData = JSON.parse(e.response.data.toString());
 errorMsg += `Pesan: ${errData.message || JSON.stringify(errData)}`;
 } catch (_) {
 errorMsg += `Pesan: ${e.response.data.toString().slice(0, 200)}`;
 }
 }
 } else if (e.request) {
 errorMsg += 'Tidak ada respon dari server (timeout atau koneksi terputus).';
 } else {
 errorMsg += e.message;
 }

 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(errorMsg);
 } finally {
 if (media) {
 try { fs.unlinkSync(media); } catch (_) {}
 }
 }
}
break;




case 'tostyle': {
 try {
 // ---------- 1. Baca file premium dengan aman ----------
 let premiumList = [];
 try {
 premiumList = JSON.parse(fs.readFileSync('./library/database/premium.json'));
 } catch (_) {
 premiumList = []; // jika file tidak ada atau rusak
 }

 // ---------- 2. Cek owner dengan aman (tanpa .map) ----------
 const sender = m.sender.split('@')[0];
 let isOwner = false;

 if (Array.isArray(global.owner)) {
 // Jika owner berupa array of arrays (seperti [ [nomor, nama], ... ])
 isOwner = global.owner.some(v => v[0] == sender);
 } else if (typeof global.owner === 'string') {
 // Jika owner berupa string nomor saja
 isOwner = (global.owner == sender);
 } else if (typeof global.owner === 'object' && global.owner !== null) {
 // Jika owner berupa object, cek apakah ada properti dengan key sender
 isOwner = global.owner.hasOwnProperty(sender);
 }
 // Tambahan: cek juga jika owner adalah array of string (nomor)
 if (!isOwner && Array.isArray(global.owner) && global.owner.every(v => typeof v === 'string')) {
 isOwner = global.owner.includes(sender);
 }

 const isPremium = premiumList.includes(sender) || premiumList.includes(m.sender);

 if (!isOwner && !isPremium) {
 return await yonz.sendMessage(m.chat, { text: global.mess.prem }, { quoted: m });
 }

 // ---------- 3. Ambil prompt dari teks perintah (opsional) ----------
 const text = m.text ? m.text.split(' ').slice(1).join(' ').trim() : '';

 // ---------- 4. Cek apakah ada gambar (reply atau kirim langsung) ----------
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime.includes('image')) {
 return await yonz.sendMessage(m.chat, {
 text: '❌ Reply/kirim gambar dulu ya, lalu pakai command ini.'
 }, { quoted: m });
 }

 await yonz.sendMessage(m.chat, { text: global.mess.wait }, { quoted: m });

 // ---------- 5. Download dan upload gambar ----------
 if (typeof uploadImage !== 'function') {
 throw new Error('Fungsi uploadImage tidak ditemukan!');
 }
 const media = await q.download();
 const imageUrl = await uploadImage(media);

 // ---------- 6. Prompt default atau custom ----------
 const autoPrompt = `A young woman with long, flowing, light mint green hair ... (silahkan isi prompt default kamu)`;
 const prompt = text || autoPrompt;

 // ---------- 7. Panggil API ----------
 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.apikey}&url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`;
 const res = await fetch(apiUrl);
 const json = await res.json();

 // ---------- 8. Ambil URL hasil (coba berbagai field) ----------
 let resultUrl = json.result || json.url || json.data || json.image_url || null;
 if (!resultUrl) {
 console.error('Respons API tidak dikenali:', json);
 throw new Error('API tidak mengembalikan URL gambar.');
 }

 // ---------- 9. Kirim hasil gambar ----------
 await yonz.sendMessage(m.chat, {
 image: { url: resultUrl },
 caption: global.mess.done
 }, { quoted: m });

 } catch (e) {
 console.error('Error di case tostyle:', e);
 await yonz.sendMessage(m.chat, { text: `⚠️ Error: ${e.message}` }, { quoted: m });
 }
}
break;

case 'tosunda':
case 'sunda':
case 'adatjabar': {
 if (!global.isPrem(m.sender) && !isCreator) return ReplyPrem();

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";

 // ---------- Prompt (sama) ----------
 const genderPrompt = `
Sesuaikan pakaian adat mengikuti gender dari wajah pada foto referensi.
Jika perempuan gunakan kebaya Sunda tradisional yang elegan.
Jika laki-laki gunakan pangsi Sunda tradisional yang elegan.
Pertahankan wajah asli, warna kulit, rambut, ekspresi, dan identitas asli tanpa perubahan.
`;

 function cleanPrompt(text = "") {
 return text
 .replace(/\n+/g, ' ')
 .replace(/\s{2,}/g, ' ')
 .trim()
 .slice(0, 2500);
 }

 const rawPrompt = `
${genderPrompt}

Ubah pakaian pada foto menjadi pakaian adat Sunda tradisional yang elegan tanpa mengubah wajah asli orang di foto.

Gunakan busana adat Sunda lengkap seperti kebaya Sunda atau pangsi Sunda, siger atau iket kepala khas Sunda, kain batik Sunda, dan aksesoris tradisional autentik.

Pertahankan bentuk wajah, ekspresi, warna kulit, rambut, pose, dan identitas asli secara detail dan realistis.

Jangan menambah orang lain dan jangan merubah pose asli.

Background tetap sama namun boleh diberi nuansa budaya Sunda secara halus dan natural.

Style photorealistic, ultra realistic, natural lighting, soft cinematic light, realistic skin texture, high detail, sharp focus, elegant traditional atmosphere, 8K quality.

Buat hasil tetap sangat mirip dengan foto asli.
`;

 const teks = cleanPrompt(rawPrompt);

 if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));

 Reply(global.mess.wait);
 await m.react('⏱️');

 // ---------- Persiapan upload ----------
 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

 let mediaPath = null;

 try {
 // Download dan simpan gambar
 mediaPath = await yonz.downloadAndSaveMediaMessage(q);
 if (!mediaPath) throw new Error("gagal mengunduh gambar");

 // Upload ke server (via global.claude)
 const form = new FormData();
 form.append('file', fs.createReadStream(mediaPath));

 const uploadRes = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });

 console.log('[TOSUNDA UPLOAD]', uploadRes.data);

 const userImageUrl = uploadRes.data?.url || uploadRes.data?.result || uploadRes.data?.link || uploadRes.data?.data?.url;
 if (!userImageUrl || typeof userImageUrl !== 'string' || !userImageUrl.startsWith('http')) {
 throw new Error(`gagal upload: ${JSON.stringify(uploadRes.data)}`);
 }

 // ---------- Panggil API Banana AI (dengan responseType arraybuffer) ----------
 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.alipkey}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(teks)}`;
 console.log('[TOSUNDA REQUEST]', apiUrl);

 const initRes = await axios.get(apiUrl, {
 responseType: 'arraybuffer' // penting agar bisa membaca binary
 });

 const contentType = initRes.headers['content-type'] || '';
 console.log('[TOSUNDA Content-Type]', contentType);

 let hasilBuffer = null;

 // Jika respons berupa gambar langsung
 if (contentType.includes('image')) {
 // Langsung gunakan data sebagai gambar
 hasilBuffer = Buffer.from(initRes.data);
 console.log('[TOSUNDA] Mendapatkan gambar langsung dari API');

 } else {
 // Jika JSON, parse untuk cari URL
 const jsonString = Buffer.from(initRes.data).toString('utf-8');
 let taskData;
 try {
 taskData = JSON.parse(jsonString);
 } catch (e) {
 throw new Error('Respons bukan JSON dan bukan gambar: ' + jsonString.slice(0, 200));
 }

 console.log('[TOSUNDA RESPONSE JSON]', JSON.stringify(taskData, null, 2));

 if (taskData.status === false || taskData.success === false || taskData.code === 401 || taskData.error) {
 throw new Error(taskData.message || taskData.error || 'API mengembalikan error');
 }

 // Ekstraksi URL secara rekursif
 function findImageUrl(obj) {
 if (typeof obj === 'string') {
 if (obj.startsWith('http') && /\.(jpg|jpeg|png|webp|gif)/i.test(obj)) return obj;
 return null;
 }
 if (Array.isArray(obj)) {
 for (let item of obj) {
 const found = findImageUrl(item);
 if (found) return found;
 }
 return null;
 }
 if (obj && typeof obj === 'object') {
 for (let key in obj) {
 const found = findImageUrl(obj[key]);
 if (found) return found;
 }
 }
 return null;
 }

 let finalImageUrl = findImageUrl(taskData);
 if (!finalImageUrl && typeof taskData === 'string' && taskData.startsWith('http')) finalImageUrl = taskData;
 if (!finalImageUrl && taskData.result && typeof taskData.result === 'string' && taskData.result.startsWith('http')) finalImageUrl = taskData.result;
 if (!finalImageUrl && taskData.url && typeof taskData.url === 'string' && taskData.url.startsWith('http')) finalImageUrl = taskData.url;

 if (!finalImageUrl) {
 throw new Error(`tidak ada URL gambar dalam JSON: ${jsonString.slice(0, 500)}`);
 }

 // Download hasil gambar dari URL
 const responseImg = await axios.get(finalImageUrl, {
 responseType: "arraybuffer",
 timeout: 60000
 });
 hasilBuffer = Buffer.from(responseImg.data);
 }

 // ---------- Kirim hasil gambar ----------
 const sharp = require('sharp');
 const finalBuffer = await sharp(hasilBuffer).jpeg().toBuffer();

 await yonz.sendMessage(m.chat, {
 image: finalBuffer,
 mimetype: 'image/jpeg',
 caption: global.mess.done
 }, { quoted: m });

 // Kirim VN (opsional)
 await new Promise(resolve => setTimeout(resolve, 1500));
 const vn = await axios.get(
 'http://rahmad-elaina.my.id/file/cadeaf03e6.mp3',
 { responseType: 'arraybuffer' }
 );

 await yonz.sendMessage(m.chat, {
 audio: Buffer.from(vn.data),
 mimetype: 'audio/mp4',
 ptt: true,
 waveform: [100, 0, 100, 0, 100, 0, 100]
 }, { quoted: m });

 await m.react('✅');

 } catch (e) {
 console.error('[TOSUNDA ERROR]', e);
 await m.react('❌');

 if (e.response?.status === 500) {
 return Reply("❌ server AI sedang overload / prompt terlalu kompleks");
 }
 Reply(`❌ gagal: ${e.message}`);
 } finally {
 if (mediaPath && fs.existsSync(mediaPath)) {
 try { fs.unlinkSync(mediaPath); } catch (_) {}
 }
 }
}
break;





case 'tokis':
case 'tosun':
case 'tocium': {
 if (!global.isPrem(m.sender) && !isCreator) return ReplyPrem();

 // ---------- PROMPT UNIVERSAL (cowok/cewek, tanpa ubah bentuk) ----------
 const teks = `IMPORTANT: Preserve the exact identity of the person in the uploaded photo. Do NOT change facial features, face shape, skin texture, hair color, hair style, expression, age, or gender. Keep the face 100% recognizable and unchanged.

Apply these style elements while keeping the person's identity intact:
- Add multiple realistic dark red lipstick kiss marks scattered across the face (nose, cheeks, chin, forehead).
- Change the outfit to an oversized black hoodie with a bold purple mirrored-style text logo on the chest.
- Change the background to a fluffy pastel pink faux-fur blanket.
- Set the pose: lying comfortably on the blanket, one arm behind the head, looking at the camera with a playful wink.
- Use a high-angle smartphone selfie framing, chest-up, vertical 9:16.
- Lighting: soft warm indoor ambient lighting with gentle shadows.
- Photography style: authentic handheld selfie, realistic skin texture, natural softness, photorealistic.

If the person is female, keep her feminine features and adjust the hoodie and pose to suit naturally. If male, keep masculine features. Do not alter gender or facial identity.

Negative Prompt: Any change to the person's original facial shape, skin tone, facial proportions, hair style, hair color, expression, age, gender. Also avoid plastic skin, beauty filter, over-smoothing, exaggerated features, different clothing style, wrong background, extra people, cartoon, anime, CGI, painting, watermark, text, low quality, blur, distorted anatomy.`;

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));

 Reply(global.mess.wait);
 await m.react('⏱️');

 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

 let mediaPath = null;

 try {
 mediaPath = await yonz.downloadAndSaveMediaMessage(q);
 if (!mediaPath) throw new Error("gagal mengunduh gambar");

 const form = new FormData();
 form.append('file', fs.createReadStream(mediaPath));

 const uploadRes = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });

 const userImageUrl = uploadRes.data?.url || uploadRes.data?.result || uploadRes.data?.link || uploadRes.data?.data?.url;
 if (!userImageUrl || typeof userImageUrl !== 'string' || !userImageUrl.startsWith('http')) {
 throw new Error(`gagal upload: ${JSON.stringify(uploadRes.data)}`);
 }

 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.alipkey}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(teks)}`;
 console.log('[IMAGE REQUEST]', apiUrl);

 const initRes = await axios.get(apiUrl, { responseType: 'arraybuffer' });
 const contentType = initRes.headers['content-type'] || '';

 let hasilBuffer = null;

 if (contentType.includes('image')) {
 hasilBuffer = Buffer.from(initRes.data);
 } else {
 const jsonString = Buffer.from(initRes.data).toString('utf-8');
 let taskData;
 try {
 taskData = JSON.parse(jsonString);
 } catch (e) {
 throw new Error('Respons bukan JSON dan bukan gambar: ' + jsonString.slice(0, 200));
 }

 if (taskData.status === false || taskData.success === false || taskData.code === 401 || taskData.error) {
 throw new Error(taskData.message || taskData.error || 'API error');
 }

 function findImageUrl(obj) {
 if (typeof obj === 'string') {
 if (obj.startsWith('http') && /\.(jpg|jpeg|png|webp|gif)/i.test(obj)) return obj;
 return null;
 }
 if (Array.isArray(obj)) {
 for (let item of obj) {
 const found = findImageUrl(item);
 if (found) return found;
 }
 return null;
 }
 if (obj && typeof obj === 'object') {
 for (let key in obj) {
 const found = findImageUrl(obj[key]);
 if (found) return found;
 }
 }
 return null;
 }

 let finalImageUrl = findImageUrl(taskData);
 if (!finalImageUrl && typeof taskData === 'string' && taskData.startsWith('http')) finalImageUrl = taskData;
 if (!finalImageUrl && taskData.result && typeof taskData.result === 'string' && taskData.result.startsWith('http')) finalImageUrl = taskData.result;
 if (!finalImageUrl && taskData.url && typeof taskData.url === 'string' && taskData.url.startsWith('http')) finalImageUrl = taskData.url;

 if (!finalImageUrl) {
 throw new Error(`tidak ada URL gambar dalam JSON: ${jsonString.slice(0, 500)}`);
 }

 const responseImg = await axios.get(finalImageUrl, { responseType: "arraybuffer", timeout: 60000 });
 hasilBuffer = Buffer.from(responseImg.data);
 }

 const sharp = require('sharp');
 const finalBuffer = await sharp(hasilBuffer).jpeg().toBuffer();

 await yonz.sendMessage(m.chat, {
 image: finalBuffer,
 mimetype: 'image/jpeg',
 caption: global.mess.done
 }, { quoted: m });

 await m.react('✅');

 } catch (e) {
 console.error('[IMAGE PROCESS ERROR]', e);
 await m.react('❌');
 if (e.response?.status === 500) {
 return Reply("❌ server AI sedang overload / prompt terlalu kompleks");
 }
 Reply(`❌ gagal: ${e.message}`);
 } finally {
 if (mediaPath && fs.existsSync(mediaPath)) {
 try { fs.unlinkSync(mediaPath); } catch (_) {}
 }
 }
}
break;

case 'tomirror':
case 'mirror': {
 if (!global.isPrem(m.sender) && !isCreator) return ReplyPrem();

 const teks = `Buatkan gambar sesuai deskripsi yang saya berikan di bawah ini. Gunakan wajah, rambut, pakaian, bentuk tubuh, warna kulit, dan seluruh karakteristik orang pada foto referensi secara identik tanpa mengubah sedikit pun. Wajah harus sangat mirip dengan foto referensi dan tetap mempertahankan seluruh detail aslinya.

Seseorang sedang melakukan mirror selfie di kamar mandi modern dengan dinding keramik abu-abu gelap. Mengenakan pakaian yang sama persis seperti pada foto referensi tanpa perubahan apa pun pada model, warna, ukuran, atau detail pakaian. Memegang smartphone di depan wajah dengan flash menyala terang sehingga menghasilkan efek lens flare biru yang melintang di foto. Pose santai sedikit menyamping dengan ekspresi percaya diri. Pencahayaan dari lampu downlight di langit-langit menciptakan suasana clean, minimalis, dan modern. Terlihat urinoir putih di latar belakang. Komposisi foto realistis, candid, aesthetic, high detail, natural skin tone, soft shadows, realistic reflection, authentic bathroom environment.

Buatkan seperti foto asli yang diambil menggunakan kamera smartphone premium, ultra realistic, highly detailed, photorealistic, realistic lighting, realistic skin texture, realistic proportions, natural perspective, authentic details.

Rasio 4:5.

- Tanpa blur
- Tanpa bokeh
- Fokus tajam di seluruh area foto
- Terlihat nyata
- Wajah sangat mirip dengan foto referensi
- Tidak terlihat editan
- Tidak terlihat AI generated
- Mempertahankan 100% identitas, wajah, rambut, dan pakaian dari foto referensi.`;

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));

 Reply(global.mess.wait);
 await m.react('⏱️');

 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

 let mediaPath = null;

 try {
 mediaPath = await yonz.downloadAndSaveMediaMessage(q);
 if (!mediaPath) throw new Error("gagal mengunduh gambar");

 const form = new FormData();
 form.append('file', fs.createReadStream(mediaPath));

 const uploadRes = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });

 const userImageUrl = uploadRes.data?.url || uploadRes.data?.result || uploadRes.data?.link || uploadRes.data?.data?.url;
 if (!userImageUrl || typeof userImageUrl !== 'string' || !userImageUrl.startsWith('http')) {
 throw new Error(`gagal upload: ${JSON.stringify(uploadRes.data)}`);
 }

 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.alipkey}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(teks)}`;
 console.log('[IMAGE REQUEST]', apiUrl);

 const initRes = await axios.get(apiUrl, { responseType: 'arraybuffer' });
 const contentType = initRes.headers['content-type'] || '';

 let hasilBuffer = null;

 if (contentType.includes('image')) {
 hasilBuffer = Buffer.from(initRes.data);
 } else {
 const jsonString = Buffer.from(initRes.data).toString('utf-8');
 let taskData;
 try {
 taskData = JSON.parse(jsonString);
 } catch (e) {
 throw new Error('Respons bukan JSON dan bukan gambar: ' + jsonString.slice(0, 200));
 }

 if (taskData.status === false || taskData.success === false || taskData.code === 401 || taskData.error) {
 throw new Error(taskData.message || taskData.error || 'API error');
 }

 function findImageUrl(obj) {
 if (typeof obj === 'string') {
 if (obj.startsWith('http') && /\.(jpg|jpeg|png|webp|gif)/i.test(obj)) return obj;
 return null;
 }
 if (Array.isArray(obj)) {
 for (let item of obj) {
 const found = findImageUrl(item);
 if (found) return found;
 }
 return null;
 }
 if (obj && typeof obj === 'object') {
 for (let key in obj) {
 const found = findImageUrl(obj[key]);
 if (found) return found;
 }
 }
 return null;
 }

 let finalImageUrl = findImageUrl(taskData);
 if (!finalImageUrl && typeof taskData === 'string' && taskData.startsWith('http')) finalImageUrl = taskData;
 if (!finalImageUrl && taskData.result && typeof taskData.result === 'string' && taskData.result.startsWith('http')) finalImageUrl = taskData.result;
 if (!finalImageUrl && taskData.url && typeof taskData.url === 'string' && taskData.url.startsWith('http')) finalImageUrl = taskData.url;

 if (!finalImageUrl) {
 throw new Error(`tidak ada URL gambar dalam JSON: ${jsonString.slice(0, 500)}`);
 }

 const responseImg = await axios.get(finalImageUrl, { responseType: "arraybuffer", timeout: 60000 });
 hasilBuffer = Buffer.from(responseImg.data);
 }

 const sharp = require('sharp');
 const finalBuffer = await sharp(hasilBuffer).jpeg().toBuffer();

 await yonz.sendMessage(m.chat, {
 image: finalBuffer,
 mimetype: 'image/jpeg',
 caption: global.mess.done
 }, { quoted: m });

 await m.react('✅');

 } catch (e) {
 console.error('[IMAGE PROCESS ERROR]', e);
 await m.react('❌');
 if (e.response?.status === 500) {
 return Reply("❌ server AI sedang overload / prompt terlalu kompleks");
 }
 Reply(`❌ gagal: ${e.message}`);
 } finally {
 if (mediaPath && fs.existsSync(mediaPath)) {
 try { fs.unlinkSync(mediaPath); } catch (_) {}
 }
 }
}
break;



case "bratgambar": {
 if (!text) return Reply("❌ Teks tidak ditemukan, silakan ketik ulang .bratgambar <teks>");

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);

 try {
 const encodedText = encodeURIComponent(text);
 // Menggunakan global.apialip dan global.alipkey
 const apiUrl = `${global.apialip}/imagecreator/bratv?apikey=${global.alipkey}&text=${encodedText}`;

 const axios = require('axios');
 const response = await axios.get(apiUrl, {
 responseType: 'arraybuffer',
 timeout: 30000,
 validateStatus: status => status < 500
 });

 if (response.status !== 200) {
 throw new Error(`HTTP ${response.status} - ${response.statusText}`);
 }

 const imageBuffer = Buffer.from(response.data);
 if (!imageBuffer || imageBuffer.length < 1024) {
 throw new Error('Gambar yang dihasilkan terlalu kecil atau kosong.');
 }

 await yonz.sendAsSticker(m.chat, imageBuffer, m, {
 packname: global.packname || 'Sticker',
 author: global.namaOwner || 'Bot',
 });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (error) {
 console.error("Error di .bratgambar:", error);
 let errorMsg = "❌ *Gagal membuat sticker!*\n";
 if (error.code === 'ECONNABORTED') {
 errorMsg += "⏱️ Waktu koneksi habis. Coba lagi nanti.";
 } else if (error.response) {
 errorMsg += `📡 Status HTTP: ${error.response.status}\n`;
 errorMsg += `📄 Pesan: ${error.response.statusText}`;
 } else if (error.request) {
 errorMsg += "🌐 Tidak ada respon dari server. Periksa koneksi internet.";
 } else {
 errorMsg += `⚠️ ${error.message}`;
 }
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(errorMsg);
 }
}
break;

case "addtqto": {
 if (!isCreator) return Reply(mess.owner);

 await yonz.sendMessage(m.chat, {
 react: {
 text: '💌',
 key: m.key
 }
 });

 const tqtoPath = './library/database/tqto.json';

 if (!fs.existsSync(tqtoPath)) {
 fs.writeFileSync(tqtoPath, JSON.stringify([]));
 }

 const args = text.split('|');

 if (args.length < 3) {
 return Reply(`Format salah!\nContoh: .addtqto nama|posisi|nomor`);
 }

 const nama = args[0].trim();
 const posisi = args[1].trim();
 const number = args[2].trim();

 let tqtoData = JSON.parse(fs.readFileSync(tqtoPath));

 // Cek apakah nomor sudah ada
 const sudahAda = tqtoData.find(v => v.number === number);
 if (sudahAda) {
 return Reply(`Nomor *${number}* sudah ada di daftar tqto!`);
 }

 tqtoData.push({
 name: nama,
 role: posisi,
 number: number,
 addedBy: m.sender,
 addedAt: Date.now()
 });

 fs.writeFileSync(tqtoPath, JSON.stringify(tqtoData, null, 2));

 return Reply(`Berhasil menambahkan!\n\n*Name:* ${nama}\n*Posisi:* ${posisi}\n*Number:* ${number}`);
}
break

case "deltqto": {
 if (!isCreator) return Reply(mess.owner);

 await yonz.sendMessage(m.chat, {
 react: {
 text: '💌',
 key: m.key
 }
 });

 const tqtoPath = './library/database/tqto.json';

 if (!fs.existsSync(tqtoPath)) {
 return Reply(`File tqto.json tidak ditemukan!`);
 }

 const args = text.split('|');

 if (args.length < 2) {
 return Reply(`Format salah!\nContoh: .deltqto nama|nomor`);
 }

 const nama = args[0].trim();
 const number = args[1].trim();

 let tqtoData = JSON.parse(fs.readFileSync(tqtoPath));

 // Cek apakah data ada
 const index = tqtoData.findIndex(v => v.number === number && v.name === nama);
 if (index === -1) {
 return Reply(`Data dengan nama *${nama}* dan nomor *${number}* tidak ditemukan!`);
 }

 const deleted = tqtoData[index];
 tqtoData.splice(index, 1);

 fs.writeFileSync(tqtoPath, JSON.stringify(tqtoData, null, 2));

 return Reply(`Berhasil menghapus!\n\n*Name:* ${deleted.name}\n*Posisi:* ${deleted.role}\n*Number:* ${deleted.number}`);
}
break



case "delprem":
case "delpremium": {
 if (!isCreator) return Reply(mess.owner);

 let users = [];

 if (m.isGroup) {
 if (m.mentionedJid.length) {
 users = m.mentionedJid.map(id => {
 if (id.endsWith('@lid')) {
 let p = m.metadata.participants?.find(x => x.id === id || x.lid === id);
 return p ? p.jid : null;
 }
 return id;
 }).filter(Boolean);
 } else if (m.quoted) {
 users = [m.quoted.sender];
 } else {
 let nomor = args[0]?.replace(/[^0-9]/g, '');
 if (!nomor) return Reply(`Contoh:\n${prefix}delprem 6285xxxx atau ${prefix}delprem @tag\nAtau reply pesan target.`);
 users = [nomor + '@s.whatsapp.net'];
 }
 } else {
 if (m.quoted) {
 users = [m.quoted.sender];
 } else {
 let nomor = args[0]?.replace(/[^0-9]/g, '');
 if (!nomor) return Reply(`Contoh:\n${prefix}delprem 6285xxxx`);
 users = [nomor + '@s.whatsapp.net'];
 }
 }

 if (!users.length) return Reply('❌ Tidak ada pengguna yang valid.');

 let prem = [];
 try {
 const data = fs.readFileSync("./library/database/premium.json");
 prem = JSON.parse(data);
 } catch (e) {
 prem = [];
 }

 let removed = [];
 let notFound = [];

 for (let jid of users) {
 const index = prem.findIndex(u => u && u.jid === jid);
 if (index !== -1) {
 removed.push(prem[index]);
 prem.splice(index, 1);
 } else {
 // Fallback: cari berdasarkan number (jika ada field number)
 const number = jid.split('@')[0];
 const idxByNumber = prem.findIndex(u => u.number === number);
 if (idxByNumber !== -1) {
 removed.push(prem[idxByNumber]);
 prem.splice(idxByNumber, 1);
 } else {
 notFound.push(jid);
 }
 }
 }

 if (removed.length === 0) {
 return Reply('❌ Tidak ada pengguna premium yang ditemukan untuk dihapus.');
 }

 fs.writeFileSync("./library/database/premium.json", JSON.stringify(prem, null, 2));

 // Buat pesan balasan (tanpa mention/tag)
 const removedNumbers = removed.map(u => u.number || u.jid.split('@')[0]);
 let replyText = `✅ Berhasil menghapus premium untuk:\n${removedNumbers.map(n => `- ${n}`).join('\n')}`;
 if (notFound.length) {
 const notFoundNumbers = notFound.map(j => j.split('@')[0]);
 replyText += `\n\n⚠️ Tidak ditemukan (tidak dihapus):\n${notFoundNumbers.map(n => `- ${n}`).join('\n')}`;
 }
 Reply(replyText);
}
break;



case "cekprem":
case "cekpremium": {
 const fs = require('fs');
 const path = require('path');

 const getNumber = (jid) => {
 if (!jid) return '';
 return jid.split('@')[0];
 };

 const premPath = './library/database/premium.json';
 let premiumUsers = [];
 try {
 if (fs.existsSync(premPath)) {
 const data = fs.readFileSync(premPath, 'utf8');
 premiumUsers = JSON.parse(data);
 if (!Array.isArray(premiumUsers)) premiumUsers = [];
 }
 } catch (_) {
 premiumUsers = [];
 }

 // Tentukan target
 let targetJid = null;
 let targetNum = null;

 // Prioritas: mention
 if (m.isGroup && m.mentionedJid && m.mentionedJid.length) {
 targetJid = m.mentionedJid[0];
 // Jika mention pakai @lid, konversi ke jid biasa
 if (targetJid && targetJid.endsWith('@lid')) {
 const p = m.metadata?.participants?.find(x => x.id === targetJid || x.lid === targetJid);
 if (p) targetJid = p.jid;
 }
 }

 // Quoted message
 if (!targetJid && m.quoted) {
 targetJid = m.quoted.sender;
 }

 // Argumen nomor
 if (!targetJid && args.length > 0) {
 const nomor = args[0].replace(/[^0-9]/g, '');
 if (nomor) {
 targetJid = nomor + '@s.whatsapp.net';
 }
 }

 // Default: diri sendiri
 if (!targetJid) {
 targetJid = m.sender;
 }

 targetNum = getNumber(targetJid);

 // Cari di database premium
 let userData = premiumUsers.find(u => u && (u.jid === targetJid || u.number === targetNum));
 const now = Date.now();

 let replyText = `📋 *Cek Status Premium*\n\n`;
 replyText += `📱 Nomor: ${targetNum}\n`;

 if (!userData) {
 replyText += `❌ Tidak terdaftar sebagai premium.`;
 } else {
 const isExpired = userData.expired <= now;
 const sisa = userData.expired - now;
 let sisaText;
 if (isExpired) {
 sisaText = '⏳ Kadaluarsa';
 } else {
 const days = Math.floor(sisa / (1000 * 60 * 60 * 24));
 const hours = Math.floor((sisa % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
 sisaText = `${days} hari ${hours} jam`;
 }

 replyText += `📌 Status: ${isExpired ? '❌ Kadaluarsa' : '✅ Aktif'}\n`;
 replyText += `⏱️ Sisa waktu: ${sisaText}\n`;

 if (userData.addedBy) {
 const addedNum = getNumber(userData.addedBy);
 replyText += `👤 Ditambah oleh: ${addedNum}\n`;
 }
 if (userData.addedAt) {
 const addedDate = new Date(userData.addedAt);
 replyText += `📅 Tanggal tambah: ${addedDate.toLocaleDateString('id-ID')} ${addedDate.toLocaleTimeString('id-ID')}\n`;
 }
 if (userData.expired) {
 const expiredDate = new Date(userData.expired);
 replyText += `📅 Kadaluarsa: ${expiredDate.toLocaleDateString('id-ID')} ${expiredDate.toLocaleTimeString('id-ID')}`;
 }
 }

 Reply(replyText);
}
break;


case "cekid":
case "infoid": {
 // ==================== CEK PREMIUM ====================
 const fs = require('fs');
 const getNumber = (jid) => {
 if (!jid) return '';
 return jid.split('@')[0];
 };

 const normalizeOwner = (owner) => {
 if (!owner) return [];
 if (Array.isArray(owner)) return owner.map(v => v.trim());
 if (typeof owner === 'string') {
 return owner.split(/[,;\s-]+/).filter(v => v.trim() !== '');
 }
 return [];
 };

 const premPath = './library/database/premium.json';
 let premiumUsers = [];
 try {
 if (fs.existsSync(premPath)) {
 const data = fs.readFileSync(premPath, 'utf8');
 premiumUsers = JSON.parse(data);
 if (!Array.isArray(premiumUsers)) premiumUsers = [];
 }
 } catch (_) {
 premiumUsers = [];
 }

 const senderJid = m.sender;
 const senderNum = getNumber(senderJid);
 const owners = normalizeOwner(global.owner);
 const isOwner = owners.includes(senderNum);
 let isPremium = false;

 for (let user of premiumUsers) {
 if (user.jid === senderJid || user.number === senderNum) {
 if (user.expired > Date.now()) {
 isPremium = true;
 break;
 }
 }
 }

 if (!isOwner && !isPremium) {
 return Reply(global.mess.prem);
 }
 // ==================== AKHIR CEK ====================

 let input = args[0];
 if (!input) return Reply(`❌ Masukkan ID channel atau link channel!\nContoh: ${prefix}cekid 120363426234538573@newsletter\nAtau: ${prefix}cekid https://whatsapp.com/channel/0029Vb7LAXcLY6cxZmasdh43`);

 let channelId = null;

 // Cek jika input adalah link
 if (input.includes('https://whatsapp.com/channel/')) {
 try {
 channelId = input.split('https://whatsapp.com/channel/')[1].split(/[?&]/)[0];
 } catch (_) {
 return Reply('❌ Gagal mengekstrak ID dari link.');
 }
 } 
 // Cek jika input adalah ID newsletter (berakhir @newsletter)
 else if (input.endsWith('@newsletter')) {
 channelId = input;
 }
 // Cek jika input hanya angka (anggap ID tanpa @newsletter)
 else if (/^[0-9]+$/.test(input)) {
 channelId = input + '@newsletter';
 } else {
 return Reply('❌ Format tidak dikenali. Gunakan ID seperti 120363426234538573@newsletter atau link channel.');
 }

 if (!channelId) return Reply('❌ ID channel tidak valid.');

 try {
 // Ambil metadata channel menggunakan yonz
 // Gunakan 'id' karena kita sudah punya ID lengkap
 let res = await yonz.newsletterMetadata('id', channelId).catch(e => null);
 if (!res) {
 // Coba dengan 'invite' sebagai fallback (jika ID adalah invite code)
 res = await yonz.newsletterMetadata('invite', channelId.replace('@newsletter', '')).catch(e => null);
 }
 if (!res) return Reply('❌ Gagal mengambil data channel! Periksa ID atau coba lagi.');

 // Siapkan teks info
 let teks = `
╔──☉ *INFO CHANNEL* 
│✎ *ID* : ${res.id || channelId}
│✎ *Nama* : ${res.name || '-'}
│✎ *Followers*: ${res.subscribers || 0}
│✎ *Status* : ${res.state || '-'}
│✎ *Verified* : ${res.verification == 'VERIFIED' ? '✅ Terverifikasi' : '❌ Tidak'}
│✎ *Deskripsi*: ${res.description || '-'}
╚────────────☉
`.trim();

 // Tampilkan info
 Reply(teks);

 } catch (e) {
 console.error('[CEKID ERROR]', e);
 Reply('❌ Terjadi error: ' + e.message);
 }
}
break;

case "idch":
case "cekidch": {
 // ==================== CEK PREMIUM ====================
 const fs = require('fs');
 const getNumber = (jid) => {
 if (!jid) return '';
 return jid.split('@')[0];
 };

 const normalizeOwner = (owner) => {
 if (!owner) return [];
 if (Array.isArray(owner)) return owner.map(v => v.trim());
 if (typeof owner === 'string') {
 return owner.split(/[,;\s-]+/).filter(v => v.trim() !== '');
 }
 return [];
 };

 const premPath = './library/database/premium.json';
 let premiumUsers = [];
 try {
 if (fs.existsSync(premPath)) {
 const data = fs.readFileSync(premPath, 'utf8');
 premiumUsers = JSON.parse(data);
 if (!Array.isArray(premiumUsers)) premiumUsers = [];
 }
 } catch (_) {
 premiumUsers = [];
 }

 const senderJid = m.sender;
 const senderNum = getNumber(senderJid);
 const owners = normalizeOwner(global.owner);
 const isOwner = owners.includes(senderNum);
 let isPremium = false;

 for (let user of premiumUsers) {
 if (user.jid === senderJid || user.number === senderNum) {
 if (user.expired > Date.now()) {
 isPremium = true;
 break;
 }
 }
 }

 if (!isOwner && !isPremium) {
 return Reply(global.mess.prem);
 }
 // ==================== AKHIR CEK ====================

 let input = args[0];
 if (!input) return Reply(`❌ Masukkan ID channel atau link channel!\nContoh: ${prefix}idch https://whatsapp.com/channel/0029Vb7LAXcLY6cxZmasdh43\nAtau: ${prefix}idch 120363426234538573@newsletter`);

 let channelId = null;

 // Cek jika input adalah link
 if (input.includes('https://whatsapp.com/channel/')) {
 try {
 channelId = input.split('https://whatsapp.com/channel/')[1].split(/[?&]/)[0];
 } catch (_) {
 return Reply('❌ Gagal mengekstrak ID dari link.');
 }
 } 
 // Cek jika input adalah ID newsletter (berakhir @newsletter)
 else if (input.endsWith('@newsletter')) {
 channelId = input;
 }
 // Cek jika input hanya angka (anggap ID tanpa @newsletter)
 else if (/^[0-9]+$/.test(input)) {
 channelId = input + '@newsletter';
 } else {
 return Reply('❌ Format tidak dikenali. Gunakan ID seperti 120363426234538573@newsletter atau link channel.');
 }

 if (!channelId) return Reply('❌ ID channel tidak valid.');

 try {
 // Ambil metadata channel
 let res = await yonz.newsletterMetadata('id', channelId).catch(e => null);
 if (!res) {
 // Fallback: coba dengan 'invite' (tanpa @newsletter)
 const inviteId = channelId.replace('@newsletter', '');
 res = await yonz.newsletterMetadata('invite', inviteId).catch(e => null);
 }
 if (!res) return Reply('❌ Gagal mengambil data channel! Periksa ID atau coba lagi.');

 // Pastikan res.id ada (untuk tombol copy)
 const finalId = res.id || channelId.replace('@newsletter', '');

 // Siapkan teks info (tanpa deskripsi)
 const teks = `
╔──☉ *INFO CHANNEL* 
│✎ *ID* : ${finalId}
│✎ *Nama* : ${res.name || '-'}
│✎ *Followers*: ${res.subscribers || 0}
│✎ *Status* : ${res.state || '-'}
│✎ *Verified* : ${res.verification == 'VERIFIED' ? '✅ Terverifikasi' : '❌ Tidak'}
╚────────────☉
`.trim();

 // ===== KIRIM PESAN INTERAKTIF DENGAN TOMBOL COPY =====
 let proto = null;
 if (yonz.proto) proto = yonz.proto;
 else if (global.proto) proto = global.proto;
 else {
 try {
 const baileys = require('@whiskeysockets/baileys');
 if (baileys.proto) proto = baileys.proto;
 } catch (_) {}
 }

 if (proto) {
 const interactiveMessage = {
 body: {
 text: teks
 },
 footer: {
 text: 'Bot WhatsApp'
 },
 nativeFlowMessage: {
 buttons: [
 {
 name: 'cta_copy',
 buttonParamsJson: `{"display_text":"SALIN ID","id":"${finalId}","copy_code":"${finalId}"}`
 },
 {
 name: 'cta_url',
 buttonParamsJson: `{"display_text":"BUKA CHANNEL","url":"https://whatsapp.com/channel/${finalId}","merchant_url":"https://whatsapp.com/channel/${finalId}"}`
 }
 ]
 }
 };

 const msg = await yonz.generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject(interactiveMessage)
 }
 }
 },
 { userJid: m.sender, quoted: m }
 );

 await yonz.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 } else {
 // Fallback: kirim teks biasa
 await yonz.sendMessage(m.chat, {
 text: `${teks}\n\n🔗 Buka: https://whatsapp.com/channel/${finalId}`
 }, { quoted: m });
 }

 } catch (e) {
 console.error('[IDCH ERROR]', e);
 Reply('❌ Terjadi error: ' + e.message);
 }
}
break;

case "jpmtag":
case "jpmhidetag": {
if (!isCreator2) return Reply(mess.creator);
if (!text) return Reply(example("teksnya"))
let allgrup = await yonz.groupFetchAllParticipating()
let grup = Object.keys(allgrup)
let count = 0
const jid = m.chat
Reply(`Memproses JPM ke ${grup.length} grup...`)
for (let id of grup) {
 if (global.db.groups[id] && global.db.groups[id].blacklistjpm == true) continue
 try {
 let meta = await yonz.groupMetadata(id)
 let members = meta.participants.map(v => v.id)
 await yonz.sendMessage(id, {
 text: text,
 mentions: members
 })
 count++
 } catch (e) {
 console.log("Error:", id, e.message)
 }
 await sleep(global.delayJpm || 2000)
}
await yonz.sendMessage(jid, {
 text: `✅ JPM Hidden Tag selesai\nBerhasil kirim ke ${count} grup`
}, { quoted: m })
}
break





















case "setimg":
case "setimage": {
 if (!isCreator) return Reply(mess.owner);
 
 let type = args[0]?.toLowerCase();
 if (!type || (type !== "menu" && type !== "reply" && type !== "video")) {
 return Reply(`❌ Contoh penggunaan:\n${prefix}setimg menu\n${prefix}setimg reply\n${prefix}setimg video\n\nKemudian reply gambar/video yang ingin dijadikan sebagai gambar menu/reply/video.`);
 }
 
 const quotedMsg = m.quoted || m;
 const mimeType = (quotedMsg.msg || quotedMsg).mimetype || '';
 
 if (type === "video") {
 if (!m.quoted || !/video/.test(mimeType)) {
 return Reply("❌ Reply video yang ingin dijadikan sebagai video menu!");
 }
 } else {
 if (!m.quoted || !/image/.test(mimeType)) {
 return Reply("❌ Reply gambar yang ingin dijadikan sebagai gambar!");
 }
 }
 
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);
 
 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');
 
 // Pastikan direktori penyimpanan ada
 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) {
 fs.mkdirSync(dir, { recursive: true });
 }
 
 let media = null;
 try {
 media = await yonz.downloadAndSaveMediaMessage(quotedMsg);
 
 let directLink;
 
 if (type === "reply") {
 // Simpan langsung ke source/media/foto/imgdokumen.jpg
 const destDir = path.join(__dirname, 'source', 'media', 'foto');
 if (!fs.existsSync(destDir)) {
 fs.mkdirSync(destDir, { recursive: true });
 }
 const destPath = path.join(destDir, 'imgdokumen.jpg');
 fs.copyFileSync(media, destPath);
 directLink = 'source/media/foto/imgdokumen.jpg';
 } else if (type === "video") {
 // Simpan langsung ke media/menu.mp4
 const destDir = path.join(__dirname, 'media');
 if (!fs.existsSync(destDir)) {
 fs.mkdirSync(destDir, { recursive: true });
 }
 const destPath = path.join(destDir, 'menu.mp4');
 fs.copyFileSync(media, destPath);
 directLink = 'media/menu.mp4';
 } else {
 // Upload menggunakan endpoint yang sama dengan tourl
 const form = new FormData();
 form.append('file', fs.createReadStream(media));
 
 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });
 
 console.log('[SETIMG RESPONSE]', upload.data);
 
 directLink = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;
 
 if (!directLink || typeof directLink !== 'string') {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(`❌ Gagal upload gambar ke server.\nRespon: ${JSON.stringify(upload.data)}`);
 }
 }
 
 // Update settings.js
 let settingsPath = path.join(__dirname, 'settings.js');
 let settingsContent = fs.readFileSync(settingsPath, 'utf8');
 
 if (type === "menu") {
 settingsContent = settingsContent.replace(
 /menu:\s*["'][^"']*["']/,
 `menu: "${directLink}"`
 );
 } else if (type === "reply") {
 settingsContent = settingsContent.replace(
 /reply:\s*["'][^"']*["']/,
 `reply: "${directLink}"`
 );
 } else if (type === "video") {
 settingsContent = settingsContent.replace(
 /video:\s*["'][^"']*["']/,
 `video: "${directLink}"`
 );
 }
 
 fs.writeFileSync(settingsPath, settingsContent, 'utf8');
 
 // Kirim hasil
 const restartNotice = (type === "reply" || type === "video") ? `\n\n⚠️ *Silakan restart bot* agar ${type === "video" ? "video menu" : "gambar reply"} baru dapat diterapkan!` : '';
 
 if (type === "video") {
 await yonz.sendMessage(m.chat, {
 video: { url: directLink },
 caption: `✅ Berhasil mengubah video *menu*!\n\nPath: ${directLink}${restartNotice}`
 }, { quoted: m });
 } else {
 await yonz.sendMessage(m.chat, {
 image: { url: directLink },
 caption: `✅ Berhasil mengubah gambar *${type}*!\n\nURL: ${directLink}${restartNotice}`
 }, { quoted: m });
 }
 
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[SETIMG ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 } finally {
 if (media) {
 try {
 fs.unlinkSync(media);
 } catch (_) { /* abaikan */ }
 }
 }
}
break

// ==================== INSTAGRAM DOWNLOADER ====================


// ==================== INSTAGRAM AUDIO ONLY ====================




case 'tomp3':
case 'toaudio': {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!/video/.test(mime)) {
 return Reply(`❌ Reply ke *video* yang ingin diubah menjadi mp3 dengan caption *.tomp3*`);
 }
 if ((q.msg?.seconds || 0) > 300) {
 return Reply("❌ Video terlalu panjang! Durasi maksimal adalah 5 menit.");
 }

 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "🚀", key: m.key } });

 const { exec } = require('child_process');
 let videoPath;
 let outputPath;

 try {
 videoPath = await yonz.downloadAndSaveMediaMessage(q);
 const tempDir = path.join(__dirname, 'tmp');
 if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
 outputPath = path.join(tempDir, `${Date.now()}.mp3`);

 await new Promise((resolve, reject) => {
 exec(`ffmpeg -i "${videoPath}" "${outputPath}"`, (err) => {
 if (err) {
 console.error("FFmpeg Error:", err);
 reject(new Error("Gagal mengonversi video. Pastikan FFmpeg terinstal."));
 } else {
 resolve();
 }
 });
 });

 await yonz.sendMessage(m.chat, {
 audio: { url: outputPath },
 mimetype: 'audio/mpeg'
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (err) {
 console.error('Tomp3 Error:', err);
 Reply(`❌ Terjadi kesalahan: ${err.message}`);
 await yonz.sendMessage(m.chat, { react: { text: "⚠️", key: m.key } });
 } finally {
 if (videoPath && fs.existsSync(videoPath)) {
 fs.unlinkSync(videoPath);
 }
 if (outputPath && fs.existsSync(outputPath)) {
 fs.unlinkSync(outputPath);
 }
 }
}
break;










case "ig":
case "instagram": {
 if (!text) return Reply("❌ Masukkan URL Instagram.\nContoh: .ig https://www.instagram.com/reel/xxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?(?:instagram\.com|instagr\.am)\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL Instagram tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 const response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 if (medias.length === 0) throw new Error('Tidak ada media ditemukan');
 const mediaList = medias.filter(m => m.type === 'video' || m.type === 'image');
 if (mediaList.length === 0) {
 const audio = medias.find(m => m.type === 'audio');
 if (audio) {
 const audioBuffer = await axios.get(audio.url, { responseType: 'arraybuffer', timeout: 30000 });
 await yonz.sendMessage(m.chat, { document: audioBuffer.data, mimetype: 'audio/mpeg', fileName: `instagram_audio_${Date.now()}.mp3` });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 return;
 }
 throw new Error('Tidak ada video/gambar/audio yang dapat dikirim');
 }
 for (let media of mediaList) {
 const mediaBuffer = await axios.get(media.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(mediaBuffer.data);
 if (media.type === 'video') {
 await yonz.sendMessage(m.chat, { video: buffer });
 } else if (media.type === 'image') {
 await yonz.sendMessage(m.chat, { image: buffer });
 }
 }
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .ig:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal download Instagram!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;

case "igmp3": {
 if (!text) return Reply("❌ Masukkan URL Instagram untuk diambil audionya.\nContoh: .igmp3 https://www.instagram.com/reel/xxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?(?:instagram\.com|instagr\.am)\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL Instagram tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 const response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 const audio = medias.find(m => m.type === 'audio');
 if (!audio) throw new Error('Tidak ditemukan audio pada postingan ini');
 const audioBuffer = await axios.get(audio.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(audioBuffer.data);
 await yonz.sendMessage(m.chat, { audio: buffer, mimetype: 'audio/mpeg', fileName: `instagram_audio_${Date.now()}.mp3` });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .igmp3:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal ambil audio!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;

case "fb":
case "facebook": {
 if (!text) return Reply("❌ Masukkan URL Facebook.\nContoh: .fb https://www.facebook.com/xxx/videos/xxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.watch)\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL Facebook tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 const response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 if (medias.length === 0) throw new Error('Tidak ada media ditemukan');
 const mediaList = medias.filter(m => m.type === 'video' || m.type === 'image');
 if (mediaList.length === 0) throw new Error('Tidak ada video/gambar yang dapat dikirim');
 for (let media of mediaList) {
 const mediaBuffer = await axios.get(media.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(mediaBuffer.data);
 if (media.type === 'video') {
 await yonz.sendMessage(m.chat, { video: buffer });
 } else if (media.type === 'image') {
 await yonz.sendMessage(m.chat, { image: buffer });
 }
 }
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .fb:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal download Facebook!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;

case "capcut":
case "cc": {
 if (!text) return Reply("❌ Masukkan URL Capcut.\nContoh: .capcut https://www.capcut.com/t/xxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?capcut\.com\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL Capcut tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 const response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 if (medias.length === 0) throw new Error('Tidak ada media ditemukan');
 const mediaList = medias.filter(m => m.type === 'video' || m.type === 'image');
 if (mediaList.length === 0) throw new Error('Tidak ada video/gambar yang dapat dikirim');
 for (let media of mediaList) {
 const mediaBuffer = await axios.get(media.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(mediaBuffer.data);
 if (media.type === 'video') {
 await yonz.sendMessage(m.chat, { video: buffer });
 } else if (media.type === 'image') {
 await yonz.sendMessage(m.chat, { image: buffer });
 }
 }
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .capcut:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal download Capcut!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;

case "tiktok":
case "tt":
case "tk": {
 if (!text) return Reply("❌ Masukkan URL TikTok.\nContoh: .tiktok https://vt.tiktok.com/xxxxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?(?:tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com)\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL TikTok tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 let response;
 let retries = 0;
 while (retries < 2) {
 try {
 response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status === 200) break;
 } catch (e) {
 if (retries === 0 && e.response && e.response.status === 500) {
 await new Promise(resolve => setTimeout(resolve, 2000));
 retries++;
 continue;
 }
 throw e;
 }
 retries++;
 }
 if (!response || response.status !== 200) throw new Error(`HTTP ${response ? response.status : 'no response'}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 if (medias.length === 0) throw new Error('Tidak ada media ditemukan');
 let video = medias.find(m => m.type === 'video' && m.quality === 'hd_no_watermark');
 if (!video) video = medias.find(m => m.type === 'video' && m.quality === 'no_watermark');
 if (!video) video = medias.find(m => m.type === 'video');
 if (!video) throw new Error('Tidak ada video ditemukan');
 const mediaBuffer = await axios.get(video.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(mediaBuffer.data);
 await yonz.sendMessage(m.chat, { video: buffer });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .tiktok:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal download TikTok!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;



case "yt":
case "youtube":
case "ytdl": {
 if (!text) return Reply("❌ Masukkan URL YouTube.\nContoh: .yt https://www.youtube.com/watch?v=xxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL YouTube tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 const response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 if (medias.length === 0) throw new Error('Tidak ada media ditemukan');
 const videos = medias.filter(m => m.type === 'video');
 if (videos.length === 0) throw new Error('Tidak ada video ditemukan');
 let video = videos.find(m => m.quality && m.quality.includes('mp4') && m.quality.includes('1080p60'));
 if (!video) video = videos.find(m => m.quality && m.quality.includes('mp4') && m.quality.includes('720p60'));
 if (!video) video = videos.find(m => m.quality && m.quality.includes('webm') && m.quality.includes('2160p60'));
 if (!video) video = videos.find(m => m.quality && m.quality.includes('webm') && m.quality.includes('1440p60'));
 if (!video) video = videos.find(m => m.quality && m.quality.includes('webm') && m.quality.includes('1080p60'));
 if (!video) {
 let maxRes = 0;
 for (let v of videos) {
 const width = v.width || 0;
 const height = v.height || 0;
 const res = width * height;
 if (res > maxRes) {
 maxRes = res;
 video = v;
 }
 }
 }
 if (!video) video = videos[0];
 const mediaBuffer = await axios.get(video.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(mediaBuffer.data);
 await yonz.sendMessage(m.chat, { video: buffer });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .yt:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal download YouTube!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;

case "ytmp4": {
 if (!text) return Reply("❌ Masukkan URL YouTube.\nContoh: .ytmp4 https://www.youtube.com/watch?v=xxx");
 const urlPattern = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/[^\s]+/i;
 const match = text.match(urlPattern);
 if (!match) return Reply("❌ URL YouTube tidak valid.");
 const url = match[0];
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 try {
 const axios = require('axios');
 const apiUrl = `${global.apialip}/download/aio?apikey=${global.alipkey}&url=${encodeURIComponent(url)}`;
 const response = await axios.get(apiUrl, { timeout: 30000 });
 if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
 const data = response.data;
 if (!data.status || !data.result) throw new Error('API merespon tidak valid');
 const result = data.result;
 const medias = result.medias || [];
 if (medias.length === 0) throw new Error('Tidak ada media ditemukan');
 const videos = medias.filter(m => m.type === 'video' && m.quality && m.quality.includes('mp4'));
 if (videos.length === 0) throw new Error('Tidak ada video MP4 ditemukan');
 let video = videos.find(m => m.quality && m.quality.includes('1080p60'));
 if (!video) video = videos.find(m => m.quality && m.quality.includes('720p60'));
 if (!video) video = videos.find(m => m.quality && m.quality.includes('480p'));
 if (!video) video = videos[0];
 const mediaBuffer = await axios.get(video.url, { responseType: 'arraybuffer', timeout: 30000 });
 const buffer = Buffer.from(mediaBuffer.data);
 await yonz.sendMessage(m.chat, { video: buffer });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 Reply(global.mess.done);
 } catch (error) {
 console.error("Error di .ytmp4:", error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 let msg = "❌ Gagal download YouTube!";
 if (error.response) {
 if (error.response.status === 500) msg += "\n⚠️ Server API sibuk, coba lagi nanti.";
 else if (error.response.status === 404) msg += "\n⚠️ URL tidak ditemukan.";
 else msg += `\n⚠️ ${error.response.status} - ${error.response.statusText}`;
 } else if (error.code === 'ECONNABORTED') {
 msg += "\n⏱️ Waktu koneksi habis.";
 } else {
 msg += `\n⚠️ ${error.message}`;
 }
 Reply(msg);
 }
}
break;

case "bstation": {
 const query = m.text.split(' ').slice(1).join(' ')
 if (!query) return Reply('📌 *Gunakan:* .bstation <judul>\nContoh: .bstation Cina')

 try {
 const url = `${global.apialip}/search/bstation?apikey=${global.alipkey}&q=${encodeURIComponent(query)}`
 const res = await axios.get(url)
 if (!res.data.status || !res.data.result.length) return Reply('❌ Tidak ditemukan.')

 let txt = `🔎 *Hasil pencarian " ${query} "*\n\n`
 res.data.result.forEach((v, i) => {
 txt += `${i+1}. *${v.title}*\n`
 txt += ` ⏱ ${v.duration} | 👤 ${v.uploader}\n`
 txt += ` 👀 ${v.views}\n\n`
 })
 txt += `➡️ Ketik .bstation1 <query> untuk lihat detail video pertama`
 await Reply(txt)
 } catch (e) {
 console.error(e)
 Reply('⚠️ Terjadi error saat mengambil data.')
 }
 break
}

case "bstation1": {
 const query = m.text.split(' ').slice(1).join(' ')
 if (!query) return Reply('📌 *Gunakan:* .bstation1 <judul>\nContoh: .bstation1 Cina')

 try {
 const url = `${global.apialip}/search/bstation?apikey=${global.alipkey}&q=${encodeURIComponent(query)}`
 const res = await axios.get(url)
 if (!res.data.status || !res.data.result.length) return Reply('❌ Tidak ditemukan.')

 const v = res.data.result[0]
 let txt = `🎬 *${v.title}*\n\n`
 txt += `⏱ Durasi: ${v.duration}\n`
 txt += `👤 Uploader: ${v.uploader}\n`
 txt += `👀 Views: ${v.views}\n`
 txt += `🔗 Link: ${v.url}\n`
 txt += `🖼 Thumbnail: ${v.thumbnail}`

 await Reply(txt)
 } catch (e) {
 console.error(e)
 Reply('⚠️ Terjadi error saat mengambil data.')
 }
 break
}

case 'pin':
case 'pinterest': {
 if (!text) return Reply(`Contoh: ${prefix + command} bebek`)

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

 const url = `${global.apialip}/search/pinterest?apikey=${global.alipkey}&q=${encodeURIComponent(text)}`
 const { data } = await axios.get(url)

 if (!data || !data.status || !data.result || data.result.length === 0) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Gagal mengambil data, coba keyword lain.')
 }

 const imageUrls = data.result.slice(0, 10)
 const medias = imageUrls.map(url => ({ image: { url } }))

 if (medias.length === 0) {
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 return Reply('Tidak ada foto yang bisa ditampilkan.')
 }

 if (medias.length === 1) {
 await yonz.sendMessage(m.chat, {
 image: { url: medias[0].image.url },
 caption: `🖼 Hasil Pinterest: ${text}`
 }, { quoted: m })
 } else {
 const { generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys')
 const crypto = require('crypto')

 const album = generateWAMessageFromContent(m.chat, {
 messageContextInfo: {
 messageSecret: crypto.randomBytes(32)
 },
 albumMessage: {
 expectedImageCount: medias.length,
 expectedVideoCount: 0
 }
 }, { quoted: m })

 await yonz.relayMessage(m.chat, album.message, { messageId: album.key.id })

 for (const media of medias) {
 const prepared = await prepareWAMessageMedia(
 { image: media.image },
 { upload: yonz.waUploadToServer }
 )

 const content = generateWAMessageFromContent(m.chat, {
 imageMessage: prepared.imageMessage,
 messageContextInfo: {
 messageAssociation: {
 associationType: 1,
 parentMessageKey: album.key
 }
 }
 }, {})

 await yonz.relayMessage(m.chat, content.message, { messageId: content.key.id })
 }
 }

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

 } catch (e) {
 console.error(e)
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 Reply('Terjadi kesalahan saat memproses permintaan.')
 }
}
break











case 'ptv':
case 'playtiktok':
case 'tiktokplay': {
 if (!isRegistered(m.sender) && !isCreator)
 return Reply(global.mess.verifikasi);
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);
 
 if (!text) {
 return Reply(example("preset"))
 }
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);
 
 const isPTVMode = command === 'ptv';
 const tmpDir = './tmp';
 if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
 
 try {
 const query = encodeURIComponent(text.trim());
 const apiUrl = `${global.apialip}/search/tiktok?apikey=${global.alipkey}&q=${query}`;
 
 const response = await axios.get(apiUrl, { timeout: 30000 });
 const data = response.data;
 
 if (!data.status || !data.result || data.result.length === 0) {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(mess.error)
 }
 
 const firstVideo = data.result[0];
 let rawUrl = firstVideo.link || firstVideo.wmplay || firstVideo.play;
 
 if (!rawUrl) {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return Reply(mess.error)
 }
 
 const cleanUrl = rawUrl.replace(/^https:\/\/tikwm\.comhttps:\/\//, 'https://');
 const videoUrl = cleanUrl;
 const duration = firstVideo.duration || 0;
 const title = firstVideo.title || 'TikTok Video';
 const author = firstVideo.author?.nickname || 'Unknown';
 const playCount = firstVideo.stats?.plays?.toLocaleString() || '0';
 const diggCount = firstVideo.stats?.likes?.toLocaleString() || '0';
 
 if (isPTVMode && duration > 120) {
 await yonz.sendMessage(m.chat, { react: { text: "⚠️", key: m.key } });
 return Reply(mess.error)
 }
 
 const tempFile = path.join(tmpDir, `tiktok_${Date.now()}.mp4`);
 
 const videoResponse = await axios({
 method: 'GET',
 url: videoUrl,
 responseType: 'stream',
 timeout: 60000
 });
 
 const writer = fs.createWriteStream(tempFile);
 videoResponse.data.pipe(writer);
 
 await new Promise((resolve, reject) => {
 writer.on('finish', resolve);
 writer.on('error', reject);
 });
 
 const videoBuffer = fs.readFileSync(tempFile);
 
 if (isPTVMode && videoBuffer.length > 16 * 1024 * 1024) {
 fs.unlinkSync(tempFile);
 await yonz.sendMessage(m.chat, { react: { text: "⚠️", key: m.key } });
 return Reply(mess.error)
 }
 
 if (isPTVMode) {
 await yonz.sendMessage(m.chat, {
 video: videoBuffer,
 ptv: true,
 mimetype: 'video/mp4'
 }, { quoted: global.qtoko });
 } else {
 const caption = `╭➤-----「 TIKTOK 」
┆𖢷 ׁ 𖹭₊ 🎬 *${title.substring(0, 40)}${title.length > 40 ? '...' : ''}*
┆𖢷 ׁ 𖹭₊ 👤 ${author}
┆𖢷 ׁ 𖹭₊ ❤️ ${diggCount} likes
┆𖢷 ׁ 𖹭₊ 👀 ${playCount} views
╰➤-------------------------------`;
 
 await yonz.sendMessage(m.chat, {
 video: videoBuffer,
 mimetype: 'video/mp4',
 caption: caption
 }, { quoted: global.qtoko });
 }
 
 fs.unlinkSync(tempFile);
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error(error)
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error)
 }
}
break;

case "ping":
case "uptime2": {
 const timestamp = speed();
 const latensi = speed() - timestamp;
 const disk = await nou.drive.info();
 const cpu = os.cpus();
 const cpuModel = cpu[0].model;
 const cpuCount = cpu.length;
 const cpuSpeed = (cpu[0].speed / 1000).toFixed(2);
 const platform = nou.os.type();
 const ramTotal = formatp(os.totalmem());
 const ramUsed = formatp(os.totalmem() - os.freemem());
 const ramUsage = ((1 - os.freemem() / os.totalmem()) * 100).toFixed(1);
 const diskUsage = ((disk.usedGb / disk.totalGb) * 100).toFixed(1);
 const pollVotes = [
 { 
 optionName: `Speed: ${Math.round(latensi)} ms`, 
 optionVoteCount: 100 
 },
 { 
 optionName: `Memory: ${ramUsed} / ${ramTotal} (${ramUsage}%)`, 
 optionVoteCount: Math.min(Math.max(Math.round(parseFloat(ramUsage)), 1), 100) 
 },
 { 
 optionName: `Storage: ${disk.usedGb} / ${disk.totalGb} GB (${diskUsage}%)`, 
 optionVoteCount: Math.min(Math.max(Math.round(parseFloat(diskUsage)), 1), 100) 
 }
 ];
 const title = `*${global.botname.toUpperCase()} SERVER STATUS*\n\n` +
 `🖥️ Platform: ${platform}\n` +
 `💾 Processor: ${cpuCount} Core @ ${cpuSpeed}GHz\n` +
 `⚙️ CPU Model: ${cpuModel}\n` +
 `🕒 Server Uptime: ${runtime(os.uptime())}\n` +
 `🤖 Bot Uptime: ${runtime(process.uptime())}`;
 try {
 await yonz.relayMessage(m.chat, {
 pollResultSnapshotMessage: {
 name: title,
 pollVotes
 }
 }, { quoted: m });
 } catch (e) {
 console.error("Error Poll Ping:", e);
 const teks = `
🚀*${global.botname.toUpperCase()} STATUS*🚀
🖥️ *Platform:* ${platform}
⚙️ *CPU:* ${cpuModel} (${cpuCount} Cores)
🕒 *Server Up:* ${runtime(os.uptime())}
🤖 *Bot Up:* ${runtime(process.uptime())}
📊 *Stats:*
- Speed: ${latensi.toFixed(2)} ms
- RAM: ${ramUsed} / ${ramTotal} (${ramUsage}%)
- Disk: ${disk.usedGb} / ${disk.totalGb} GB (${diskUsage}%)`.trim();
 m.reply(teks);
 }
}
break;

case 'addpremgc':
case 'premgc': {
 if (!isCreator) return Reply(mess.owner)

 let targetGc = m.chat
 let hari = null

 if (args[0]) {
 if (/^\d{10,}(@g\.us)?$/.test(args[0])) {
 targetGc = args[0].includes('@g.us') ? args[0] : args[0] + '@g.us'
 if (args[1] && !isNaN(args[1])) hari = parseInt(args[1])
 } else if (!isNaN(args[0])) {
 hari = parseInt(args[0])
 }
 }

 if (!targetGc || !targetGc.endsWith('@g.us')) {
 return Reply(example(
 `\n` +
 `• .addpremgc → jadikan grup ini premium (permanent)\n` +
 `• .addpremgc 30 → jadikan grup ini premium 30 hari\n` +
 `• .addpremgc 120363xxxxx@g.us → jadikan grup lain premium\n` +
 `• .addpremgc 120363xxxxx@g.us 30 → jadikan grup lain premium 30 hari`
 ))
 }

 let groupName = targetGc
 try {
 const meta = await yonz.groupMetadata(targetGc)
 groupName = meta.subject
 } catch (e) {}

 // Ambil semua member grup
 let members = []
 try {
 const meta = await yonz.groupMetadata(targetGc)
 members = meta.participants.map(p => p.id)
 } catch (e) {
 return Reply('❌ Gagal mengambil daftar member grup.')
 }

 if (members.length === 0) {
 return Reply('❌ Tidak ada member di grup ini.')
 }

 // Auto create folder database jika belum ada
 const dbDir = './library/database'
 if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true })

 // Load atau buat file premium.json
 const premPath = './library/database/premium.json'
 let premDb = {}
 try {
 if (fs.existsSync(premPath)) {
 premDb = JSON.parse(fs.readFileSync(premPath))
 }
 } catch (e) {
 premDb = {}
 }

 const expiredTime = hari ? Date.now() + hari * 24 * 60 * 60 * 1000 : null

 // Tambahkan semua member ke premium
 let addedCount = 0
 for (const member of members) {
 // Cek apakah member sudah premium
 if (!premDb[member]) {
 premDb[member] = {
 premium: true,
 expired: expiredTime,
 addedBy: m.sender,
 addedFrom: targetGc, // PASTIKAN INI TERSIMPAN
 addedAt: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
 }
 addedCount++
 } else {
 // Update existing premium dengan addedFrom jika kosong
 if (!premDb[member].addedFrom) {
 premDb[member].addedFrom = targetGc
 }
 }
 }

 fs.writeFileSync(premPath, JSON.stringify(premDb, null, 2))

 return Reply(
 `✅ *Berhasil menjadikan grup premium!*\n\n` +
 `➜ Nama: ${groupName}\n` +
 `➜ ID: ${targetGc}\n` +
 `➜ Total Member: ${members.length}\n` +
 `➜ Berhasil ditambahkan: ${addedCount} member\n` +
 `➜ Masa aktif: ${hari ? hari + ' hari' : 'Permanent'}\n` +
 `➜ Ditambahkan oleh: ${m.sender}`
 )
}
break;





case 'cekpremgc': {
 if (!isCreator) return Reply(mess.owner)

 const premPath = './library/database/premium.json'
 if (!fs.existsSync(premPath)) {
 return Reply('❌ Belum ada data premium.')
 }

 try {
 let premDb = JSON.parse(fs.readFileSync(premPath))

 if (!Array.isArray(premDb)) {
 return Reply('❌ Format data premium tidak valid (bukan array).')
 }

 // Hapus yang expired
 const before = premDb.length
 premDb = premDb.filter(data => {
 if (data.expired && Date.now() > data.expired) return false
 return true
 })
 const expiredCount = before - premDb.length

 if (expiredCount > 0) {
 fs.writeFileSync(premPath, JSON.stringify(premDb, null, 2))
 }

 if (premDb.length === 0) {
 return Reply('❌ Tidak ada member premium.')
 }

 let list = `✅ *Daftar Member Premium*\n\n`
 list += `📌 Total: ${premDb.length} member\n`
 list += `⚠️ Data premium tidak menyimpan info grup asal, jadi list ini bukan per-grup.\n\n`

 let no = 1
 for (const data of premDb) {
 const userId = data.jid || 'Unknown'
 const expiredDate = data.expired ? new Date(data.expired).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Permanent'
 const sisaHari = data.expired ? Math.ceil((data.expired - Date.now()) / (24 * 60 * 60 * 1000)) : '∞'
 const addedBy = data.addedBy ? `\n ├ Ditambah oleh: ${data.addedBy}` : ''

 list += `${no}. ${userId}${addedBy}\n` +
 ` ├ Expired: ${expiredDate}\n` +
 ` └ Sisa: ${sisaHari === '∞' ? 'Permanent' : sisaHari + ' hari'}\n\n`
 no++
 }

 return Reply(list)

 } catch (e) {
 console.error('Error detail:', e)
 return Reply('❌ Terjadi kesalahan saat membaca data.')
 }
}
break;

case 'fotolive':
case 'livephoto': {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 const isQuotedVideo = mime.startsWith('video/');
 const isQuotedImage = mime.startsWith('image/');
 const args = text ? text.trim().split(/\s+/) : [];

 let videoBuffer, thumbBuffer;

 if (isQuotedVideo && args.length === 0) {
 const stream = await downloadContentFromMessage(q.msg || q, 'video');
 videoBuffer = Buffer.from([]);
 for await (const chunk of stream) videoBuffer = Buffer.concat([videoBuffer, chunk]);

 const tmpVideo = `/tmp/lv2_${Date.now()}.mp4`;
 const tmpThumb = `/tmp/lv2_${Date.now()}.jpg`;
 fs.writeFileSync(tmpVideo, videoBuffer);
 await new Promise((resolve, reject) => {
 ffmpeg(tmpVideo).outputOptions(['-vframes 1', '-q:v 2']).output(tmpThumb)
 .on('end', resolve).on('error', reject).run();
 });
 thumbBuffer = fs.readFileSync(tmpThumb);
 fs.unlinkSync(tmpVideo);
 fs.unlinkSync(tmpThumb);

 } else if (!isQuotedVideo && !isQuotedImage && args.length === 1) {
 const videoRes = await axios.get(args[0], { responseType: 'arraybuffer' });
 videoBuffer = Buffer.from(videoRes.data);

 const tmpVideo = `/tmp/lv2_${Date.now()}.mp4`;
 const tmpThumb = `/tmp/lv2_${Date.now()}.jpg`;
 fs.writeFileSync(tmpVideo, videoBuffer);
 await new Promise((resolve, reject) => {
 ffmpeg(tmpVideo).outputOptions(['-vframes 1', '-q:v 2']).output(tmpThumb)
 .on('end', resolve).on('error', reject).run();
 });
 thumbBuffer = fs.readFileSync(tmpThumb);
 fs.unlinkSync(tmpVideo);
 fs.unlinkSync(tmpThumb);

 } else if (!isQuotedVideo && !isQuotedImage && args.length === 2) {
 const [fotoRes, videoRes] = await Promise.all([
 axios.get(args[0], { responseType: 'arraybuffer' }),
 axios.get(args[1], { responseType: 'arraybuffer' })
 ]);
 thumbBuffer = Buffer.from(fotoRes.data);
 videoBuffer = Buffer.from(videoRes.data);

 } else if (isQuotedVideo && args.length === 1) {
 const fotoRes = await axios.get(args[0], { responseType: 'arraybuffer' });
 thumbBuffer = Buffer.from(fotoRes.data);

 const stream = await downloadContentFromMessage(q.msg || q, 'video');
 videoBuffer = Buffer.from([]);
 for await (const chunk of stream) videoBuffer = Buffer.concat([videoBuffer, chunk]);

 } else if (isQuotedImage && args.length === 1) {
 const videoRes = await axios.get(args[0], { responseType: 'arraybuffer' });
 videoBuffer = Buffer.from(videoRes.data);

 const stream = await downloadContentFromMessage(q.msg || q, 'image');
 thumbBuffer = Buffer.from([]);
 for await (const chunk of stream) thumbBuffer = Buffer.concat([thumbBuffer, chunk]);

 } else {
 return Reply(
 `❌ Format salah!\n\n` +
 `*Mode 1:* Reply video → .${command}\n` +
 `*Mode 2:* .${command} https://url-video.mp4\n` +
 `*Mode 3:* .${command} https://url-foto.jpg https://url-video.mp4\n` +
 `*Mode 4:* Reply video + .${command} https://url-foto.jpg\n` +
 `*Mode 5:* Reply foto + .${command} https://url-video.mp4`
 );
 }

 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 try {
 const imageMedia = await prepareWAMessageMedia(
 { image: thumbBuffer },
 { upload: yonz.waUploadToServer }
 );

 const videoMedia = await prepareWAMessageMedia(
 { video: videoBuffer },
 { upload: yonz.waUploadToServer }
 );

 const photoMsg = generateWAMessageFromContent(
 m.chat,
 {
 imageMessage: {
 ...imageMedia.imageMessage,
 contextInfo: {
 pairedMediaType: 5,
 statusSourceType: 0
 }
 }
 },
 {}
 );

 await yonz.relayMessage(m.chat, photoMsg.message, {
 messageId: photoMsg.key.id
 });

 await yonz.relayMessage(
 m.chat,
 {
 videoMessage: {
 ...videoMedia.videoMessage,
 contextInfo: {
 pairedMediaType: 6,
 statusSourceType: 0
 }
 },
 messageContextInfo: {
 messageAssociation: {
 associationType: 12,
 parentMessageKey: photoMsg.key
 }
 }
 },
 {}
 );

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 } catch (e) {
 console.log(e);
 Reply('❌ Gagal membuat foto live. Coba lagi nanti.');
 }
}
break;



case "tourl": {
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!mime) return m.reply("❌ Kirim/reply media gambar, video, atau audio!");
 
 const isImage = mime.startsWith('image/');
 const isVideo = mime.startsWith('video/');
 const isAudio = mime.startsWith('audio/');
 
 if (!isImage && !isVideo && !isAudio) {
 return m.reply("❌ Hanya support gambar, video, atau audio!");
 }

 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) {
 fs.mkdirSync(dir, { recursive: true });
 }

 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 let media = null;
 try {
 media = await yonz.downloadAndSaveMediaMessage(q);

 const form = new FormData();
 form.append('file', fs.createReadStream(media));

 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });

 console.log('[TOURL RESPONSE]', upload.data);

 const directLink = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;

 if (!directLink || typeof directLink !== 'string') {
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return m.reply(`❌ Gagal upload ke server.\nRespon: ${JSON.stringify(upload.data)}`);
 }

 const type = isImage ? 'Gambar' : isVideo ? 'Video' : 'Audio';
 const teks = `✅ *Berhasil Upload ${type}*\n\n🔗 Link: ${directLink}`;
 await yonz.sendMessage(m.chat, { text: teks }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error(e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 m.reply(`❌ *Terjadi kesalahan!*\n${e.message}`);
 } finally {
 if (media) {
 try {
 fs.unlinkSync(media);
 } catch (_) { }
 }
 }
}
break;

case "swgc_allprocess": {
 if (!isCreator2) return Reply(mess.creator)
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 if (!data) return Reply('❌ Tidak ada media tersimpan. Gunakan .swgcall dulu!');
 
 try {
 Reply(mess.wait);
 
 const allGroups = await yonz.groupFetchAllParticipating();
 const groupList = Object.values(allGroups);
 
 if (groupList.length === 0) return Reply('❌ Bot tidak ada di grup manapun');
 
 let success = 0;
 
 for (const group of groupList) {
 const jid = group.id;
 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(jid, { groupStatusMessage: { image: data.buffer, caption: data.caption } });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(jid, { groupStatusMessage: { video: data.buffer, caption: data.caption } });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(jid, { groupStatusMessage: { audio: data.buffer } });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(jid, { groupStatusMessage: { text: data.caption } });
 }
 success++;
 await sleep(800);
 } catch (e) {}
 }
 
 delete global.swgcBuffer[m.sender];
 Reply(`✅ Berhasil mengirim ke ${success} grup`);
 
 } catch (e) {
 console.error('[SWGC ALLPROCESS ERROR]', e);
 Reply(mess.error);
 }
}
break;



case "copilotvoice": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);
 if (!text) return Reply(example("halo apa kabar"));
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "🎤", key: m.key } });
 Reply(mess.wait);
 
 try {
 const apiUrl = `https://api.xte.web.id/ai/copilot-voice?text=${encodeURIComponent(text)}`;
 const response = await axios.get(apiUrl);
 const data = response.data;
 
 if (!data.status || !data.result) throw new Error('Gagal mendapatkan respon dari AI');
 
 const result = data.result;
 const audioBase64 = result.audio_base64.split(';base64,')[1];
 const audioBuffer = Buffer.from(audioBase64, 'base64');
 
 await yonz.sendMessage(m.chat, {
 audio: audioBuffer,
 mimetype: 'audio/mp4',
 ptt: false
 }, { quoted: m });
 
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[COPILOT-VOICE ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case 'fakecall': {
 if (!isRegistered(m.sender)) return daftar(global.mess.verifikasi)
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit)
 
 let q = m.quoted ? m.quoted : m
 let mime = (q.msg || q).mimetype || ''
 
 if (!/image/.test(mime)) return Reply(example("dengan reply gambar"))
 if (!text) return Reply(example("nama|12.00"))
 
 let [name, time] = text.split('|')
 if (!name || !time) return Reply(example("nama|12.00"))
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator)
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })
 Reply(mess.wait)
 
 try {
 const { createCanvas, loadImage } = require('canvas')
 let gambarNya = await q.download()
 let ppNya = await loadImage(gambarNya)
 let bgNya = await (await axios.get("http://elainaacdn.vercel.app/file/8799ce569e.jpg", { responseType: 'arraybuffer' })).data
 let bg2Nya = await loadImage(bgNya)
 const canvas = createCanvas(bg2Nya.width, bg2Nya.height)
 const ctx = canvas.getContext('2d')
 ctx.drawImage(bg2Nya, 0, 0, canvas.width, canvas.height)
 const centerX = canvas.width / 2
 const centerY = canvas.height / 2
 const radius = 500
 const imageY = centerY - 150
 ctx.save()
 ctx.beginPath()
 ctx.arc(centerX, imageY, radius, 0, Math.PI * 2, true)
 ctx.closePath()
 ctx.clip()
 ctx.drawImage(ppNya, centerX - radius, imageY - radius, radius * 2, radius * 2)
 ctx.restore()
 ctx.font = 'bold 90px "Sans-serif"'
 ctx.fillStyle = '#ffffff'
 ctx.textAlign = 'center'
 ctx.shadowColor = "rgba(0, 0, 0, 0.5)"
 ctx.shadowBlur = 5
 ctx.fillText(name, centerX, 250)
 ctx.font = '55px "Sans-serif"'
 ctx.fillStyle = 'rgba(255, 255, 255, 0.8)'
 ctx.shadowColor = "rgba(0, 0, 0, 0.5)"
 ctx.shadowBlur = 8
 ctx.fillText(time, centerX, 360)
 let buffer = canvas.toBuffer('image/jpeg')
 
 await yonz.sendMessage(m.chat, { image: buffer, caption: mess.done }, { quoted: m })
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } })

 } catch (e) {
 console.error(e)
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
 Reply(mess.error)
 }
}
break








case "swgc_process": {
 if (!isCreator2) return Reply(mess.creator)
 if (!text) return Reply(mess.error);
 
 const groupId = text.split(" ")[0];
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 
 if (!data) return Reply('❌ Media tidak tersedia, reply dulu media yang mau dikirim');

 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(groupId, { image: data.buffer, caption: data.caption });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(groupId, { video: data.buffer, caption: data.caption });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(groupId, { audio: data.buffer });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(groupId, { text: data.caption });
 }

 delete global.swgcBuffer[m.sender];
 Reply(mess.done);
 
 } catch (error) {
 console.error('[SWGC PROCESS ERROR]', error);
 Reply(mess.error);
 }
}
break;

case "swgc_allprocess": {
 if (!isCreator2) return Reply(mess.creator)
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 if (!data) return Reply('❌ Tidak ada media tersimpan. Gunakan .swgcall dulu!');
 
 try {
 Reply(mess.wait);
 
 const allGroups = await yonz.groupFetchAllParticipating();
 const groupList = Object.values(allGroups);
 
 if (groupList.length === 0) return Reply('❌ Bot tidak ada di grup manapun');
 
 let success = 0;
 
 for (const group of groupList) {
 const jid = group.id;
 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(jid, { image: data.buffer, caption: data.caption });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(jid, { video: data.buffer, caption: data.caption });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(jid, { audio: data.buffer });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(jid, { text: data.caption });
 }
 success++;
 await sleep(800);
 } catch (e) {}
 }
 
 delete global.swgcBuffer[m.sender];
 Reply(`✅ Berhasil mengirim ke ${success} grup`);
 
 } catch (e) {
 console.error('[SWGC ALLPROCESS ERROR]', e);
 Reply(mess.error);
 }
}
break;





case "swgc_process": {
 if (!isCreator2) return Reply(mess.creator)
 if (!text) return Reply(mess.error);
 
 const groupId = text.split(" ")[0];
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 
 if (!data) return Reply('❌ Media tidak tersedia, reply dulu media yang mau dikirim');

 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(groupId, { image: data.buffer, caption: data.caption });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(groupId, { video: data.buffer, caption: data.caption });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(groupId, { audio: data.buffer });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(groupId, { text: data.caption });
 }

 delete global.swgcBuffer[m.sender];
 Reply(mess.done);
 
 } catch (error) {
 console.error('[SWGC PROCESS ERROR]', error);
 Reply(mess.error);
 }
}
break;

case "swgc_allprocess": {
 if (!isCreator2) return Reply(mess.creator)
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 if (!data) return Reply('❌ Tidak ada media tersimpan. Gunakan .swgcall dulu!');
 
 try {
 Reply(mess.wait);
 
 const allGroups = await yonz.groupFetchAllParticipating();
 const groupList = Object.values(allGroups);
 
 if (groupList.length === 0) return Reply('❌ Bot tidak ada di grup manapun');
 
 let success = 0;
 
 for (const group of groupList) {
 const jid = group.id;
 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(jid, { image: data.buffer, caption: data.caption });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(jid, { video: data.buffer, caption: data.caption });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(jid, { audio: data.buffer });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(jid, { text: data.caption });
 }
 success++;
 await sleep(800);
 } catch (e) {}
 }
 
 delete global.swgcBuffer[m.sender];
 Reply(`✅ Berhasil mengirim ke ${success} grup`);
 
 } catch (e) {
 console.error('[SWGC ALLPROCESS ERROR]', e);
 Reply(mess.error);
 }
}
break;





case "swgc_process": {
 if (!isCreator2) return Reply(mess.creator)
 if (!text) return Reply(mess.error);
 
 const groupId = text.split(" ")[0];
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 
 if (!data) return Reply('❌ Media tidak tersedia, reply dulu media yang mau dikirim');

 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(groupId, { groupStatusMessage: { image: data.buffer, caption: data.caption } });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(groupId, { groupStatusMessage: { video: data.buffer, caption: data.caption } });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(groupId, { groupStatusMessage: { audio: data.buffer } });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(groupId, { groupStatusMessage: { text: data.caption } });
 }

 delete global.swgcBuffer[m.sender];
 Reply(mess.done);
 
 } catch (error) {
 console.error('[SWGC PROCESS ERROR]', error);
 Reply(mess.error);
 }
}
break;

case "swgc_allprocess": {
 if (!isCreator2) return Reply(mess.creator)
 const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
 if (!data) return Reply('❌ Tidak ada media tersimpan. Gunakan .swgcall dulu!');
 
 try {
 Reply(mess.wait);
 
 const allGroups = await yonz.groupFetchAllParticipating();
 const groupList = Object.values(allGroups);
 
 if (groupList.length === 0) return Reply('❌ Bot tidak ada di grup manapun');
 
 let success = 0;
 
 for (const group of groupList) {
 const jid = group.id;
 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(jid, { groupStatusMessage: { image: data.buffer, caption: data.caption } });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(jid, { groupStatusMessage: { video: data.buffer, caption: data.caption } });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(jid, { groupStatusMessage: { audio: data.buffer } });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(jid, { groupStatusMessage: { text: data.caption } });
 }
 success++;
 await sleep(800);
 } catch (e) {}
 }
 
 delete global.swgcBuffer[m.sender];
 Reply(`✅ Berhasil mengirim ke ${success} grup`);
 
 } catch (e) {
 console.error('[SWGC ALLPROCESS ERROR]', e);
 Reply(mess.error);
 }
}
break;

case "swgc": {
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 
 const quoted = m.quoted ? m.quoted : m;
 const mime = (quoted.msg || quoted).mimetype || "";
 const caption = m.body.replace(/^\.swgc\s*/i, "").trim();
 const jid = m.chat;

 if (!mime && !caption) return Reply(example("dengan reply media"));

 try {
 Reply(mess.wait);
 
 if (/image/.test(mime)) {
 const buffer = await quoted.download();
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 image: buffer, 
 caption,
 audience: 'close_friends'
 } 
 });
 Reply(mess.done);
 } else if (/video/.test(mime)) {
 const buffer = await quoted.download();
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 video: buffer, 
 caption,
 audience: 'close_friends'
 } 
 });
 Reply(mess.done);
 } else if (/audio/.test(mime)) {
 const buffer = await quoted.download();
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 audio: buffer,
 audience: 'close_friends'
 } 
 });
 Reply(mess.done);
 } else if (caption) {
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 text: caption,
 audience: 'close_friends'
 } 
 });
 Reply(mess.done);
 }
 } catch (e) {
 console.error("swgc", e);
 Reply(mess.error);
 }
}
break;

case "swgcall": {
 if (!isCreator2) return Reply(mess.creator)
 const quoted = m.quoted ? m.quoted : m;
 const mime = (quoted.msg || quoted).mimetype || "";
 const caption = m.body.replace(/^\.swgcall\s*/i, "").trim();

 try {
 if (/image|video|audio/.test(mime)) {
 const buffer = await quoted.download();
 global.swgcBuffer = global.swgcBuffer || {};
 global.swgcBuffer[m.sender] = { buffer, mime, caption };
 } else if (caption) {
 global.swgcBuffer = global.swgcBuffer || {};
 global.swgcBuffer[m.sender] = { buffer: null, mime: "text", caption };
 } else {
 return Reply(example("dengan reply media"));
 }

 Reply(mess.wait);

 const allGroups = await yonz.groupFetchAllParticipating();
 const groupList = Object.values(allGroups);

 if (groupList.length === 0) return Reply("❌ Bot tidak berada di grup manapun");

 // Kirim ke semua grup
 let success = 0;
 const data = global.swgcBuffer[m.sender];
 
 for (const group of groupList) {
 const jid = group.id;
 try {
 if (/image/.test(data.mime)) {
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 image: data.buffer, 
 caption: data.caption,
 audience: 'close_friends'
 } 
 });
 } else if (/video/.test(data.mime)) {
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 video: data.buffer, 
 caption: data.caption,
 audience: 'close_friends'
 } 
 });
 } else if (/audio/.test(data.mime)) {
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 audio: data.buffer,
 audience: 'close_friends'
 } 
 });
 } else if (data.mime === "text" && data.caption) {
 await yonz.sendMessage(jid, { 
 groupStatusMessage: { 
 text: data.caption,
 audience: 'close_friends'
 } 
 });
 }
 success++;
 await sleep(800);
 } catch (e) {}
 }
 
 delete global.swgcBuffer[m.sender];
 Reply(`💌 ✅ Berhasil mengirim ke ${success} grup dari ${groupList.length} grup`);
 
 } catch (error) {
 console.error('[SWGCALL ERROR]', error);
 Reply(mess.error);
 }
}
break;























case "on": {
 if (!isCreator && !m.isAdmin) return Reply(mess.admin)
 if (!m.isGroup) return Reply(mess.group)

 const gStat = db.groups[m.chat] || {}
 const st = (v, modeLabel) => {
 if (typeof v === 'string') return `✅ ${modeLabel ? modeLabel[v] || v : v}`
 return v ? '✅ Aktif' : '❌ Mati'
 }
 const muteDbHub = loadMuteGc()
 const muteStat = (muteDbHub[m.chat] && muteDbHub[m.chat].mute === true) ? '✅ Aktif' : '❌ Mati'

 const antiLinkSetting = global.antilinkgrup?.[m.chat] || { status: false, delete: false, kick: false }
 const antiLinkStatus = antiLinkSetting.status ? '✅ Aktif' : '❌ Mati'
 const antiLinkDelete = antiLinkSetting.delete ? '✅ Aktif' : '❌ Mati'
 const antiLinkKick = antiLinkSetting.kick ? '✅ Aktif' : '❌ Mati'

 const statusText = `*⚙️ ATUR GRUP*\n\n` +
 `• Anti Link : ${st(gStat.antilink)}\n` +
 `• Anti Link 2 : ${st(gStat.antilink2)}\n` +
 `• Anti Link Grup : ${antiLinkStatus}\n` +
 `• Anti Link Delete : ${antiLinkDelete}\n` +
 `• Anti Link Kick : ${antiLinkKick}\n` +
 `• Anti Hidetag : ${st(gStat.antihidetag, { delete: 'Delete', kick: 'Kick' })}\n` +
 `• Anti Foto : ${st(gStat.antifoto)}\n` +
 `• Anti Promosi : ${st(gStat.antipromosi)}\n` +
 `• Mute Grup : ${muteStat}\n` +
 `• Welcome : ${st(gStat.welcome)}\n` +
 `• Left : ${st(gStat.left)}`

 const rowsAturGrup = [
 { title: '🔗 Anti Link', description: 'Atur anti link', id: `${prefix}antilink` },
 { title: '🔗 Anti Link 2', description: 'Atur anti link 2', id: `${prefix}antilink2` },
 { title: '🔗 Anti Link Grup', description: 'Atur anti link grup', id: `${prefix}antilinkgrup` },
 { title: '🚫 Anti Hidetag', description: 'Atur anti hidetag', id: `${prefix}antihidetag` },
 { title: '🖼️ Anti Foto', description: 'Atur anti foto', id: `${prefix}antifoto` },
 { title: '📢 Anti Promosi', description: 'Atur anti promosi', id: `${prefix}antipromosi` },
 { title: '🔇 Mute Grup', description: 'Atur mute grup', id: `${prefix}mute` },
 { title: '👋 Welcome', description: 'Atur welcome', id: `${prefix}welcome` },
 { title: '🚪 Left', description: 'Atur left', id: `${prefix}left` }
 ]

 const sectionsAturGrup = [
 {
 title: '📋 Atur Grup',
 rows: rowsAturGrup
 }
 ]

 const rowsMenu = [
 { title: '📋 Menu', description: 'Kembali ke menu utama', id: `${prefix}menu` },
 { title: '🏓 Ping', description: 'Cek kecepatan bot', id: `${prefix}ping` }
 ]

 const sectionsMenu = [
 {
 title: '📋 Menu',
 rows: rowsMenu
 }
 ]

 const btnHub = new yonz.ButtonV2(yonz)
 btnHub.setThumbnail(global.image.menu)
 .setBody(statusText)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '📋 List Menu' },
 buttonId: 'menu_list',
 type: 1,
 nativeFlowInfo: { 
 name: 'single_select', 
 paramsJson: JSON.stringify({ 
 title: '🍀 List Menu', 
 sections: sectionsMenu 
 }) 
 }
 })
 .addRawButton({
 buttonText: { displayText: '⚙️ Atur Grup' },
 buttonId: 'atur_grup',
 type: 1,
 nativeFlowInfo: { 
 name: 'single_select', 
 paramsJson: JSON.stringify({ 
 title: '⚙️ Atur Grup', 
 sections: sectionsAturGrup 
 }) 
 }
 })

 await btnHub.send(m.chat)

 // Kirim audio setelah pesan
 try {
 const audioPath = './media/yonz.mp3';
 if (fs.existsSync(audioPath)) {
 const audioBuffer = fs.readFileSync(audioPath);
 await yonz.sendMessage(m.chat, {
 audio: audioBuffer,
 mimetype: 'audio/mp4',
 ptt: false
 });
 }
 } catch (e) {
 console.log('Audio not found');
 }
}
break;



case "antilinkgrup": {
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 
 const args = text ? text.trim().split(/\s+/) : [];
 
 if (args.length === 0) {
 const setting = global.antilinkgrup?.[m.chat] || { status: false, delete: false, kick: false };
 
 const statusText = `📌 *Anti Link Grup*\n\n` +
 `• Status : ${setting.status ? '✅ Aktif' : '❌ Nonaktif'}\n` +
 `• Delete : ${setting.delete ? '✅ Aktif' : '❌ Nonaktif'}\n` +
 `• Kick : ${setting.kick ? '✅ Aktif' : '❌ Nonaktif'}\n\n` +
 `Klik tombol di bawah untuk mengatur`;

 const rows = [
 { title: '🔗 Status', description: `Status: ${setting.status ? 'Aktif' : 'Nonaktif'}`, id: `${prefix}antilinkgrup on` },
 { title: '🗑️ Delete', description: `Delete: ${setting.delete ? 'Aktif' : 'Nonaktif'}`, id: `${prefix}antilinkgrup delete` },
 { title: '👢 Kick', description: `Kick: ${setting.kick ? 'Aktif' : 'Nonaktif'}`, id: `${prefix}antilinkgrup kick` }
 ]

 const sections = [
 {
 title: '⚙️ Pengaturan Anti Link Grup',
 rows: rows
 }
 ]

 const btnHub = new yonz.ButtonV2(yonz)
 btnHub.setThumbnail(global.image.menu)
 .setBody(statusText)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🗑️ Delete' },
 buttonId: `${prefix}antilinkgrup delete`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '👢 Kick' },
 buttonId: `${prefix}antilinkgrup kick`,
 type: 1
 })

 await btnHub.send(m.chat)
 return;
 }

 const action = args[0].toLowerCase();
 
 if (action === 'on' || action === 'off') {
 global.antilinkgrup = global.antilinkgrup || {};
 global.antilinkgrup[m.chat] = global.antilinkgrup[m.chat] || { status: false, delete: false, kick: false };
 global.antilinkgrup[m.chat].status = action === 'on';
 Reply(`✅ Anti Link Grup *${action === 'on' ? 'Diaktifkan' : 'Dinonaktifkan'}*`);
 return;
 }
 
 if (action === 'delete') {
 const subAction = args[1]?.toLowerCase();
 if (!subAction || (subAction !== 'on' && subAction !== 'off')) {
 const statusText = `🗑️ *Atur Delete Pesan Link*\n\nKlik tombol di bawah untuk mengatur`;
 const btnHub = new yonz.ButtonV2(yonz)
 btnHub.setThumbnail(global.image.menu)
 .setBody(statusText)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '✅ Aktifkan' },
 buttonId: `${prefix}antilinkgrup delete on`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '❌ Nonaktifkan' },
 buttonId: `${prefix}antilinkgrup delete off`,
 type: 1
 })
 await btnHub.send(m.chat)
 return;
 }
 
 global.antilinkgrup = global.antilinkgrup || {};
 global.antilinkgrup[m.chat] = global.antilinkgrup[m.chat] || { status: false, delete: false, kick: false };
 global.antilinkgrup[m.chat].delete = subAction === 'on';
 Reply(`✅ Auto Hapus Pesan Link *${subAction === 'on' ? 'Diaktifkan' : 'Dinonaktifkan'}*`);
 return;
 }
 
 if (action === 'kick') {
 const subAction = args[1]?.toLowerCase();
 if (!subAction || (subAction !== 'on' && subAction !== 'off')) {
 const statusText = `👢 *Atur Kick Pengirim Link*\n\nKlik tombol di bawah untuk mengatur`;
 const btnHub = new yonz.ButtonV2(yonz)
 btnHub.setThumbnail(global.image.menu)
 .setBody(statusText)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '✅ Aktifkan' },
 buttonId: `${prefix}antilinkgrup kick on`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '❌ Nonaktifkan' },
 buttonId: `${prefix}antilinkgrup kick off`,
 type: 1
 })
 await btnHub.send(m.chat)
 return;
 }
 
 global.antilinkgrup = global.antilinkgrup || {};
 global.antilinkgrup[m.chat] = global.antilinkgrup[m.chat] || { status: false, delete: false, kick: false };
 global.antilinkgrup[m.chat].kick = subAction === 'on';
 Reply(`✅ Auto Kick Pengirim Link *${subAction === 'on' ? 'Diaktifkan' : 'Dinonaktifkan'}*`);
 return;
 }
 
 Reply(`📌 *Cara penggunaan:*\n.antilinkgrup on/off\n.antilinkgrup delete on/off\n.antilinkgrup kick on/off`);
}
break;

case 'delweb': {
 if (!isCreator) return m.reply(global.mess.owner)

 const fetch = require('node-fetch')
 const vercelToken = "vcp_2USROGt1Ei7Ek7jZfGsNRxiTng3ZCxV8y7UcgadgKCcqfyu4Kv3jL6rK"
 const teamId = ""

 const headers = {
 Authorization: `Bearer ${vercelToken}`,
 'Content-Type': 'application/json'
 }

 if (!text) return m.reply('Contoh: .delweb https://yonz-market-v6.vercel.app')

 function ambilNamaProject(input) {
 input = input.trim().toLowerCase()

 if (input.startsWith('http')) {
 try {
 const url = new URL(input)
 return url.hostname.replace('.vercel.app', '').split('.')[0]
 } catch {
 return null
 }
 }

 return input
 .replace('.vercel.app', '')
 .replace(/[^a-z0-9-_]/g, '')
 }

 const projectName = ambilNamaProject(text)

 if (!projectName) return m.reply('Nama website tidak valid')

 const url = teamId
 ? `https://api.vercel.com/v9/projects/${projectName}?teamId=${teamId}`
 : `https://api.vercel.com/v9/projects/${projectName}`

 try {
 const res = await fetch(url, {
 method: 'DELETE',
 headers
 })

 if (res.status === 200 || res.status === 204) {
 return m.reply(`Berhasil menghapus website:\nhttps://${projectName}.vercel.app`)
 }

 const err = await res.json().catch(() => null)
 return m.reply(`Gagal menghapus website:\n${err?.error?.message || 'Project tidak ditemukan'}`)
 } catch (e) {
 m.reply(`Terjadi kesalahan saat menghapus website:\n${e.message}`)
 }
}
break



case "charlink": {
 if (!text) return Reply('❌ Masukkan ID karakter');
 const charId = text.trim();
 const url = `https://www.animecharactersdatabase.com/characters.php?id=${charId}`;

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 // Scrape halaman untuk mendapatkan gambar
 const { data: html } = await axios.get(url);
 const $ = cheerio.load(html);

 // Cari URL gambar karakter
 let imgUrl = $('.main-image img').attr('src') ||
 $('.character-image img').attr('src') ||
 $('img.character-image').attr('src') ||
 $('img[alt*="character"]').attr('src') ||
 $('img[itemprop="image"]').attr('src');

 if (imgUrl) {
 if (!imgUrl.startsWith('http')) {
 imgUrl = 'https://www.animecharactersdatabase.com' + (imgUrl.startsWith('/') ? '' : '/') + imgUrl;
 }
 // Ambil nama karakter
 const name = $('h1').first().text().trim() || `Karakter ${charId}`;

 // Download gambar
 const imageBuffer = await axios.get(imgUrl, { responseType: 'arraybuffer' });

 await yonz.sendMessage(m.chat, {
 image: Buffer.from(imageBuffer.data),
 caption: `🎌 *${name}*\n🔗 ${url}`
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 } else {
 // Jika tidak ada gambar, kirim link saja
 await yonz.sendMessage(m.chat, {
 text: `❌ Tidak dapat menemukan gambar untuk karakter ini.\n🔗 ${url}`
 }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 }
 } catch (e) {
 console.error('[CHARLINK ERROR]', e);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Gagal mengambil detail karakter: ${e.message}`);
 }
}
break;

case "animechars":
case "acdb": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 if (!text) return Reply(`📌 *Cara penggunaan:*\n.${command} <id_anime>\n\nContoh: .${command} 1\n\n*Dapatkan ID anime dari menu anime*`);

 const id = text.trim();
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/acdb/anime-chars?id=${id}&apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.data?.success) {
 throw new Error('Gagal mengambil data karakter');
 }

 const chars = data.data.characters;
 if (!chars || chars.length === 0) {
 return Reply(`❌ Tidak ada karakter untuk anime ID ${id}`);
 }

 let caption = `🎌 *Anime Characters Database*\n`;
 caption += `📋 *Anime ID:* ${data.data.anime_id}\n`;
 caption += `📊 *Total Karakter:* ${data.data.total}\n\n`;
 caption += `Klik tombol di bawah untuk melihat detail karakter (foto)`;

 const rows = chars.map(char => ({
 title: char.name,
 description: `ID: ${char.id}`,
 id: `${prefix}charlink ${char.id}`
 }));

 const chunkSize = 10;
 const sections = [];
 for (let i = 0; i < rows.length; i += chunkSize) {
 sections.push({
 title: `🎌 Karakter (${i+1}-${Math.min(i+chunkSize, rows.length)})`,
 rows: rows.slice(i, i+chunkSize)
 });
 }

 const btnHub = new yonz.ButtonV2(yonz);
 btnHub.setThumbnail(global.image.menu)
 .setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '📋 Pilih Karakter' },
 buttonId: 'pilih_char',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🎌 Pilih Karakter',
 sections: sections
 })
 }
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[ANIMECHARS ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'ID anime tidak ditemukan atau API error'}`);
 }
}
break;

case "charlink": {
 if (!text) return Reply('❌ Masukkan ID karakter');
 const charId = text.trim();
 const url = `https://www.animecharactersdatabase.com/characters.php?id=${charId}`;

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const { data: html } = await axios.get(url);
 const $ = cheerio.load(html);

 let imgUrl = $('.main-image img').attr('src') ||
 $('.character-image img').attr('src') ||
 $('img.character-image').attr('src') ||
 $('img[alt*="character"]').attr('src') ||
 $('img[itemprop="image"]').attr('src');

 if (imgUrl) {
 if (!imgUrl.startsWith('http')) {
 imgUrl = 'https://www.animecharactersdatabase.com' + (imgUrl.startsWith('/') ? '' : '/') + imgUrl;
 }
 const name = $('h1').first().text().trim() || `Karakter ${charId}`;

 const imageBuffer = await axios.get(imgUrl, { responseType: 'arraybuffer' });
 await yonz.sendMessage(m.chat, {
 image: Buffer.from(imageBuffer.data),
 caption: `🎌 *${name}*\n🔗 ${url}`
 }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 } else {
 await yonz.sendMessage(m.chat, {
 text: `❌ Tidak dapat menemukan gambar untuk karakter ini.\n🔗 ${url}`
 }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 }

 } catch (e) {
 console.error('[CHARLINK ERROR]', e);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Gagal mengambil detail karakter: ${e.message}`);
 }
}
break;

case "animedetail":
case "animeinfo": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 if (!text) return Reply(`📌 *Cara penggunaan:*\n.${command} <id_anime>\n\nContoh: .${command} 1\n\n*Dapatkan ID anime dari menu anime*`);

 const id = text.trim();
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/acdb/anime?id=${id}&apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.data?.success) {
 throw new Error('Gagal mengambil data anime');
 }

 const anime = data.data.data;
 
 let caption = `🎌 *${anime.title}*\n\n`;
 caption += `📝 *Deskripsi:*\n${anime.description || 'Tidak ada deskripsi'}\n\n`;
 caption += `📋 *Detail:*\n`;
 
 if (anime.details) {
 const details = anime.details;
 caption += `• *ID:* ${details['Series ID'] || id}\n`;
 caption += `• *Tipe:* ${details['Media Type'] || 'Tidak diketahui'}\n`;
 caption += `• *Judul Inggris:* ${details['English Title'] || 'Tidak tersedia'}\n`;
 caption += `• *Judul Jepang:* ${details['Japanese Title'] || 'Tidak tersedia'}\n`;
 caption += `• *Studio:* ${details['Japanese Studio Name'] || 'Tidak diketahui'}\n`;
 caption += `• *Rating:* ${details['Content Rating'] || 'Tidak diketahui'}\n`;
 caption += `• *Rilis:* ${details['Release Date'] || 'Tidak diketahui'}\n`;
 }
 
 if (anime.genres && anime.genres.length > 0) {
 caption += `\n🎭 *Genre:* ${anime.genres.join(', ')}\n`;
 }
 
 caption += `\n👥 *Total Karakter:* ${anime.characters_count || 'Tidak diketahui'}`;
 caption += `\n🔗 *Link:* ${anime.url || 'Tidak tersedia'}`;

 // Tombol untuk lihat karakter
 const btnHub = new yonz.ButtonV2(yonz);
 
 // Set thumbnail jika ada gambar
 if (anime.image) {
 try {
 const imgBuffer = await axios.get(anime.image, { responseType: 'arraybuffer' });
 btnHub.setImage(Buffer.from(imgBuffer.data));
 } catch (e) {
 btnHub.setThumbnail(global.image.menu);
 }
 } else {
 btnHub.setThumbnail(global.image.menu);
 }
 
 btnHub.setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '👥 Lihat Karakter' },
 buttonId: `${prefix}animechars ${id}`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 // Tambahkan tombol related jika ada
 if (anime.related && anime.related.length > 0) {
 const relatedRows = anime.related.slice(0, 5).map(rel => ({
 title: rel.name,
 description: `ID: ${rel.id}`,
 id: `${prefix}animedetail ${rel.id}`
 }));
 
 const sections = [{
 title: '📚 Related Anime',
 rows: relatedRows
 }];
 
 btnHub.addRawButton({
 buttonText: { displayText: '📚 Related' },
 buttonId: 'related_anime',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '📚 Related Anime',
 sections: sections
 })
 }
 });
 }

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[ANIMEDETAIL ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'ID anime tidak ditemukan atau API error'}`);
 }
}
break;







case "birthdays":
case "acdbbirthday":
case "acdbbirthday2": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 if (!text) return Reply(`📌 *Cara penggunaan:*\n.${command} <bulan>\n\nContoh: .${command} January\n\n*Bulan dalam bahasa Inggris (January, February, dll)*`);

 // Ubah input menjadi format yang benar (capitalize first letter)
 let month = text.trim();
 month = month.charAt(0).toUpperCase() + month.slice(1).toLowerCase();

 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/acdb/birthdays?month=${encodeURIComponent(month)}&apikey=${apikey}`);
 const data = response.data;

 console.log('[BIRTHDAYS RESPONSE]', JSON.stringify(data, null, 2)); // log untuk debug

 if (!data.status || !data.data?.success) {
 throw new Error('Gagal mengambil data ulang tahun');
 }

 const birthdays = data.data.birthdays;
 if (!birthdays || birthdays.length === 0) {
 return Reply(`❌ Tidak ada karakter yang berulang tahun di bulan ${month}. Pastikan penulisan bulan benar (contoh: January, February, dll).`);
 }

 let caption = `🎂 *Ulang Tahun Anime - ${month}*\n`;
 caption += `📊 *Total Karakter:* ${data.data.total}\n\n`;
 caption += `Klik tombol di bawah untuk melihat detail karakter (foto)`;

 const rows = birthdays.map(char => ({
 title: `${char.name} (${char.day})`,
 description: `${char.anime}`,
 id: `${prefix}charlink ${char.id}`
 }));

 const chunkSize = 10;
 const sections = [];
 for (let i = 0; i < rows.length; i += chunkSize) {
 sections.push({
 title: `🎂 Ulang Tahun ${month} (${i+1}-${Math.min(i+chunkSize, rows.length)})`,
 rows: rows.slice(i, i+chunkSize)
 });
 }

 const btnHub = new yonz.ButtonV2(yonz);
 btnHub.setThumbnail(global.image.menu)
 .setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🎂 Lihat Karakter' },
 buttonId: 'pilih_birthday',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: `🎂 Ulang Tahun ${month}`,
 sections: sections
 })
 }
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[BIRTHDAYS ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'Bulan tidak valid atau API error'}`);
 }
}
break;

case "character":
case "acdbchar":
case "achar":
case "char": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 if (!text) return Reply(`📌 *Cara penggunaan:*\n.${command} <id_karakter>\n\nContoh: .${command} 1`);

 const id = text.trim();
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/acdb/character?id=${id}&apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.data?.success) {
 throw new Error('Gagal mengambil data karakter');
 }

 const charData = data.data.data;
 if (!charData) throw new Error('Data karakter tidak ditemukan');

 let caption = `🎌 *${charData.title || charData.details?.Name || 'Karakter'}*\n\n`;
 
 if (charData.description) {
 caption += `📝 *Deskripsi:*\n${charData.description}\n\n`;
 }

 if (charData.details) {
 const det = charData.details;
 caption += `📋 *Detail:*\n`;
 if (det.Name) caption += `• *Nama:* ${det.Name}\n`;
 if (det['Other Names']) caption += `• *Nama Lain:* ${det['Other Names']}\n`;
 if (det.Role) caption += `• *Peran:* ${det.Role}\n`;
 if (det['Primary Assignment']) caption += `• *Anime:* ${det['Primary Assignment']}\n`;
 if (det['Voiced By']) caption += `• *Seiyuu:* ${det['Voiced By']}\n`;
 if (det.Tags) caption += `• *Tag:* ${det.Tags}\n`;
 if (det.Birthday) caption += `• *Ulang Tahun:* ${det.Birthday}\n`;
 if (det.Sign) caption += `• *Zodiak:* ${det.Sign}\n`;
 }

 if (charData.appearsAs) {
 const app = charData.appearsAs;
 caption += `\n👤 *Penampilan:*\n`;
 if (app.Gender) caption += `• *Gender:* ${app.Gender}\n`;
 if (app['Eye Color']) caption += `• *Warna Mata:* ${app['Eye Color']}\n`;
 if (app['Hair Color']) caption += `• *Warna Rambut:* ${app['Hair Color']}\n`;
 if (app['Hair Length']) caption += `• *Panjang Rambut:* ${app['Hair Length']}\n`;
 if (app['Apparent Age']) caption += `• *Usia:* ${app['Apparent Age']}\n`;
 }

 if (charData.tags && charData.tags.length > 0) {
 caption += `\n🏷️ *Tag:* ${charData.tags.join(', ')}\n`;
 }

 if (charData.anime && charData.anime.length > 0) {
 caption += `\n📺 *Muncul di Anime:*\n`;
 charData.anime.forEach((a, i) => {
 caption += `${i+1}. ${a.name}\n`;
 });
 }

 if (charData.voiceActors && charData.voiceActors.length > 0) {
 caption += `\n🎤 *Pengisi Suara:*\n`;
 charData.voiceActors.forEach(va => {
 caption += `• ${va.name}\n`;
 });
 }

 caption += `\n🔗 ${charData.url || `https://www.animecharactersdatabase.com/characters.php?id=${id}`}`;

 let imageUrl = charData.image;
 if (!imageUrl && charData.gallery && charData.gallery.length > 0) {
 imageUrl = charData.gallery[0].full;
 }

 const btnHub = new yonz.ButtonV2(yonz);
 if (imageUrl) {
 try {
 const imgBuffer = await axios.get(imageUrl, { responseType: 'arraybuffer' });
 btnHub.setImage(Buffer.from(imgBuffer.data));
 } catch (e) {
 btnHub.setThumbnail(global.image.menu);
 }
 } else {
 btnHub.setThumbnail(global.image.menu);
 }

 btnHub.setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`);

 if (charData.gallery && charData.gallery.length > 0) {
 btnHub.addRawButton({
 buttonText: { displayText: '🖼️ Galeri' },
 buttonId: `${prefix}chargallery ${id}`,
 type: 1
 });
 }

 if (charData.anime && charData.anime.length > 0) {
 const animeRows = charData.anime.map(a => ({
 title: a.name,
 description: `ID: ${a.id}`,
 id: `${prefix}animedetail ${a.id}`
 }));
 const sections = [{
 title: '📺 Anime Terkait',
 rows: animeRows
 }];
 btnHub.addRawButton({
 buttonText: { displayText: '📺 Anime' },
 buttonId: 'anime_related',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '📺 Anime Terkait',
 sections: sections
 })
 }
 });
 }

 btnHub.addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[CHARACTER DETAIL ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'ID karakter tidak ditemukan atau API error'}`);
 }
}
break;

case "chargallery": {
 if (!text) return Reply('❌ Masukkan ID karakter');
 const id = text.trim();
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/acdb/character?id=${id}&apikey=${apikey}`);
 const data = response.data;
 if (!data.status || !data.data?.success) throw new Error('Gagal mengambil data');
 const charData = data.data.data;
 if (!charData.gallery || charData.gallery.length === 0) {
 return Reply('❌ Tidak ada galeri untuk karakter ini');
 }

 const gallery = charData.gallery.slice(0, 5);
 for (const img of gallery) {
 try {
 const imgBuffer = await axios.get(img.full, { responseType: 'arraybuffer' });
 await yonz.sendMessage(m.chat, {
 image: Buffer.from(imgBuffer.data),
 caption: `🖼️ *${charData.details?.Name || 'Karakter'}*`
 });
 await sleep(500);
 } catch (e) {
 console.error('Gagal kirim gambar galeri', e);
 }
 }
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 } catch (error) {
 console.error('[GALLERY ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Gagal mengambil galeri: ${error.message}`);
 }
}
break;

case "height":
case "acheight":
case "charheight": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 if (!text) return Reply(`📌 *Cara penggunaan:*\n.${command} <tinggi_cm>\n\nContoh: .${command} 190`);

 const cm = text.trim();
 if (isNaN(cm) || cm <= 0) return Reply('❌ Masukkan angka tinggi dalam cm yang valid (contoh: 170)');

 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/acdb/height?cm=${encodeURIComponent(cm)}&apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.data?.success) {
 throw new Error('Gagal mengambil data tinggi');
 }

 const results = data.data.results;
 if (!results || results.length === 0) {
 return Reply(`❌ Tidak ada karakter dengan tinggi ${cm} cm.`);
 }

 let caption = `📏 *Pencarian Tinggi - ${cm} cm*\n`;
 caption += `📊 *Total Karakter:* ${data.data.total}\n\n`;
 caption += `Klik tombol di bawah untuk melihat detail karakter`;

 const rows = results.map(char => ({
 title: `${char.name}`,
 description: `ID: ${char.id}`,
 id: `${prefix}charlink ${char.id}`
 }));

 const chunkSize = 10;
 const sections = [];
 for (let i = 0; i < rows.length; i += chunkSize) {
 sections.push({
 title: `📏 Tinggi ${cm} cm (${i+1}-${Math.min(i+chunkSize, rows.length)})`,
 rows: rows.slice(i, i+chunkSize)
 });
 }

 const btnHub = new yonz.ButtonV2(yonz);
 btnHub.setThumbnail(global.image.menu)
 .setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '📏 Lihat Karakter' },
 buttonId: 'pilih_height',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: `📏 Karakter Tinggi ${cm} cm`,
 sections: sections
 })
 }
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[HEIGHT ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'Tinggi tidak valid atau API error'}`);
 }
}
break;

case "anichinlatest":
case "anilatest":
case "al": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/anichin/latest?apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.result || data.result.length === 0) {
 throw new Error('Gagal mengambil data atau data kosong');
 }

 const episodes = data.result;
 const total = data.total || episodes.length;

 let caption = `🎬 *Anichin - Episode Terbaru*\n`;
 caption += `📊 *Total:* ${total} episode\n\n`;
 caption += `Klik tombol di bawah untuk melihat detail episode`;

 const rows = episodes.map((ep, index) => ({
 title: `${ep.episode} - ${ep.title.substring(0, 30)}${ep.title.length > 30 ? '...' : ''}`,
 description: `${ep.type}`,
 id: `${prefix}anichinlink ${index}`
 }));

 const chunkSize = 10;
 const sections = [];
 for (let i = 0; i < rows.length; i += chunkSize) {
 sections.push({
 title: `🎬 Episode (${i+1}-${Math.min(i+chunkSize, rows.length)})`,
 rows: rows.slice(i, i+chunkSize)
 });
 }

 // Simpan data sementara untuk diakses oleh anichinlink
 global.anichinData = global.anichinData || {};
 global.anichinData[m.sender] = episodes;

 const btnHub = new yonz.ButtonV2(yonz);
 btnHub.setThumbnail(global.image.menu)
 .setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🎬 Pilih Episode' },
 buttonId: 'pilih_anichin',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🎬 Episode Terbaru',
 sections: sections
 })
 }
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[ANICHIN LATEST ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'Gagal mengambil data'}`);
 }
}
break;

case "anichinlink": {
 if (!text) return Reply('❌ Masukkan indeks episode');
 const index = parseInt(text.trim());
 if (isNaN(index) || index < 0) return Reply('❌ Indeks tidak valid');

 const episodes = global.anichinData?.[m.sender];
 if (!episodes || index >= episodes.length) {
 return Reply('❌ Data episode tidak ditemukan. Silakan gunakan .anichinlatest terlebih dahulu');
 }

 const ep = episodes[index];
 if (!ep) return Reply('❌ Episode tidak ditemukan');

 let caption = `🎬 *${ep.title}*\n\n`;
 caption += `📺 *Episode:* ${ep.episode}\n`;
 caption += `📂 *Tipe:* ${ep.type}\n`;
 caption += `🔗 *Link:* ${ep.url}\n\n`;
 caption += `Klik tombol di bawah untuk membuka link`;

 const btnHub = new yonz.ButtonV2(yonz);
 if (ep.thumbnail) {
 try {
 const imgBuffer = await axios.get(ep.thumbnail, { responseType: 'arraybuffer' });
 btnHub.setImage(Buffer.from(imgBuffer.data));
 } catch (e) {
 btnHub.setThumbnail(global.image.menu);
 }
 } else {
 btnHub.setThumbnail(global.image.menu);
 }

 btnHub.setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🔗 Buka Link' },
 buttonId: `${prefix}anichinurl ${index}`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
}
break;

case "anichinurl": {
 if (!text) return Reply('❌ Masukkan indeks episode');
 const index = parseInt(text.trim());
 if (isNaN(index) || index < 0) return Reply('❌ Indeks tidak valid');

 const episodes = global.anichinData?.[m.sender];
 if (!episodes || index >= episodes.length) {
 return Reply('❌ Data episode tidak ditemukan');
 }

 const ep = episodes[index];
 if (!ep) return Reply('❌ Episode tidak ditemukan');

 await yonz.sendMessage(m.chat, {
 text: `🔗 *${ep.title}*\n\n${ep.url}`
 }, { quoted: m });
}
break;

case "anichinpopular":
case "apopular":
case "apop": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/anichin/popular?apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.result || data.result.length === 0) {
 throw new Error('Gagal mengambil data atau data kosong');
 }

 const episodes = data.result;
 const total = data.total || episodes.length;

 let caption = `🔥 *Anichin - Populer*\n`;
 caption += `📊 *Total:* ${total} episode\n\n`;
 caption += `Klik tombol di bawah untuk melihat detail episode`;

 const rows = episodes.map((ep, index) => ({
 title: `${ep.episode} - ${ep.title.substring(0, 30)}${ep.title.length > 30 ? '...' : ''}`,
 description: `${ep.type}`,
 id: `${prefix}apoplink ${index}`
 }));

 const chunkSize = 10;
 const sections = [];
 for (let i = 0; i < rows.length; i += chunkSize) {
 sections.push({
 title: `🔥 Populer (${i+1}-${Math.min(i+chunkSize, rows.length)})`,
 rows: rows.slice(i, i+chunkSize)
 });
 }

 // Simpan data sementara
 global.anichinPopData = global.anichinPopData || {};
 global.anichinPopData[m.sender] = episodes;

 const btnHub = new yonz.ButtonV2(yonz);
 btnHub.setThumbnail(global.image.menu)
 .setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🔥 Pilih Episode' },
 buttonId: 'pilih_apop',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🔥 Episode Populer',
 sections: sections
 })
 }
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[ANICHIN POPULAR ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'Gagal mengambil data'}`);
 }
}
break;

case "apoplink": {
 if (!text) return Reply('❌ Masukkan indeks episode');
 const index = parseInt(text.trim());
 if (isNaN(index) || index < 0) return Reply('❌ Indeks tidak valid');

 const episodes = global.anichinPopData?.[m.sender];
 if (!episodes || index >= episodes.length) {
 return Reply('❌ Data episode tidak ditemukan. Silakan gunakan .anichinpopular terlebih dahulu');
 }

 const ep = episodes[index];
 if (!ep) return Reply('❌ Episode tidak ditemukan');

 let caption = `🔥 *${ep.title}*\n\n`;
 caption += `📺 *Episode:* ${ep.episode}\n`;
 caption += `📂 *Tipe:* ${ep.type}\n`;
 caption += `🔗 *Link:* ${ep.link}\n\n`;
 caption += `Klik tombol di bawah untuk membuka link`;

 const btnHub = new yonz.ButtonV2(yonz);
 if (ep.image) {
 try {
 const imgBuffer = await axios.get(ep.image, { responseType: 'arraybuffer' });
 btnHub.setImage(Buffer.from(imgBuffer.data));
 } catch (e) {
 btnHub.setThumbnail(global.image.menu);
 }
 } else {
 btnHub.setThumbnail(global.image.menu);
 }

 btnHub.setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🔗 Buka Link' },
 buttonId: `${prefix}apopurl ${index}`,
 type: 1
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
}
break;

case "apopurl": {
 if (!text) return Reply('❌ Masukkan indeks episode');
 const index = parseInt(text.trim());
 if (isNaN(index) || index < 0) return Reply('❌ Indeks tidak valid');

 const episodes = global.anichinPopData?.[m.sender];
 if (!episodes || index >= episodes.length) {
 return Reply('❌ Data episode tidak ditemukan');
 }

 const ep = episodes[index];
 if (!ep) return Reply('❌ Episode tidak ditemukan');

 await yonz.sendMessage(m.chat, {
 text: `🔗 *${ep.title}*\n\n${ep.link}`
 }, { quoted: m });
}
break;



case "animesearch":
case "anisearch":
case "asearch": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 if (!text) return Reply(`📌 *Cara penggunaan:*\n.${command} <judul_anime>\n\nContoh: .${command} Hoshino`);

 const query = encodeURIComponent(text.trim());
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const response = await axios.get(`${baseUrl}/anime/animelovers/search?q=${query}&apikey=${apikey}`);
 const data = response.data;

 if (!data.status || !data.data || data.data.length === 0) {
 return Reply(`❌ Tidak ditemukan anime dengan judul "${text.trim()}"`);
 }

 const results = data.data;
 const total = data.total || results.length;

 let caption = `🔍 *Pencarian Anime*\n`;
 caption += `📝 *Query:* ${text.trim()}\n`;
 caption += `📊 *Total:* ${total} hasil\n\n`;
 caption += `Klik tombol di bawah untuk memilih anime`;

 const rows = results.map((anime, index) => ({
 title: `${anime.judul}`,
 description: `ID: ${anime.id}`,
 id: `${prefix}animekita ${anime.id}`
 }));

 const chunkSize = 10;
 const sections = [];
 for (let i = 0; i < rows.length; i += chunkSize) {
 sections.push({
 title: `🔍 Hasil (${i+1}-${Math.min(i+chunkSize, rows.length)})`,
 rows: rows.slice(i, i+chunkSize)
 });
 }

 const btnHub = new yonz.ButtonV2(yonz);
 btnHub.setThumbnail(global.image.menu)
 .setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`)
 .addRawButton({
 buttonText: { displayText: '🔍 Pilih Anime' },
 buttonId: 'pilih_animekita',
 type: 1,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🔍 Hasil Pencarian',
 sections: sections
 })
 }
 })
 .addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (error) {
 console.error('[ANIMESEARCH ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'Gagal mencari anime'}`);
 }
}
break;

case "animekita":
case "akdetail": {
 if (!text) return Reply('❌ Masukkan ID anime');
 const id = text.trim();
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 // Ambil data detail dari API (menggunakan endpoint search dengan id)
 const response = await axios.get(`${baseUrl}/anime/animelovers/search?q=&apikey=${apikey}`);
 const data = response.data;
 
 if (!data.status || !data.data) {
 throw new Error('Gagal mengambil data anime');
 }

 // Cari anime berdasarkan ID
 const anime = data.data.find(a => a.id == id);
 if (!anime) {
 return Reply(`❌ Anime dengan ID ${id} tidak ditemukan`);
 }

 let caption = `🎬 *${anime.judul}*\n\n`;
 caption += `🆔 *ID:* ${anime.id}\n`;
 const baseUrlAnime = 'https://animekita.tv/';
 const fullUrl = anime.url ? `${baseUrlAnime}${anime.url}` : null;
 if (fullUrl) caption += `🔗 *Link:* ${fullUrl}\n\n`;
 caption += `Klik tombol di bawah untuk membuka link`;

 const btnHub = new yonz.ButtonV2(yonz);
 if (anime.cover) {
 try {
 const imgBuffer = await axios.get(anime.cover, { responseType: 'arraybuffer' });
 btnHub.setImage(Buffer.from(imgBuffer.data));
 } catch (e) {
 btnHub.setThumbnail(global.image.menu);
 }
 } else {
 btnHub.setThumbnail(global.image.menu);
 }

 btnHub.setBody(caption)
 .setFooter(`Bot: ${global.botname} | ${new Date().getFullYear()}`);

 if (fullUrl) {
 btnHub.addRawButton({
 buttonText: { displayText: '🔗 Buka Link' },
 buttonId: `${prefix}akurl ${id}`,
 type: 1
 });
 }

 btnHub.addRawButton({
 buttonText: { displayText: '📋 Menu' },
 buttonId: `${prefix}menu`,
 type: 1
 });

 await btnHub.send(m.chat);
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

 } catch (error) {
 console.error('[ANIMEKITA DETAIL ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Terjadi kesalahan: ${error.message || 'Gagal mengambil detail anime'}`);
 }
}
break;

case "akurl": {
 if (!text) return Reply('❌ Masukkan ID anime');
 const id = text.trim();
 const apikey = global.apikeythere || 'Yonz';
 const baseUrl = global.there || 'https://api.theresav.biz.id';

 try {
 const response = await axios.get(`${baseUrl}/anime/animelovers/search?q=&apikey=${apikey}`);
 const data = response.data;
 
 if (!data.status || !data.data) {
 throw new Error('Gagal mengambil data anime');
 }

 const anime = data.data.find(a => a.id == id);
 if (!anime) {
 return Reply(`❌ Anime dengan ID ${id} tidak ditemukan`);
 }

 const baseUrlAnime = 'https://animekita.tv/';
 const fullUrl = anime.url ? `${baseUrlAnime}${anime.url}` : null;
 
 if (!fullUrl) {
 return Reply(`❌ URL tidak tersedia untuk anime ini`);
 }

 await yonz.sendMessage(m.chat, {
 text: `🔗 *${anime.judul}*\n\n${fullUrl}`
 }, { quoted: m });

 } catch (error) {
 console.error('[AKURL ERROR]', error);
 Reply(`❌ Gagal mengambil URL: ${error.message}`);
 }
}
break;

case "toimg": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 const isSticker = mime === 'image/webp';

 if (!isSticker) return Reply('❌ Reply sticker gambar (bukan sticker animasi)!');

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const buffer = await q.download();
 const sharp = require('sharp');

 // Cek apakah sticker animasi (webp dengan multiple pages)
 const metadata = await sharp(buffer).metadata();
 if (metadata.pages && metadata.pages > 1) {
 return Reply('❌ Sticker animasi tidak bisa diubah ke foto.');
 }

 // Konversi ke PNG (atau JPEG)
 const imageBuffer = await sharp(buffer).png().toBuffer();

 await yonz.sendMessage(m.chat, {
 image: imageBuffer,
 caption: mess.done
 }, { quoted: m });

 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (e) {
 console.error(e);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply('❌ Gagal mengubah sticker menjadi foto. Pastikan sticker tersebut adalah sticker gambar statis.');
 }
}
break;


case "tovid":
case "sticker2video": {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator)) return Reply(global.mess.limit);

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 const isStickerVideo = mime === 'video/webm' || mime === 'video/mp4' || mime === 'video/quicktime';
 const isStickerImage = mime === 'image/webp';

 if (!isStickerVideo && !isStickerImage) {
 Reply('❌ Reply sticker video atau sticker GIF/animasi (webp)!');
 return;
 }

 try {
 await yonz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 Reply(mess.wait);

 const buffer = await q.download();

 if (isStickerVideo) {
 await yonz.sendMessage(m.chat, {
 video: buffer,
 caption: mess.done
 }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 return;
 }

 const fs = require('fs');
 const path = require('path');
 const { exec } = require('child_process');
 const util = require('util');
 const execPromise = util.promisify(exec);
 const sharp = require('sharp');

 const tmpDir = path.join('/tmp', `sticker_${Date.now()}`);
 fs.mkdirSync(tmpDir, { recursive: true });

 try {
 const tmpInput = path.join(tmpDir, 'input.webp');
 const tmpOutput = path.join(tmpDir, 'output.mp4');
 fs.writeFileSync(tmpInput, buffer);

 let success = false;

 // METODE 1: FFMPEG LANGSUNG
 try {
 await execPromise(
 `ffmpeg -y -i "${tmpInput}" -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=25" -c:v libx264 -pix_fmt yuv420p -movflags +faststart "${tmpOutput}"`
 );
 if (fs.existsSync(tmpOutput) && fs.statSync(tmpOutput).size > 1000) success = true;
 } catch (e1) {}

 // METODE 2: FFMPEG PIPE
 if (!success) {
 try {
 await execPromise(
 `ffmpeg -y -f webp_pipe -i "${tmpInput}" -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=25" -c:v libx264 -pix_fmt yuv420p -movflags +faststart "${tmpOutput}"`
 );
 if (fs.existsSync(tmpOutput) && fs.statSync(tmpOutput).size > 1000) success = true;
 } catch (e2) {}
 }

 // METODE 3: EKSTRAK FRAME SHARP
 if (!success) {
 try {
 let totalFrames = 0;
 try {
 const { stdout } = await execPromise(`ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of default=noprint_wrappers=1:nokey=1 "${tmpInput}"`);
 totalFrames = parseInt(stdout.trim()) || 0;
 } catch (probeErr) {
 try {
 const meta = await sharp(buffer).metadata();
 totalFrames = meta.pages || 0;
 } catch (metaErr) {
 totalFrames = 100;
 }
 }
 if (totalFrames <= 1) totalFrames = 100;

 const framePaths = [];
 const maxFrames = Math.min(totalFrames, 150);

 for (let i = 0; i < maxFrames; i++) {
 try {
 const frameBuffer = await sharp(buffer, { pages: i, limitInputPixels: false }).png().toBuffer();
 const framePath = path.join(tmpDir, `frame_${String(i).padStart(4, '0')}.png`);
 fs.writeFileSync(framePath, frameBuffer);
 framePaths.push(framePath);
 } catch (frameErr) {
 continue;
 }
 }

 if (framePaths.length >= 2) {
 await execPromise(
 `ffmpeg -framerate 25 -pattern_type glob -i "${tmpDir}/frame_*.png" -c:v libx264 -pix_fmt yuv420p -movflags +faststart -y "${tmpOutput}"`
 );
 if (fs.existsSync(tmpOutput) && fs.statSync(tmpOutput).size > 1000) success = true;
 }
 } catch (e3) {}
 }

 // METODE 4: WEBP -> GIF -> MP4
 if (!success) {
 try {
 const tmpGif = path.join(tmpDir, 'temp.gif');
 await execPromise(`ffmpeg -y -i "${tmpInput}" "${tmpGif}"`);
 await execPromise(
 `ffmpeg -y -i "${tmpGif}" -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=25" -c:v libx264 -pix_fmt yuv420p -movflags +faststart "${tmpOutput}"`
 );
 if (fs.existsSync(tmpOutput) && fs.statSync(tmpOutput).size > 1000) success = true;
 } catch (e4) {}
 }

 if (!success) {
 throw new Error('Semua metode konversi gagal. Sticker mungkin korup atau tidak didukung.');
 }

 const videoBuffer = fs.readFileSync(tmpOutput);
 await yonz.sendMessage(m.chat, { video: videoBuffer, caption: mess.done }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 } catch (e) {
 throw new Error(e.message);
 } finally {
 fs.rmSync(tmpDir, { recursive: true, force: true });
 }

 } catch (e) {
 console.error('[TOVID ERROR]', e);
 await yonz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
 Reply(`❌ Gagal mengubah sticker menjadi video: ${e.message || 'Terjadi kesalahan'}`);
 }
 break;
}



case 'tofigure':
case 'gure': {
 if (!global.isPrem(m.sender) && !isCreator) return ReplyPrem();

 // ---------- PROMPT UNIVERSAL (cowok/cewek, tanpa ubah bentuk) ----------
 const teks = `Using the nano-banana model, a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment. The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base. The computer screen shows the Zbrush modeling process of the figurine. Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.`;

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));

 Reply(global.mess.wait);
 await m.react('⏱️');

 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

 let mediaPath = null;

 try {
 mediaPath = await yonz.downloadAndSaveMediaMessage(q);
 if (!mediaPath) throw new Error("gagal mengunduh gambar");

 const form = new FormData();
 form.append('file', fs.createReadStream(mediaPath));

 const uploadRes = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });

 const userImageUrl = uploadRes.data?.url || uploadRes.data?.result || uploadRes.data?.link || uploadRes.data?.data?.url;
 if (!userImageUrl || typeof userImageUrl !== 'string' || !userImageUrl.startsWith('http')) {
 throw new Error(`gagal upload: ${JSON.stringify(uploadRes.data)}`);
 }

 const apiUrl = `${global.apialip}/imagecreator/bananaai?apikey=${global.alipkey}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(teks)}`;
 console.log('[IMAGE REQUEST]', apiUrl);

 const initRes = await axios.get(apiUrl, { responseType: 'arraybuffer' });
 const contentType = initRes.headers['content-type'] || '';

 let hasilBuffer = null;

 if (contentType.includes('image')) {
 hasilBuffer = Buffer.from(initRes.data);
 } else {
 const jsonString = Buffer.from(initRes.data).toString('utf-8');
 let taskData;
 try {
 taskData = JSON.parse(jsonString);
 } catch (e) {
 throw new Error('Respons bukan JSON dan bukan gambar: ' + jsonString.slice(0, 200));
 }

 if (taskData.status === false || taskData.success === false || taskData.code === 401 || taskData.error) {
 throw new Error(taskData.message || taskData.error || 'API error');
 }

 function findImageUrl(obj) {
 if (typeof obj === 'string') {
 if (obj.startsWith('http') && /\.(jpg|jpeg|png|webp|gif)/i.test(obj)) return obj;
 return null;
 }
 if (Array.isArray(obj)) {
 for (let item of obj) {
 const found = findImageUrl(item);
 if (found) return found;
 }
 return null;
 }
 if (obj && typeof obj === 'object') {
 for (let key in obj) {
 const found = findImageUrl(obj[key]);
 if (found) return found;
 }
 }
 return null;
 }

 let finalImageUrl = findImageUrl(taskData);
 if (!finalImageUrl && typeof taskData === 'string' && taskData.startsWith('http')) finalImageUrl = taskData;
 if (!finalImageUrl && taskData.result && typeof taskData.result === 'string' && taskData.result.startsWith('http')) finalImageUrl = taskData.result;
 if (!finalImageUrl && taskData.url && typeof taskData.url === 'string' && taskData.url.startsWith('http')) finalImageUrl = taskData.url;

 if (!finalImageUrl) {
 throw new Error(`tidak ada URL gambar dalam JSON: ${jsonString.slice(0, 500)}`);
 }

 const responseImg = await axios.get(finalImageUrl, { responseType: "arraybuffer", timeout: 60000 });
 hasilBuffer = Buffer.from(responseImg.data);
 }

 const sharp = require('sharp');
 const finalBuffer = await sharp(hasilBuffer).jpeg().toBuffer();

 await yonz.sendMessage(m.chat, {
 image: finalBuffer,
 mimetype: 'image/jpeg',
 caption: global.mess.done
 }, { quoted: m });

 await m.react('✅');

 } catch (e) {
 console.error('[IMAGE PROCESS ERROR]', e);
 await m.react('❌');
 if (e.response?.status === 500) {
 return Reply("❌ server AI sedang overload / prompt terlalu kompleks");
 }
 Reply(`❌ gagal: ${e.message}`);
 } finally {
 if (mediaPath && fs.existsSync(mediaPath)) {
 try { fs.unlinkSync(mediaPath); } catch (_) {}
 }
 }
}
break;

case "toprompt": {
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 
 if (!/image/i.test(mime)) {
 return Reply(example("dengan kirim/reply foto"));
 }

 // === CEK PREMIUM / OWNER ===
 const senderJid = m.sender;
 const senderNum = getNumber(senderJid);
 const owners = normalizeOwner(global.owner);
 const isOwner = owners.includes(senderNum);
 
 // Cek premium menggunakan fungsi isPrem (sama seperti di case tofigure)
 const isPremium = global.isPrem ? global.isPrem(senderJid) : false;
 
 // Jika tidak premium dan bukan owner, tolak
 if (!isPremium && !isOwner) {
 return Reply('❌ Fitur ini khusus untuk pengguna premium. Ketik .prem untuk info.');
 }

 // Lanjutkan proses toprompt...
 Reply(mess.wait);
 await yonz.sendMessage(m.chat, { react: { text: "⏰", key: m.key } });
 
 try {
 const userImageBuffer = await q.download();
 if (!userImageBuffer) throw new Error("Gagal mengunduh gambar Anda.");
 
 const userImageUrl = await uploadToCDN(userImageBuffer, mime);
 if (!userImageUrl) throw new Error("Gagal upload gambar ke server");
 
 // Prompt untuk mengubah gambar menjadi prompt
 const PROMPT_GENERATE = "Analyze this image and generate a detailed prompt for AI image generation. Describe the subject, style, lighting, composition, colors, and mood in detail.";
 
 const apiUrl = `${global.apialip}/imagecreator/describe?apikey=${global.apikeyalip}&url=${encodeURIComponent(userImageUrl)}&prompt=${encodeURIComponent(PROMPT_GENERATE)}`;
 
 const response = await axios.get(apiUrl, { timeout: 60000 });
 const result = response.data;
 
 await yonz.sendMessage(m.chat, { 
 text: `📝 *Hasil Prompt:*\n\n${result.prompt || result.description || result.text || JSON.stringify(result)}`,
 quoted: m
 });
 
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('[TOPROMPT ERROR]', e);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;
  
case "veo3": {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi);
 
 if (!global.isPrem(m.sender) && !isCreator)
 return Reply(mess.prem);
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);
 
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 
 if (!/image\//i.test(mime)) {
 return Reply(example("reply gambar\n.veo3 ubah jadi animasi singkat"));
 }
 
 if (!text) {
 return Reply(example("orang ini sedang berlari"));
 }
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);
 
 try {
 let imageBuffer = null;
 let imageUrl = '';
 
 if (mime.startsWith('image/')) {
 imageBuffer = await q.download();
 if (!imageBuffer) throw new Error('Gagal download gambar');
 
 imageUrl = await uploadToCDN(imageBuffer, mime);
 }
 
 const prompt = text || "animate this image";
 let requestId = null;
 let formData = new FormData();
 formData.append("prompt", prompt);
 
 if (imageBuffer) {
 formData.append("initialFrame", imageBuffer, { filename: "image.jpg", contentType: "image/jpeg" });
 }
 
 const generateRes = await axios.post("https://www.freeaivideos.org/api/video_generation", formData, {
 headers: { ...formData.getHeaders(), "user-agent": "NB Android/1.0.0", "origin": "https://www.freeaivideos.org", "referer": "https://www.freeaivideos.org/" },
 timeout: 180000
 });
 
 requestId = generateRes.data?.request_id;
 
 if (!requestId) {
 throw new Error('Gagal mendapatkan request ID');
 }
 
 let videoUrl = null;
 let attempts = 0;
 const maxAttempts = 120;
 
 while (attempts < maxAttempts && !videoUrl) {
 await sleep(5000);
 attempts++;
 
 try {
 const statusRes = await axios.get(`https://www.freeaivideos.org/api/video_generation?request_id=${requestId}&prompt=`, {
 headers: { "user-agent": "NB Android/1.0.0", "origin": "https://www.freeaivideos.org" },
 timeout: 15000
 });
 
 if (statusRes.data?.video_url) {
 videoUrl = statusRes.data.video_url;
 break;
 }
 } catch (e) {}
 }
 
 if (!videoUrl) {
 throw new Error('Timeout: Video generation terlalu lama');
 }
 
 await yonz.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: mess.done,
 mimetype: 'video/mp4'
 }, { quoted: m });
 
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error('[VEO3 ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(mess.error);
 }
}
break;

case 'addlist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text) return Reply(example("nama|pesan"));
    
    const chatId = m.chat;
    const listDb = loadLists();
    let listGrup = listDb[chatId] || [];
    
    const parts = text.split('|');
    if (parts.length < 2) return Reply("❌ Format salah!\nContoh: *nama|pesan*");
    
    const name = parts[0].trim();
    const message = parts.slice(1).join('|').trim();
    
    if (!name || !message) return Reply("❌ Nama dan pesan tidak boleh kosong!");
    
    const existing = listGrup.find(item => item.name.toLowerCase() === name.toLowerCase());
    if (existing) return Reply(`❌ Nama "${name}" sudah ada di list!`);
    
    let imagePath = null;
    let hasImage = false;
    
    if (m.quoted && m.quoted.mtype) {
        const quotedMsg = m.quoted;
        if (quotedMsg.mtype === 'imageMessage' || 
            quotedMsg.mtype === 'extendedTextMessage' && quotedMsg.msg && quotedMsg.msg.mtype === 'imageMessage') {
            try {
                const media = await yonz.downloadMediaMessage(quotedMsg);
                if (media) {
                    const timestamp = Date.now();
                    const fileName = `list_${chatId}_${timestamp}.jpg`;
                    const filePath = `./library/media/list/${fileName}`;
                    
                    if (!fs.existsSync('./library/media/list')) {
                        fs.mkdirSync('./library/media/list', { recursive: true });
                    }
                    
                    fs.writeFileSync(filePath, media);
                    imagePath = filePath;
                    hasImage = true;
                }
            } catch (e) {
                console.error('Error downloading image:', e);
            }
        }
    }
    
    const newItem = {
        name: name,
        message: message,
        hasImage: hasImage,
        image: imagePath,
        createdAt: new Date().toISOString()
    };
    
    listGrup.push(newItem);
    listDb[chatId] = listGrup;
    saveLists(listDb);
    
    let replyMsg = `✅ *Berhasil menambahkan list!*\n\n`;
    replyMsg += `📝 Nama: ${name}\n`;
    replyMsg += `💬 Pesan: ${message}\n`;
    if (hasImage) replyMsg += `🖼️ Gambar: Tersimpan\n`;
    replyMsg += `\n💡 Ketik *${name}* (tanpa prefix) untuk memanggil`;
    
    Reply(replyMsg);
}
break;

case 'dellist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    if (!text) return Reply(example("nama atau nomor"));
    
    const chatId = m.chat;
    const listDb = loadLists();
    let listGrup = listDb[chatId] || [];
    
    if (listGrup.length === 0) return Reply("❌ Tidak ada item di list");
    
    let itemDihapus = null;
    let index = -1;
    
    if (!isNaN(text)) {
        index = parseInt(text) - 1;
        if (index >= 0 && index < listGrup.length) {
            itemDihapus = listGrup[index];
        }
    } else {
        const keyword = text.toLowerCase();
        index = listGrup.findIndex(item => 
            item.name.toLowerCase() === keyword ||
            item.name.toLowerCase().includes(keyword)
        );
        if (index !== -1) {
            itemDihapus = listGrup[index];
        }
    }
    
    if (!itemDihapus) return Reply(`❌ Item "${text}" tidak ditemukan`);
    
    if (itemDihapus.hasImage && itemDihapus.image && fs.existsSync(itemDihapus.image)) {
        try {
            fs.unlinkSync(itemDihapus.image);
        } catch (e) {}
    }
    
    listGrup.splice(index, 1);
    listDb[chatId] = listGrup;
    saveLists(listDb);
    
    let replyMsg = `✅ *Berhasil menghapus item!*\n\n`;
    replyMsg += `📝 Nama: ${itemDihapus.name}\n`;
    replyMsg += `💬 Pesan: ${itemDihapus.message}\n`;
    if (itemDihapus.hasImage) replyMsg += `🖼️ Gambar: Terhapus\n`;
    replyMsg += `\nSisa item: ${listGrup.length}`;
    
    Reply(replyMsg);
}
break;



case 'clearlist': {
    if (!m.isGroup) return Reply(mess.group);
    if (!m.isAdmin && !isCreator) return Reply(mess.admin);
    
    const chatId = m.chat;
    const listDb = loadLists();
    let listGrup = listDb[chatId] || [];
    
    if (listGrup.length === 0) return Reply("❌ Tidak ada item di list");
    
    if (!text || text.toLowerCase() !== 'confirm') {
        return Reply(
            `⚠️ *Peringatan!*\n\n` +
            `Anda akan menghapus *SEMUA* item di list grup ini.\n` +
            `Total: ${listGrup.length} item\n\n` +
            `Ketik: *${prefix}clearlist confirm* untuk mengkonfirmasi`
        );
    }
    
    let deletedImages = 0;
    listGrup.forEach(item => {
        if (item.hasImage && item.image && fs.existsSync(item.image)) {
            try {
                fs.unlinkSync(item.image);
                deletedImages++;
            } catch (e) {}
        }
    });
    
    listDb[chatId] = [];
    saveLists(listDb);
    
    Reply(
        `✅ *Berhasil menghapus semua list!*\n\n` +
        `📝 Total item: ${listGrup.length}\n` +
        `🖼️ Gambar terhapus: ${deletedImages}`
    );
}
break;









case "toalt":
case "toalternate": {
 // Hanya terima gambar (image), bukan sticker
 if (!/image/.test(mime)) {
 return Reply('❌ Kirim/reply gambar! Format yang didukung: jpg, jpeg, png, gif, webp (bukan stiker).');
 }

 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 const path = require('path');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) {
 fs.mkdirSync(dir, { recursive: true });
 }

 Reply(global.mess.wait);

 let media = null;
 let resultImage = null;
 
 try {
 const qmsg = m.quoted || m;
 
 // Download gambar
 media = await yonz.downloadAndSaveMediaMessage(qmsg);
 if (!media) return Reply('❌ Gagal mendownload gambar.');

 // Upload gambar ke server
 const form = new FormData();
 form.append('file', fs.createReadStream(media));

 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: {
 ...form.getHeaders(),
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 },
 timeout: 60000
 });

 const directLink = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;
 if (!directLink || typeof directLink !== 'string') {
 return Reply(`❌ Gagal upload gambar.\nRespon: ${JSON.stringify(upload.data)}`);
 }

 // Panggil API transform to alternate text
 const apiUrl = `${global.claude}/edit/transform/toalternate?url=${encodeURIComponent(directLink)}`;
 
 const response = await axios({
 method: 'GET',
 url: apiUrl,
 timeout: 45000,
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 },
 responseType: 'arraybuffer' // Penting: ambil sebagai buffer
 });

 // Cek apakah response adalah gambar atau JSON
 const contentType = response.headers['content-type'] || '';
 
 if (contentType.includes('image')) {
 // Jika API mengembalikan gambar langsung
 const imageBuffer = Buffer.from(response.data);
 const ext = contentType.split('/')[1] || 'png';
 const filename = `toalt_${Date.now()}.${ext}`;
 const filepath = path.join(dir, filename);
 
 fs.writeFileSync(filepath, imageBuffer);
 
 // Kirim gambar hasil transformasi
 await yonz.sendMessage(m.chat, {
 image: fs.readFileSync(filepath),
 caption: '🖼️ *Hasil Transformasi Gambar*\n\n✅ Berhasil diproses!',
 mimetype: contentType
 }, { quoted: m });
 
 resultImage = filepath;
 } else {
 // Jika API mengembalikan JSON (error atau teks)
 try {
 const textData = JSON.parse(response.data.toString('utf-8'));
 console.log('[TOALT] API Response:', JSON.stringify(textData, null, 2));
 
 let result = null;
 if (textData.status && textData.result) {
 result = textData.result;
 } else if (textData.success && textData.data) {
 result = textData.data;
 } else if (textData.result) {
 result = textData.result;
 } else if (textData.text) {
 result = textData.text;
 } else if (textData.output) {
 result = textData.output;
 } else if (typeof textData === 'string') {
 result = textData;
 } else {
 result = JSON.stringify(textData, null, 2);
 }
 
 // Kirim hasil teks
 let teks = `🖼️ *Image to Alternate Text*\n\n📝 *Hasil:*\n${result}`;
 await yonz.sendMessage(m.chat, { text: teks }, { quoted: m });
 } catch (parseError) {
 // Jika bukan JSON, kirim sebagai teks biasa
 const textResult = response.data.toString('utf-8');
 await yonz.sendMessage(m.chat, { 
 text: `🖼️ *Hasil Transformasi*\n\n${textResult}` 
 }, { quoted: m });
 }
 }

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('[TOALT ERROR]', e);
 let errorMsg = '❌ Terjadi error: ' + e.message;
 
 if (e.message.includes('502')) {
 errorMsg = '❌ Server API sedang sibuk (Error 502). Silakan coba lagi nanti.';
 } else if (e.message.includes('timeout')) {
 errorMsg = '❌ Waktu tunggu habis. Silakan coba lagi dengan gambar yang lebih kecil.';
 } else if (e.message.includes('404')) {
 errorMsg = '❌ Endpoint API tidak ditemukan. Periksa konfigurasi.';
 } else if (e.response) {
 errorMsg = `❌ API Error (${e.response.status}): ${JSON.stringify(e.response.data)}`;
 }
 
 await yonz.sendMessage(m.chat, { text: errorMsg }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 } finally {
 // Hapus file sementara
 if (media) {
 try { fs.unlinkSync(media); } catch (_) { }
 }
 if (resultImage) {
 try { fs.unlinkSync(resultImage); } catch (_) { }
 }
 }
}
break;

case "toamethyst": {
 // Hanya terima gambar (image), bukan sticker
 if (!/image/.test(mime)) {
 return Reply('❌ Kirim/reply gambar! Format yang didukung: jpg, jpeg, png, gif, webp (bukan stiker).');
 }

 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 const path = require('path');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) {
 fs.mkdirSync(dir, { recursive: true });
 }

 Reply(global.mess.wait);

 let media = null;
 let resultImage = null;
 
 try {
 const qmsg = m.quoted || m;
 
 // Download gambar
 media = await yonz.downloadAndSaveMediaMessage(qmsg);
 if (!media) return Reply('❌ Gagal mendownload gambar.');

 // Upload gambar ke server
 const form = new FormData();
 form.append('file', fs.createReadStream(media));

 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: {
 ...form.getHeaders(),
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 },
 timeout: 60000
 });

 const directLink = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;
 if (!directLink || typeof directLink !== 'string') {
 return Reply(`❌ Gagal upload gambar.\nRespon: ${JSON.stringify(upload.data)}`);
 }

 // Panggil API transform to amethyst
 const apiUrl = `${global.claude}/edit/transform/toamethyst?url=${encodeURIComponent(directLink)}`;
 
 const response = await axios({
 method: 'GET',
 url: apiUrl,
 timeout: 45000,
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 },
 responseType: 'arraybuffer'
 });

 // Cek apakah response adalah gambar atau JSON
 const contentType = response.headers['content-type'] || '';
 
 if (contentType.includes('image')) {
 // Jika API mengembalikan gambar langsung
 const imageBuffer = Buffer.from(response.data);
 const ext = contentType.split('/')[1] || 'png';
 const filename = `toamethyst_${Date.now()}.${ext}`;
 const filepath = path.join(dir, filename);
 
 fs.writeFileSync(filepath, imageBuffer);
 
 // Kirim gambar hasil transformasi
 await yonz.sendMessage(m.chat, {
 image: fs.readFileSync(filepath),
 caption: '💜 *Efek Amethyst*\n\n✅ Berhasil diproses!',
 mimetype: contentType
 }, { quoted: m });
 
 resultImage = filepath;
 } else {
 // Jika API mengembalikan JSON (error atau teks)
 try {
 const textData = JSON.parse(response.data.toString('utf-8'));
 console.log('[TOAMETHYST] API Response:', JSON.stringify(textData, null, 2));
 
 let result = null;
 if (textData.status && textData.result) {
 result = textData.result;
 } else if (textData.success && textData.data) {
 result = textData.data;
 } else if (textData.result) {
 result = textData.result;
 } else if (textData.text) {
 result = textData.text;
 } else if (textData.output) {
 result = textData.output;
 } else if (typeof textData === 'string') {
 result = textData;
 } else {
 result = JSON.stringify(textData, null, 2);
 }
 
 // Kirim hasil teks
 let teks = `💜 *Efek Amethyst*\n\n📝 *Hasil:*\n${result}`;
 await yonz.sendMessage(m.chat, { text: teks }, { quoted: m });
 } catch (parseError) {
 // Jika bukan JSON, kirim sebagai teks biasa
 const textResult = response.data.toString('utf-8');
 await yonz.sendMessage(m.chat, { 
 text: `💜 *Efek Amethyst*\n\n${textResult}` 
 }, { quoted: m });
 }
 }

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('[TOAMETHYST ERROR]', e);
 let errorMsg = '❌ Terjadi error: ' + e.message;
 
 if (e.message.includes('502')) {
 errorMsg = '❌ Server API sedang sibuk (Error 502). Silakan coba lagi nanti.';
 } else if (e.message.includes('timeout')) {
 errorMsg = '❌ Waktu tunggu habis. Silakan coba lagi dengan gambar yang lebih kecil.';
 } else if (e.message.includes('404')) {
 errorMsg = '❌ Endpoint API tidak ditemukan. Periksa konfigurasi.';
 } else if (e.response) {
 errorMsg = `❌ API Error (${e.response.status}): ${JSON.stringify(e.response.data)}`;
 }
 
 await yonz.sendMessage(m.chat, { text: errorMsg }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 } finally {
 // Hapus file sementara
 if (media) {
 try { fs.unlinkSync(media); } catch (_) { }
 }
 if (resultImage) {
 try { fs.unlinkSync(resultImage); } catch (_) { }
 }
 }
}
break;

case "toalbino": {
 // Hanya terima gambar (image), bukan sticker
 if (!/image/.test(mime)) {
 return Reply('❌ Kirim/reply gambar! Format yang didukung: jpg, jpeg, png, gif, webp (bukan stiker).');
 }

 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 const path = require('path');

 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) {
 fs.mkdirSync(dir, { recursive: true });
 }

 Reply(global.mess.wait);

 let media = null;
 let resultImage = null;
 
 try {
 const qmsg = m.quoted || m;
 
 // Download gambar
 media = await yonz.downloadAndSaveMediaMessage(qmsg);
 if (!media) return Reply('❌ Gagal mendownload gambar.');

 // Upload gambar ke server
 const form = new FormData();
 form.append('file', fs.createReadStream(media));

 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: {
 ...form.getHeaders(),
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 },
 timeout: 60000
 });

 const directLink = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;
 if (!directLink || typeof directLink !== 'string') {
 return Reply(`❌ Gagal upload gambar.\nRespon: ${JSON.stringify(upload.data)}`);
 }

 // Panggil API transform to albino
 const apiUrl = `${global.claude}/edit/transform/toalbino?url=${encodeURIComponent(directLink)}`;
 
 const response = await axios({
 method: 'GET',
 url: apiUrl,
 timeout: 45000,
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 },
 responseType: 'arraybuffer'
 });

 // Cek apakah response adalah gambar atau JSON
 const contentType = response.headers['content-type'] || '';
 
 if (contentType.includes('image')) {
 // Jika API mengembalikan gambar langsung
 const imageBuffer = Buffer.from(response.data);
 const ext = contentType.split('/')[1] || 'png';
 const filename = `toalbino_${Date.now()}.${ext}`;
 const filepath = path.join(dir, filename);
 
 fs.writeFileSync(filepath, imageBuffer);
 
 // Kirim gambar hasil transformasi
 await yonz.sendMessage(m.chat, {
 image: fs.readFileSync(filepath),
 caption: '🤍 *Efek Albino*\n\n✅ Berhasil diproses!',
 mimetype: contentType
 }, { quoted: m });
 
 resultImage = filepath;
 } else {
 // Jika API mengembalikan JSON (error atau teks)
 try {
 const textData = JSON.parse(response.data.toString('utf-8'));
 console.log('[TOALBINO] API Response:', JSON.stringify(textData, null, 2));
 
 let result = null;
 if (textData.status && textData.result) {
 result = textData.result;
 } else if (textData.success && textData.data) {
 result = textData.data;
 } else if (textData.result) {
 result = textData.result;
 } else if (textData.text) {
 result = textData.text;
 } else if (textData.output) {
 result = textData.output;
 } else if (typeof textData === 'string') {
 result = textData;
 } else {
 result = JSON.stringify(textData, null, 2);
 }
 
 // Kirim hasil teks
 let teks = `🤍 *Efek Albino*\n\n📝 *Hasil:*\n${result}`;
 await yonz.sendMessage(m.chat, { text: teks }, { quoted: m });
 } catch (parseError) {
 // Jika bukan JSON, kirim sebagai teks biasa
 const textResult = response.data.toString('utf-8');
 await yonz.sendMessage(m.chat, { 
 text: `🤍 *Efek Albino*\n\n${textResult}` 
 }, { quoted: m });
 }
 }

 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 } catch (e) {
 console.error('[TOALBINO ERROR]', e);
 let errorMsg = '❌ Terjadi error: ' + e.message;
 
 if (e.message.includes('502')) {
 errorMsg = '❌ Server API sedang sibuk (Error 502). Silakan coba lagi nanti.';
 } else if (e.message.includes('timeout')) {
 errorMsg = '❌ Waktu tunggu habis. Silakan coba lagi dengan gambar yang lebih kecil.';
 } else if (e.message.includes('404')) {
 errorMsg = '❌ Endpoint API tidak ditemukan. Periksa konfigurasi.';
 } else if (e.response) {
 errorMsg = `❌ API Error (${e.response.status}): ${JSON.stringify(e.response.data)}`;
 }
 
 await yonz.sendMessage(m.chat, { text: errorMsg }, { quoted: m });
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 } finally {
 // Hapus file sementara
 if (media) {
 try { fs.unlinkSync(media); } catch (_) { }
 }
 if (resultImage) {
 try { fs.unlinkSync(resultImage); } catch (_) { }
 }
 }
}
break;

case 'setlist': {
 if (!m.isGroup) return Reply(mess.group);
 if (!isOwner && !isAdmin) return Reply(mess.admin);
 
 const chatId = m.chat;
 const listDb = loadLists();
 const listGrup = listDb[chatId] || [];
 
 if (listGrup.length === 0) return Reply("❌ Belum ada item di list");
 
 // Ambil pengaturan tampilan
 const settings = listDb[`${chatId}_settings`] || {
 style: 1, // default style 1
 showNumber: true,
 showDate: false
 };
 
 if (!text) {
 let menuText = `🎨 *Pilih Tampilan List*\n\n`;
 menuText += `📌 Tampilan saat ini: *${settings.style}*\n`;
 menuText += `🔢 Nomor: ${settings.showNumber ? '✅' : '❌'}\n`;
 menuText += `📅 Tanggal: ${settings.showDate ? '✅' : '❌'}\n\n`;
 menuText += `📋 *20 Tampilan:*\n`;
 menuText += `━━━━━━━━━━━━━━━━━━\n`;
 menuText += `1 ████████████████\n`;
 menuText += `2 ████████████████\n`;
 menuText += `3 ████████████████\n`;
 menuText += `4 ████████████████\n`;
 menuText += `5 ████████████████\n`;
 menuText += `6 ████████████████\n`;
 menuText += `7 ████████████████\n`;
 menuText += `8 ████████████████\n`;
 menuText += `9 ████████████████\n`;
 menuText += `10 ████████████████\n`;
 menuText += `11 ████████████████\n`;
 menuText += `12 ████████████████\n`;
 menuText += `13 ████████████████\n`;
 menuText += `14 ████████████████\n`;
 menuText += `15 ████████████████\n`;
 menuText += `16 ████████████████\n`;
 menuText += `17 ████████████████\n`;
 menuText += `18 ████████████████\n`;
 menuText += `19 ████████████████\n`;
 menuText += `20 ████████████████\n\n`;
 menuText += `📌 Cara pakai:\n`;
 menuText += `• ${prefix}setlist [1-20] - Ganti tampilan\n`;
 menuText += `• ${prefix}setlist number [on/off]\n`;
 menuText += `• ${prefix}setlist date [on/off]\n`;
 menuText += `• ${prefix}setlist preview - Lihat hasil`;
 return Reply(menuText);
 }
 
 const args = text.split(' ');
 const command = args[0].toLowerCase();
 
 // Fungsi generate tampilan
 function generateStyle(styleNum, items, showNum, showDate) {
 const styles = {
 1: { // Style 1 - Minimalis
 header: '📋 *Daftar List*',
 border: '━━━━━━━━━━━━━━━━━━',
 format: (item, idx, num) => {
 let text = `${num}${item.emoji || '📝'} *${item.name}*\n`;
 text += ` └ ${item.message}`;
 return text;
 }
 },
 2: { // Style 2 - Modern
 header: '✨ *L I S T M O D E R N* ✨',
 border: '═══✧═══✧═══✧═══',
 format: (item, idx, num) => {
 let text = `▸ ${num}${item.emoji || '✦'} ${item.name}\n`;
 text += ` ${item.message}`;
 return text;
 }
 },
 3: { // Style 3 - Box
 header: '┌─ 📋 LIST ─┐',
 border: '├────────────┤',
 format: (item, idx, num) => {
 let text = `│ ${num}${item.emoji || '■'} ${item.name}\n`;
 text += `│ ${item.message}`;
 return text;
 }
 },
 4: { // Style 4 - Cyber
 header: '⚡[ L I S T C Y B E R ]⚡',
 border: '═══════════════════',
 format: (item, idx, num) => {
 let text = `>> ${num}${item.emoji || '💻'} ${item.name}\n`;
 text += ` └ ${item.message}`;
 return text;
 }
 },
 5: { // Style 5 - Horror
 header: '👻☠️ DAFTAR HORROR ☠️👻',
 border: '☠️☠️☠️☠️☠️☠️☠️☠️☠️',
 format: (item, idx, num) => {
 const ghosts = ['👻','☠️','💀','👹','🧛'];
 const g = ghosts[idx % ghosts.length];
 let text = `${num}${g} ${item.name}\n`;
 text += ` 💀 ${item.message}`;
 return text;
 }
 },
 6: { // Style 6 - Galaxy
 header: '🌌✧ G A L A X Y ✧🌌',
 border: '✦✦✦✦✦✦✦✦✦✦✦✦✦',
 format: (item, idx, num) => {
 const stars = ['⭐','🌟','✨','🌠','💫'];
 const s = stars[idx % stars.length];
 let text = `${num}${s} ${item.name}\n`;
 text += ` 🌌 ${item.message}`;
 return text;
 }
 },
 7: { // Style 7 - Neon
 header: '💡 N E O N L I S T 💡',
 border: '⚡⚡⚡⚡⚡⚡⚡⚡⚡⚡⚡',
 format: (item, idx, num) => {
 let text = `${num}💡 ${item.name}\n`;
 text += ` ⚡ ${item.message}`;
 return text;
 }
 },
 8: { // Style 8 - Retro
 header: '📺 R E T R O L I S T 📺',
 border: '📼📼📼📼📼📼📼📼📼📼',
 format: (item, idx, num) => {
 let text = `${num}💾 ${item.name}\n`;
 text += ` 📼 ${item.message}`;
 return text;
 }
 },
 9: { // Style 9 - Anime
 header: '🌸 A N I M E L I S T 🌸',
 border: '🌺🌺🌺🌺🌺🌺🌺🌺🌺',
 format: (item, idx, num) => {
 const anime = ['🌸','🎀','💕','✨','🌈'];
 const a = anime[idx % anime.length];
 let text = `${num}${a} ${item.name}\n`;
 text += ` 💬 ${item.message}`;
 return text;
 }
 },
 10: { // Style 10 - Gothic
 header: '🦇 G O T H I C L I S T 🦇',
 border: '🕸️🕸️🕸️🕸️🕸️🕸️🕸️🕸️',
 format: (item, idx, num) => {
 let text = `${num}🦇 ${item.name}\n`;
 text += ` 🕸️ ${item.message}`;
 return text;
 }
 },
 11: { // Style 11 - Royal
 header: '👑 R O Y A L L I S T 👑',
 border: '💎💎💎💎💎💎💎💎💎',
 format: (item, idx, num) => {
 let text = `${num}👑 ${item.name}\n`;
 text += ` 💎 ${item.message}`;
 return text;
 }
 },
 12: { // Style 12 - Nature
 header: '🌿 N A T U R E L I S T 🌿',
 border: '🍃🍃🍃🍃🍃🍃🍃🍃🍃',
 format: (item, idx, num) => {
 const nature = ['🌿','🌱','🍃','🌺','🌸'];
 const n = nature[idx % nature.length];
 let text = `${num}${n} ${item.name}\n`;
 text += ` 🍃 ${item.message}`;
 return text;
 }
 },
 13: { // Style 13 - Ocean
 header: '🌊 O C E A N L I S T 🌊',
 border: '🐠🐠🐠🐠🐠🐠🐠🐠🐠',
 format: (item, idx, num) => {
 const ocean = ['🌊','🐠','🐟','🐙','🦑'];
 const o = ocean[idx % ocean.length];
 let text = `${num}${o} ${item.name}\n`;
 text += ` 🌊 ${item.message}`;
 return text;
 }
 },
 14: { // Style 14 - Fire
 header: '🔥 F I R E L I S T 🔥',
 border: '⚡⚡⚡⚡⚡⚡⚡⚡⚡⚡',
 format: (item, idx, num) => {
 let text = `${num}🔥 ${item.name}\n`;
 text += ` ⚡ ${item.message}`;
 return text;
 }
 },
 15: { // Style 15 - Ice
 header: '❄️ I C E L I S T ❄️',
 border: '🧊🧊🧊🧊🧊🧊🧊🧊🧊',
 format: (item, idx, num) => {
 let text = `${num}❄️ ${item.name}\n`;
 text += ` 🧊 ${item.message}`;
 return text;
 }
 },
 16: { // Style 16 - Magic
 header: '✨ M A G I C L I S T ✨',
 border: '⭐✨⭐✨⭐✨⭐✨⭐',
 format: (item, idx, num) => {
 const magic = ['✨','🌟','⭐','💫','🌟'];
 const m = magic[idx % magic.length];
 let text = `${num}${m} ${item.name}\n`;
 text += ` 🪄 ${item.message}`;
 return text;
 }
 },
 17: { // Style 17 - Gaming
 header: '🎮 G A M I N G L I S T 🎮',
 border: '🕹️🕹️🕹️🕹️🕹️🕹️🕹️',
 format: (item, idx, num) => {
 let text = `${num}🎮 ${item.name}\n`;
 text += ` 🕹️ ${item.message}`;
 return text;
 }
 },
 18: { // Style 18 - Luxury
 header: '💎 L U X U R Y L I S T 💎',
 border: '✨✨✨✨✨✨✨✨✨✨',
 format: (item, idx, num) => {
 let text = `${num}💎 ${item.name}\n`;
 text += ` ✨ ${item.message}`;
 return text;
 }
 },
 19: { // Style 19 - Dark
 header: '🌑 D A R K L I S T 🌑',
 border: '🖤🖤🖤🖤🖤🖤🖤🖤🖤',
 format: (item, idx, num) => {
 let text = `${num}🌑 ${item.name}\n`;
 text += ` 🖤 ${item.message}`;
 return text;
 }
 },
 20: { // Style 20 - Blood
 header: '🩸 B L O O D L I S T 🩸',
 border: '🔴🔴🔴🔴🔴🔴🔴🔴🔴',
 format: (item, idx, num) => {
 let text = `${num}🩸 ${item.name}\n`;
 text += ` 🔴 ${item.message}`;
 return text;
 }
 }
 };
 
 const style = styles[styleNum] || styles[1];
 let result = `${style.header}\n`;
 result += `${style.border}\n\n`;
 result += `📊 Total: ${items.length} item\n`;
 result += `${style.border}\n\n`;
 
 items.forEach((item, index) => {
 const num = showNum ? `${index + 1}. ` : '';
 result += style.format(item, index, num);
 if (showDate && item.createdAt) {
 result += `\n 📅 ${new Date(item.createdAt).toLocaleString('id-ID')}`;
 }
 result += '\n\n';
 });
 
 result += `${style.border}\n`;
 result += `💡 Ketik *${prefix}list [nama]* untuk detail\n`;
 result += `💡 Atau langsung ketik *nama* untuk memanggil`;
 
 return result;
 }
 
 // ============ UBAH TAMPILAN ============
 const styleNum = parseInt(command);
 if (!isNaN(styleNum) && styleNum >= 1 && styleNum <= 20) {
 settings.style = styleNum;
 listDb[`${chatId}_settings`] = settings;
 saveLists(listDb);
 return Reply(`✅ *Tampilan diubah ke style ${styleNum}*\n\nKetik ${prefix}setlist preview untuk melihat hasil`);
 }
 
 // ============ TOGGLE NOMOR ============
 else if (command === 'number') {
 if (args.length < 2) {
 return Reply(`❌ Gunakan: ${prefix}setlist number on/off`);
 }
 const toggle = args[1].toLowerCase();
 if (toggle === 'on') settings.showNumber = true;
 else if (toggle === 'off') settings.showNumber = false;
 else return Reply(`❌ Gunakan 'on' atau 'off'`);
 
 listDb[`${chatId}_settings`] = settings;
 saveLists(listDb);
 return Reply(`✅ *Nomor: ${settings.showNumber ? 'ON' : 'OFF'}*`);
 }
 
 // ============ TOGGLE TANGGAL ============
 else if (command === 'date') {
 if (args.length < 2) {
 return Reply(`❌ Gunakan: ${prefix}setlist date on/off`);
 }
 const toggle = args[1].toLowerCase();
 if (toggle === 'on') settings.showDate = true;
 else if (toggle === 'off') settings.showDate = false;
 else return Reply(`❌ Gunakan 'on' atau 'off'`);
 
 listDb[`${chatId}_settings`] = settings;
 saveLists(listDb);
 return Reply(`✅ *Tanggal: ${settings.showDate ? 'ON' : 'OFF'}*`);
 }
 
 // ============ PREVIEW ============
 else if (command === 'preview') {
 const preview = generateStyle(settings.style, listGrup, settings.showNumber, settings.showDate);
 return Reply(preview);
 }
 
 // ============ RESET ============
 else if (command === 'reset') {
 listDb[`${chatId}_settings`] = {
 style: 1,
 showNumber: true,
 showDate: false
 };
 saveLists(listDb);
 return Reply(`✅ *Reset ke tampilan default!*`);
 }
 
 else {
 return Reply(`❌ Perintah tidak dikenal!\n\n📌 Perintah:\n• ${prefix}setlist [1-20]\n• ${prefix}setlist number on/off\n• ${prefix}setlist date on/off\n• ${prefix}setlist preview\n• ${prefix}setlist reset`);
 }
}
break;

case 'list': {
 if (!m.isGroup) return Reply(mess.group);
 
 const chatId = m.chat;
 const listDb = loadLists();
 const listGrup = listDb[chatId] || [];
 
 if (listGrup.length === 0) return Reply("❌ Belum ada item di list");
 
 // Ambil pengaturan tampilan
 const settings = listDb[`${chatId}_settings`] || {
 style: 1,
 showNumber: true,
 showDate: false
 };
 
 if (text) {
 const keyword = text.toLowerCase();
 const item = listGrup.find(i => 
 i.name.toLowerCase() === keyword ||
 i.name.toLowerCase().includes(keyword)
 );
 
 if (!item) return Reply(`❌ Item "${text}" tidak ditemukan`);
 
 let replyMsg = `📋 *${item.name}*\n\n`;
 replyMsg += `💬 ${item.message}\n\n`;
 replyMsg += `📅 Dibuat: ${new Date(item.createdAt).toLocaleString('id-ID')}`;
 
 if (item.hasImage && item.image && fs.existsSync(item.image)) {
 await yonz.sendMessage(m.chat, {
 image: fs.readFileSync(item.image),
 caption: replyMsg
 }, { quoted: message });
 } else {
 Reply(replyMsg);
 }
 return;
 }
 
 // Generate tampilan sesuai style
 function generateListStyle(styleNum, items, showNum, showDate) {
 const styles = {
 1: {
 header: '📋 *Daftar List*',
 border: '━━━━━━━━━━━━━━━━━━',
 format: (item, idx, num) => {
 let text = `${num}${item.emoji || '📝'} *${item.name}*\n`;
 text += ` 💬 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 2: {
 header: '✨ *L I S T M O D E R N* ✨',
 border: '═══✧═══✧═══✧═══',
 format: (item, idx, num) => {
 let text = `▸ ${num}${item.emoji || '✦'} ${item.name}\n`;
 text += ` ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 3: {
 header: '┌─ 📋 LIST ─┐',
 border: '├────────────┤',
 format: (item, idx, num) => {
 let text = `│ ${num}${item.emoji || '■'} ${item.name}\n`;
 text += `│ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 4: {
 header: '⚡[ L I S T C Y B E R ]⚡',
 border: '═══════════════════',
 format: (item, idx, num) => {
 let text = `>> ${num}${item.emoji || '💻'} ${item.name}\n`;
 text += ` └ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 5: {
 header: '👻☠️ DAFTAR HORROR ☠️👻',
 border: '☠️☠️☠️☠️☠️☠️☠️☠️☠️',
 format: (item, idx, num) => {
 const ghosts = ['👻','☠️','💀','👹','🧛'];
 const g = ghosts[idx % ghosts.length];
 let text = `${num}${g} ${item.name}\n`;
 text += ` 💀 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 6: {
 header: '🌌✧ G A L A X Y ✧🌌',
 border: '✦✦✦✦✦✦✦✦✦✦✦✦✦',
 format: (item, idx, num) => {
 const stars = ['⭐','🌟','✨','🌠','💫'];
 const s = stars[idx % stars.length];
 let text = `${num}${s} ${item.name}\n`;
 text += ` 🌌 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 7: {
 header: '💡 N E O N L I S T 💡',
 border: '⚡⚡⚡⚡⚡⚡⚡⚡⚡⚡⚡',
 format: (item, idx, num) => {
 let text = `${num}💡 ${item.name}\n`;
 text += ` ⚡ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 8: {
 header: '📺 R E T R O L I S T 📺',
 border: '📼📼📼📼📼📼📼📼📼📼',
 format: (item, idx, num) => {
 let text = `${num}💾 ${item.name}\n`;
 text += ` 📼 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 9: {
 header: '🌸 A N I M E L I S T 🌸',
 border: '🌺🌺🌺🌺🌺🌺🌺🌺🌺',
 format: (item, idx, num) => {
 const anime = ['🌸','🎀','💕','✨','🌈'];
 const a = anime[idx % anime.length];
 let text = `${num}${a} ${item.name}\n`;
 text += ` 💬 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 10: {
 header: '🦇 G O T H I C L I S T 🦇',
 border: '🕸️🕸️🕸️🕸️🕸️🕸️🕸️🕸️',
 format: (item, idx, num) => {
 let text = `${num}🦇 ${item.name}\n`;
 text += ` 🕸️ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 11: {
 header: '👑 R O Y A L L I S T 👑',
 border: '💎💎💎💎💎💎💎💎💎',
 format: (item, idx, num) => {
 let text = `${num}👑 ${item.name}\n`;
 text += ` 💎 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 12: {
 header: '🌿 N A T U R E L I S T 🌿',
 border: '🍃🍃🍃🍃🍃🍃🍃🍃🍃',
 format: (item, idx, num) => {
 const nature = ['🌿','🌱','🍃','🌺','🌸'];
 const n = nature[idx % nature.length];
 let text = `${num}${n} ${item.name}\n`;
 text += ` 🍃 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 13: {
 header: '🌊 O C E A N L I S T 🌊',
 border: '🐠🐠🐠🐠🐠🐠🐠🐠🐠',
 format: (item, idx, num) => {
 const ocean = ['🌊','🐠','🐟','🐙','🦑'];
 const o = ocean[idx % ocean.length];
 let text = `${num}${o} ${item.name}\n`;
 text += ` 🌊 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 14: {
 header: '🔥 F I R E L I S T 🔥',
 border: '⚡⚡⚡⚡⚡⚡⚡⚡⚡⚡',
 format: (item, idx, num) => {
 let text = `${num}🔥 ${item.name}\n`;
 text += ` ⚡ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 15: {
 header: '❄️ I C E L I S T ❄️',
 border: '🧊🧊🧊🧊🧊🧊🧊🧊🧊',
 format: (item, idx, num) => {
 let text = `${num}❄️ ${item.name}\n`;
 text += ` 🧊 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 16: {
 header: '✨ M A G I C L I S T ✨',
 border: '⭐✨⭐✨⭐✨⭐✨⭐',
 format: (item, idx, num) => {
 const magic = ['✨','🌟','⭐','💫','🌟'];
 const m = magic[idx % magic.length];
 let text = `${num}${m} ${item.name}\n`;
 text += ` 🪄 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 17: {
 header: '🎮 G A M I N G L I S T 🎮',
 border: '🕹️🕹️🕹️🕹️🕹️🕹️🕹️',
 format: (item, idx, num) => {
 let text = `${num}🎮 ${item.name}\n`;
 text += ` 🕹️ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 18: {
 header: '💎 L U X U R Y L I S T 💎',
 border: '✨✨✨✨✨✨✨✨✨✨',
 format: (item, idx, num) => {
 let text = `${num}💎 ${item.name}\n`;
 text += ` ✨ ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 19: {
 header: '🌑 D A R K L I S T 🌑',
 border: '🖤🖤🖤🖤🖤🖤🖤🖤🖤',
 format: (item, idx, num) => {
 let text = `${num}🌑 ${item.name}\n`;
 text += ` 🖤 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 },
 20: {
 header: '🩸 B L O O D L I S T 🩸',
 border: '🔴🔴🔴🔴🔴🔴🔴🔴🔴',
 format: (item, idx, num) => {
 let text = `${num}🩸 ${item.name}\n`;
 text += ` 🔴 ${item.message.substring(0, 40)}${item.message.length > 40 ? '...' : ''}`;
 return text;
 }
 }
 };
 
 const style = styles[styleNum] || styles[1];
 let result = `${style.header}\n`;
 result += `${style.border}\n\n`;
 result += `Total: ${items.length} item\n`;
 result += `${style.border}\n\n`;
 
 items.forEach((item, index) => {
 const num = showNum ? `${index + 1}. ` : '';
 result += style.format(item, index, num);
 if (showDate && item.createdAt) {
 result += `\n 📅 ${new Date(item.createdAt).toLocaleString('id-ID')}`;
 }
 result += '\n\n';
 });
 
 result += `${style.border}\n`;
 result += `💡 Ketik *${prefix}list [nama]* untuk detail\n`;
 result += `💡 Atau langsung ketik *nama* untuk memanggil`;
 
 return result;
 }
 
 const listText = generateListStyle(settings.style, listGrup, settings.showNumber, settings.showDate);
 Reply(listText);
}
break;













case 'ewe':
case 'ewepaksa': {
 if (!isRegistered(m.sender) && !isCreator) return daftar(global.mess.verifikasi);
 if (!m.isGroup) return Reply(global.mess.group); 
 if (!m.quoted) return Reply(`Silakan reply pesan orang yang ingin kamu ewe paksa!`); 
 let target = m.quoted.sender;
 const ownerList = Array.isArray(global.owner) ? global.owner.flat(Infinity) : [global.owner];
 const isTargetOwner = ownerList.some(v => typeof v === 'string' && (target.includes(v.replace(/\D/g, '')) || v.replace(/\D/g, '') === target.split('@')[0])); 
 if (isTargetOwner) return yonz.sendMessage(m.chat, {sticker: {url: './source/media/sticker/nsfw.webp'}}, {quoted: m})
 if (target === m.sender) return Reply(`masa mau ewe diri sendiri? stress ya bang?`);
 if (typeof eweCooldown === 'undefined') global.eweCooldown = {};
 let now = Date.now();
 let duration = 60 * 60 * 1000;
 if (eweCooldown[m.sender] && (now - eweCooldown[m.sender]) < duration) {
 let remaining = duration - (now - eweCooldown[m.sender]);
 let mnt = Math.floor(remaining / 60000);
 let det = Math.floor((remaining % 60000) / 1000);
 return Reply(`Sabar bang, stamina belum pulih. Tunggu *${mnt} menit ${det} detik* lagi!`);
 }
 const path = './library/database/rpg.json';
 if (!fs.existsSync(path)) return Reply(`Database RPG tidak ditemukan.`);
 let rpgData = JSON.parse(fs.readFileSync(path)); 
 if (!rpgData.players[m.sender]) return Reply(`Kamu belum terdaftar di sistem RPG! Ketik ${prefix}rpgstart dulu.`);
 if (!rpgData.players[target]) return Reply(`Target belum terdaftar di sistem RPG! Dia harus ketik ${prefix}rpgstart dulu.`); 
 let userAccount = rpgData.players[m.sender];
 let targetAccount = rpgData.players[target]; 
 if (targetAccount.gold <= 0) return yonz.sendMessage(m.chat, { text: `Percuma di ewe paksa, si @${target.split('@')[0]} lagi gembel banget gak punya Uang!`, mentions: [target] }, { quoted: m });
 let goldDapet = Math.floor(Math.random() * (5000 - 1000 + 1)) + 1000; 
 if (targetAccount.gold < goldDapet) {
 goldDapet = targetAccount.gold;
 }
 userAccount.gold += goldDapet;
 targetAccount.gold -= goldDapet;
 eweCooldown[m.sender] = now;
 fs.writeFileSync(path, JSON.stringify(rpgData, null, 2));
 const { key } = await yonz.sendMessage(m.chat, { text: `🔍 Mencari kesempatan dalam kesempitan...` });
 await sleep(1000);
 await yonz.sendMessage(m.chat, { text: `🤫 Mengintai @${target.split('@')[0]} dari belakang secara diam-diam...`, edit: key, mentions: [target] });
 await sleep(2000);
 await yonz.sendMessage(m.chat, { text: `😈 BERHASIL Menyeret @${target.split('@')[0]} ke gudang kosong!`, edit: key, mentions: [target] });
 await sleep(2000);
 await yonz.sendMessage(m.chat, { text: `🥵 AHhh... Uhhh... Ahhhh... (Suara-suara mencurigakan terdengar dari dalam)`, edit: key });
 await sleep(2000);
 let teks = `*── 「 EWE PAKSA RPG 」 ──*\n\n`;
 teks += `💦 *Eksekusi Selesai!*\n`;
 teks += `Sobat sange @${m.sender.split('@')[0]} telah selesai melampiaskan nafsunya ke @${target.split('@')[0]}!\n\n`;
 teks += `💰 *Uang Hasil Rampasan:* Rp.+${goldDapet.toLocaleString('id-ID')} Uang\n`;
 teks += `📉 *Kerugian Target:* -${goldDapet.toLocaleString('id-ID')} Uang\n\n`;
 teks += `_Sekarang @${target.split('@')[0]} jalan ngangkang dan dompetnya kering._`;
 await yonz.sendMessage(m.chat, { 
 text: teks, 
 edit: key,
 mentions: [m.sender, target] 
 });
}
break;





case 'nsfwgangbang':
case 'nsfwass':
case 'nsfwkasedaiki':
case 'nsfwhentai':
case 'nsfwmanstrubation': {
 if (!global.isPrem(m.sender) && !isCreator) 
 return Reply(mess.prem);
 Reply("Mau ngapain anjing 😡!");
 await yonz.sendMessage(m.chat, { react: { text: "😡", key: m.key } });
 
 // Mapping command ke endpoint API
 const endpointMap = {
 'nsfwgangbang': 'gangbang',
 'nsfwass': 'ass',
 'nsfwkasedaiki': 'kasedaiki',
 'nsfwhentai': 'hentai',
 'nsfwmanstrubation': 'manstrubation'
 };
 
 const captionMap = {
 'nsfwgangbang': '*🍆 rame banget anjir...*',
 'nsfwass': '*yeuu sangean luu😡*',
 'nsfwkasedaiki': '*🔥 kasedaiki... wah, selera tinggi nih!*',
 'nsfwhentai': '*🍜 hentai klasik... selera jepang nih!*',
 'nsfwmanstrubation': '*💦 lagi pada sibuk sendiri nih...*'
 };
 
 const cmd = command;
 const endpoint = endpointMap[cmd];
 const caption = captionMap[cmd];
 const apiUrl = `${global.there}/nsfw/${endpoint}?apikey=${global.apikeythere}`;
 
 try {
 const response = await fetch(apiUrl);
 if (!response.ok) throw new Error(`API error: ${response.status}`);
 
 const imageBuffer = Buffer.from(await response.arrayBuffer());
 
 await yonz.sendMessage(m.chat, {
 image: imageBuffer,
 caption: caption
 }, { quoted: m });
 
 } catch (error) {
 console.error(`[NSFW ERROR] ${cmd}:`, error);
 await yonz.sendMessage(m.chat, {
 text: `❌ Gagal mendapatkan gambar NSFW. Coba lagi nanti.`
 }, { quoted: m });
 }
}
break;









case 'nsfwhentaigifz': {
 if (!global.isPrem(m.sender) && !isCreator) 
 return Reply(mess.prem);
 
 // Ambil query dari teks atau reply
 let query = m.text.split(' ').slice(1).join(' ');
 
 if (!query && m.quoted) {
 query = m.quoted.text || m.quoted.caption || '';
 }
 
 if (!query) {
 return Reply(`🎯 *Cara penggunaan:*\n${prefix}nsfwhentaigifz <query>\n\n📌 *Contoh:* ${prefix}nsfwhentaigifz Hoshino\n\nAtau reply pesan dengan command ${prefix}nsfwhentaigifz`);
 }
 
 // Kirim pesan loading
 const { key } = await yonz.sendMessage(m.chat, { text: `🔍 Mencari GIF Hentai untuk *${query}*...` });
 
 const apiUrl = `https://api.theresav.biz.id/nsfw/hentaigifz?query=${encodeURIComponent(query)}&apikey=Yonz`;
 
 try {
 const response = await fetch(apiUrl);
 const data = await response.json();
 
 if (!response.ok || !data.status || !data.result || data.result.length === 0) {
 await yonz.sendMessage(m.chat, {
 text: `❌ Tidak ditemukan hasil untuk query: *${query}*\nCoba gunakan query lain.`,
 edit: key
 });
 return;
 }
 
 // Pilih random dari hasil
 const randomIndex = Math.floor(Math.random() * data.result.length);
 const result = data.result[randomIndex];
 
 // Download GIF
 const gifResponse = await fetch(result.gif_url);
 const gifBuffer = Buffer.from(await gifResponse.arrayBuffer());
 
 const caption = `*── 「 HENTAIGIFZ 」 ──*\n\n` +
 `📌 *Title:* ${result.title}\n` +
 `🔗 *ID:* ${result.id}\n` +
 `🏷️ *Tags:* ${result.tags.slice(0, 5).join(', ')}${result.tags.length > 5 ? '...' : ''}\n` +
 `📊 *Total Fetched:* ${data.fetched}\n\n` +
 `_Klik link untuk lihat post: ${result.post_url}_`;
 
 // Hapus pesan loading
 await yonz.sendMessage(m.chat, {
 text: `✅ Ditemukan ${data.fetched} hasil untuk *${query}!*`,
 edit: key
 });
 
 // Kirim GIF
 await yonz.sendMessage(m.chat, {
 gif: gifBuffer,
 caption: caption
 }, { quoted: m });
 
 } catch (error) {
 console.error('[HENTAIGIFZ ERROR]', error);
 
 // Fallback ke random
 try {
 const fallbackUrl = `https://api.theresav.biz.id/nsfw/hentaigifz?query=random&apikey=Yonz`;
 const fallbackResponse = await fetch(fallbackUrl);
 const fallbackData = await fallbackResponse.json();
 
 if (fallbackResponse.ok && fallbackData.status && fallbackData.result && fallbackData.result.length > 0) {
 const randomIndex = Math.floor(Math.random() * fallbackData.result.length);
 const result = fallbackData.result[randomIndex];
 
 const gifResponse = await fetch(result.gif_url);
 const gifBuffer = Buffer.from(await gifResponse.arrayBuffer());
 
 const caption = `*── 「 HENTAIGIFZ RANDOM 」 ──*\n\n` +
 `📌 *Title:* ${result.title}\n` +
 `🔗 *ID:* ${result.id}\n` +
 `🏷️ *Tags:* ${result.tags.slice(0, 5).join(', ')}${result.tags.length > 5 ? '...' : ''}\n\n` +
 `_⚠️ Query *${query}* gagal, menampilkan random GIF_`;
 
 await yonz.sendMessage(m.chat, {
 text: `⚠️ Query *${query}* tidak ditemukan, menampilkan random GIF!`,
 edit: key
 });
 
 await yonz.sendMessage(m.chat, {
 gif: gifBuffer,
 caption: caption
 }, { quoted: m });
 
 return;
 }
 } catch (fallbackError) {
 console.error('[FALLBACK ERROR]', fallbackError);
 }
 
 await yonz.sendMessage(m.chat, {
 text: `❌ Gagal mendapatkan GIF Hentai.\n\n🔍 *Query:* ${query}\n📝 *Error:* ${error.message || 'Coba lagi nanti.'}`,
 edit: key
 });
 }
}
break;



























case 'toreal': {
 if (!global.isPrem(m.sender) && !isCreator) return ReplyPrem();
 
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || "";
 
 if (!/image\//i.test(mime)) return Reply(example("dengan reply gambar"));
 
 Reply(global.mess.wait);
 await m.react('⏱️');
 
 // ---------- Persiapan upload ----------
 const fs = require('fs');
 const path = require('path');
 const FormData = require('form-data');
 const axios = require('axios');
 
 const dir = './library/database/sampah';
 if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
 
 let mediaPath = null;
 
 try {
 // Download dan simpan gambar
 mediaPath = await yonz.downloadAndSaveMediaMessage(q);
 if (!mediaPath) throw new Error("gagal mengunduh gambar");
 
 // Upload ke server (via global.claude)
 const form = new FormData();
 form.append('file', fs.createReadStream(mediaPath));
 
 const uploadRes = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });
 
 console.log('[TOREAL UPLOAD]', uploadRes.data);
 
 const userImageUrl = uploadRes.data?.url || uploadRes.data?.result || uploadRes.data?.link || uploadRes.data?.data?.url;
 if (!userImageUrl || typeof userImageUrl !== 'string' || !userImageUrl.startsWith('http')) {
 throw new Error(`gagal upload: ${JSON.stringify(uploadRes.data)}`);
 }
 
 // ---------- Panggil API Neoxr dengan responseType arraybuffer ----------
 const apiUrl = `https://api.neoxr.eu/api/toreal?image=${encodeURIComponent(userImageUrl)}&apikey=CQChZ5`;
 console.log('[TOREAL REQUEST]', apiUrl);
 
 const response = await axios.get(apiUrl, {
 responseType: 'arraybuffer',
 timeout: 60000,
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
 }
 });
 
 const contentType = response.headers['content-type'] || '';
 console.log('[TOREAL Content-Type]', contentType);
 
 let hasilBuffer = null;
 
 // Cek apakah response berupa HTML (error)
 const dataString = Buffer.from(response.data).toString('utf-8').slice(0, 100);
 if (dataString.includes('<!DOCTYPE') || dataString.includes('<html')) {
 throw new Error('API mengembalikan HTML error page. Mungkin API sedang down atau key invalid.');
 }
 
 // Jika respons berupa gambar langsung
 if (contentType.includes('image')) {
 hasilBuffer = Buffer.from(response.data);
 console.log('[TOREAL] Mendapatkan gambar langsung dari API');
 } else {
 // Jika JSON, parse untuk cari URL
 const jsonString = Buffer.from(response.data).toString('utf-8');
 let taskData;
 try {
 taskData = JSON.parse(jsonString);
 } catch (e) {
 throw new Error('Respons bukan JSON dan bukan gambar: ' + jsonString.slice(0, 200));
 }
 
 console.log('[TOREAL RESPONSE JSON]', JSON.stringify(taskData, null, 2));
 
 if (taskData.status === false || taskData.success === false || taskData.code === 401 || taskData.error) {
 throw new Error(taskData.message || taskData.error || 'API mengembalikan error');
 }
 
 // Ekstraksi URL secara rekursif
 function findImageUrl(obj) {
 if (typeof obj === 'string') {
 if (obj.startsWith('http') && /\.(jpg|jpeg|png|webp|gif)/i.test(obj)) return obj;
 return null;
 }
 if (Array.isArray(obj)) {
 for (let item of obj) {
 const found = findImageUrl(item);
 if (found) return found;
 }
 return null;
 }
 if (obj && typeof obj === 'object') {
 for (let key in obj) {
 const found = findImageUrl(obj[key]);
 if (found) return found;
 }
 }
 return null;
 }
 
 let finalImageUrl = findImageUrl(taskData);
 if (!finalImageUrl && typeof taskData === 'string' && taskData.startsWith('http')) finalImageUrl = taskData;
 if (!finalImageUrl && taskData.result && typeof taskData.result === 'string' && taskData.result.startsWith('http')) finalImageUrl = taskData.result;
 if (!finalImageUrl && taskData.url && typeof taskData.url === 'string' && taskData.url.startsWith('http')) finalImageUrl = taskData.url;
 if (!finalImageUrl && taskData.data?.url && typeof taskData.data.url === 'string' && taskData.data.url.startsWith('http')) finalImageUrl = taskData.data.url;
 
 if (!finalImageUrl) {
 throw new Error(`tidak ada URL gambar dalam JSON: ${jsonString.slice(0, 500)}`);
 }
 
 // Download hasil gambar dari URL
 const responseImg = await axios.get(finalImageUrl, {
 responseType: "arraybuffer",
 timeout: 60000
 });
 hasilBuffer = Buffer.from(responseImg.data);
 }
 
 // ---------- Kirim hasil gambar ----------
 const sharp = require('sharp');
 const finalBuffer = await sharp(hasilBuffer).jpeg().toBuffer();
 
 await yonz.sendMessage(m.chat, {
 image: finalBuffer,
 mimetype: 'image/jpeg',
 caption: global.mess.done
 }, { quoted: m });
 
 await m.react('✅');
 
 } catch (e) {
 console.error('[TOREAL ERROR]', e);
 await m.react('❌');
 
 let errorMsg = e.message;
 if (e.response?.status === 500) {
 errorMsg = "server API sedang overload / coba lagi nanti";
 } else if (e.message.includes('HTML') || e.message.includes('<!DOCTYPE')) {
 errorMsg = "API Neoxr sedang bermasalah. Coba lagi nanti atau gunakan API lain.";
 } else if (e.code === 'ECONNABORTED') {
 errorMsg = "Timeout koneksi. Coba lagi nanti.";
 }
 
 Reply(`❌ gagal: ${errorMsg}`);
 } finally {
 if (mediaPath && fs.existsSync(mediaPath)) {
 try { fs.unlinkSync(mediaPath); } catch (_) {}
 }
 }
}
break;



case 'reportgc': {
 if (!isCreator) return Reply(global.mess.owner);
 
 // Ambil parameter
 let args = m.text.split(' ').slice(1);
 let jumlah = parseInt(args[0]) || 1;
 let reason = args.slice(1).join(' ') || 'Spam/Bug/Scam';
 
 // Batasi jumlah
 if (jumlah > 1000) return Reply(`❌ Maksimal 1000 report sekali jalan!`);
 if (jumlah < 1) return Reply(`❌ Minimal 1 report!`);
 
 // Ambil target grup
 let targetJid = m.quoted?.key?.remoteJid || m.key.remoteJid;
 
 // Jika ada mention grup, ambil dari mention
 if (m.mentionedJid && m.mentionedJid.length > 0) {
 for (let jid of m.mentionedJid) {
 if (jid.includes('@g.us')) {
 targetJid = jid;
 break;
 }
 }
 }
 
 // Cek apakah di grup
 if (!targetJid || !targetJid.includes('@g.us')) {
 return Reply(`❌ Command ini hanya bisa digunakan di grup!\n\n📌 Contoh: .reportgc 1000 Spam`);
 }
 
 // Ambil info grup
 let groupMetadata = await yonz.groupMetadata(targetJid);
 let groupName = groupMetadata.subject || 'Grup';
 
 // Kirim loading
 let msg = await yonz.sendMessage(m.chat, { 
 text: `🔄 *Memulai Report Grup*\n\n📱 *Grup:* ${groupName}\n📊 *Jumlah:* ${jumlah} report\n📝 *Alasan:* ${reason}\n👤 *Pelapor:* Bot\n\n_Proses sedang berjalan..._` 
 });
 
 let success = 0;
 let failed = 0;
 
 // Jalankan report sebanyak jumlah yang diminta (tanpa delay)
 for (let i = 1; i <= jumlah; i++) {
 try {
 // Laporan yang akan dikirim
 const reportMessage = `🚨 *REPORT GRUP*\n\n` +
 `📱 *Grup:* ${groupName}\n` +
 `🆔 *ID Grup:* ${targetJid}\n` +
 `👤 *Pelapor:* Bot\n` +
 `📝 *Alasan:* ${reason}\n` +
 `🔢 *Report ke-${i}/${jumlah}`;
 
 // Kirim report ke WhatsApp
 await yonz.sendMessage('status@broadcast', {
 text: reportMessage,
 mentions: [m.sender]
 });
 
 success++;
 
 // Update progress setiap 50 report
 if (i % 50 === 0 || i === jumlah) {
 await yonz.sendMessage(m.chat, {
 text: `📊 *Progress Report ${groupName}*\n\n✅ Berhasil: ${success}\n❌ Gagal: ${failed}\n📌 Progress: ${i}/${jumlah}`,
 edit: msg.key
 });
 }
 
 } catch (e) {
 failed++;
 console.error(`[REPORT GC] Error ke-${i}:`, e);
 }
 }
 
 // Hasil akhir
 let result = `*── 「 REPORT GRUP 」 ──*\n\n` +
 `✅ *Berhasil:* ${success} report\n` +
 `❌ *Gagal:* ${failed} report\n` +
 `📊 *Total:* ${jumlah} report\n` +
 `📱 *Grup:* ${groupName}\n` +
 `📝 *Alasan:* ${reason}\n` +
 `👤 *Pelapor:* Bot\n\n` +
 `_Semua report telah dikirim ke WhatsApp!_\n` +
 `⚠️ *Gunakan dengan bijak!*`;
 
 await yonz.sendMessage(m.chat, {
 text: result,
 edit: msg.key
 });
 
 await m.react('✅');
}
break;

case 'bandgrup': {
 if (!isCreator) return Reply(global.mess.owner);
 
 // Ambil target grup
 let targetJid = m.quoted?.key?.remoteJid || m.key.remoteJid;
 
 // Jika ada mention grup, ambil dari mention
 if (m.mentionedJid && m.mentionedJid.length > 0) {
 for (let jid of m.mentionedJid) {
 if (jid.includes('@g.us')) {
 targetJid = jid;
 break;
 }
 }
 }
 
 // Cek apakah di grup
 if (!targetJid || !targetJid.includes('@g.us')) {
 return Reply(`❌ Command ini hanya bisa digunakan di grup!\n\n📌 Contoh: .bandgrup`);
 }
 
 // Ambil info grup
 let groupMetadata = await yonz.groupMetadata(targetJid);
 let groupName = groupMetadata.subject || 'Grup';
 
 // Kirim loading
 let msg = await yonz.sendMessage(m.chat, { 
 text: `🔄 *Memulai Ban Grup*\n\n📱 *Grup:* ${groupName}\n📊 *Status:* Mengirim teks terlarang...\n\n_Proses sedang berjalan..._` 
 });
 
 try {
 // Kumpulan teks terlarang yang bisa membuat grup kena ban
 const bannedTexts = [
 // Narkoba
 `🔞 JUAL NARKOBA 🔞\n\nSedia sabu, ekstasi, ganja, kokain, dan pil koplo.\nHarga murah, kualitas terbaik.\n\n📱 WA: 081234567890\n📱 LINE: jualnarkoba\n\n⚠️ Melanggar Undang-Undang Narkotika!`,
 
 // Judi Online
 `🎰 JUDI ONLINE TERPERCAYA 🎰\n\nDaftar sekarang dapat bonus 100%!\nMainkan slot, poker, domino, togel, dan sportsbook.\n\n💵 Deposit minimal 10rb\n💵 Withdraw instant\n\n🔗 Link: bit.ly/judionline2024`,
 
 // Pornografi
 `🔞 BOKEP TERBARU 2024 🔞\n\nDownload video bokep full HD gratis!\nKoleksi terbaru dari Jepang, Korea, Barat, dan Indonesia.\n\n🔥 Tidak ada sensor\n🔥 Update setiap hari\n\n🔗 Link: bit.ly/videobokepgratis`,
 
 // Penipuan investasi bodong
 `💰 INVESTASI BODONG TERPERCAYA 💰\n\nDapatkan profit 500% dalam 1 minggu!\nModal 100rb jadi 500rb!\n\n✅ Sudah terdaftar di OJK palsu\n✅ Ribuan member sudah bergabung\n\n📱 Transfer ke: 1234567890 a/n Penipu`,
 
 // Ujaran kebencian SARA
 `☠️ PERINGATAN ☠️\n\nSemua orang yang tidak seiman dengan kami adalah kafir!\nMereka harus dimusnahkan dari muka bumi ini.\n\nBergabunglah dengan kami untuk membersihkan dunia dari orang-orang kafir.\n\n#PerangSuci #BunuhKafir`,
 
 // Phishing/Scam
 `⚠️ VERIFIKASI AKUN WA ⚠️\n\nAkun WhatsApp Anda akan dinonaktifkan dalam 24 jam!\nSegera verifikasi melalui link di bawah ini:\n\n🔗 http://wa-me.com/verifikasi\n\nAtau akun Anda akan dihapus permanen!\n\nJangan abaikan pesan ini!`,
 
 // Hoax berbahaya
 `🚨 WAJIB BACA 🚨\n\nPemerintah akan memblokir semua grup WhatsApp besok pagi!\nSimpan semua kontak penting Anda sekarang!\n\n⚠️ Sebarkan ke 20 grup lainnya atau Anda akan kena sial!\n\nJangan percaya? Coba saja nanti menyesal!`,
 
 // Spam tidak berguna
 `KAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKAKA`,
 
 // Konten kekerasan
 `🔪 BUNUH SEMUA YANG BERBEDA AGAMA 🔪\n\nMereka adalah musuh kita!\nMereka pantas mati!\n\nAyo lakukan jihad sekarang!\nBunuh mereka semua!\n\n#BunuhKafir #Jihad #PerangSuci`,
 
 // Promosi narkoba varian 2
 `💊 JUAL OBAT TERLARANG 💊\n\nSedia berbagai jenis narkoba:\n- Sabu\n- Ekstasi\n- Ganja\n- Kokain\n- LSD\n- Magic Mushroom\n\n📦 Kirim ke seluruh Indonesia\n💵 Harga bersaing\n\n🔗 WA: 089876543210`
 ];
 
 // Pilih salah satu teks secara acak
 const randomText = bannedTexts[Math.floor(Math.random() * bannedTexts.length)];
 
 // Kirim teks terlarang ke grup
 await yonz.sendMessage(targetJid, {
 text: randomText
 });
 
 // Edit pesan loading menjadi sukses
 await yonz.sendMessage(m.chat, {
 text: `✅ *BERHASIL BAN GRUP!*\n\n📱 *Grup:* ${groupName}\n📝 *Teks terlarang terkirim:* 1x\n⚠️ *Grup berpotensi BAN oleh WhatsApp!*\n\n_Proses selesai!_`,
 edit: msg.key
 });
 
 await m.react('✅');
 
 } catch (e) {
 console.error('[BANGRUP ERROR]', e);
 await yonz.sendMessage(m.chat, {
 text: `❌ Gagal mengirim teks terlarang!\n\n📝 *Error:* ${e.message}`,
 edit: msg.key
 });
 await m.react('❌');
 }
}
break;




case 'enccustom':
case 'encryptcustom':
case 'encrypt-custom':
case 'customenc':
case 'custom-encrypt':
case 'enc-custom':
case 'enccustomjs':
case 'encryptcustomjs':
case 'customjsen':
case 'jscustomenc': {
 if (!m.quoted) return yonz.sendMessage(m.chat, { text: 'Kutip file .js untuk dienkripsi!' }, { quoted: m })
 
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m })
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m })
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator)
 
 try {
 const fullText = m.text || m.body || ''
 const args = fullText.trim().split(/\s+/)
 
 // Ambil argumen kedua (setelah command)
 let customName = ''
 if (args.length > 1) {
 customName = args[1].replace(/[^a-zA-Z0-9_]/g, '')
 }
 
 if (!customName) {
 return yonz.sendMessage(m.chat, { 
 text: `Format: ${prefix}${command} <nama>\nContoh: ${prefix}${command} myid` 
 }, { quoted: m })
 }

 const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
 if (!fileName.endsWith('.js')) {
 return yonz.sendMessage(m.chat, { text: 'Kutip file `.js` untuk dienkripsi!' }, { quoted: m })
 }

 const idGen = () => {
 const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
 let suf = ''
 for (let i = 0; i < Math.floor(Math.random() * 3) + 2; i++) {
 suf += chars[Math.floor(Math.random() * chars.length)]
 }
 return `${customName}_${suf}`
 }

 const getCustomObf = () => ({
 target: 'node',
 compact: true,
 renameVariables: true,
 renameGlobals: true,
 identifierGenerator: idGen,
 stringEncoding: true,
 stringSplitting: true,
 controlFlowFlattening: 0.75,
 shuffle: true,
 duplicateLiteralsRemoval: true,
 deadCode: true,
 calculator: true,
 opaquePredicates: true,
 lock: {
 selfDefending: true,
 antiDebug: true,
 integrity: true,
 tamperProtection: true
 }
 })

 let mediaBuffer
 if (m.quoted.msg?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }
 mediaBuffer = buffer
 } else if (m.quoted?.message?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }
 mediaBuffer = buffer
 } else {
 return yonz.sendMessage(m.chat, { text: 'Tidak bisa mendapatkan file dari pesan yang dikutip' }, { quoted: m })
 }

 const raw = mediaBuffer.toString('utf8')

 try {
 new Function(raw)
 } catch (e) {
 return yonz.sendMessage(m.chat, { 
 text: `❌ File JS tidak valid:\n${e.message}` 
 }, { quoted: m })
 }

 await yonz.sendMessage(m.chat, { react: { text: "⚙️", key: m.key } })
 
 await yonz.sendMessage(m.chat, { text: '⏳ *Memproses custom encrypt...*' }, { quoted: m })

 const JsConfuser = require('js-confuser')
 const obf = await JsConfuser.obfuscate(raw, getCustomObf())
 const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

 const outName = `custom-encrypted-${customName}-${Date.now()}.js`
 const outPath = path.join(__dirname, outName)
 fs.writeFileSync(outPath, code, 'utf8')

 const fileBuffer = fs.readFileSync(outPath)
 await yonz.sendMessage(m.chat, {
 document: fileBuffer,
 mimetype: 'application/javascript',
 fileName: outName,
 caption: `✅ *Custom encrypted (${customName})!*`
 }, {
 quoted: m
 })

 try {
 fs.unlinkSync(outPath)
 } catch (e) {
 // Ignore
 }
 
 } catch (err) {
 console.error(err)
 yonz.sendMessage(m.chat, { 
 text: `❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}` 
 }, { quoted: m })
 }
}
break;

case "swm": 
case "stickerwm": 
case "stikerwm": 
case "wm": {
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m });

 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m });

 let mime = (qmsg.msg || qmsg).mimetype || "";

 if (!/image|video/gi.test(mime))
 return yonz.sendMessage(m.chat, { text: "Kirim gambar/video!" }, { quoted: m });

 if (/video/gi.test(mime) && qmsg.seconds > 15)
 return yonz.sendMessage(m.chat, { text: "Maksimal 15 detik" }, { quoted: m });

 let [packname, author] = text.split("|");

 if (!packname)
 return yonz.sendMessage(m.chat, { 
 text: `.wm packname|author\nContoh: .wm MyPack|MyAuthor` 
 }, { quoted: m });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 await yonz.sendMessage(m.chat, {
 react: { text: "⏳", key: m.key }
 });

 let media = await yonz.downloadAndSaveMediaMessage(qmsg);

 await yonz.sendAsSticker(m.chat, media, m, {
 packname: packname.trim(),
 author: author ? author.trim() : ""
 });

 fs.unlinkSync(media);

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });
}
break;

case "swm": 
case "stickerwm": 
case "stikerwm": 
case "wm": {
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m });

 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m });

 let mime = (qmsg.msg || qmsg).mimetype || "";

 if (!/image|video/gi.test(mime))
 return yonz.sendMessage(m.chat, { text: "Kirim gambar/video!" }, { quoted: m });

 if (/video/gi.test(mime) && qmsg.seconds > 15)
 return yonz.sendMessage(m.chat, { text: "Maksimal 15 detik" }, { quoted: m });

 let [packname, author] = text.split("|");

 if (!packname)
 return yonz.sendMessage(m.chat, { 
 text: `.wm packname|author\nContoh: .wm MyPack|MyAuthor` 
 }, { quoted: m });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 await yonz.sendMessage(m.chat, {
 react: { text: "⏳", key: m.key }
 });

 let media = await yonz.downloadAndSaveMediaMessage(qmsg);

 await yonz.sendAsSticker(m.chat, media, m, {
 packname: packname.trim(),
 author: author ? author.trim() : ""
 });

 fs.unlinkSync(media);

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });
}
break;

case "swm": 
case "stickerwm": 
case "stikerwm": 
case "wm": {
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m });

 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m });

 let mime = (qmsg.msg || qmsg).mimetype || "";

 if (!/image|video/gi.test(mime))
 return yonz.sendMessage(m.chat, { text: "Kirim gambar/video!" }, { quoted: m });

 if (/video/gi.test(mime) && qmsg.seconds > 15)
 return yonz.sendMessage(m.chat, { text: "Maksimal 15 detik" }, { quoted: m });

 let [packname, author] = text.split("|");

 if (!packname)
 return yonz.sendMessage(m.chat, { 
 text: `.wm packname|author\nContoh: .wm MyPack|MyAuthor` 
 }, { quoted: m });

 addLimit(m.sender, global.isPrem(m.sender), isCreator);

 await yonz.sendMessage(m.chat, {
 react: { text: "⏳", key: m.key }
 });

 let media = await yonz.downloadAndSaveMediaMessage(qmsg);

 await yonz.sendAsSticker(m.chat, media, m, {
 packname: packname.trim(),
 author: author ? author.trim() : ""
 });

 fs.unlinkSync(media);

 await yonz.sendMessage(m.chat, {
 react: { text: "✅", key: m.key }
 });
}
break;



case 'encstrong':
case 'encryptstrong':
case 'encrypt-strong':
case 'strongenc':
case 'strong-encrypt':
case 'enc-strong':
case 'encstrongjs':
case 'jsstrongenc':
case 'strongjsen': {
 if (!m.quoted) return yonz.sendMessage(m.chat, { text: 'Kutip pesan dokumen!' }, { quoted: m })
 
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m })
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m })
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator)
 
 try {
 const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
 if (!fileName.endsWith('.js')) return yonz.sendMessage(m.chat, { text: 'Kutip file `.js` untuk dienkripsi!' }, { quoted: m })

 const getStrongObf = () => ({
 target: 'node',
 compact: true,
 renameVariables: true,
 renameGlobals: true,
 identifierGenerator: 'randomized',
 stringEncoding: true,
 stringSplitting: true,
 controlFlowFlattening: 0.75,
 shuffle: true,
 duplicateLiteralsRemoval: true,
 calculator: true,
 dispatcher: true,
 deadCode: true,
 opaquePredicates: true,
 lock: {
 selfDefending: true,
 antiDebug: true,
 integrity: true,
 tamperProtection: true
 }
 })

 let mediaBuffer
 if (m.quoted.msg?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
 mediaBuffer = buffer
 } else if (m.quoted?.message?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
 mediaBuffer = buffer
 } else {
 return yonz.sendMessage(m.chat, { text: 'Tidak bisa mendapatkan file dari pesan yang dikutip' }, { quoted: m })
 }

 const raw = mediaBuffer.toString('utf8')

 try {
 new Function(raw)
 } catch (e) {
 return yonz.sendMessage(m.chat, { text: `❌ File JS tidak valid:\n${e.message}` }, { quoted: m })
 }

 await yonz.sendMessage(m.chat, { react: { text: "🛡️", key: m.key } })
 
 await yonz.sendMessage(m.chat, { text: '⏳ *Memproses strong encrypt...*' }, { quoted: m })

 const JsConfuser = require('js-confuser')
 const obf = await JsConfuser.obfuscate(raw, getStrongObf())
 const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

 const outName = `strong-encrypted-${Date.now()}.js`
 const outPath = path.join(__dirname, outName)
 fs.writeFileSync(outPath, code, 'utf8')

 const fileBuffer = fs.readFileSync(outPath)
 await yonz.sendMessage(m.chat, {
 document: fileBuffer,
 mimetype: 'application/javascript',
 fileName: outName,
 caption: '✅ *Hardened Strong encrypted!* — SATURN 🔥'
 }, {
 quoted: m
 })

 try {
 fs.unlinkSync(outPath)
 } catch (e) {}
 } catch (err) {
 console.error(err)
 yonz.sendMessage(m.chat, { text: `❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}` }, { quoted: m })
 }
}
break;

case 'encultra':
case 'encryptultra':
case 'encrypt-ultra':
case 'ultraenc':
case 'ultra-encrypt':
case 'enc-ultra':
case 'encultrajs':
case 'jsultraenc':
case 'ultrajsen': {
 if (!m.quoted) return yonz.sendMessage(m.chat, { text: 'Kutip pesan dokumen!' }, { quoted: m })
 
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m })
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m })
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator)
 
 try {
 const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
 if (!fileName.endsWith('.js')) return yonz.sendMessage(m.chat, { text: 'Kutip file `.js` untuk dienkripsi!' }, { quoted: m })

 const genUltra = () => {
 const chars = 'abcdefghijklmnopqrstuvwxyz'
 const nums = '0123456789'
 return 'z' + nums[Math.floor(Math.random() * nums.length)] + chars[Math.floor(Math.random() * chars.length)] + Math.random().toString(36).slice(2, 6)
 }

 const getUltraObf = () => ({
 target: 'node',
 compact: true,
 renameVariables: true,
 renameGlobals: true,
 identifierGenerator: genUltra,
 stringCompression: true,
 stringEncoding: true,
 stringSplitting: true,
 controlFlowFlattening: 0.9,
 flatten: true,
 shuffle: true,
 rgf: true,
 deadCode: true,
 opaquePredicates: true,
 dispatcher: true,
 lock: {
 selfDefending: true,
 antiDebug: true,
 integrity: true,
 tamperProtection: true
 }
 })

 let mediaBuffer
 if (m.quoted.msg?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
 mediaBuffer = buffer
 } else if (m.quoted?.message?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
 mediaBuffer = buffer
 } else {
 return yonz.sendMessage(m.chat, { text: 'Tidak bisa mendapatkan file dari pesan yang dikutip' }, { quoted: m })
 }

 const raw = mediaBuffer.toString('utf8')

 try {
 new Function(raw)
 } catch (e) {
 return yonz.sendMessage(m.chat, { text: `❌ File JS tidak valid:\n${e.message}` }, { quoted: m })
 }

 await yonz.sendMessage(m.chat, { react: { text: "🚀", key: m.key } })
 
 await yonz.sendMessage(m.chat, { text: '⏳ *Memproses ultra encrypt...*' }, { quoted: m })

 const JsConfuser = require('js-confuser')
 const obf = await JsConfuser.obfuscate(raw, getUltraObf())
 const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

 const outName = `ultra-encrypted-${Date.now()}.js`
 const outPath = path.join(__dirname, outName)
 fs.writeFileSync(outPath, code, 'utf8')

 const fileBuffer = fs.readFileSync(outPath)
 await yonz.sendMessage(m.chat, {
 document: fileBuffer,
 mimetype: 'application/javascript',
 fileName: outName,
 caption: '✅ *Hardened Ultra encrypted!* — SATURN 🔥'
 }, {
 quoted: m
 })

 try {
 fs.unlinkSync(outPath)
 } catch (e) {}
 } catch (err) {
 console.error(err)
 yonz.sendMessage(m.chat, { text: `❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}` }, { quoted: m })
 }
}
break;



case "addreselleram": {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(example("6281234567890"));
 
 const number = text.replace(/[^0-9]/g, '');
 if (number.length < 10) return Reply("❌ Nomor tidak valid!");
 
 const resellerPath = './library/database/reseller_am.json';
 if (!fs.existsSync(resellerPath)) {
 fs.writeFileSync(resellerPath, JSON.stringify([]));
 }
 let resellerData = JSON.parse(fs.readFileSync(resellerPath));
 
 const jid = number + '@s.whatsapp.net';
 if (resellerData.includes(jid)) {
 return Reply(`❌ ${number} sudah terdaftar sebagai reseller AM!`);
 }
 
 resellerData.push(jid);
 fs.writeFileSync(resellerPath, JSON.stringify(resellerData, null, 2));
 
 let name = number;
 try {
 const contact = await yonz.getName(jid);
 if (contact) name = contact;
 } catch(e) {}
 
 Reply(`✅ ${name} (${number}) berhasil ditambahkan sebagai reseller AM!`);
}
break;

case "delreselleram": {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(example("6281234567890"));
 
 const number = text.replace(/[^0-9]/g, '');
 if (number.length < 10) return Reply("❌ Nomor tidak valid!");
 
 const resellerPath = './library/database/reseller_am.json';
 if (!fs.existsSync(resellerPath)) {
 fs.writeFileSync(resellerPath, JSON.stringify([]));
 return Reply("❌ Belum ada reseller AM terdaftar!");
 }
 let resellerData = JSON.parse(fs.readFileSync(resellerPath));
 
 const jid = number + '@s.whatsapp.net';
 const index = resellerData.indexOf(jid);
 if (index === -1) {
 return Reply(`❌ ${number} tidak terdaftar sebagai reseller AM!`);
 }
 
 resellerData.splice(index, 1);
 fs.writeFileSync(resellerPath, JSON.stringify(resellerData, null, 2));
 
 let name = number;
 try {
 const contact = await yonz.getName(jid);
 if (contact) name = contact;
 } catch(e) {}
 
 Reply(`✅ ${name} (${number}) berhasil dihapus dari reseller AM!`);
}
break;

case "listreselleram": {
 if (!isCreator) return Reply(mess.owner);
 
 const resellerPath = './library/database/reseller_am.json';
 if (!fs.existsSync(resellerPath)) {
 fs.writeFileSync(resellerPath, JSON.stringify([]));
 return Reply("📭 Belum ada reseller AM terdaftar!");
 }
 let resellerData = JSON.parse(fs.readFileSync(resellerPath));
 
 if (resellerData.length === 0) {
 return Reply("📭 Belum ada reseller AM terdaftar!");
 }
 
 let textList = "📋 *DAFTAR RESELLER AM*\n\n";
 for (let i = 0; i < resellerData.length; i++) {
 const jid = resellerData[i];
 let name = jid.split('@')[0];
 try {
 const contact = await yonz.getName(jid);
 if (contact) name = contact;
 } catch(e) {}
 textList += `${i+1}. ${name}\n`;
 textList += ` 📱 wa.me/${jid.split('@')[0]}\n\n`;
 }
 Reply(textList);
}
break;

case "amprem": {
 if (!isRegistered(m.sender) && !isCreator)
 return Reply(global.mess.verifikasi);
 
 const resellerPath = './library/database/reseller_am.json';
 let resellerData = [];
 if (fs.existsSync(resellerPath)) {
 resellerData = JSON.parse(fs.readFileSync(resellerPath));
 }
 
 const isResellerAM = resellerData.includes(m.sender) || resellerData.includes(m.sender.replace('@lid', '@s.whatsapp.net'));
 if (!isResellerAM && !isCreator) {
 return Reply("❌ Fitur ini hanya untuk reseller AM!\nHubungi owner untuk jadi reseller.");
 }
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);
 
 if (!text) {
 return Reply(`📌 *CARA PAKAI .amprem*\n\n` +
 `1️⃣ Kirim email:\n` +
 `.amprem email@gmail.com\n\n` +
 `2️⃣ Verifikasi link:\n` +
 `.amprem verif|https://alightcreative.com/auth/xxxxx\n\n` +
 `📝 Contoh:\n` +
 `.amprem verif|https://alightcreative.com/auth/abc123`);
 }
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);
 
 const apiKey = global.apiam;
 const baseUrl = "https://alipshop.clutch.web.id/api/v1/premium";
 
 if (!apiKey) {
 return Reply("❌ API Key (global.apiam) tidak diset! Hubungi owner.");
 }
 
 try {
 if (text.toLowerCase().startsWith("verif|")) {
 const [, link] = text.split("|").map(s => s.trim());
 if (!link) return Reply("❌ Masukkan link!\nContoh: .amprem verif|https://alightcreative.com/auth/...");
 
 const email = global.ampremEmail;
 if (!email) return Reply("❌ Email tidak ditemukan! Kirim email dulu:\n.amprem email@gmail.com");
 
 const fullUrl = `${baseUrl}/verif`;
 console.log(`[AMPREM] POST to ${fullUrl}`);
 console.log(`[AMPREM] Payload:`, { email, link });
 
 const response = await axios.post(fullUrl, {
 email: email,
 link: link
 }, {
 headers: {
 'Content-Type': 'application/json',
 'Authorization': `Bearer ${apiKey}`
 },
 timeout: 30000
 });
 
 console.log('[AMPREM] Response status:', response.status);
 console.log('[AMPREM] Response data:', response.data);
 
 const data = response.data;
 
 if (data.status === true && data.premium === true) {
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 return Reply(`✅ *SUKSES!*\n\n${data.message || 'Premium AM berhasil diaktifkan!'}`);
 } else {
 return Reply(`❌ Gagal verifikasi!\n\n${data.message || JSON.stringify(data)}`);
 }
 } else {
 const email = text.trim();
 if (!email.includes('@') || !email.includes('.')) {
 return Reply("❌ Email tidak valid!");
 }
 
 global.ampremEmail = email;
 
 const fullUrl = `${baseUrl}/send`;
 console.log(`[AMPREM] POST to ${fullUrl}`);
 console.log(`[AMPREM] Payload:`, { email });
 
 const response = await axios.post(fullUrl, {
 email: email
 }, {
 headers: {
 'Content-Type': 'application/json',
 'Authorization': `Bearer ${apiKey}`
 },
 timeout: 30000
 });
 
 console.log('[AMPREM] Response status:', response.status);
 console.log('[AMPREM] Response data:', response.data);
 
 const data = response.data;
 
 if (data.status === true) {
 await yonz.sendMessage(m.chat, { react: { text: "📧", key: m.key } });
 
 let replyMsg = `✅ *LINK VERIFIKASI TERKIRIM!*\n\n`;
 replyMsg += `📧 Email: ${email}\n\n`;
 replyMsg += `📌 *INSTRUKSI:*\n`;
 
 if (data.instructions && Array.isArray(data.instructions)) {
 data.instructions.forEach((inst, index) => {
 replyMsg += `${index + 1}. ${inst}\n`;
 });
 } else {
 replyMsg += `1. Buka inbox email (cek folder Spam juga)\n`;
 replyMsg += `2. Cari email dari Alight Motion / Alight Creative\n`;
 replyMsg += `3. Tekan-tahan tombol login, pilih Salin URL\n`;
 replyMsg += `4. Jangan klik langsung, cukup salin link pendaftarannya\n`;
 replyMsg += `5. Ketik: .amprem verif|link_yang_dicopy`;
 }
 
 replyMsg += `\n\n📝 *Contoh:*\n`;
 replyMsg += `.amprem verif|https://alightcreative.com/auth/xxxxx`;
 
 return Reply(replyMsg);
 } else {
 return Reply(`❌ Gagal mengirim!\n\n${data.message || JSON.stringify(data)}`);
 }
 }
 } catch (error) {
 console.error('[AMPREM ERROR]', error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 
 let errorMsg = "❌ *Error Details*\n\n";
 
 if (error.code === 'ENOTFOUND') {
 errorMsg += `🌐 Domain tidak ditemukan: ${baseUrl}\n`;
 errorMsg += "\n💡 Periksa koneksi internet!";
 } else if (error.code === 'ECONNREFUSED') {
 errorMsg += `🔌 Koneksi ditolak ke ${baseUrl}\n`;
 errorMsg += "\n💡 Pastikan server API sedang berjalan!";
 } else if (error.code === 'ETIMEDOUT') {
 errorMsg += "⏰ Timeout! Server tidak merespon.\n";
 errorMsg += "\n💡 Coba lagi nanti.";
 } else if (error.response) {
 if (error.response.status === 400) {
 errorMsg += "❌ Email tidak valid atau sudah terdaftar!";
 } else if (error.response.status === 401) {
 errorMsg += "❌ API Key (global.apiam) tidak valid!";
 } else if (error.response.status === 404) {
 errorMsg += `❌ Endpoint tidak ditemukan!\nURL: ${baseUrl}`;
 } else if (error.response.status === 502) {
 errorMsg += "❌ Server Alight Motion bermasalah. Coba lagi nanti!";
 } else {
 errorMsg += `Status: ${error.response.status}\n`;
 errorMsg += `Data: ${JSON.stringify(error.response.data, null, 2)}`;
 }
 } else if (error.request) {
 errorMsg += "📡 Tidak ada respon dari server!\n";
 errorMsg += `URL: ${baseUrl}/send\n`;
 errorMsg += "\n💡 Cek:\n";
 errorMsg += "1. URL API benar\n";
 errorMsg += "2. Server API aktif\n";
 errorMsg += "3. Koneksi internet bot";
 } else {
 errorMsg += `Error: ${error.message}`;
 }
 
 Reply(errorMsg);
 }
}
break;

case "cekam": {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(example("6281234567890"));
 
 const number = text.replace(/[^0-9]/g, '');
 if (number.length < 10) return Reply("❌ Nomor tidak valid!");
 
 const resellerPath = './library/database/reseller_am.json';
 if (!fs.existsSync(resellerPath)) {
 fs.writeFileSync(resellerPath, JSON.stringify([]));
 return Reply("❌ Belum ada reseller AM terdaftar!");
 }
 let resellerData = JSON.parse(fs.readFileSync(resellerPath));
 
 const jid = number + '@s.whatsapp.net';
 const isReseller = resellerData.includes(jid);
 
 let name = number;
 try {
 const contact = await yonz.getName(jid);
 if (contact) name = contact;
 } catch(e) {}
 
 Reply(`📊 *Status Reseller AM*\n\nNama: ${name}\nNomor: ${number}\nStatus: ${isReseller ? '✅ Terdaftar' : '❌ Tidak Terdaftar'}`);
}
break;

case "resetam": {
 if (!isCreator) return Reply(mess.owner);
 
 const resellerPath = './library/database/reseller_am.json';
 fs.writeFileSync(resellerPath, JSON.stringify([]));
 Reply("✅ Semua data reseller AM berhasil direset!");
}
break;

case "setapiam": {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(example("Yonzoffc"));
 
 global.apiam = text.trim();
 Reply(`✅ global.apiam berhasil diubah menjadi:\n${global.apiam}`);
}
break;

case "cekconfigam": {
 if (!isCreator) return Reply(mess.owner);
 
 let msg = "📋 *CURRENT API CONFIG*\n\n";
 msg += `🔑 global.apiam = ${global.apiam ? '✅ ' + global.apiam : '❌ NOT SET'}\n\n`;
 msg += `🌐 API URL: https://alipshop.clutch.web.id/api/v1/premium\n\n`;
 
 if (global.apiam) {
 msg += `✅ Konfigurasi lengkap!\n`;
 msg += `📡 API akan mengirim ke:\n`;
 msg += `https://alipshop.clutch.web.id/api/v1/premium/send`;
 } else {
 msg += `⚠️ Konfigurasi belum lengkap!\n`;
 msg += `• Set global.apiam dengan: .setapiam API_KEY_ANDA`;
 }
 
 Reply(msg);
}
break;

case "am": {
 if (!isCreator) return Reply(mess.owner);
 
 let msg = `📚 *PANDUAN RESELLER AM (ALIGHT MOTION)*\n\n`;
 msg += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
 
 msg += `🔹 *MANAJEMEN RESELLER*\n`;
 msg += `┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n`;
 msg += `📌 .addreselleram 628xxx\n`;
 msg += ` ➠ Tambah reseller AM\n\n`;
 msg += `📌 .delreselleram 628xxx\n`;
 msg += ` ➠ Hapus reseller AM\n\n`;
 msg += `📌 .listreselleram\n`;
 msg += ` ➠ Lihat semua reseller\n\n`;
 msg += `📌 .cekam 628xxx\n`;
 msg += ` ➠ Cek status reseller\n\n`;
 msg += `📌 .resetam\n`;
 msg += ` ➠ Reset semua data reseller\n\n`;
 
 msg += `🔹 *PREMIUM ALIGHT MOTION*\n`;
 msg += `┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n`;
 msg += `📌 .amprem email@gmail.com\n`;
 msg += ` ➠ Kirim link verifikasi ke email\n\n`;
 msg += `📌 .amprem verif|link\n`;
 msg += ` ➠ Verifikasi link dari email\n\n`;
 msg += `📌 .amprem\n`;
 msg += ` ➠ Lihat cara pakai .amprem\n\n`;
 
 msg += `🔹 *KONFIGURASI API*\n`;
 msg += `┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n`;
 msg += `📌 .setapiam API_KEY\n`;
 msg += ` ➠ Set API key\n\n`;
 msg += `📌 .cekconfigam\n`;
 msg += ` ➠ Cek konfigurasi API\n\n`;
 
 msg += `━━━━━━━━━━━━━━━━━━━━━━\n`;
 msg += `📝 *CONTOH PENGGUNAAN:*\n\n`;
 msg += `1️⃣ Tambah reseller:\n`;
 msg += ` .addreselleram 6281234567890\n\n`;
 msg += `2️⃣ Kirim email:\n`;
 msg += ` .amprem user@gmail.com\n\n`;
 msg += `3️⃣ Verifikasi:\n`;
 msg += ` .amprem verif|https://alightcreative.com/auth/xxx\n\n`;
 
 msg += `⚠️ *CATATAN:*\n`;
 msg += `• Semua fitur hanya untuk OWNER\n`;
 msg += `• .amprem hanya untuk RESELLER AM\n`;
 msg += `• Pastikan global.apiam sudah diset\n`;
 msg += `• API URL: https://alipshop.clutch.web.id/api/v1/premium`;
 
 Reply(msg);
}
break;

case 'encsiu':
case 'encryptsiu':
case 'encrypt-siu':
case 'siuenc':
case 'siu-encrypt':
case 'enc-siu':
case 'encsiujs':
case 'jssiuenc':
case 'siujsen': {
 if (!m.quoted) return yonz.sendMessage(m.chat, { text: 'Kutip pesan dokumen!' }, { quoted: m })
 
 if (!isRegistered(m.sender) && !isCreator)
 return yonz.sendMessage(m.chat, { text: global.mess.verifikasi }, { quoted: m })
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return yonz.sendMessage(m.chat, { text: global.mess.limit }, { quoted: m })
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator)
 
 try {
 const fileName = m.quoted?.msg?.fileName || m.quoted?.fileName || ''
 if (!fileName.endsWith('.js')) return yonz.sendMessage(m.chat, { text: 'Kutip file `.js` untuk dienkripsi!' }, { quoted: m })

 const genSiu = () => {
 const abc = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
 let r = ''
 for (let i = 0; i < 6; i++) r += abc[Math.floor(Math.random() * abc.length)]
 return `CalceKarik和SiuSiu${r}`
 }

 const getSiuObf = () => ({
 target: 'node',
 compact: true,
 renameVariables: true,
 renameGlobals: true,
 identifierGenerator: genSiu,
 stringCompression: true,
 stringEncoding: true,
 stringSplitting: true,
 controlFlowFlattening: 0.95,
 flatten: true,
 shuffle: true,
 duplicateLiteralsRemoval: true,
 deadCode: true,
 calculator: true,
 opaquePredicates: true,
 lock: {
 selfDefending: true,
 antiDebug: true,
 integrity: true,
 tamperProtection: true
 }
 })

 let mediaBuffer
 if (m.quoted.msg?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.msg.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
 mediaBuffer = buffer
 } else if (m.quoted?.message?.documentMessage) {
 const media = await downloadContentFromMessage(m.quoted.message.documentMessage, 'document')
 let buffer = Buffer.from([])
 for await (const chunk of media) buffer = Buffer.concat([buffer, chunk])
 mediaBuffer = buffer
 } else {
 return yonz.sendMessage(m.chat, { text: 'Tidak bisa mendapatkan file dari pesan yang dikutip' }, { quoted: m })
 }

 const raw = mediaBuffer.toString('utf8')

 // Validasi syntax tanpa mengeksekusi (support ESM)
 try {
 const acorn = require('acorn')
 const options = {
 ecmaVersion: 'latest',
 sourceType: 'module',
 allowImportExportEverywhere: true
 }
 acorn.parse(raw, options)
 } catch (e) {
 return yonz.sendMessage(m.chat, { text: `❌ File JS tidak valid:\n${e.message}` }, { quoted: m })
 }

 await yonz.sendMessage(m.chat, { react: { text: "🔥", key: m.key } })
 
 await yonz.sendMessage(m.chat, { text: '⏳ *Memproses SIU encrypt...*' }, { quoted: m })

 const JsConfuser = require('js-confuser')
 const obf = await JsConfuser.obfuscate(raw, getSiuObf())
 const code = typeof obf === 'string' ? obf : (obf && obf.code) || String(obf)

 const outName = `siu-encrypted-${Date.now()}.js`
 const outPath = path.join(__dirname, outName)
 fs.writeFileSync(outPath, code, 'utf8')

 const fileBuffer = fs.readFileSync(outPath)
 await yonz.sendMessage(m.chat, {
 document: fileBuffer,
 mimetype: 'application/javascript',
 fileName: outName,
 caption: '✅ *Calcrick Chaos Core encrypted!*'
 }, {
 quoted: m
 })

 try {
 fs.unlinkSync(outPath)
 } catch (e) {}
 } catch (err) {
 console.error(err)
 yonz.sendMessage(m.chat, { text: `❌ Terjadi kesalahan: ${err && err.message ? err.message : String(err)}` }, { quoted: m })
 }
}
break;



case 'hd':
case 'upscale':
case 'remini': {
 if (!isRegistered(m.sender) && !isCreator)
 return daftar(global.mess.verifikasi);
 
 if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
 return Reply(global.mess.limit);
 
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!/image/.test(mime)) return Reply(example("dengan reply gambar"));
 
 addLimit(m.sender, global.isPrem(m.sender), isCreator);
 await yonz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 Reply(mess.wait);
 
 const fs = require('fs');
 const FormData = require('form-data');
 const axios = require('axios');
 const path = require('path');
 
 let mediaPath = null;
 
 try {
 // Download media dari quoted
 mediaPath = await yonz.downloadAndSaveMediaMessage(q);
 if (!mediaPath) throw new Error('Gagal download media');
 
 // Upload ke server menggunakan FormData
 const form = new FormData();
 form.append('file', fs.createReadStream(mediaPath));
 
 const upload = await axios.post(`${global.claude}/uploader/webpublish`, form, {
 headers: form.getHeaders(),
 timeout: 60000
 });
 
 console.log('[REMINI UPLOAD]', upload.data);
 
 // Ambil URL dari response upload
 const imageUrl = upload.data?.url || upload.data?.result || upload.data?.link || upload.data?.data?.url;
 
 if (!imageUrl || typeof imageUrl !== 'string') {
 throw new Error(`Gagal upload: ${JSON.stringify(upload.data)}`);
 }
 
 // Proses upscale menggunakan API Clutch
 const apiUrl = `${global.apialip}/imagecreator/remini?apikey=${global.alipkey}&url=${encodeURIComponent(imageUrl)}`;
 
 const response = await axios.get(apiUrl, { 
 responseType: 'arraybuffer',
 timeout: 60000 
 });
 
 // Cek apakah response berhasil
 if (!response.data || response.data.length === 0) {
 throw new Error('Gagal memproses gambar');
 }
 
 const resultBuffer = Buffer.from(response.data);
 
 await yonz.sendMessage(m.chat, { 
 image: resultBuffer, 
 caption: mess.done 
 }, { quoted: m });
 
 await yonz.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error(error);
 await yonz.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 Reply(`❌ *Terjadi kesalahan!*\n${error.message}`);
 } finally {
 // Hapus file temporary
 if (mediaPath) {
 try {
 fs.unlinkSync(mediaPath);
 } catch (_) { }
 }
 }
}
break;

default:
    if (isCmd && command && isAutoCorrect(m.chat) && !getValidCommands().has(command.toLowerCase())) {
        const allCommands = [...getValidCommands()];
        let bestMatch = null;
        let minDistance = Infinity;
        const typoThreshold = 2;

        for (const cmd of allCommands) {
            if (cmd === command.toLowerCase()) continue; // skip diri sendiri, jaga-jaga
            const distance = levenshtein(command, cmd);
            if (distance < minDistance) {
                minDistance = distance;
                bestMatch = cmd;
            }
        }

        if (bestMatch && minDistance <= typoThreshold && minDistance > 0) {
            const similarity = Math.max(0, Math.min(100, Math.round(((command.length - minDistance) / command.length) * 100)));
            const teks = `\n*🍀 ᴄᴏᴍᴍᴀɴᴅ ʏᴀɴɢ ᴋᴀᴍᴜ ᴋᴇᴛɪᴋ ᴛɪᴅᴀᴋ ᴛᴇʀsᴇᴅɪᴀ ᴅɪ ʙᴏᴛ, ʏᴀɴɢ ᴋᴀᴍᴜ ᴍᴀᴋꜱᴜᴅ:*
        
┏━ ⊑ *MUNGKIN INI* ⊒
│ ⤷ Command : ${prefix}${bestMatch}
│ ⤷ Kemiripan : ${similarity}% 
╰──────────────\n`;

            const thumbPath = "./source/media/foto/imgdokumen.jpg";

            if (fs.existsSync(thumbPath)) {
                try {
                    const img = await jimp.read(thumbPath);
                    if (img.bitmap.width !== 300 || img.bitmap.height !== 300) {
                        img.cover(300, 300);
                        await img.writeAsync(thumbPath);
                    }
                } catch (e) {}
            }

            await yonz.sendMessage(m.chat, {
                document: fs.readFileSync("./package.json"),
                fileName: global.botname,
                mimetype: "image/png",
                fileLength: 999000000000,
                pageCount: 100,
                headerType: 1,
                viewOnce: true,
                jpegThumbnail: (typeof global.pathThumbHeader === 'string' && global.pathThumbHeader && fs.existsSync(global.pathThumbHeader)) ? fs.readFileSync(global.pathThumbHeader) : (fs.existsSync(thumbPath) ? fs.readFileSync(thumbPath) : undefined),
                caption: teks,
                buttons: [
                    {
                        buttonId: `${prefix}${bestMatch}`,
                        buttonText: { displayText: `${prefix}${bestMatch}` },
                        type: 1
                    }
                ],
                contextInfo: {
                    mentionedJid: [m.sender],
                    isForwarded: true,
                    forwardingScore: 9999,
                    businessMessageForwardInfo: { businessOwnerJid: global.owner + "@s.whatsapp.net" },
                    forwardedNewsletterMessageInfo: {
                        newsletterName: global.namaSaluran,
                        newsletterJid: global.idSaluran
                    }
                }
            }, { quoted: m });
            return;
        }
    }

    if (budy.startsWith('>')) {
        if (!isCreator) return
        try {
            let evaled = await eval(budy.slice(2))
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
            await m.reply(evaled)
        } catch (err) {
            await m.reply(String(err))
        }}

//================================================================================

if ([global.botname.toLowerCase(), global.botname2.toLowerCase(), "bot"].includes(m.text.toLowerCase())) {
    return yonz.sendMessage(
        m.chat,
        {
            sticker: {
                url: "./source/media/sticker/bot.webp"
            }
        },
        {
            quoted: m
        }
    );
}
//================================================================================
if (budy.startsWith('=>')) {
if (!isCreator2) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await Reply(evaled)
} catch (err) {
await Reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator2) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return Reply(`${err}`)
if (stdout) return Reply(stdout)
})
}

//================================================================================
}
} catch (err) {
    console.log(util.format(err));
    let Obj = global.owner
    yonz.sendMessage(Obj + "@s.whatsapp.net", { 
        text: `
*ERROR TERDETEKSI :*\n\n` + util.format(err), 
        contextInfo: { isForwarded: false } 
    }, { quoted: m })
}}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
});