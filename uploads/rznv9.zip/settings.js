const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.owner = '6285174301390'
global.versi = version
global.namaOwner = "Yonz official"
global.packname = 'New Script By Yonz'
global.botname = 'Yonz official'
global.botname2 = 'Yonz official'
global.custompairing = "YONZOFFC";
global.adm4 = "31.71.03.1001"

//Apikey Yonz official Jangan di ganti 
global.apialip = "https://api.clutch.web.id"
global.there = "https://api.theresav.biz.id"
global.claude = "https://api.synoxcloud.xyz"
global.apikeyalip = "alipaiapikeybaru"
global.am = "https://api.example.com"

//Apikey Yonz official jangan ubah
global.alipkey = "Yonzofficial"
global.apikeythere = "Yonz"

// Settings gif welcome / left
global.gifWelcome = 'https://rahmad-elaina.my.id/file/0dcc693bdc.mp4'
global.audioWelcome = 'https://rahmad-elaina.my.id/file/2b622482eb.mp3'

global.gifLeft = 'https://d.uguu.se/XoggFCMb.mp4'
global.audioLeft = 'https://rahmad-elaina.my.id/file/dd7639989b.mp3'

global.linkOwner = "https://wa.me/6285174301390"
global.linkowner = global.linkOwner
global.linkGrup = "https://chat.whatsapp.com/Di0qSfAsE4AH0o31J2hkti"
global.groupBackup = "120363429449087831@g.us"

global.linkSaluran = "https://whatsapp.com/channel/0029Vb7LAXcLY6cxZmasdh43"
global.idSaluran = "120363426234538573@newsletter"
global.namaSaluran = "✦ ──『 𝐘𝐨𝐧𝐳 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 』── ✦"

global.bottele = "8532901111:AAGgyEBnNvrprZ0Is4ZtoSkydliXs2qCI-A" //token bit fathar
global.idtele = "8369310752"

//Setting limit harian 
global.limitFree = 20
global.limitPremium = 1000

// Delay
global.delayJpm = 3000

// Settings Image Url
global.image = {
	menu: "https://cdn.webpublish.biz.id/cdn/zdP4A.jpg",
	reply: "source/media/foto/imgdokumen.jpg",
    menuv3: "https://img2.pixhost.to/images/9041/745365248_image_1782976745234.jpg"
}

// Settings Panel (Pterodactyl) - dipakai plugins/cpanel.js
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
global.resellerPricePerGB = 3000

require('./library/database/reseller.js')

// Message Command
global.mess = {
 owner: `💌 *AKSES DITOLAK*\nFitur ini hanya bisa digunakan oleh *Owner Bot*.`,
 admin: `💌 *AKSES DITOLAK*\nFitur ini khusus untuk *Admin Grup*.`,
 botAdmin: `💌 *AKSES DITOLAK*\nBot harus menjadi *Admin Grup* terlebih dahulu.`,
 group: `💌 *AKSES DITOLAK*\nFitur ini hanya dapat digunakan di *dalam grup*.`,
 wait: `⏳ *Mohon tunggu...*\nPermintaan kamu sedang diproses.`,
 error: `❌ *Terjadi kesalahan!*\nSilakan coba lagi nanti.`,
 done: `✅ *Berhasil!*\nProses telah selesai dengan sukses.`,
 verifikasi: `💌 *AKSES DITOLAK*\nKamu belum terdaftar. Silakan hubungi Owner untuk melakukan pendaftaran.`,
 prem: `💌 *FITUR PREMIUM*\nFitur ini khusus untuk pengguna *Premium*.\nHubungi Owner untuk upgrade ke Premium.`,
 limit: `❌ *Limit Habis!*\nLimit harian kamu telah habis.`,
 resam: {
   notReseller: `❌ *BUKAN RESELLER AM*\nFitur ini khusus untuk Reseller AM dan Owner!`,
   notFound: `❌ *TIDAK DITEMUKAN*\nNomor tidak terdaftar sebagai reseller AM.`,
   alreadyExist: `❌ *SUDAH TERDAFTAR*\nNomor sudah terdaftar sebagai reseller AM.`,
   noData: `📋 *BELUM ADA DATA*\nBelum ada reseller AM terdaftar.`,
   addSuccess: `✅ *BERHASIL MENAMBAHKAN*\nReseller AM berhasil ditambahkan.`,
   deleteSuccess: `✅ *BERHASIL MENGHAPUS*\nReseller AM berhasil dihapus.`,
   extendSuccess: `✅ *BERHASIL DIPERPANJANG*\nMasa aktif reseller AM berhasil diperpanjang.`,
   limitReached: `❌ *LIMIT HABIS*\nLimit reseller AM hari ini sudah habis! (50x/hari)`,
   listTitle: `📋 *DAFTAR RESELLER ALIGHT MOTION*\n\n`,
   expired: `❌ *EXPIRED*`,
   active: `✅ *AKTIF*`
 }
};

global.pairing_code = true
global.tempatDB = 'database.json'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})