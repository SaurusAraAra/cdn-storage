/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './config/**/*.{js,jsx}'
  ],
  theme: {
    extend: {
      colors: {
        accent: {
          DEFAULT: '#1DB954',
          dark: '#1AA34A',
          light: '#1ED760'
        },
        bg: {
          base: '#0A0A0A',
          elevated: '#121212',
          highlight: '#1A1A1A',
          press: '#000000'
        },
        text: {
          base: '#FFFFFF',
          subdued: '#A7A7A7',
          bright: '#FFFFFF'
        }
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif']
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.5s ease-out'
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' }
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' }
        }
      }
    }
  },
  plugins: []
};
