'use client';

import { createContext, useContext, useRef, useState, useCallback, useEffect } from 'react';

const PlayerContext = createContext(null);

const MAX_HISTORY = 30;
const HISTORY_KEY = 'vellzyy_history';

export function PlayerProvider({ children }) {
  const audioRef = useRef(null);

  const [currentTrack, setCurrentTrack] = useState(null);
  const [status, setStatus] = useState('idle'); // idle | loading | playing | paused | error
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [errorMsg, setErrorMsg] = useState('');
  const [history, setHistory] = useState([]);

  // Load history dari localStorage saat pertama kali
  useEffect(() => {
    try {
      const saved = localStorage.getItem(HISTORY_KEY);
      if (saved) setHistory(JSON.parse(saved));
    } catch {}
  }, []);

  const addToHistory = useCallback((track) => {
    setHistory((prev) => {
      // Hapus duplikat
      const filtered = prev.filter((t) => t.id !== track.id);
      const next = [{ ...track, playedAt: Date.now() }, ...filtered].slice(0, MAX_HISTORY);
      try { localStorage.setItem(HISTORY_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    try { localStorage.removeItem(HISTORY_KEY); } catch {}
  }, []);

  const playTrack = useCallback(async (track) => {
    setErrorMsg('');
    setStatus('loading');
    setProgress(0);
    setCurrentTime(0);
    setDuration(0);
    setCurrentTrack(track);
    addToHistory(track);

    try {
      const res = await fetch(`/api/stream/${track.id}`);
      const json = await res.json();

      if (!json.ok || !json.url) {
        throw new Error(json.error || 'Audio tidak tersedia');
      }

      if (!audioRef.current) audioRef.current = new Audio();
      const audio = audioRef.current;
      audio.pause();
      audio.src = '';
      audio.src = json.url;
      audio.volume = volume;

      audio.ontimeupdate = () => {
        if (audio.duration) {
          setCurrentTime(audio.currentTime);
          setProgress(audio.currentTime / audio.duration);
        }
      };
      audio.onloadedmetadata = () => setDuration(audio.duration);
      audio.onended = () => {
        setStatus('paused');
        setProgress(0);
        setCurrentTime(0);
        audio.currentTime = 0;
      };
      audio.onerror = () => {
        setStatus('error');
        setErrorMsg('Gagal memutar audio');
      };

      await audio.play();
      setStatus('playing');
    } catch (err) {
      setStatus('error');
      setErrorMsg(err?.message || 'Gagal memutar lagu');
    }
  }, [volume, addToHistory]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (status === 'playing') {
      audio.pause();
      setStatus('paused');
    } else if (status === 'paused') {
      audio.play().then(() => setStatus('playing')).catch(() => setStatus('error'));
    }
  }, [status]);

  const seek = useCallback((ratio) => {
    const audio = audioRef.current;
    if (!audio || !audio.duration) return;
    audio.currentTime = ratio * audio.duration;
    setProgress(ratio);
    setCurrentTime(audio.currentTime);
  }, []);

  const changeVolume = useCallback((v) => {
    setVolume(v);
    if (audioRef.current) audioRef.current.volume = v;
  }, []);

  return (
    <PlayerContext.Provider value={{
      currentTrack, status, progress, currentTime, duration,
      volume, errorMsg, history,
      playTrack, togglePlay, seek, changeVolume, clearHistory,
    }}>
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error('usePlayer must be inside PlayerProvider');
  return ctx;
}
