/**
 * ============================================================
 *  VellzyyMusik - CREATOR PROFILE CONFIG
 * ============================================================
 *
 *  File ini berisi profil kreator yang ditampilkan di halaman /profile.
 *  Edit file ini saja jika ingin mengubah nama, bio, foto, atau link donasi.
 *
 *  Cara mengganti foto:
 *    1. Letakkan file gambar di folder `public/` (mis. `public/me.jpg`)
 *    2. Set `avatar: '/me.jpg'`
 *    3. Atau gunakan URL eksternal seperti `https://...`
 *
 *  Cara menambah link donasi / sosial:
 *    Tambahkan object baru ke array `donations` atau `socials`
 *    dengan format { label, url, icon (opsional) }.
 * ============================================================
 */

const creator = {
  // === Identitas Kreator (tampil di halaman profil) ===
  name: 'Dan',
  tagline: 'Creator of VellzyyMusik',
  bio: 'Halo! Saya kreator di balik VellzyyMusik — sebuah project music streaming yang dibuat untuk fun dan eksplorasi. Terima kasih sudah mampir!',
  avatar: 'https://api.dicebear.com/9.x/initials/svg?seed=Vellzyy&backgroundColor=1DB954&textColor=ffffff',

  // === Statistik dummy yang tampil di profil (boleh diubah) ===
  stats: {
    projects: 12,
    followers: '∞',
    since: 2024
  },

  // === Link Donasi (akan tampil sebagai tombol di profil) ===
  donations: [
    {
      label: 'Saweria',
      url: 'https://saweria.co/',
      description: 'Dukung lewat Saweria'
    },
    {
      label: 'Trakteer',
      url: 'https://trakteer.id/',
      description: 'Traktir kopi via Trakteer'
    },
    {
      label: 'Ko-fi',
      url: 'https://ko-fi.com/',
      description: 'Buy me a coffee'
    }
  ],

  // === Link Sosial Media (opsional, akan tampil di profil) ===
  socials: [
    { label: 'GitHub', url: 'https://github.com/' },
    { label: 'Instagram', url: 'https://instagram.com/' },
    { label: 'WhatsApp', url: 'https://wa.me/' }
  ],

  // === Nama Aplikasi (tampil di sidebar & header) ===
  app: {
    name: 'VellzyyMusik',
    short: 'Vellzyy',
    description: 'Modern music streaming inspired by Spotify',
    tagline: 'Dengarkan musik favoritmu, kapan saja.'
  }
};

module.exports = creator;
