import './globals.css';
import { Suspense } from 'react';
import { DesktopSidebar, MobileBottomNav } from '@/components/Sidebar';
import TopBar from '@/components/TopBar';
import PlayerBar from '@/components/PlayerBar';
import { PlayerProvider } from '@/context/PlayerContext';
import creator from '@/config/creator';

export const metadata = {
  title: `${creator.app.name} — ${creator.app.tagline}`,
  description: creator.app.description,
  applicationName: creator.app.name
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0a0a0a'
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className="overflow-x-hidden">
        <PlayerProvider>
          <div className="flex h-screen overflow-hidden bg-bg-base w-full">
            {/* Desktop sidebar */}
            <DesktopSidebar />

            <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
              <Suspense fallback={<div className="h-12 border-b border-white/5 bg-bg-base" />}>
                <TopBar />
              </Suspense>
              {/* Konten scroll — pb besar di mobile agar tidak ketutup mini player + bottom nav */}
              <div className="flex-1 overflow-y-auto overflow-x-hidden pb-40 md:pb-24">
                <div className="px-3 sm:px-6 lg:px-8 pb-6 animate-fade-in w-full">
                  {children}
                </div>
              </div>
            </main>
          </div>

          <PlayerBar />
          <MobileBottomNav />
        </PlayerProvider>
      </body>
    </html>
  );
}
