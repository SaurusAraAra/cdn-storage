import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="pt-20 text-center max-w-md mx-auto">
      <div className="text-7xl">🎵</div>
      <h1 className="text-3xl font-black text-white mt-4">404</h1>
      <p className="text-text-subdued mt-2">Halaman yang kamu cari tidak ada.</p>
      <Link
        href="/"
        className="inline-block mt-6 bg-accent text-black font-bold px-5 py-2 rounded-full hover:bg-accent-light transition-colors"
      >
        Kembali ke Home
      </Link>
    </div>
  );
}
