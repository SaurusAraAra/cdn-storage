import Link from 'next/link';
import TrackRow from '@/components/TrackRow';
import { getSpotify } from '@/lib/spotify';
import { bestImage, formatNumber } from '@/lib/utils';

export const revalidate = 600;

export async function generateMetadata({ params }) {
  try {
    const data = await getSpotify().playlist(params.id);
    if (!data) return { title: 'Playlist — VellzyyMusik' };
    return { title: `${data.name} — VellzyyMusik` };
  } catch {
    return { title: 'Playlist — VellzyyMusik' };
  }
}

export default async function PlaylistPage({ params }) {
  let data;
  let error = null;
  try {
    data = await getSpotify().playlist(params.id);
  } catch (e) {
    error = e?.message || 'Gagal memuat playlist';
  }

  if (error) {
    return (
      <div className="pt-10 rounded-lg border border-red-500/30 bg-red-500/10 text-red-200 px-4 py-3 text-sm">
        {error}
      </div>
    );
  }
  if (!data) {
    return <div className="pt-10 text-text-subdued">Playlist tidak ditemukan.</div>;
  }

  const cover = bestImage(data.images, 'large');
  const accentColor = data.color || '#1DB954';

  return (
    <div className="-mx-4 sm:-mx-6 lg:-mx-8">
      {/* Hero */}
      <section
        className="px-4 sm:px-6 lg:px-8 pt-8 pb-6"
        style={{
          background: `linear-gradient(180deg, ${accentColor}55 0%, ${accentColor}22 30%, rgba(10,10,10,1) 100%)`
        }}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6">
          <div className="w-44 h-44 sm:w-56 sm:h-56 rounded-md overflow-hidden bg-bg-highlight shadow-2xl shrink-0">
            {cover && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={cover} alt={data.name} className="w-full h-full object-cover" />
            )}
          </div>
          <div className="min-w-0">
            <div className="text-xs uppercase tracking-widest text-text-subdued font-bold">
              Playlist
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mt-1 line-clamp-3">
              {data.name}
            </h1>
            {data.description && (
              <div
                className="text-text-subdued text-sm mt-2 line-clamp-2"
                dangerouslySetInnerHTML={{ __html: data.description }}
              />
            )}
            <div className="flex flex-wrap items-center gap-x-2 mt-4 text-sm text-white/90">
              {data.owner?.display_name && (
                <span className="font-semibold">{data.owner.display_name}</span>
              )}
              {data.followers > 0 && (
                <>
                  <span className="text-text-subdued">•</span>
                  <span className="text-text-subdued">
                    {formatNumber(data.followers)} pengikut
                  </span>
                </>
              )}
              <span className="text-text-subdued">•</span>
              <span className="text-text-subdued">{data.tracks?.length || 0} lagu</span>
            </div>
            <div className="mt-6 flex items-center gap-3">
              <button className="w-14 h-14 rounded-full bg-accent text-black hover:scale-105 transition-transform flex items-center justify-center glow-accent">
                <svg viewBox="0 0 24 24" className="w-6 h-6 ml-0.5" fill="currentColor">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </button>
              {data.url && (
                <a
                  href={data.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-text-subdued hover:text-white text-sm"
                >
                  Buka di Spotify →
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Tracks */}
      <section className="px-4 sm:px-6 lg:px-8 mt-2">
        <div className="grid grid-cols-[40px_1fr_auto] sm:grid-cols-[40px_1fr_1fr_60px] gap-4 px-4 py-2 border-b border-white/10 text-text-subdued text-xs uppercase tracking-widest">
          <div className="text-right">#</div>
          <div>Judul</div>
          <div className="hidden sm:block">Album</div>
          <div className="text-right">
            <svg viewBox="0 0 24 24" className="w-4 h-4 inline" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="9" />
              <path d="M12 7v5l3 2" strokeLinecap="round" />
            </svg>
          </div>
        </div>
        <div className="mt-2">
          {(data.tracks || []).map((t, i) => (
            <TrackRow key={t.id || i} index={i + 1} track={t} showAlbum showCover />
          ))}
        </div>
      </section>
    </div>
  );
}
