import Link from 'next/link';
import { getSpotify } from '@/lib/spotify';
import { bestImage, formatDuration, formatNumber } from '@/lib/utils';
import PlayButton from '@/components/PlayButton';

export const revalidate = 600;

export async function generateMetadata({ params }) {
  try {
    const data = await getSpotify().track(params.id);
    if (!data) return { title: 'Track — VellzyyMusik' };
    const artistNames = (data.artists || []).map((a) => a.name).join(', ');
    return { title: `${data.name} • ${artistNames} — VellzyyMusik` };
  } catch {
    return { title: 'Track — VellzyyMusik' };
  }
}

export default async function TrackPage({ params }) {
  let data;
  let error = null;
  try {
    data = await getSpotify().track(params.id);
  } catch (e) {
    error = e?.message || 'Gagal memuat lagu';
  }

  if (error) {
    return (
      <div className="pt-10 rounded-lg border border-red-500/30 bg-red-500/10 text-red-200 px-4 py-3 text-sm">
        {error}
      </div>
    );
  }
  if (!data) {
    return <div className="pt-10 text-text-subdued">Lagu tidak ditemukan.</div>;
  }

  const cover = bestImage(data.album?.images, 'large');
  const accentColor = data.album?.color || '#1DB954';
  const artistNames = (data.artists || []).map((a) => a.name).join(', ');

  const trackInfo = {
    id: params.id,
    name: data.name,
    artist: artistNames,
    cover: cover,
  };

  return (
    <div className="-mx-4 sm:-mx-6 lg:-mx-8">
      <section
        className="px-4 sm:px-6 lg:px-8 pt-8 pb-8"
        style={{
          background: `linear-gradient(180deg, ${accentColor}55 0%, ${accentColor}22 30%, rgba(10,10,10,1) 100%)`
        }}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6">
          <div className="w-52 h-52 sm:w-64 sm:h-64 rounded-md overflow-hidden bg-bg-highlight shadow-2xl shrink-0">
            {cover && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={cover} alt={data.name} className="w-full h-full object-cover" />
            )}
          </div>
          <div className="min-w-0">
            <div className="text-xs uppercase tracking-widest text-text-subdued font-bold">
              Lagu {data.explicit && <span className="ml-2 bg-text-subdued/30 text-text-subdued px-1.5 rounded">E</span>}
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mt-1 line-clamp-3">
              {data.name}
            </h1>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-4 text-sm text-white/90">
              {(data.artists || []).map((a, i) => (
                <span key={a.id || a.name || i}>
                  {i > 0 && <span className="text-text-subdued">,</span>}{' '}
                  {a.id ? (
                    <Link href={`/artist/${a.id}`} className="font-semibold hover:underline">
                      {a.name}
                    </Link>
                  ) : (
                    <span className="font-semibold">{a.name}</span>
                  )}
                </span>
              ))}
              {data.album?.id && (
                <>
                  <span className="text-text-subdued">•</span>
                  <Link href={`/album/${data.album.id}`} className="text-text-subdued hover:text-white hover:underline">
                    {data.album.name}
                  </Link>
                </>
              )}
              {data.album?.release_year && (
                <>
                  <span className="text-text-subdued">•</span>
                  <span className="text-text-subdued">{data.album.release_year}</span>
                </>
              )}
              <span className="text-text-subdued">•</span>
              <span className="text-text-subdued">{formatDuration(data.duration_ms)}</span>
            </div>
            <div className="mt-6 flex items-center gap-3">
              {/* Tombol Play — client component */}
              <PlayButton track={trackInfo} />

              {data.url && (
                <a
                  href={data.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-text-subdued hover:text-white text-sm"
                >
                  Buka di Spotify →
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 sm:px-6 lg:px-8 mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-bg-elevated rounded-lg p-4">
          <div className="text-text-subdued text-xs uppercase tracking-widest">Durasi</div>
          <div className="text-white font-bold text-lg mt-1">{formatDuration(data.duration_ms)}</div>
        </div>
        <div className="bg-bg-elevated rounded-lg p-4">
          <div className="text-text-subdued text-xs uppercase tracking-widest">Plays</div>
          <div className="text-white font-bold text-lg mt-1">{formatNumber(data.playcount)}</div>
        </div>
        <div className="bg-bg-elevated rounded-lg p-4">
          <div className="text-text-subdued text-xs uppercase tracking-widest">Track #</div>
          <div className="text-white font-bold text-lg mt-1">{data.track_number || '—'}</div>
        </div>
      </section>
    </div>
  );
}
