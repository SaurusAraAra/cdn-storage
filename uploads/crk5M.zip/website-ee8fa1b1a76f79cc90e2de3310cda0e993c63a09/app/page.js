import Link from 'next/link';
import Card from '@/components/Card';
import HistorySection from '@/components/HistorySection';
import { getSpotify } from '@/lib/spotify';
import { bestImage } from '@/lib/utils';
import creator from '@/config/creator';

export const revalidate = 600;

const GENRES = [
  { label: 'Top Hits',    q: 'top hits',    gradient: 'from-pink-500 to-rose-700' },
  { label: 'Indonesia',   q: 'indonesia',   gradient: 'from-red-500 to-orange-600' },
  { label: 'K-Pop',       q: 'kpop',        gradient: 'from-purple-500 to-fuchsia-700' },
  { label: 'EDM',         q: 'edm',         gradient: 'from-cyan-500 to-blue-700' },
  { label: 'Hip-Hop',     q: 'hip hop',     gradient: 'from-amber-500 to-yellow-700' },
  { label: 'Chill / Lofi',q: 'lofi chill',  gradient: 'from-teal-500 to-emerald-700' },
  { label: 'Jazz',        q: 'jazz',        gradient: 'from-orange-500 to-red-700' },
  { label: 'Rock',        q: 'rock',        gradient: 'from-slate-500 to-stone-700' },
];

async function fetchHomeSections() {
  const spotify = getSpotify();
  const queries = ['top hits', 'indonesia', 'chill lofi'];
  const results = await Promise.allSettled(queries.map((q) => spotify.search(q)));
  const sections = [];
  results.forEach((r, idx) => {
    if (r.status !== 'fulfilled' || !r.value) return;
    const title = idx === 0 ? 'Top Hits Sekarang' : idx === 1 ? 'Populer di Indonesia' : 'Chill & Relax';
    const playlists = (r.value.playlists || []).slice(0, 6);
    const albums = (r.value.albums || []).slice(0, 6);
    if (playlists.length > 0 || albums.length > 0) sections.push({ title, playlists, albums });
  });
  return sections;
}

function greeting() {
  const h = new Date().getUTCHours() + 7;
  const hour = ((h % 24) + 24) % 24;
  if (hour < 11) return 'Selamat pagi';
  if (hour < 15) return 'Selamat siang';
  if (hour < 18) return 'Selamat sore';
  return 'Selamat malam';
}

export default async function HomePage() {
  let sections = [];
  let fetchError = null;
  try { sections = await fetchHomeSections(); }
  catch (e) { fetchError = e?.message || 'Gagal memuat data'; }

  return (
    <div className="space-y-8 pt-4">

      {/* Greeting */}
      <section>
        <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
          {greeting()}, <span className="text-accent">{creator.name}</span>
        </h1>
        <p className="text-text-subdued mt-1 text-sm">
          Cari lagu, album, artis, atau playlist favoritmu.
        </p>
      </section>

      {/* Riwayat — client component, render hanya jika ada history */}
      <HistorySection />

      {/* Genre tiles */}
      <section>
        <div className="flex items-baseline justify-between mb-3">
          <h2 className="text-lg sm:text-2xl font-bold text-white">Jelajahi Genre</h2>
          <Link href="/search" className="text-xs text-text-subdued hover:text-white font-semibold uppercase tracking-widest">
            Lihat semua
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
          {GENRES.map((g) => (
            <Link key={g.q} href={`/search?q=${encodeURIComponent(g.q)}`}
              className={`relative aspect-[16/9] rounded-xl overflow-hidden bg-gradient-to-br ${g.gradient} active:scale-95 hover:scale-[1.02] transition-transform`}>
              <div className="absolute inset-0 flex items-end p-3">
                <span className="text-white text-base sm:text-xl font-black drop-shadow-md">{g.label}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {fetchError && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 text-red-200 px-4 py-3 text-sm">
          {fetchError}
        </div>
      )}

      {/* Trending sections */}
      {sections.map((section) => (
        <section key={section.title}>
          <h2 className="text-lg sm:text-2xl font-bold text-white mb-3">{section.title}</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5 sm:gap-4">
            {section.playlists.map((p) => (
              <Card key={p.id} href={p.id ? `/playlist/${p.id}` : '#'}
                image={bestImage(p.images, 'mid')} title={p.name}
                subtitle={p.description || `By ${p.owner?.display_name || 'Unknown'}`} badge="Playlist" />
            ))}
            {section.albums.slice(0, 3).map((a) => (
              <Card key={a.id} href={a.id ? `/album/${a.id}` : '#'}
                image={bestImage(a.images, 'mid')} title={a.name}
                subtitle={(a.artists || []).map((x) => x.name).join(', ')} badge="Album" />
            ))}
          </div>
        </section>
      ))}

      {sections.length === 0 && !fetchError && (
        <section className="bg-bg-elevated rounded-xl p-8 text-center text-text-subdued">
          Belum ada konten.{' '}
          <Link href="/search" className="text-accent hover:underline">Cari sesuatu</Link>
          {' '}untuk memulai.
        </section>
      )}
    </div>
  );
}
