import TrackRow from '@/components/TrackRow';
import { getSpotify } from '@/lib/spotify';
import { bestImage, formatNumber } from '@/lib/utils';

export const revalidate = 600;

export async function generateMetadata({ params }) {
  try {
    const data = await getSpotify().artist(params.id);
    if (!data) return { title: 'Artist — VellzyyMusik' };
    return { title: `${data.name} — VellzyyMusik` };
  } catch {
    return { title: 'Artist — VellzyyMusik' };
  }
}

export default async function ArtistPage({ params }) {
  let data;
  let error = null;
  try {
    data = await getSpotify().artist(params.id);
  } catch (e) {
    error = e?.message || 'Gagal memuat artis';
  }

  if (error) {
    return (
      <div className="pt-10 rounded-lg border border-red-500/30 bg-red-500/10 text-red-200 px-4 py-3 text-sm">
        {error}
      </div>
    );
  }
  if (!data) {
    return <div className="pt-10 text-text-subdued">Artis tidak ditemukan.</div>;
  }

  const header = bestImage(data.header_images, 'large');
  const avatar = bestImage(data.images, 'large');
  const accentColor = data.color || '#1DB954';

  return (
    <div className="-mx-4 sm:-mx-6 lg:-mx-8">
      {/* Hero */}
      <section
        className="relative h-72 sm:h-96 px-4 sm:px-6 lg:px-8 flex items-end overflow-hidden"
        style={{
          backgroundImage: header
            ? `url(${header})`
            : `linear-gradient(180deg, ${accentColor}66, ${accentColor}11)`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 gradient-mask" />
        <div className="relative z-10 pb-6 max-w-4xl">
          {data.verified && (
            <div className="flex items-center gap-2 text-white text-sm mb-2">
              <span className="bg-blue-500 rounded-full w-5 h-5 flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-3 h-3" fill="white">
                  <path d="M9 12.5l2 2 4-4.5" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
              <span className="font-semibold">Verified Artist</span>
            </div>
          )}
          <h1 className="text-5xl sm:text-7xl font-black text-white drop-shadow-2xl line-clamp-2">
            {data.name}
          </h1>
          {data.statistics?.monthly_listeners > 0 && (
            <div className="mt-4 text-white/90 text-sm">
              {formatNumber(data.statistics.monthly_listeners)} pendengar bulanan
            </div>
          )}
        </div>
      </section>

      {/* Quick actions */}
      <section className="px-4 sm:px-6 lg:px-8 mt-6 flex items-center gap-3">
        <button className="w-14 h-14 rounded-full bg-accent text-black hover:scale-105 transition-transform flex items-center justify-center glow-accent">
          <svg viewBox="0 0 24 24" className="w-6 h-6 ml-0.5" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </button>
        {data.url && (
          <a
            href={data.url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-text-subdued hover:text-white text-sm"
          >
            Buka di Spotify →
          </a>
        )}
      </section>

      {/* Top tracks */}
      {data.top_tracks?.length > 0 && (
        <section className="px-4 sm:px-6 lg:px-8 mt-10">
          <h2 className="text-xl sm:text-2xl font-bold text-white mb-4">Lagu Populer</h2>
          <div className="bg-bg-elevated/40 rounded-lg p-2">
            {data.top_tracks.slice(0, 10).map((t, i) => (
              <TrackRow
                key={t.id || i}
                index={i + 1}
                track={{
                  ...t,
                  artists: [{ id: data.id, name: data.name }]
                }}
                showAlbum
                showCover
              />
            ))}
          </div>
        </section>
      )}

      {/* About */}
      <section className="px-4 sm:px-6 lg:px-8 mt-10 pb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-white mb-4">Tentang</h2>
        <div className="bg-bg-elevated rounded-lg overflow-hidden">
          {avatar && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={avatar} alt={data.name} className="w-full h-64 object-cover" />
          )}
          <div className="p-5 grid grid-cols-2 gap-4">
            <div>
              <div className="text-text-subdued text-xs uppercase tracking-widest">
                Pendengar Bulanan
              </div>
              <div className="text-white font-bold text-lg mt-1">
                {formatNumber(data.statistics?.monthly_listeners || 0)}
              </div>
            </div>
            <div>
              <div className="text-text-subdued text-xs uppercase tracking-widest">
                Pengikut
              </div>
              <div className="text-white font-bold text-lg mt-1">
                {formatNumber(data.statistics?.followers || 0)}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
