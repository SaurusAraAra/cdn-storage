import Link from 'next/link';
import Card from '@/components/Card';
import TrackRow from '@/components/TrackRow';
import { getSpotify } from '@/lib/spotify';
import { bestImage } from '@/lib/utils';

export const dynamic = 'force-dynamic';

export default async function SearchPage({ searchParams }) {
  const q = (searchParams?.q || '').trim();

  if (!q) {
    return (
      <div className="pt-10 max-w-2xl mx-auto text-center">
        <div className="mx-auto w-20 h-20 rounded-full bg-bg-elevated flex items-center justify-center text-text-subdued mb-6">
          <svg viewBox="0 0 24 24" className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.8">
            <circle cx="11" cy="11" r="7" />
            <path d="M21 21l-4.3-4.3" strokeLinecap="round" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-white">Cari di VellzyyMusik</h1>
        <p className="text-text-subdued mt-2 text-sm">
          Temukan lagu, album, artis, atau playlist favoritmu. Gunakan kolom pencarian di atas.
        </p>
        <div className="flex flex-wrap gap-2 justify-center mt-6">
          {['Tulus', 'Coldplay', 'NIKI', 'BTS', 'Taylor Swift', 'Bruno Mars'].map((s) => (
            <Link
              key={s}
              href={`/search?q=${encodeURIComponent(s)}`}
              className="px-3 py-1.5 rounded-full bg-bg-elevated hover:bg-bg-highlight text-sm text-text-subdued hover:text-white transition-colors"
            >
              {s}
            </Link>
          ))}
        </div>
      </div>
    );
  }

  let result;
  let error = null;
  try {
    result = await getSpotify().search(q);
  } catch (e) {
    error = e?.message || 'Gagal mencari';
  }

  if (error) {
    return (
      <div className="pt-10">
        <h1 className="text-2xl font-bold text-white">Hasil untuk &quot;{q}&quot;</h1>
        <div className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 text-red-200 px-4 py-3 text-sm">
          {error}
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="pt-10 text-text-subdued">
        Tidak ada hasil untuk &quot;{q}&quot;.
      </div>
    );
  }

  const topResult = result.top_results?.[0];
  const tracks = (result.tracks || []).slice(0, 5);
  const artists = (result.artists || []).slice(0, 8);
  const albums = (result.albums || []).slice(0, 8);
  const playlists = (result.playlists || []).slice(0, 8);

  return (
    <div className="space-y-10 pt-6">
      <h1 className="text-2xl sm:text-3xl font-black text-white">
        Hasil untuk <span className="text-accent">&ldquo;{q}&rdquo;</span>
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top result */}
        {topResult && (
          <section className="lg:col-span-1">
            <h2 className="text-xl font-bold text-white mb-4">Top Result</h2>
            <Link
              href={topResultHref(topResult)}
              className="block bg-bg-elevated card-hover rounded-lg p-5"
            >
              <div className={`w-24 h-24 ${topResult.type === 'Artist' ? 'rounded-full' : 'rounded-md'} overflow-hidden bg-bg-highlight mb-4 shadow-lg`}>
                {topResult.images?.[0]?.url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={bestImage(topResult.images, 'mid')} alt={topResult.name} className="w-full h-full object-cover" />
                )}
              </div>
              <div className="text-2xl font-black text-white line-clamp-2">{topResult.name}</div>
              <div className="text-text-subdued text-sm mt-2 uppercase tracking-widest">
                {topResult.type || 'Result'}
              </div>
            </Link>
          </section>
        )}

        {/* Songs */}
        {tracks.length > 0 && (
          <section className="lg:col-span-2">
            <h2 className="text-xl font-bold text-white mb-4">Lagu</h2>
            <div className="bg-bg-elevated rounded-lg p-2">
              {tracks.map((t, i) => (
                <TrackRow key={t.id || i} index={i + 1} track={t} showAlbum showCover />
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Artists */}
      {artists.length > 0 && (
        <section>
          <h2 className="text-xl font-bold text-white mb-4">Artis</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {artists.map((a) => (
              <Card
                key={a.id}
                href={a.id ? `/artist/${a.id}` : '#'}
                image={bestImage(a.images, 'mid')}
                title={a.name}
                subtitle="Artis"
                rounded="full"
              />
            ))}
          </div>
        </section>
      )}

      {/* Albums */}
      {albums.length > 0 && (
        <section>
          <h2 className="text-xl font-bold text-white mb-4">Album</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {albums.map((a) => (
              <Card
                key={a.id}
                href={a.id ? `/album/${a.id}` : '#'}
                image={bestImage(a.images, 'mid')}
                title={a.name}
                subtitle={`${a.release_year || ''} • ${(a.artists || []).map((x) => x.name).join(', ')}`}
                badge={a.type || 'Album'}
              />
            ))}
          </div>
        </section>
      )}

      {/* Playlists */}
      {playlists.length > 0 && (
        <section>
          <h2 className="text-xl font-bold text-white mb-4">Playlist</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {playlists.map((p) => (
              <Card
                key={p.id}
                href={p.id ? `/playlist/${p.id}` : '#'}
                image={bestImage(p.images, 'mid')}
                title={p.name}
                subtitle={p.description || `By ${p.owner?.display_name || 'Unknown'}`}
                badge="Playlist"
              />
            ))}
          </div>
        </section>
      )}

      {tracks.length === 0 &&
        artists.length === 0 &&
        albums.length === 0 &&
        playlists.length === 0 && (
          <div className="text-text-subdued text-center py-12">
            Tidak ditemukan hasil untuk &quot;{q}&quot;.
          </div>
        )}
    </div>
  );
}

function topResultHref(top) {
  if (!top?.id) return '#';
  const t = (top.type || '').toLowerCase();
  if (t === 'artist') return `/artist/${top.id}`;
  if (t === 'album') return `/album/${top.id}`;
  if (t === 'playlist') return `/playlist/${top.id}`;
  if (t === 'track') return `/track/${top.id}`;
  return '#';
}
