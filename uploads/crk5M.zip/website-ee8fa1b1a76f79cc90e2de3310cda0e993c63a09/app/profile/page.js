import creator from '@/config/creator';

export const metadata = {
  title: `Profil Kreator — ${creator.app.name}`,
  description: `Profil ${creator.name}, kreator ${creator.app.name}.`
};

export default function ProfilePage() {
  return (
    <div className="-mx-4 sm:-mx-6 lg:-mx-8">
      {/* Hero */}
      <section className="hero-gradient px-4 sm:px-6 lg:px-8 pt-10 pb-12">
        <div className="flex flex-col sm:flex-row items-center sm:items-end gap-6 max-w-5xl mx-auto">
          {/* Avatar */}
          <div className="w-44 h-44 sm:w-52 sm:h-52 rounded-full overflow-hidden bg-bg-highlight shadow-2xl shrink-0 ring-4 ring-white/10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={creator.avatar}
              alt={creator.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="min-w-0 text-center sm:text-left">
            <div className="text-xs uppercase tracking-widest text-text-subdued font-bold">
              Creator
            </div>
            <h1 className="text-5xl sm:text-7xl font-black text-white mt-1 leading-tight">
              {creator.name}
            </h1>
            <div className="text-text-subdued text-sm mt-2 max-w-md">
              {creator.tagline}
            </div>
            <div className="text-text-subdued text-xs mt-4 flex flex-wrap gap-x-3 gap-y-1 justify-center sm:justify-start">
              <span>
                <span className="text-white font-semibold">{creator.stats.projects}</span> projects
              </span>
              <span>•</span>
              <span>
                <span className="text-white font-semibold">{creator.stats.followers}</span> followers
              </span>
              <span>•</span>
              <span>since {creator.stats.since}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Bio */}
      <section className="px-4 sm:px-6 lg:px-8 mt-6 max-w-3xl mx-auto">
        <h2 className="text-xl sm:text-2xl font-bold text-white mb-3">Tentang Saya</h2>
        <p className="text-text-subdued leading-relaxed">{creator.bio}</p>
      </section>

      {/* Donations */}
      {creator.donations?.length > 0 && (
        <section className="px-4 sm:px-6 lg:px-8 mt-10 max-w-3xl mx-auto">
          <h2 className="text-xl sm:text-2xl font-bold text-white mb-4">
            Dukung Kreator <span className="text-accent">♥</span>
          </h2>
          <p className="text-text-subdued text-sm mb-5">
            Jika kamu suka project ini, kamu bisa support kreator via salah satu platform di bawah.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {creator.donations.map((d) => (
              <a
                key={d.label}
                href={d.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group bg-bg-elevated card-hover rounded-lg p-5 flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-full bg-accent/20 text-accent flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:text-black transition-colors">
                  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="currentColor">
                    <path d="M12 21s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.5-7 10-7 10z" />
                  </svg>
                </div>
                <div className="min-w-0">
                  <div className="text-white font-semibold">{d.label}</div>
                  <div className="text-text-subdued text-xs truncate">{d.description}</div>
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Socials */}
      {creator.socials?.length > 0 && (
        <section className="px-4 sm:px-6 lg:px-8 mt-10 max-w-3xl mx-auto pb-4">
          <h2 className="text-xl sm:text-2xl font-bold text-white mb-4">Sosial Media</h2>
          <div className="flex flex-wrap gap-2">
            {creator.socials.map((s) => (
              <a
                key={s.label}
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-full bg-bg-elevated hover:bg-bg-highlight text-white text-sm font-semibold border border-white/10 hover:border-white/20 transition-colors"
              >
                {s.label}
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Footer note */}
      <section className="px-4 sm:px-6 lg:px-8 mt-10 max-w-3xl mx-auto pb-6">
        <div className="bg-bg-elevated/50 rounded-lg p-5 text-text-subdued text-xs border border-white/5">
          <strong className="text-white">Catatan:</strong> Untuk mengubah profil ini
          (nama, foto, link donasi, sosial media), edit file{' '}
          <code className="bg-black/50 px-1 py-0.5 rounded text-white font-mono">config/creator.js</code>{' '}
          — tidak perlu menyentuh kode lain.
        </div>
      </section>
    </div>
  );
}
