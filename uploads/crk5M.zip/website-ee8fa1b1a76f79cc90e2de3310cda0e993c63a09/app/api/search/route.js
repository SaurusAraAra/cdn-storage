import { NextResponse } from 'next/server';
import { getSpotify } from '@/lib/spotify';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get('q');

  if (!q || !q.trim()) {
    return NextResponse.json({ error: 'Missing query parameter `q`' }, { status: 400 });
  }

  try {
    const data = await getSpotify().search(q.trim());
    return NextResponse.json({ ok: true, data });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err?.message || 'Search failed' },
      { status: 500 }
    );
  }
}
