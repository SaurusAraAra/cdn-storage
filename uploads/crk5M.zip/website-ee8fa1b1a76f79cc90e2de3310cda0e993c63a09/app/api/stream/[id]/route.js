import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const API_BASE = 'https://kyzznekoo.zone.id/api/downloader/spotify';

export async function GET(_request, { params }) {
  const { id } = params;
  if (!id) {
    return NextResponse.json({ ok: false, error: 'Missing id' }, { status: 400 });
  }

  const spotifyUrl = `https://open.spotify.com/track/${id}`;
  const apiUrl = `${API_BASE}?url=${encodeURIComponent(spotifyUrl)}`;

  try {
    const res = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json, */*',
        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8',
      },
      cache: 'no-store',
    });

    const json = await res.json();

    // Format: { result: { result: { title, artist, image, download: { url } } } }
    const inner = json?.result?.result;

    if (!inner) {
      throw new Error('Format response tidak dikenali: ' + JSON.stringify(json).slice(0, 200));
    }

    const audioUrl = inner?.download?.url;

    if (!audioUrl) {
      throw new Error('Audio URL tidak tersedia untuk lagu ini');
    }

    return NextResponse.json({
      ok: true,
      url: audioUrl,
      title: inner.title || '',
      artist: inner.artist || '',
      thumbnail: inner.image || '',
    });
  } catch (err) {
    console.error('[stream] Error:', err?.message);
    return NextResponse.json(
      { ok: false, error: err?.message || 'Gagal mengambil audio' },
      { status: 500 }
    );
  }
}
