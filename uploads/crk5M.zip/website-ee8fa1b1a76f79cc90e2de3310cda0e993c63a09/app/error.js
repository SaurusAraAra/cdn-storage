'use client';

import { useEffect } from 'react';
import Link from 'next/link';

export default function GlobalError({ error, reset }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="pt-20 text-center max-w-md mx-auto">
      <div className="text-7xl">⚠️</div>
      <h1 className="text-3xl font-black text-white mt-4">Terjadi Kesalahan</h1>
      <p className="text-text-subdued mt-2 text-sm break-words">{error?.message || 'Unknown error'}</p>
      <div className="flex justify-center gap-3 mt-6">
        <button
          onClick={() => reset()}
          className="bg-accent text-black font-bold px-5 py-2 rounded-full hover:bg-accent-light transition-colors"
        >
          Coba Lagi
        </button>
        <Link
          href="/"
          className="bg-bg-elevated text-white font-bold px-5 py-2 rounded-full hover:bg-bg-highlight transition-colors"
        >
          Home
        </Link>
      </div>
    </div>
  );
}
