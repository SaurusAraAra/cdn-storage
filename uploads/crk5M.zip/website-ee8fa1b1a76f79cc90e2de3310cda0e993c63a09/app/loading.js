export default function Loading() {
  return (
    <div className="pt-10 animate-pulse">
      <div className="space-y-6">
        <div className="h-8 w-64 bg-bg-elevated rounded" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="bg-bg-elevated rounded-lg p-4">
              <div className="aspect-square bg-bg-highlight rounded-md" />
              <div className="h-4 w-3/4 bg-bg-highlight rounded mt-3" />
              <div className="h-3 w-1/2 bg-bg-highlight rounded mt-2" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
