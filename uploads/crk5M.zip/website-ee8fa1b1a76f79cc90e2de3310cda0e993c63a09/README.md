# VellzyyMusik

> Modern, elegant music streaming website inspired by Spotify. Built with **Next.js 14 (App Router)** and ready to deploy on **Vercel** with zero config.

VellzyyMusik uses a Spotify public-API scraper under the hood to provide search, track, artist, album, and playlist browsing — all wrapped in a sleek Spotify-style dark UI.

---

## Features

- **Search** — tracks, artists, albums, playlists, podcasts, episodes, users
- **Track detail** — name, artists, album, duration, playcount
- **Artist detail** — verified badge, monthly listeners, top tracks
- **Album detail** — full track list with durations, copyrights
- **Playlist detail** — owner info, followers, full track list
- **Creator profile** — single configurable file (`config/creator.js`) for name, bio, avatar, donation links, and socials
- **Spotify-like UI** — sidebar nav, sticky topbar with search, bottom player bar, smooth animations
- **Mobile-friendly** — responsive layout from phone to desktop
- **Vercel-ready** — `vercel.json` included; deploy in one click

## Quick Start

```bash
# 1. Install deps
npm install

# 2. Dev server (http://localhost:3000)
npm run dev

# 3. Build for production
npm run build && npm start
```

## Deploy to Vercel

1. Push this repo to GitHub.
2. Go to <https://vercel.com/new> and import the repo.
3. Click **Deploy**. No environment variables are required.

## Customize Your Creator Profile

Open <a href="./config/creator.js">`config/creator.js`</a> and edit it. This is the **only file** you need to touch:

```js
const creator = {
  name: 'Dan',                          // Your name
  tagline: 'Creator of VellzyyMusik',
  bio: '...',
  avatar: '/me.jpg',                    // or a full URL

  donations: [
    { label: 'Saweria', url: 'https://saweria.co/yourname', description: '...' },
    // add more...
  ],
  socials: [
    { label: 'GitHub', url: 'https://github.com/yourname' },
    // add more...
  ],
  app: {
    name: 'VellzyyMusik',               // App name shown in sidebar/header
    // ...
  }
};
```

After editing, restart the dev server (or redeploy on Vercel).

## Project Structure

```
app/
  ├─ layout.js              Root layout (sidebar + topbar + player)
  ├─ page.js                Home (greeting + genre tiles + trending)
  ├─ search/page.js         Search results
  ├─ album/[id]/page.js     Album detail
  ├─ artist/[id]/page.js    Artist detail
  ├─ playlist/[id]/page.js  Playlist detail
  ├─ track/[id]/page.js     Track detail
  ├─ profile/page.js        Creator profile
  └─ api/
     ├─ search/route.js     GET /api/search?q=...
     ├─ track/[id]/route.js
     ├─ artist/[id]/route.js
     ├─ album/[id]/route.js
     └─ playlist/[id]/route.js
components/
  ├─ Sidebar.js
  ├─ TopBar.js
  ├─ PlayerBar.js
  ├─ Card.js                Cover card (album/artist/playlist)
  └─ TrackRow.js
config/
  └─ creator.js             ← EDIT THIS FILE to change profile
lib/
  ├─ spotify.js             Spotify scrape client (server-side)
  └─ utils.js
```

## API Routes

| Endpoint                | Method | Description                                  |
| ----------------------- | ------ | -------------------------------------------- |
| `/api/search?q=<query>` | GET    | Search tracks/artists/albums/playlists/...   |
| `/api/track/[id]`       | GET    | Get full track detail by Spotify track id    |
| `/api/artist/[id]`      | GET    | Get artist overview + top tracks             |
| `/api/album/[id]`       | GET    | Get album detail + tracks                    |
| `/api/playlist/[id]`    | GET    | Get playlist detail + tracks                 |

All API responses follow the shape `{ ok: boolean, data?: ..., error?: ... }`.

## Theming

The accent color (default Spotify-green `#1DB954`) is defined in `tailwind.config.js`. Edit the `colors.accent.*` keys to rebrand.

## Notes

- The scraper does **not** provide playable audio streams. The bottom player bar is decorative; clicking "Open in Spotify" on a track/album/playlist opens the original page where you can play.
- All Spotify API calls run **server-side** in Next.js API routes / Server Components — your client never sees the auth token.
- Free Vercel functions cap at 10s by default; we extend that to 30s in `vercel.json` for safety.

## License

MIT — do whatever you want.
