'use client';

import Link from 'next/link';
import { formatDuration } from '@/lib/utils';
import { usePlayer } from '@/context/PlayerContext';

/**
 * Compact track row used inside album / playlist / artist top-tracks list.
 * Klik nomor/ikon → play langsung. Klik nama → buka halaman track.
 */
export default function TrackRow({ index, track, showAlbum = true, showCover = true }) {
  const { playTrack, togglePlay, currentTrack, status } = usePlayer();

  if (!track) return null;
  const artists = track.artists || [];
  const cover = track.album?.images?.[0]?.url;

  const isThisTrack = currentTrack?.id === track.id;
  const isPlaying = isThisTrack && status === 'playing';
  const isLoading = isThisTrack && status === 'loading';

  const handlePlay = () => {
    if (!track.id) return;
    if (isThisTrack && (status === 'playing' || status === 'paused')) {
      togglePlay();
    } else {
      playTrack({
        id: track.id,
        name: track.name,
        artist: artists.map((a) => a.name).join(', '),
        cover: cover || null,
      });
    }
  };

  return (
    <div
      className={`group grid grid-cols-[40px_1fr_auto] sm:grid-cols-[40px_1fr_1fr_60px] gap-4 items-center px-4 py-2 rounded-md hover:bg-white/5 transition-colors ${isThisTrack ? 'bg-white/5' : ''}`}
    >
      {/* Index / play icon */}
      <div
        className="text-text-subdued text-sm tabular-nums text-right cursor-pointer select-none"
        onClick={handlePlay}
        title={isPlaying ? 'Pause' : 'Play'}
      >
        {isLoading ? (
          <svg className="w-4 h-4 animate-spin inline text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4" strokeLinecap="round" />
          </svg>
        ) : isPlaying ? (
          <svg viewBox="0 0 24 24" className="w-4 h-4 inline text-accent" fill="currentColor">
            <path d="M6 5h4v14H6zM14 5h4v14h-4z" />
          </svg>
        ) : (
          <span className="group-hover:hidden">{index ?? '·'}</span>
        )}
        {!isPlaying && !isLoading && (
          <svg viewBox="0 0 24 24" className="w-4 h-4 hidden group-hover:inline text-white ml-0.5" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        )}
      </div>

      <div className="flex items-center gap-3 min-w-0">
        {showCover && (
          <div
            className="w-10 h-10 shrink-0 rounded bg-bg-highlight overflow-hidden cursor-pointer"
            onClick={handlePlay}
          >
            {cover ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={cover} alt="" className="w-full h-full object-cover" loading="lazy" />
            ) : null}
          </div>
        )}
        <div className="min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            {track.id ? (
              <Link
                href={`/track/${track.id}`}
                className={`text-sm font-medium hover:underline truncate ${isThisTrack ? 'text-accent' : 'text-white'}`}
              >
                {track.name || 'Unknown'}
              </Link>
            ) : (
              <span className="text-white text-sm font-medium truncate">{track.name || 'Unknown'}</span>
            )}
            {track.explicit && (
              <span className="text-[9px] bg-text-subdued/30 text-text-subdued px-1 rounded shrink-0">E</span>
            )}
          </div>
          <div className="text-text-subdued text-xs truncate">
            {artists.length === 0
              ? '—'
              : artists.map((a, i) => (
                  <span key={`${a.id || a.uri}-${i}`}>
                    {i > 0 && ', '}
                    {a.id ? (
                      <Link href={`/artist/${a.id}`} className="hover:text-white hover:underline">
                        {a.name}
                      </Link>
                    ) : (
                      <span>{a.name}</span>
                    )}
                  </span>
                ))}
          </div>
        </div>
      </div>

      {showAlbum && (
        <div className="hidden sm:block text-text-subdued text-xs truncate">
          {track.album?.id ? (
            <Link href={`/album/${track.album.id}`} className="hover:text-white hover:underline">
              {track.album?.name || ''}
            </Link>
          ) : (
            track.album?.name || ''
          )}
        </div>
      )}

      <div className="text-text-subdued text-xs tabular-nums text-right">
        {formatDuration(track.duration_ms)}
      </div>
    </div>
  );
}
