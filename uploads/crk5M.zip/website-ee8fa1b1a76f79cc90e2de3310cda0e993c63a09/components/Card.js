import Link from 'next/link';

/**
 * Reusable cover-card used for albums, artists, playlists in grids.
 *
 * Props:
 *  - href: link target
 *  - image: cover image url (string) or null
 *  - title: main label
 *  - subtitle: secondary label
 *  - rounded: 'square' (album/playlist) or 'full' (artist)
 *  - badge: optional small label shown over the cover
 */
export default function Card({
  href,
  image,
  title,
  subtitle,
  rounded = 'square',
  badge
}) {
  const roundedClass = rounded === 'full' ? 'rounded-full' : 'rounded-md';

  return (
    <Link
      href={href || '#'}
      className="group relative block bg-bg-elevated card-hover rounded-lg p-3 sm:p-4 transition-colors"
    >
      <div className={`relative aspect-square w-full ${roundedClass} overflow-hidden bg-bg-highlight shadow-lg`}>
        {image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={image}
            alt={title || ''}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-text-subdued text-3xl">
            ♪
          </div>
        )}

        {badge && (
          <span className="absolute top-2 left-2 bg-black/70 text-[10px] uppercase tracking-widest px-2 py-1 rounded-full text-white">
            {badge}
          </span>
        )}

        {/* Play button overlay */}
        <button
          tabIndex={-1}
          aria-hidden="true"
          className="play-btn absolute bottom-2 right-2 w-11 h-11 rounded-full bg-accent text-black flex items-center justify-center shadow-xl glow-accent"
        >
          <svg viewBox="0 0 24 24" className="w-5 h-5 ml-0.5" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </button>
      </div>

      <div className="mt-3">
        <div className="text-white font-semibold text-sm line-clamp-1">{title || '—'}</div>
        {subtitle && (
          <div className="text-text-subdued text-xs mt-1 line-clamp-2">{subtitle}</div>
        )}
      </div>
    </Link>
  );
}
