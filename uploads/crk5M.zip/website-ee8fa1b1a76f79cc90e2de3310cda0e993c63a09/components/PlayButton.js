'use client';

import { usePlayer } from '@/context/PlayerContext';

/**
 * Tombol play di halaman track.
 * track = { id, name, artist, cover }
 */
export default function PlayButton({ track }) {
  const { playTrack, togglePlay, currentTrack, status } = usePlayer();

  const isThisTrack = currentTrack?.id === track?.id;
  const isPlaying = isThisTrack && status === 'playing';
  const isLoading = isThisTrack && status === 'loading';

  const handleClick = () => {
    if (isThisTrack && (status === 'playing' || status === 'paused')) {
      togglePlay();
    } else {
      playTrack(track);
    }
  };

  return (
    <button
      onClick={handleClick}
      className="w-14 h-14 rounded-full bg-accent text-black hover:scale-105 transition-transform flex items-center justify-center glow-accent disabled:opacity-60"
      aria-label={isPlaying ? 'Pause' : 'Play'}
      disabled={isLoading}
    >
      {isLoading ? (
        <svg className="w-6 h-6 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" strokeLinecap="round" />
        </svg>
      ) : isPlaying ? (
        <svg viewBox="0 0 24 24" className="w-6 h-6" fill="currentColor">
          <path d="M6 5h4v14H6zM14 5h4v14h-4z" />
        </svg>
      ) : (
        <svg viewBox="0 0 24 24" className="w-6 h-6 ml-0.5" fill="currentColor">
          <path d="M8 5v14l11-7z" />
        </svg>
      )}
    </button>
  );
}
