'use client';

import Link from 'next/link';
import { usePlayer } from '@/context/PlayerContext';

function timeAgo(ts) {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'Baru saja';
  if (m < 60) return `${m} menit lalu`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} jam lalu`;
  return `${Math.floor(h / 24)} hari lalu`;
}

export default function HistorySection() {
  const { history, playTrack, clearHistory, currentTrack, status } = usePlayer();

  if (history.length === 0) return null;

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-xl font-bold text-white">Terakhir Diputar</h2>
        <button onClick={clearHistory}
          className="text-xs text-text-subdued hover:text-white transition-colors">
          Hapus semua
        </button>
      </div>

      <div className="flex flex-col gap-1">
        {history.slice(0, 8).map((track) => {
          const isActive = currentTrack?.id === track.id;
          const isPlaying = isActive && status === 'playing';

          return (
            <div key={`${track.id}-${track.playedAt}`}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 active:bg-white/10 transition-colors group ${isActive ? 'bg-white/5' : ''}`}>

              {/* Cover */}
              <div className="w-12 h-12 rounded-xl bg-bg-highlight overflow-hidden shrink-0 relative">
                {track.cover
                  ? <img src={track.cover} alt="" className="w-full h-full object-cover" loading="lazy" /> // eslint-disable-line
                  : <div className="w-full h-full flex items-center justify-center text-accent">
                      <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M9 18V5l12-2v13M9 18a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    </div>
                }
                {/* Play overlay */}
                <button onClick={() => playTrack(track)}
                  className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-xl">
                  {isPlaying
                    ? <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>
                    : <svg viewBox="0 0 24 24" className="w-5 h-5 text-white ml-0.5" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                  }
                </button>
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <Link href={`/track/${track.id}`}
                  className={`text-sm font-semibold truncate block hover:underline ${isActive ? 'text-accent' : 'text-white'}`}>
                  {track.name}
                </Link>
                <div className="text-text-subdued text-xs truncate">{track.artist}</div>
              </div>

              {/* Waktu */}
              <div className="text-text-subdued text-xs shrink-0 hidden sm:block">
                {timeAgo(track.playedAt)}
              </div>

              {/* Indikator sedang main */}
              {isPlaying && (
                <div className="flex items-end gap-0.5 h-4 shrink-0">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="w-0.5 bg-accent rounded-full animate-pulse"
                      style={{ height: `${[60, 100, 70][i - 1]}%`, animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
