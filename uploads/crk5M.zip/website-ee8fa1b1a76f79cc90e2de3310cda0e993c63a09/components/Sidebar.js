'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import creator from '@/config/creator';

const navItems = [
  {
    href: '/',
    label: 'Beranda',
    icon: (active) => (
      <svg viewBox="0 0 24 24" className="w-6 h-6" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2">
        <path d="M3 11.5L12 4l9 7.5V20a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1v-8.5z" />
      </svg>
    )
  },
  {
    href: '/search',
    label: 'Cari',
    icon: (active) => (
      <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="11" cy="11" r="7" />
        <path d="M21 21l-4.3-4.3" strokeLinecap="round" />
        {active && <circle cx="11" cy="11" r="3" fill="currentColor" stroke="none" />}
      </svg>
    )
  },
  {
    href: '/profile',
    label: 'Profil',
    icon: (active) => (
      <svg viewBox="0 0 24 24" className="w-6 h-6" fill={active ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21c0-4 4-7 8-7s8 3 8 7" />
      </svg>
    )
  }
];

// ─── Desktop Sidebar (md+) ───────────────────────────────────────────────────
export function DesktopSidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex flex-col w-64 lg:w-72 bg-bg-press border-r border-white/5 shrink-0">
      <div className="px-6 pt-6 pb-4">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-black font-black text-lg shadow-lg glow-accent">V</div>
          <div>
            <div className="text-white font-bold text-lg leading-tight">{creator.app.name}</div>
            <div className="text-text-subdued text-[10px] uppercase tracking-widest">Music Streaming</div>
          </div>
        </Link>
      </div>

      <nav className="px-3">
        {navItems.map((item) => {
          const active = item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href}
              className={`flex items-center gap-4 px-4 py-3 rounded-md text-sm font-semibold transition-colors ${active ? 'bg-white/10 text-white' : 'text-text-subdued hover:text-white'}`}>
              <span>{item.icon(active)}</span>
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="mx-6 my-4 h-px bg-white/5" />

      <div className="flex-1 overflow-y-auto px-3">
        <div className="px-4 pt-2 pb-3 text-text-subdued text-xs font-bold uppercase tracking-widest">Explore</div>
        <div className="flex flex-col gap-1">
          {[
            { q: 'Top Hits', href: '/search?q=top+hits' },
            { q: 'Chill Lofi', href: '/search?q=lofi+chill' },
            { q: 'Indonesia', href: '/search?q=indonesia' },
            { q: 'K-Pop', href: '/search?q=kpop' },
            { q: 'EDM', href: '/search?q=edm' },
            { q: 'Hip-Hop', href: '/search?q=hip+hop' },
          ].map((s) => (
            <Link key={s.q} href={s.href}
              className="px-4 py-2 rounded-md text-sm text-text-subdued hover:text-white hover:bg-white/5 transition-colors">
              {s.q}
            </Link>
          ))}
        </div>
      </div>

      <div className="p-3 border-t border-white/5">
        <Link href="/profile" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-white/5 transition-colors">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={creator.avatar} alt={creator.name} className="w-9 h-9 rounded-full object-cover bg-white/10" />
          <div className="min-w-0">
            <div className="text-white text-sm font-semibold truncate">{creator.name}</div>
            <div className="text-text-subdued text-xs truncate">{creator.tagline}</div>
          </div>
        </Link>
      </div>
    </aside>
  );
}

// ─── Mobile Bottom Nav Bar ───────────────────────────────────────────────────
export function MobileBottomNav() {
  const pathname = usePathname();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-bg-press/95 backdrop-blur-lg border-t border-white/10">
      <div className="flex items-center justify-around px-2 pt-2 pb-safe" style={{ paddingBottom: 'max(8px, env(safe-area-inset-bottom))' }}>
        {navItems.map((item) => {
          const active = item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href}
              className={`flex flex-col items-center gap-0.5 px-5 py-1 rounded-xl transition-colors ${active ? 'text-accent' : 'text-text-subdued'}`}>
              {item.icon(active)}
              <span className="text-[10px] font-semibold">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

// Default export tetap untuk desktop (dipakai layout)
export default DesktopSidebar;
