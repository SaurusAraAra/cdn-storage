'use client';

import { usePlayer } from '@/context/PlayerContext';
import { formatDuration } from '@/lib/utils';

function fmtSec(sec) {
  if (!sec || isNaN(sec)) return '0:00';
  return formatDuration(Math.floor(sec) * 1000);
}

export default function PlayerBar() {
  const { currentTrack, status, progress, currentTime, duration, volume, errorMsg, togglePlay, seek, changeVolume } = usePlayer();

  const isLoading = status === 'loading';
  const isPlaying = status === 'playing';
  const hasTrack = !!currentTrack;

  // ─── Mobile mini-player (di atas bottom nav) ──────────────────────────────
  const MobilePlayer = () => (
    <div className={`md:hidden fixed z-30 left-3 right-3 bg-bg-elevated border border-white/10 rounded-2xl shadow-2xl transition-all duration-300 ${hasTrack ? 'bottom-[68px] opacity-100' : 'bottom-[-100px] opacity-0 pointer-events-none'}`}>
      {/* Progress bar tipis di atas */}
      <div className="relative h-0.5 bg-white/10 rounded-t-2xl overflow-hidden"
        onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); seek((e.clientX - r.left) / r.width); }}>
        <div className="h-full bg-accent transition-all" style={{ width: `${(progress * 100).toFixed(1)}%` }} />
      </div>

      <div className="flex items-center gap-3 px-3 py-2.5">
        {/* Cover */}
        <div className="w-11 h-11 rounded-xl bg-bg-highlight overflow-hidden shrink-0 shadow">
          {currentTrack?.cover
            ? <img src={currentTrack.cover} alt="" className="w-full h-full object-cover" /> // eslint-disable-line
            : <div className="w-full h-full flex items-center justify-center text-accent">
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M9 18V5l12-2v13M9 18a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              </div>
          }
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className={`text-sm font-semibold truncate ${status === 'error' ? 'text-red-400' : 'text-white'}`}>
            {status === 'error' ? errorMsg : (currentTrack?.name || 'Tidak ada lagu')}
          </div>
          <div className="text-text-subdued text-xs truncate">{currentTrack?.artist || ''}</div>
        </div>

        {/* Waktu */}
        <div className="text-text-subdued text-xs tabular-nums shrink-0">
          {fmtSec(currentTime)}<span className="opacity-40 mx-0.5">/</span>{fmtSec(duration)}
        </div>

        {/* Play/Pause */}
        <button onClick={hasTrack ? togglePlay : undefined} disabled={isLoading || !hasTrack}
          className="w-10 h-10 rounded-full bg-accent flex items-center justify-center text-black shrink-0 disabled:opacity-40 active:scale-95 transition-transform shadow glow-accent">
          {isLoading
            ? <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4" strokeLinecap="round"/></svg>
            : isPlaying
              ? <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>
              : <svg viewBox="0 0 24 24" className="w-5 h-5 ml-0.5" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          }
        </button>
      </div>
    </div>
  );

  // ─── Desktop player bar (fixed bottom) ───────────────────────────────────
  const DesktopPlayer = () => (
    <div className="hidden md:block fixed bottom-0 left-0 right-0 z-30 bg-gradient-to-r from-black via-bg-press to-black border-t border-white/5 backdrop-blur-md">
      <div className="px-4 py-3 flex items-center justify-between gap-4">
        {/* Track info */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="w-12 h-12 rounded bg-bg-highlight overflow-hidden flex items-center justify-center text-accent shrink-0">
            {currentTrack?.cover
              ? <img src={currentTrack.cover} alt="" className="w-full h-full object-cover" /> // eslint-disable-line
              : <svg viewBox="0 0 24 24" className="w-6 h-6" fill="currentColor"><path d="M9 18V5l12-2v13M9 18a3 3 0 11-6 0 3 3 0 016 0zM21 16a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            }
          </div>
          <div className="min-w-0">
            <div className="text-white text-sm font-semibold truncate">{currentTrack?.name || 'Tidak ada lagu'}</div>
            <div className="text-text-subdued text-xs truncate">
              {status === 'error' ? <span className="text-red-400">{errorMsg}</span> : (currentTrack?.artist || 'Pilih lagu untuk diputar')}
            </div>
          </div>
        </div>

        {/* Controls + progress */}
        <div className="flex flex-col items-center gap-1 flex-1 max-w-xl">
          <button onClick={hasTrack ? togglePlay : undefined} disabled={isLoading || !hasTrack}
            className={`w-9 h-9 rounded-full bg-white hover:scale-105 transition-transform flex items-center justify-center text-black disabled:opacity-40 ${isLoading ? 'animate-pulse' : ''}`}>
            {isLoading
              ? <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83" strokeLinecap="round"/></svg>
              : isPlaying
                ? <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>
                : <svg viewBox="0 0 24 24" className="w-5 h-5 ml-0.5" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
            }
          </button>
          <div className="flex items-center gap-2 w-full text-[10px] text-text-subdued">
            <span>{fmtSec(currentTime)}</span>
            <div className="h-1 flex-1 rounded-full bg-white/10 overflow-hidden cursor-pointer group"
              onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); seek((e.clientX - r.left) / r.width); }}>
              <div className="h-full bg-white group-hover:bg-accent transition-colors" style={{ width: `${(progress * 100).toFixed(1)}%` }} />
            </div>
            <span>{fmtSec(duration)}</span>
          </div>
        </div>

        {/* Volume */}
        <div className="flex items-center justify-end flex-1 gap-2">
          <svg viewBox="0 0 24 24" className="w-4 h-4 text-text-subdued shrink-0" fill="currentColor">
            <path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/>
          </svg>
          <input type="range" min="0" max="1" step="0.05" value={volume}
            onChange={(e) => changeVolume(Number(e.target.value))}
            className="w-20 accent-accent cursor-pointer" />
        </div>
      </div>
    </div>
  );

  return (
    <>
      <MobilePlayer />
      <DesktopPlayer />
    </>
  );
}
