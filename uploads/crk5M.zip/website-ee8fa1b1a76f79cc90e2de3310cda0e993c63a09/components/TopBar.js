'use client';

import { useRouter, usePathname, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import creator from '@/config/creator';

export default function TopBar() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [q, setQ] = useState('');

  useEffect(() => {
    if (pathname === '/search') {
      setQ(searchParams.get('q') || '');
    }
  }, [pathname, searchParams]);

  const onSubmit = (e) => {
    e.preventDefault();
    if (!q.trim()) return;
    router.push(`/search?q=${encodeURIComponent(q.trim())}`);
  };

  return (
    <header className="sticky top-0 z-20 bg-bg-base/90 backdrop-blur-md border-b border-white/5">
      <div className="px-3 sm:px-6 py-2.5 flex items-center gap-3">

        {/* Mobile: Logo kiri */}
        <Link href="/" className="md:hidden flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-black font-black text-sm shadow glow-accent">V</div>
          <span className="text-white font-bold text-sm">{creator.app.name}</span>
        </Link>

        {/* Desktop: back/forward */}
        <div className="hidden md:flex items-center gap-2 shrink-0">
          <button onClick={() => router.back()}
            className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white transition-colors">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M15 18l-6-6 6-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <button onClick={() => router.forward()}
            className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white transition-colors">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* Search bar */}
        <form onSubmit={onSubmit} className="flex-1">
          <label className="flex items-center gap-2 bg-bg-elevated border border-white/8 focus-within:border-white/25 rounded-full px-3 py-2 transition-colors">
            <svg viewBox="0 0 24 24" className="w-4 h-4 text-text-subdued shrink-0" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="7" />
              <path d="M21 21l-4.3-4.3" strokeLinecap="round" />
            </svg>
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={`Cari di ${creator.app.name}…`}
              className="bg-transparent flex-1 outline-none text-sm text-white placeholder:text-text-subdued"
            />
            {q && (
              <button type="button" onClick={() => setQ('')}
                className="text-text-subdued hover:text-white text-xs shrink-0">✕</button>
            )}
          </label>
        </form>

        {/* Avatar — desktop only */}
        <Link href="/profile"
          className="hidden sm:flex items-center gap-2 bg-black/50 hover:bg-black/70 rounded-full pl-1 pr-3 py-1 transition-colors shrink-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={creator.avatar} alt={creator.name} className="w-7 h-7 rounded-full bg-white/10" />
          <span className="text-white text-sm font-semibold hidden md:inline">{creator.name}</span>
        </Link>
      </div>
    </header>
  );
}
