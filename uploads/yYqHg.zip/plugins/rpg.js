const fs = require('fs')
const path = require('path')
const rpgDBPath = './library/database/rpg.json'

let _getBanInfo = null
try {
    _getBanInfo = require('./rpg-anticheat').getBanInfo
} catch(e) {
    _getBanInfo = () => null
}
const userDBPath = './library/database/user.json'
const limitBonusPath = './library/database/limit_bonus.json'
const marketDBPath = './library/database/market.json'
const pantiDBPath = './library/database/panti_asuhan.json'
const toRupiah = (n) => {
    const num = Number(n) || 0
    return 'Rp. ' + num.toLocaleString('id-ID')
}
if (!fs.existsSync(pantiDBPath)) {
    fs.writeFileSync(pantiDBPath, JSON.stringify({ anak: [] }, null, 2))
}
if (!fs.existsSync(rpgDBPath)) {
    const defaultRPG = {
        players: {},
        monsters: {
            // ════════════════════════════════════════════
            //  ⭐ TIER 1 — PEMULA (Level 1–5)
            // ════════════════════════════════════════════
            "1":  { "name": "🐀 Tikus Got",         "hp": 18,  "attack": 3,  "defense": 1,  "exp": 8,   "gold": 5,   "level": 1,  "tier": 1, "drops": { "kulit_goblin": 0.4 } },
            "2":  { "name": "🐛 Ulat Beracun",       "hp": 22,  "attack": 4,  "defense": 1,  "exp": 10,  "gold": 7,   "level": 1,  "tier": 1, "drops": { "racun_laba": 0.5, "rumput_liar": 0.6 } },
            "3":  { "name": "🐸 Katak Raksasa",      "hp": 28,  "attack": 5,  "defense": 2,  "exp": 14,  "gold": 10,  "level": 2,  "tier": 1, "drops": { "kulit_goblin": 0.5, "jamur_ajaib": 0.2 } },
            "4":  { "name": "👺 Goblin",              "hp": 30,  "attack": 5,  "defense": 2,  "exp": 15,  "gold": 10,  "level": 2,  "tier": 1, "drops": { "kulit_goblin": 0.7, "taring_goblin": 0.3 } },
            "5":  { "name": "🐺 Serigala Kecil",     "hp": 35,  "attack": 6,  "defense": 2,  "exp": 18,  "gold": 12,  "level": 3,  "tier": 1, "drops": { "kulit_goblin": 0.4, "taring_goblin": 0.2 } },
            "6":  { "name": "🦎 Kadal Pasir",        "hp": 32,  "attack": 6,  "defense": 3,  "exp": 16,  "gold": 11,  "level": 3,  "tier": 1, "drops": { "kulit_goblin": 0.5, "batu": 0.8 } },
            "7":  { "name": "🐝 Lebah Raksasa",      "hp": 25,  "attack": 7,  "defense": 1,  "exp": 13,  "gold": 9,   "level": 2,  "tier": 1, "drops": { "racun_laba": 0.4, "bunga_langka": 0.3 } },
            "8":  { "name": "🌿 Tanaman Berjalan",   "hp": 40,  "attack": 4,  "defense": 4,  "exp": 17,  "gold": 8,   "level": 3,  "tier": 1, "drops": { "rumput_liar": 0.9, "bunga_langka": 0.2 } },

            // ════════════════════════════════════════════
            //  ⭐⭐ TIER 2 — MENENGAH BAWAH (Level 5–10)
            // ════════════════════════════════════════════
            "9":  { "name": "🕷️ Laba-laba Raksasa",  "hp": 45,  "attack": 7,  "defense": 3,  "exp": 20,  "gold": 15,  "level": 4,  "tier": 2, "drops": { "racun_laba": 0.6, "kulit_goblin": 0.2 } },
            "10": { "name": "🐗 Babi Hutan Liar",    "hp": 55,  "attack": 8,  "defense": 4,  "exp": 25,  "gold": 18,  "level": 5,  "tier": 2, "drops": { "kulit_orc": 0.4, "batu_kekuatan": 0.1 } },
            "11": { "name": "💀 Goblin Pemanah",     "hp": 48,  "attack": 9,  "defense": 3,  "exp": 22,  "gold": 17,  "level": 5,  "tier": 2, "drops": { "taring_goblin": 0.7, "batu_bara": 0.3 } },
            "12": { "name": "🧟 Zombie Prajurit",    "hp": 60,  "attack": 8,  "defense": 5,  "exp": 28,  "gold": 20,  "level": 5,  "tier": 2, "drops": { "kulit_orc": 0.3, "batu_kekuatan": 0.1 } },
            "13": { "name": "🐊 Buaya Sungai",       "hp": 65,  "attack": 10, "defense": 6,  "exp": 30,  "gold": 22,  "level": 6,  "tier": 2, "drops": { "kulit_orc": 0.5, "racun_laba": 0.2 } },
            "14": { "name": "🧌 Orc Prajurit",       "hp": 70,  "attack": 10, "defense": 5,  "exp": 32,  "gold": 25,  "level": 6,  "tier": 2, "drops": { "kulit_orc": 0.6, "batu_kekuatan": 0.15 } },
            "15": { "name": "🦂 Kalajengking Bara",  "hp": 58,  "attack": 11, "defense": 4,  "exp": 27,  "gold": 20,  "level": 6,  "tier": 2, "drops": { "racun_laba": 0.7, "batu_bara": 0.4 } },
            "16": { "name": "🐻 Beruang Hutan",      "hp": 80,  "attack": 9,  "defense": 6,  "exp": 35,  "gold": 28,  "level": 7,  "tier": 2, "drops": { "kulit_orc": 0.5, "taring_goblin": 0.3 } },

            // ════════════════════════════════════════════
            //  ⭐⭐⭐ TIER 3 — MENENGAH (Level 8–15)
            // ════════════════════════════════════════════
            "17": { "name": "👹 Goblin Jendral",     "hp": 80,  "attack": 12, "defense": 6,  "exp": 70,  "gold": 60,  "level": 7,  "tier": 3, "drops": { "batu_kekuatan": 0.5, "taring_goblin": 0.8 } },
            "18": { "name": "🌊 Troll Rawa",         "hp": 90,  "attack": 13, "defense": 7,  "exp": 55,  "gold": 45,  "level": 8,  "tier": 3, "drops": { "kulit_orc": 0.6, "batu_kekuatan": 0.25 } },
            "19": { "name": "🦁 Singa Berbisa",      "hp": 95,  "attack": 14, "defense": 6,  "exp": 60,  "gold": 50,  "level": 8,  "tier": 3, "drops": { "racun_laba": 0.5, "batu_kekuatan": 0.3 } },
            "20": { "name": "🌲 Troll Hutan",        "hp": 100, "attack": 13, "defense": 8,  "exp": 65,  "gold": 55,  "level": 9,  "tier": 3, "drops": { "kulit_orc": 0.4, "batu_kekuatan": 0.2 } },
            "21": { "name": "🐍 Ular Raksasa Biru",  "hp": 88,  "attack": 15, "defense": 5,  "exp": 62,  "gold": 52,  "level": 9,  "tier": 3, "drops": { "racun_laba": 0.8, "kristal_es": 0.15 } },
            "22": { "name": "🧙 Penyihir Gelap",     "hp": 75,  "attack": 16, "defense": 4,  "exp": 68,  "gold": 58,  "level": 10, "tier": 3, "drops": { "batu_kekuatan": 0.4, "permata": 0.1 } },
            "23": { "name": "🦅 Elang Api Kecil",    "hp": 85,  "attack": 14, "defense": 5,  "exp": 60,  "gold": 50,  "level": 9,  "tier": 3, "drops": { "bulu_phoenix": 0.15, "batu_kekuatan": 0.3 } },
            "24": { "name": "⚔️ Ksatria Mati",       "hp": 110, "attack": 15, "defense": 9,  "exp": 75,  "gold": 65,  "level": 10, "tier": 3, "drops": { "bijih_besi": 0.6, "batu_kekuatan": 0.35 } },

            // ════════════════════════════════════════════
            //  ⭐⭐⭐⭐ TIER 4 — KUAT (Level 12–18)
            // ════════════════════════════════════════════
            "25": { "name": "🐲 Naga Kecil",         "hp": 130, "attack": 17, "defense": 9,  "exp": 90,  "gold": 80,  "level": 11, "tier": 4, "drops": { "sisik_naga": 0.4, "batu_kekuatan": 0.3 } },
            "26": { "name": "🌋 Elemental Api",      "hp": 120, "attack": 19, "defense": 8,  "exp": 95,  "gold": 85,  "level": 12, "tier": 4, "drops": { "batu_kekuatan": 0.5, "permata": 0.2 } },
            "27": { "name": "❄️ Elemental Es",       "hp": 115, "attack": 18, "defense": 10, "exp": 90,  "gold": 80,  "level": 12, "tier": 4, "drops": { "kristal_es": 0.6, "batu_kekuatan": 0.25 } },
            "28": { "name": "🦈 Hiu Daratan",        "hp": 125, "attack": 20, "defense": 7,  "exp": 98,  "gold": 88,  "level": 13, "tier": 4, "drops": { "kulit_orc": 0.3, "tulang_naga": 0.1 } },
            "29": { "name": "🧿 Beholder",           "hp": 140, "attack": 18, "defense": 11, "exp": 105, "gold": 95,  "level": 13, "tier": 4, "drops": { "permata": 0.3, "batu_kekuatan": 0.4 } },
            "30": { "name": "🦴 Raja Zombie",        "hp": 145, "attack": 19, "defense": 10, "exp": 110, "gold": 100, "level": 14, "tier": 4, "drops": { "tulang_naga": 0.15, "mithril": 0.05 } },
            "31": { "name": "🌪️ Djinn Badai",        "hp": 130, "attack": 22, "defense": 8,  "exp": 115, "gold": 105, "level": 14, "tier": 4, "drops": { "kristal_es": 0.4, "permata": 0.25 } },
            "32": { "name": "🐯 Harimau Roh",        "hp": 135, "attack": 21, "defense": 9,  "exp": 108, "gold": 98,  "level": 13, "tier": 4, "drops": { "batu_kekuatan": 0.45, "kristal_es": 0.2 } },

            // ════════════════════════════════════════════
            //  ⭐⭐⭐⭐⭐ TIER 5 — SANGAT KUAT (Level 16–22)
            // ════════════════════════════════════════════
            "33": { "name": "🐉 Naga",               "hp": 160, "attack": 23, "defense": 12, "exp": 140, "gold": 130, "level": 15, "tier": 5, "drops": { "sisik_naga": 0.5, "tulang_naga": 0.2, "batu_kekuatan": 0.3 } },
            "34": { "name": "🦊 Serigala Roh",       "hp": 150, "attack": 22, "defense": 10, "exp": 130, "gold": 120, "level": 15, "tier": 5, "drops": { "kristal_es": 0.4, "batu_kekuatan": 0.2 } },
            "35": { "name": "🌑 Wraith Kegelapan",   "hp": 145, "attack": 25, "defense": 9,  "exp": 145, "gold": 135, "level": 16, "tier": 5, "drops": { "permata": 0.4, "mithril": 0.08 } },
            "36": { "name": "🗿 Golem Batu",         "hp": 200, "attack": 20, "defense": 18, "exp": 155, "gold": 145, "level": 17, "tier": 5, "drops": { "batu_kekuatan": 0.6, "mithril": 0.1, "permata": 0.2 } },
            "37": { "name": "🧊 Ice Drake",          "hp": 185, "attack": 24, "defense": 15, "exp": 165, "gold": 155, "level": 17, "tier": 5, "drops": { "kristal_es": 0.6, "tulang_naga": 0.3 } },
            "38": { "name": "🌊 Leviathan Kecil",    "hp": 195, "attack": 23, "defense": 14, "exp": 170, "gold": 160, "level": 18, "tier": 5, "drops": { "sisik_naga": 0.4, "tulang_naga": 0.25 } },
            "39": { "name": "🔥 Ifrit",              "hp": 175, "attack": 27, "defense": 12, "exp": 160, "gold": 150, "level": 17, "tier": 5, "drops": { "bulu_phoenix": 0.3, "permata": 0.3 } },
            "40": { "name": "⚡ Raksasa Petir",      "hp": 190, "attack": 26, "defense": 13, "exp": 158, "gold": 148, "level": 18, "tier": 5, "drops": { "kristal_es": 0.5, "mithril": 0.1 } },

            // ════════════════════════════════════════════
            //  💀 TIER 6 — BOSS KELAS (Level 20–28)
            // ════════════════════════════════════════════
            "41": { "name": "🦅 Phoenix",            "hp": 220, "attack": 28, "defense": 15, "exp": 200, "gold": 190, "level": 20, "tier": 6, "drops": { "bulu_phoenix": 0.5, "sisik_naga": 0.3 } },
            "42": { "name": "👑 Lich King",          "hp": 300, "attack": 32, "defense": 18, "exp": 280, "gold": 260, "level": 22, "tier": 6, "drops": { "orichalcum": 0.2, "bulu_phoenix": 0.3, "mithril": 0.5 } },
            "43": { "name": "🐲 Naga Tua",           "hp": 280, "attack": 30, "defense": 17, "exp": 250, "gold": 230, "level": 21, "tier": 6, "drops": { "sisik_naga": 0.6, "tulang_naga": 0.4, "mithril": 0.15 } },
            "44": { "name": "🕯️ Overlord Sihir",     "hp": 260, "attack": 35, "defense": 14, "exp": 270, "gold": 250, "level": 22, "tier": 6, "drops": { "permata": 0.5, "mithril": 0.2, "orichalcum": 0.08 } },
            "45": { "name": "🦂 Kalajengking Raksasa","hp": 290, "attack": 29, "defense": 20, "exp": 240, "gold": 220, "level": 21, "tier": 6, "drops": { "racun_laba": 0.8, "mithril": 0.1, "permata": 0.3 } },
            "46": { "name": "🌀 Void Walker",        "hp": 270, "attack": 33, "defense": 16, "exp": 260, "gold": 240, "level": 23, "tier": 6, "drops": { "mithril": 0.25, "orichalcum": 0.1 } },

            // ════════════════════════════════════════════
            //  💀💀 TIER 7 — ELITE (Level 25–35)
            // ════════════════════════════════════════════
            "47": { "name": "🌑 Demon Lord",         "hp": 380, "attack": 40, "defense": 22, "exp": 400, "gold": 380, "level": 25, "tier": 7, "drops": { "orichalcum": 0.25, "mithril": 0.4, "tulang_naga": 0.5 } },
            "48": { "name": "🐉 Naga Merah Purba",   "hp": 420, "attack": 38, "defense": 24, "exp": 450, "gold": 420, "level": 27, "tier": 7, "drops": { "sisik_naga": 0.8, "tulang_naga": 0.6, "orichalcum": 0.2 } },
            "49": { "name": "⚔️ Ksatria Iblis",      "hp": 360, "attack": 42, "defense": 20, "exp": 420, "gold": 400, "level": 26, "tier": 7, "drops": { "mithril": 0.5, "orichalcum": 0.15, "permata": 0.4 } },
            "50": { "name": "🌊 Leviathan",          "hp": 450, "attack": 36, "defense": 26, "exp": 480, "gold": 450, "level": 28, "tier": 7, "drops": { "tulang_naga": 0.7, "orichalcum": 0.2, "kristal_es": 0.5 } },
            "51": { "name": "🦴 Necromancer Agung",  "hp": 340, "attack": 45, "defense": 18, "exp": 460, "gold": 440, "level": 27, "tier": 7, "drops": { "orichalcum": 0.3, "mithril": 0.45, "bulu_phoenix": 0.4 } },

            // ════════════════════════════════════════════
            //  ☠️ TIER 8 — LEGENDA (Level 30–40)
            // ════════════════════════════════════════════
            "52": { "name": "🌋 Titan Api",          "hp": 550, "attack": 50, "defense": 30, "exp": 650, "gold": 620, "level": 30, "tier": 8, "drops": { "orichalcum": 0.35, "bulu_phoenix": 0.5, "mithril": 0.6 } },
            "53": { "name": "❄️ Titan Es",           "hp": 560, "attack": 48, "defense": 33, "exp": 680, "gold": 650, "level": 32, "tier": 8, "drops": { "kristal_es": 0.8, "orichalcum": 0.3, "mithril": 0.55 } },
            "54": { "name": "🌑 Abyssal Horror",     "hp": 600, "attack": 55, "defense": 28, "exp": 750, "gold": 720, "level": 33, "tier": 8, "drops": { "orichalcum": 0.4, "mithril": 0.65, "permata": 0.5 } },
            "55": { "name": "🐲 Naga Hitam Kuno",    "hp": 620, "attack": 52, "defense": 35, "exp": 780, "gold": 750, "level": 35, "tier": 8, "drops": { "sisik_naga": 1.0, "tulang_naga": 0.8, "orichalcum": 0.35 } },

            // ════════════════════════════════════════════
            //  💥 TIER 9 — MITOLOGI (Level 38–50)
            // ════════════════════════════════════════════
            "56": { "name": "👁️ Dewa Kegelapan",     "hp": 800, "attack": 65, "defense": 40, "exp": 1100, "gold": 1050, "level": 38, "tier": 9, "drops": { "orichalcum": 0.5, "mithril": 0.8, "bulu_phoenix": 0.6 } },
            "57": { "name": "🔱 Poseidon Palsu",     "hp": 850, "attack": 60, "defense": 45, "exp": 1200, "gold": 1150, "level": 40, "tier": 9, "drops": { "orichalcum": 0.55, "tulang_naga": 1.0, "kristal_es": 0.7 } },
            "58": { "name": "☄️ Meteor Golem",       "hp": 900, "attack": 58, "defense": 50, "exp": 1300, "gold": 1250, "level": 42, "tier": 9, "drops": { "orichalcum": 0.6, "permata": 0.8, "mithril": 0.9 } },
            "59": { "name": "🌑 Void Dragon",        "hp": 950, "attack": 70, "defense": 42, "exp": 1400, "gold": 1350, "level": 45, "tier": 9, "drops": { "orichalcum": 0.65, "sisik_naga": 1.0, "tulang_naga": 1.0 } },

            // ════════════════════════════════════════════
            //  🌟 TIER 10 — DEWA (Level 50+)
            // ════════════════════════════════════════════
            "60": { "name": "⚡ Zeus Terlarang",     "hp": 1200, "attack": 80, "defense": 55, "exp": 2000, "gold": 1950, "level": 50, "tier": 10, "drops": { "orichalcum": 0.8, "mithril": 1.0, "bulu_phoenix": 0.9 } },
            "61": { "name": "🔥 Surtr Sang Api",     "hp": 1400, "attack": 85, "defense": 50, "exp": 2200, "gold": 2150, "level": 52, "tier": 10, "drops": { "orichalcum": 0.85, "bulu_phoenix": 1.0, "tulang_naga": 1.0 } },
            "62": { "name": "💀 Azrael Si Maut",     "hp": 1600, "attack": 90, "defense": 58, "exp": 2500, "gold": 2450, "level": 55, "tier": 10, "drops": { "orichalcum": 1.0, "mithril": 1.0, "permata": 1.0, "bulu_phoenix": 1.0 } },
            "63": { "name": "🌌 Chaos Dragon",      "hp": 2000, "attack": 100,"defense": 65, "exp": 3000, "gold": 2950, "level": 60, "tier": 10, "drops": { "orichalcum": 1.0, "mithril": 1.0, "sisik_naga": 1.0, "tulang_naga": 1.0, "bulu_phoenix": 1.0 } }
        },
        locations: {
            // ══ Tier 1 ══
            "desa":         { "name": "🏡 Desa Pemula",        "monsters": [1,2,3,4,5,6,7,8],         "minLevel": 1,  "maxLevel": 5  },
            // ══ Tier 2 ══
            "hutan":        { "name": "🌲 Hutan Gelap",        "monsters": [4,5,8,9,10,11,12],         "minLevel": 3,  "maxLevel": 9  },
            "rawa":         { "name": "🌿 Rawa Beracun",       "monsters": [9,11,13,15,16],             "minLevel": 5,  "maxLevel": 10 },
            // ══ Tier 3 ══
            "gua":          { "name": "⛏️ Gua Naga",           "monsters": [14,17,18,19,20,21,22,23,24],"minLevel": 8,  "maxLevel": 16 },
            "padang_api":   { "name": "🌋 Padang Api",         "monsters": [15,22,23,26,31],            "minLevel": 10, "maxLevel": 18 },
            // ══ Tier 4 ══
            "pegunungan":   { "name": "🏔️ Pegunungan Es",      "monsters": [27,29,31,32,34,37],         "minLevel": 12, "maxLevel": 20 },
            "reruntuhan":   { "name": "🏚️ Reruntuhan Kuno",    "monsters": [24,28,29,30,36],            "minLevel": 13, "maxLevel": 20 },
            // ══ Tier 5 ══
            "kuil_api":     { "name": "🔥 Kuil Api Abadi",     "monsters": [33,35,39,40,41],            "minLevel": 16, "maxLevel": 24 },
            "laut_dalam":   { "name": "🌊 Laut Dalam",         "monsters": [34,38,40,43,50],            "minLevel": 17, "maxLevel": 25 },
            // ══ Tier 6 ══
            "menara_sihir": { "name": "🗼 Menara Sihir",       "monsters": [42,44,46,47,51],            "minLevel": 20, "maxLevel": 30 },
            "hutan_iblis":  { "name": "😈 Hutan Iblis",        "monsters": [43,45,47,48,49],            "minLevel": 22, "maxLevel": 32 },
            // ══ Tier 7 ══
            "neraka_atas":  { "name": "🌑 Gerbang Neraka",     "monsters": [47,48,49,50,51,52],         "minLevel": 25, "maxLevel": 35 },
            "samudera_void":{ "name": "🌀 Samudera Void",      "monsters": [46,50,53,54,55],            "minLevel": 28, "maxLevel": 38 },
            // ══ Tier 8 ══
            "gunung_titan": { "name": "⚡ Gunung Titan",       "monsters": [52,53,54,55,56],            "minLevel": 30, "maxLevel": 45 },
            // ══ Tier 9 ══
            "alam_dewa":    { "name": "👁️ Alam Para Dewa",     "monsters": [56,57,58,59],               "minLevel": 38, "maxLevel": 52 },
            // ══ Tier 10 ══
            "kekacauan":    { "name": "🌌 Dimensi Kekacauan",  "monsters": [60,61,62,63],               "minLevel": 50, "maxLevel": 999 },
            // ══ Resource Zones ══
            "tambang":      { "name": "⛏️ Tambang Terbengkalai","minLevel": 5,  "maxLevel": 30, "ores": { "batu": 0.8, "batu_bara": 0.5, "bijih_besi": 0.2, "permata": 0.05, "mithril": 0.02, "orichalcum": 0.005 } },
            "padang_rumput":{ "name": "🌾 Padang Rumput Liar", "minLevel": 2,  "maxLevel": 20, "herbs": { "rumput_liar": 0.9, "bunga_langka": 0.3, "jamur_ajaib": 0.1, "kristal_es": 0.05 } }
        },
        items: {
            "potion": { "name": "Potion", "type": "heal", "value": 40, "price": 2000 },
            "potion_besar": { "name": "Potion Besar", "type": "heal", "value": 100, "price": 8000 },
            "potion_super": { "name": "Super Potion", "type": "heal", "value": 200, "price": 25000 },
            "elixir_hidup": { "name": "Elixir Kehidupan", "type": "heal", "value": 999, "price": 150000 },
            "limit_bot_10": { "name": "10 Limit Bot", "type": "bot_feature", "value": 10, "price": 1000000 },
            "limit_bot_50": { "name": "50 Limit Bot", "type": "bot_feature", "value": 50, "price": 4000000 },
            "elixir": { "name": "Elixir", "type": "mana", "value": 30, "price": 3000 },
            "elixir_besar": { "name": "Elixir Besar", "type": "mana", "value": 80, "price": 12000 },
            "elixir_mana_penuh": { "name": "Mana Crystal", "type": "mana", "value": 999, "price": 100000 },
            // Senjata — harga jual ~35-50% dari price
            // Pemula: jual 500–5rb
            "pedang_kayu":    { "name": "Pedang Kayu",    "type": "weapon", "attack": 3,  "price": 3000 },
            "busur_kayu":     { "name": "Busur Kayu",     "type": "weapon", "attack": 5,  "price": 5000 },
            // Menengah: jual 5rb–50rb
            "pedang_besi":    { "name": "Pedang Besi",    "type": "weapon", "attack": 7,  "price": 30000 },
            "busur_besi":     { "name": "Busur Besi",     "type": "weapon", "attack": 12, "price": 60000 },
            "tongkat_sihir":  { "name": "Tongkat Sihir",  "type": "weapon", "attack": 10, "price": 50000 },
            // Mahir: jual 50rb–500rb
            "pedang_baja":    { "name": "Pedang Baja",    "type": "weapon", "attack": 13, "price": 400000 },
            "tongkat_kuno":   { "name": "Tongkat Kuno",   "type": "weapon", "attack": 25, "price": 800000 },
            "busur_elven":    { "name": "Busur Elven",    "type": "weapon", "attack": 28, "price": 1000000 },
            // Langka: jual 500rb–5jt
            "pedang_mithril": { "name": "Pedang Mithril", "type": "weapon", "attack": 22, "price": 5000000 },
            // Legendaris: jual 5jt–15jt
            "pedang_naga":    { "name": "Pedang Naga",    "type": "weapon", "attack": 35, "price": 25000000 },
            // Armor — harga jual ~35-50% dari price
            // Pemula: jual 300–3rb
            "baju_kain":      { "name": "Baju Kain",      "type": "armor", "defense": 2,  "price": 1500 },
            "perisai_kayu":   { "name": "Perisai Kayu",   "type": "armor", "defense": 3,  "price": 3000 },
            // Menengah: jual 3rb–30rb
            "zirah_kulit":    { "name": "Zirah Kulit",    "type": "armor", "defense": 5,  "price": 20000 },
            "perisai_besi":   { "name": "Perisai Besi",   "type": "armor", "defense": 8,  "price": 50000 },
            // Mahir: jual 30rb–300rb
            "zirah_besi":     { "name": "Zirah Besi",     "type": "armor", "defense": 10, "price": 200000 },
            "jubah_penyihir": { "name": "Jubah Penyihir", "type": "armor", "defense": 7,  "price": 150000 },
            // Kuat: jual 300rb–3jt
            "zirah_baja":     { "name": "Zirah Baja",     "type": "armor", "defense": 18, "price": 2000000 },
            // Legendaris: jual 3jt–10jt
            "zirah_mithril":  { "name": "Zirah Mithril",  "type": "armor", "defense": 30, "price": 15000000 },
            "zirah_baja":     { "name": "Zirah Baja",     "type": "armor", "defense": 18, "price": 2000000 },
            "jubah_penyihir": { "name": "Jubah Penyihir", "type": "armor", "defense": 7,  "price": 150000 },
            "zirah_mithril":  { "name": "Zirah Mithril",  "type": "armor", "defense": 30, "price": 15000000 },
            "perisai_kayu":   { "name": "Perisai Kayu",   "type": "armor", "defense": 3,  "price": 3000 },
            "perisai_besi":   { "name": "Perisai Besi",   "type": "armor", "defense": 8,  "price": 50000 },
            // Material — harga jual = 40% dari price
            // Tier 1 drop: jual 100–400
            "kulit_goblin":  { "name": "Kulit Goblin",      "type": "material", "price": 300 },
            "taring_goblin": { "name": "Taring Goblin",     "type": "material", "price": 700 },
            "rumput_liar":   { "name": "Rumput Liar",       "type": "material", "price": 250 },
            "batu":          { "name": "Batu",              "type": "material", "price": 150 },
            // Tier 2 drop: jual 500–2rb
            "kulit_orc":     { "name": "Kulit Orc",         "type": "material", "price": 2000 },
            "batu_bara":     { "name": "Batu Bara",         "type": "material", "price": 1500 },
            "racun_laba":    { "name": "Racun Laba-laba",   "type": "material", "price": 3000 },
            "bunga_langka":  { "name": "Bunga Langka",      "type": "material", "price": 8000 },
            "jamur_ajaib":   { "name": "Jamur Ajaib",       "type": "material", "price": 15000 },
            // Tier 3 drop: jual 2rb–10rb
            "batu_kekuatan": { "name": "Batu Kekuatan",     "type": "material", "price": 8000 },
            "bijih_besi":    { "name": "Bijih Besi",        "type": "material", "price": 4000 },
            // Tier 4 drop: jual 10rb–50rb
            "sisik_naga":    { "name": "Sisik Naga",        "type": "material", "price": 50000 },
            "kristal_es":    { "name": "Kristal Es",        "type": "material", "price": 30000 },
            "permata":       { "name": "Permata",           "type": "material", "price": 80000 },
            // Tier 5 drop: jual 100rb–500rb
            "tulang_naga":   { "name": "Tulang Naga",       "type": "material", "price": 300000 },
            "bulu_phoenix":  { "name": "Bulu Phoenix",      "type": "material", "price": 500000 },
            // Tambang premium
            "nikel":         { "name": "Nikel",             "type": "material", "price": 15000 },
            "emas":          { "name": "Emas",              "type": "material", "price": 500000 },
            "berlian":       { "name": "Berlian",           "type": "material", "price": 2000000 },
            // Tier 6 — jual 1jt–5jt
            "mithril":       { "name": "Mithril",           "type": "material", "price": 4000000 },
            // Tier 7 — jual max ~5jt (40% dari 12.5jt)
            "orichalcum":    { "name": "Orichalcum",        "type": "material", "price": 12500000 },
            // ── SENJATA ULTRA PREMIUM — jual 35% dari price, max ~25jt ──
            // pedang_dewa: 35% × 70jt = 24.5jt ✓
            "pedang_dewa":        { "name": "Pedang Dewa",        "type": "weapon", "attack": 60, "price": 70000000 },
            // tombak: 35% × 60jt = 21jt ✓
            "tombak_halilintar":  { "name": "Tombak Halilintar",  "type": "weapon", "attack": 55, "price": 60000000 },
            // katana: 35% × 50jt = 17.5jt ✓
            "katana_jiwa":        { "name": "Katana Jiwa",        "type": "weapon", "attack": 50, "price": 50000000 },
            // busur abadi: 35% × 45jt = 15.75jt ✓
            "busur_abadi":        { "name": "Busur Abadi",        "type": "weapon", "attack": 48, "price": 45000000 },
            // tongkat dewa: 35% × 40jt = 14jt ✓
            "tongkat_dewa":       { "name": "Tongkat Dewa",       "type": "weapon", "attack": 45, "price": 40000000 },
            // ── ARMOR ULTRA PREMIUM — jual 35% dari price, max ~25jt ──
            // zirah_dewa: 35% × 70jt = 24.5jt ✓
            "zirah_dewa":         { "name": "Zirah Dewa",         "type": "armor", "defense": 60, "price": 70000000 },
            // jubah_lich: 35% × 28.5jt = ~10jt ✓
            "jubah_lich":         { "name": "Jubah Lich King",    "type": "armor", "defense": 50, "price": 28500000 },
            // perisai_naga: 35% × 43jt = ~15jt ✓
            "perisai_naga":       { "name": "Perisai Naga",       "type": "armor", "defense": 45, "price": 43000000 },
            // zirah_orichalcum: 35% × 60jt = 21jt ✓
            "zirah_orichalcum":   { "name": "Zirah Orichalcum",   "type": "armor", "defense": 55, "price": 60000000 },
            // ── POTION ULTRA ──
            "megapotion":    { "name": "Mega Potion",  "type": "heal", "value": 400, "price": 500000 },
            "divinepotion":  { "name": "Divine Potion","type": "heal", "value": 999, "price": 5000000 },
            "megaelixir":    { "name": "Mega Elixir",  "type": "mana", "value": 400, "price": 500000 },
            "divineelixir":  { "name": "Divine Elixir","type": "mana", "value": 999, "price": 5000000 },
            // ── BOT FEATURE PREMIUM ──
            "limit_bot_100": { "name": "100 Limit Bot", "type": "bot_feature", "value": 100, "price": 7000000 },
            "limit_bot_500": { "name": "500 Limit Bot", "type": "bot_feature", "value": 500, "price": 25000000 }
        },
        craftingRecipes: {
            // ══════════════════════════════════════════
            //  🧪 POTION & ELIXIR
            // ══════════════════════════════════════════
            "potion_kuat":          { "name": "Potion Besar (craft)",    "result": "potion_besar",    "amount": 2, "materials": { "bunga_langka": 2, "jamur_ajaib": 1 } },
            "super_potion_craft":   { "name": "Super Potion (craft)",    "result": "potion_super",    "amount": 1, "materials": { "bunga_langka": 5, "jamur_ajaib": 3, "kristal_es": 1 } },
            "elixir_hidup_craft":   { "name": "Elixir Kehidupan (craft)","result": "elixir_hidup",   "amount": 1, "materials": { "bulu_phoenix": 1, "bunga_langka": 8, "jamur_ajaib": 5 } },
            "elixir_mana_craft":    { "name": "Elixir Besar (craft)",    "result": "elixir_besar",    "amount": 2, "materials": { "jamur_ajaib": 3, "rumput_liar": 5 } },
            "mana_crystal_craft":   { "name": "Mana Crystal (craft)",    "result": "elixir_mana_penuh","amount": 1,"materials": { "kristal_es": 3, "jamur_ajaib": 5, "bunga_langka": 3 } },
            "mega_potion_craft":    { "name": "Mega Potion (craft)",     "result": "megapotion",      "amount": 1, "materials": { "bulu_phoenix": 2, "sisik_naga": 3, "bunga_langka": 10, "jamur_ajaib": 8 } },
            "divine_potion_craft":  { "name": "Divine Potion (craft)",   "result": "divinepotion",    "amount": 1, "materials": { "orichalcum": 1, "bulu_phoenix": 3, "kristal_es": 5, "bunga_langka": 15 } },
            "mega_elixir_craft":    { "name": "Mega Elixir (craft)",     "result": "megaelixir",      "amount": 1, "materials": { "kristal_es": 5, "racun_laba": 3, "jamur_ajaib": 10, "bunga_langka": 8 } },
            "divine_elixir_craft":  { "name": "Divine Elixir (craft)",   "result": "divineelixir",    "amount": 1, "materials": { "orichalcum": 1, "kristal_es": 8, "bulu_phoenix": 2, "jamur_ajaib": 15 } },
            // ══════════════════════════════════════════
            //  🗡️ SENJATA — GOBLIN MATERIAL
            // ══════════════════════════════════════════
            "pedang_goblin":        { "name": "Pedang Goblin (craft)",   "result": "pedang_kayu",     "amount": 1, "materials": { "kulit_goblin": 5, "taring_goblin": 2 } },
            "busur_goblin":         { "name": "Busur Goblin (craft)",    "result": "busur_kayu",      "amount": 1, "materials": { "kulit_goblin": 3, "taring_goblin": 3 } },
            // ── ORC / TROLL ──
            "pedang_orc":           { "name": "Pedang Besi (craft)",     "result": "pedang_besi",     "amount": 1, "materials": { "bijih_besi": 5, "kulit_orc": 3, "taring_goblin": 2 } },
            "tongkat_orc":          { "name": "Tongkat Sihir (craft)",   "result": "tongkat_sihir",   "amount": 1, "materials": { "batu_kekuatan": 3, "kulit_orc": 2, "batu_bara": 3 } },
            "busur_orc":            { "name": "Busur Besi (craft)",      "result": "busur_besi",      "amount": 1, "materials": { "bijih_besi": 4, "kulit_orc": 4, "taring_goblin": 1 } },
            // ── BAJA ──
            "pedang_besi_tempa":    { "name": "Pedang Baja (craft)",     "result": "pedang_baja",     "amount": 1, "materials": { "bijih_besi": 10, "batu_bara": 5, "nikel": 2 } },
            "tongkat_kuno_craft":   { "name": "Tongkat Kuno (craft)",    "result": "tongkat_kuno",    "amount": 1, "materials": { "batu_kekuatan": 8, "sisik_naga": 3, "permata": 2 } },
            // ── LABA-LABA / SERIGALA ROH ──
            "pedang_racun":         { "name": "Pedang Racun (craft)",    "result": "pedang_baja",     "amount": 1, "materials": { "racun_laba": 5, "bijih_besi": 8, "kulit_goblin": 4 } },
            "busur_elven_craft":    { "name": "Busur Elven (craft)",     "result": "busur_elven",     "amount": 1, "materials": { "kristal_es": 5, "bulu_phoenix": 1, "batu_kekuatan": 5, "mithril": 2 } },
            // ── MITHRIL / NAGA ──
            "pedang_mithril_craft": { "name": "Pedang Mithril (craft)",  "result": "pedang_mithril",  "amount": 1, "materials": { "mithril": 5, "batu_kekuatan": 3, "sisik_naga": 2 } },
            "tongkat_mithril":      { "name": "Tongkat Mithril (craft)", "result": "pedang_mithril",  "amount": 1, "materials": { "mithril": 4, "kristal_es": 4, "batu_kekuatan": 5 } },
            // ── NAGA / PHOENIX ──
            "pedang_naga_craft":    { "name": "Pedang Naga (craft)",     "result": "pedang_naga",     "amount": 1, "materials": { "tulang_naga": 3, "sisik_naga": 10, "orichalcum": 2, "bulu_phoenix": 1 } },
            "tombak_halilintar_c":  { "name": "Tombak Halilintar (craft)","result": "tombak_halilintar","amount": 1,"materials": { "orichalcum": 3, "tulang_naga": 5, "bulu_phoenix": 3, "kristal_es": 5 } },
            "katana_jiwa_craft":    { "name": "Katana Jiwa (craft)",     "result": "katana_jiwa",     "amount": 1, "materials": { "mithril": 8, "tulang_naga": 4, "sisik_naga": 8, "batu_kekuatan": 10 } },
            "busur_abadi_craft":    { "name": "Busur Abadi (craft)",     "result": "busur_abadi",     "amount": 1, "materials": { "orichalcum": 2, "bulu_phoenix": 4, "mithril": 6, "kristal_es": 8 } },
            "tongkat_dewa_craft":   { "name": "Tongkat Dewa (craft)",    "result": "tongkat_dewa",    "amount": 1, "materials": { "orichalcum": 4, "bulu_phoenix": 5, "sisik_naga": 10, "kristal_es": 10 } },
            "pedang_dewa_craft":    { "name": "Pedang Dewa (craft)",     "result": "pedang_dewa",     "amount": 1, "materials": { "orichalcum": 10, "tulang_naga": 8, "bulu_phoenix": 8, "mithril": 10, "sisik_naga": 15 } },
            // ══════════════════════════════════════════
            //  🛡️ ARMOR — GOBLIN MATERIAL
            // ══════════════════════════════════════════
            "baju_kulit_goblin":    { "name": "Zirah Kulit (craft)",     "result": "zirah_kulit",     "amount": 1, "materials": { "kulit_goblin": 8, "taring_goblin": 3 } },
            "perisai_goblin":       { "name": "Perisai Kayu (craft)",    "result": "perisai_kayu",    "amount": 1, "materials": { "kulit_goblin": 4, "taring_goblin": 1 } },
            // ── ORC / TROLL ──
            "zirah_kulit_kuat":     { "name": "Zirah Besi (craft)",      "result": "zirah_besi",      "amount": 1, "materials": { "bijih_besi": 8, "kulit_orc": 3 } },
            "perisai_orc":          { "name": "Perisai Besi (craft)",    "result": "perisai_besi",    "amount": 1, "materials": { "bijih_besi": 5, "kulit_orc": 4, "batu_bara": 3 } },
            "jubah_penyihir_craft": { "name": "Jubah Penyihir (craft)",  "result": "jubah_penyihir",  "amount": 1, "materials": { "racun_laba": 4, "kulit_orc": 5, "bunga_langka": 5 } },
            // ── BAJA ──
            "zirah_baja_craft":     { "name": "Zirah Baja (craft)",      "result": "zirah_baja",      "amount": 1, "materials": { "bijih_besi": 12, "batu_bara": 8, "nikel": 5, "kulit_orc": 4 } },
            // ── MITHRIL / NAGA ──
            "zirah_mithril_craft":  { "name": "Zirah Mithril (craft)",   "result": "zirah_mithril",   "amount": 1, "materials": { "mithril": 8, "sisik_naga": 5, "kristal_es": 2 } },
            "jubah_lich_craft":     { "name": "Jubah Lich (craft)",      "result": "jubah_lich",      "amount": 1, "materials": { "orichalcum": 3, "tulang_naga": 5, "kristal_es": 8, "mithril": 5 } },
            "perisai_naga_craft":   { "name": "Perisai Naga (craft)",    "result": "perisai_naga",    "amount": 1, "materials": { "sisik_naga": 10, "tulang_naga": 5, "batu_kekuatan": 8, "mithril": 4 } },
            "zirah_orichal_craft":  { "name": "Zirah Orichalcum (craft)","result": "zirah_orichalcum","amount": 1, "materials": { "orichalcum": 6, "mithril": 8, "sisik_naga": 12, "tulang_naga": 5 } },
            "zirah_dewa_craft":     { "name": "Zirah Dewa (craft)",      "result": "zirah_dewa",      "amount": 1, "materials": { "orichalcum": 12, "mithril": 15, "bulu_phoenix": 8, "sisik_naga": 15, "tulang_naga": 8 } },
            // ══════════════════════════════════════════
            //  💎 MATERIAL OLAHAN
            // ══════════════════════════════════════════
            "permata_craft":        { "name": "Permata (dari batu)",     "result": "permata",         "amount": 1, "materials": { "batu": 20, "batu_bara": 5, "bijih_besi": 3 } },
            "nikel_craft":          { "name": "Nikel (craft)",           "result": "nikel",           "amount": 2, "materials": { "batu": 15, "batu_bara": 8, "bijih_besi": 5 } },
            "kristal_es_craft":     { "name": "Kristal Es (craft)",      "result": "kristal_es",      "amount": 1, "materials": { "batu": 10, "racun_laba": 3, "bunga_langka": 3 } },
            "batu_kekuatan_craft":  { "name": "Batu Kekuatan (craft)",   "result": "batu_kekuatan",   "amount": 1, "materials": { "batu": 12, "batu_bara": 5, "nikel": 2, "permata": 1 } },
            // ══════════════════════════════════════════
            //  🧬 CRAFTING KOMBINASI DROP LANGKA
            // ══════════════════════════════════════════
            "racun_perkuat":        { "name": "Racun Kuat (craft)",      "result": "racun_laba",      "amount": 3, "materials": { "jamur_ajaib": 4, "rumput_liar": 8, "bunga_langka": 2 } },
            "bulu_phoenix_craft":   { "name": "Bulu Phoenix (craft)",    "result": "bulu_phoenix",    "amount": 1, "materials": { "sisik_naga": 5, "kristal_es": 3, "batu_kekuatan": 5 } },
            "sisik_naga_craft":     { "name": "Sisik Naga (craft)",      "result": "sisik_naga",      "amount": 2, "materials": { "kulit_orc": 5, "batu_kekuatan": 3, "batu_bara": 5 } },
            "tulang_naga_craft":    { "name": "Tulang Naga (craft)",     "result": "tulang_naga",     "amount": 1, "materials": { "sisik_naga": 8, "batu_kekuatan": 5, "orichalcum": 1 } },
            "mithril_craft":        { "name": "Mithril (craft)",         "result": "mithril",         "amount": 1, "materials": { "permata": 5, "batu_kekuatan": 8, "bijih_besi": 15, "nikel": 5 } },
            "orichalcum_craft":     { "name": "Orichalcum (craft)",      "result": "orichalcum",      "amount": 1, "materials": { "mithril": 5, "bulu_phoenix": 3, "sisik_naga": 10, "permata": 8 } }
        },
        quests: {
            // ══ TIER 1 — Desa Pemula (Level 1-5) ══
            "basmi_tikus":     { "title": "🐀 Basmi Tikus",        "description": "Bunuh 8 Tikus Got. Ganggu warga desa!",     "type": "kill",    "target": "🐀 Tikus Got",         "count": 8,  "reward": { "exp": 160,  "gold": 200,   "item": { "id": "potion",        "amount": 5 } } },
            "ulat_beracun":    { "title": "🐛 Musnahkan Ulat",      "description": "Bunuh 10 Ulat Beracun di ladang.",          "type": "kill",    "target": "🐛 Ulat Beracun",      "count": 10, "reward": { "exp": 200,  "gold": 250,   "item": { "id": "potion",        "amount": 5 } } },
            "goblin_awal":     { "title": "👺 Pembasmi Goblin",     "description": "Bunuh 8 Goblin yang merusak desa.",         "type": "kill",    "target": "👺 Goblin",            "count": 8,  "reward": { "exp": 220,  "gold": 300,   "item": { "id": "potion_besar",  "amount": 3 } } },
            "kulit_goblin":    { "title": "🧤 Kolektor Kulit",      "description": "Kumpulkan 15 Kulit Goblin untuk pembuat baju.", "type": "collect","target": "kulit_goblin",        "count": 15, "reward": { "exp": 200,  "gold": 280,   "item": { "id": "baju_kain",     "amount": 1 } } },
            "lebah_raksasa":   { "title": "🐝 Basmi Lebah",         "description": "Bunuh 8 Lebah Raksasa di ladang.",          "type": "kill",    "target": "🐝 Lebah Raksasa",     "count": 8,  "reward": { "exp": 180,  "gold": 220,   "item": { "id": "potion",        "amount": 4 } } },
            // ══ TIER 2 — Hutan & Rawa (Level 4-9) ══
            "laba_maut":       { "title": "🕷️ Laba-laba Maut",      "description": "Bunuh 10 Laba-laba Raksasa di Hutan.",      "type": "kill",    "target": "🕷️ Laba-laba Raksasa", "count": 10, "reward": { "exp": 500,  "gold": 600,   "item": { "id": "potion_besar",  "amount": 4 } } },
            "babi_liar":       { "title": "🐗 Perburuan Babi",      "description": "Bunuh 8 Babi Hutan Liar.",                  "type": "kill",    "target": "🐗 Babi Hutan Liar",  "count": 8,  "reward": { "exp": 600,  "gold": 700,   "item": { "id": "zirah_kulit",   "amount": 1 } } },
            "orc_prajurit":    { "title": "🧌 Pembasmi Orc",        "description": "Bunuh 8 Orc Prajurit di Hutan Gelap.",      "type": "kill",    "target": "🧌 Orc Prajurit",     "count": 8,  "reward": { "exp": 700,  "gold": 800,   "item": { "id": "batu_kekuatan", "amount": 3 } } },
            "zombie_prajurit": { "title": "🧟 Pembasmi Undead",     "description": "Bunuh 10 Zombie Prajurit.",                 "type": "kill",    "target": "🧟 Zombie Prajurit",  "count": 10, "reward": { "exp": 750,  "gold": 900,   "item": { "id": "potion_super",  "amount": 3 } } },
            "taring_kolektor": { "title": "🦷 Taring Goblin",       "description": "Kumpulkan 20 Taring Goblin.",               "type": "collect", "target": "taring_goblin",        "count": 20, "reward": { "exp": 500,  "gold": 650,   "item": { "id": "pedang_besi",   "amount": 1 } } },
            // ══ TIER 3 — Gua & Padang Api (Level 8-15) ══
            "goblin_jendral":  { "title": "👹 Kepala Goblin",       "description": "Bunuh 5 Goblin Jendral.",                   "type": "kill",    "target": "👹 Goblin Jendral",    "count": 5,  "reward": { "exp": 1200, "gold": 1500,  "item": { "id": "batu_kekuatan", "amount": 5 } } },
            "troll_rawa":      { "title": "🌊 Troll Pemburu",       "description": "Bunuh 6 Troll Rawa.",                       "type": "kill",    "target": "🌊 Troll Rawa",        "count": 6,  "reward": { "exp": 1400, "gold": 1800,  "item": { "id": "zirah_besi",    "amount": 1 } } },
            "ksatria_mati":    { "title": "⚔️ Hancurkan Ksatria",   "description": "Bunuh 5 Ksatria Mati di Gua Naga.",         "type": "kill",    "target": "⚔️ Ksatria Mati",      "count": 5,  "reward": { "exp": 1600, "gold": 2000,  "item": { "id": "bijih_besi",    "amount": 8 } } },
            "kulit_orc_kol":   { "title": "🧥 Kulit Orc Premium",   "description": "Kumpulkan 20 Kulit Orc untuk pandai besi.",  "type": "collect", "target": "kulit_orc",            "count": 20, "reward": { "exp": 1000, "gold": 1400,  "item": { "id": "perisai_besi",  "amount": 1 } } },
            // ══ TIER 4 — Pegunungan & Reruntuhan (Level 12-18) ══
            "elemental_api":   { "title": "🌋 Penjinakan Api",      "description": "Bunuh 5 Elemental Api.",                    "type": "kill",    "target": "🌋 Elemental Api",     "count": 5,  "reward": { "exp": 2500, "gold": 3000,  "item": { "id": "pedang_baja",   "amount": 1 } } },
            "elemental_es":    { "title": "❄️ Kehancuran Es",       "description": "Bunuh 5 Elemental Es.",                     "type": "kill",    "target": "❄️ Elemental Es",      "count": 5,  "reward": { "exp": 2500, "gold": 3000,  "item": { "id": "kristal_es",    "amount": 5 } } },
            "raja_zombie":     { "title": "🦴 Raja Terakhir",       "description": "Bunuh 3 Raja Zombie.",                      "type": "kill",    "target": "🦴 Raja Zombie",       "count": 3,  "reward": { "exp": 3000, "gold": 3500,  "item": { "id": "mithril",       "amount": 2 } } },
            "sisik_kolektor":  { "title": "🐉 Sisik Naga",          "description": "Kumpulkan 10 Sisik Naga untuk pandai besi.", "type": "collect", "target": "sisik_naga",           "count": 10, "reward": { "exp": 2000, "gold": 2800,  "item": { "id": "zirah_baja",    "amount": 1 } } },
            // ══ TIER 5 — Kuil Api & Laut Dalam (Level 15-22) ══
            "naga_pemburu":    { "title": "🐉 Pemburu Naga",        "description": "Bunuh 5 Naga di Kuil Api.",                 "type": "kill",    "target": "🐉 Naga",              "count": 5,  "reward": { "exp": 5000, "gold": 6000,  "item": { "id": "sisik_naga",    "amount": 5 } } },
            "phoenix_hunter":  { "title": "🦅 Pemburu Phoenix",     "description": "Bunuh 3 Phoenix.",                          "type": "kill",    "target": "🦅 Phoenix",           "count": 3,  "reward": { "exp": 5500, "gold": 6500,  "item": { "id": "bulu_phoenix",  "amount": 3 } } },
            "wraith_darkness": { "title": "🌑 Pemburu Kegelapan",   "description": "Bunuh 4 Wraith Kegelapan.",                 "type": "kill",    "target": "🌑 Wraith Kegelapan",  "count": 4,  "reward": { "exp": 5000, "gold": 6000,  "item": { "id": "permata",       "amount": 4 } } },
            // ══ TIER 6 — Menara Sihir & Hutan Iblis (Level 20-30) ══
            "lich_pemburu":    { "title": "👑 Pemburu Lich",        "description": "Bunuh 3 Lich King di Menara Sihir.",        "type": "kill",    "target": "👑 Lich King",         "count": 3,  "reward": { "exp": 9000, "gold": 10000, "item": { "id": "mithril",       "amount": 4 } } },
            "naga_tua":        { "title": "🐲 Naga Kuno",           "description": "Bunuh 3 Naga Tua.",                         "type": "kill",    "target": "🐲 Naga Tua",          "count": 3,  "reward": { "exp": 8500, "gold": 9500,  "item": { "id": "tulang_naga",   "amount": 5 } } },
            "void_hunter":     { "title": "🌀 Void Hunter",         "description": "Bunuh 3 Void Walker.",                      "type": "kill",    "target": "🌀 Void Walker",       "count": 3,  "reward": { "exp": 9500, "gold": 11000, "item": { "id": "orichalcum",    "amount": 2 } } },
            "orichal_kolektor":{ "title": "💎 Kolektor Orichalcum", "description": "Kumpulkan 5 Orichalcum.",                   "type": "collect", "target": "orichalcum",           "count": 5,  "reward": { "exp": 7000, "gold": 9000,  "item": { "id": "zirah_mithril", "amount": 1 } } },
            // ══ TIER 7 — Endgame (Level 25+) ══
            "titan_pemburu":   { "title": "🌋 Pembasmi Titan",      "description": "Bunuh 3 Titan Api.",                        "type": "kill",    "target": "🌋 Titan Api",         "count": 3,  "reward": { "exp": 15000,"gold": 18000, "item": { "id": "orichalcum",    "amount": 4 } } },
            "void_dragon":     { "title": "🌑 Void Dragon Slayer",  "description": "Bunuh 2 Void Dragon.",                      "type": "kill",    "target": "🌑 Void Dragon",       "count": 2,  "reward": { "exp": 20000,"gold": 25000, "item": { "id": "pedang_naga",   "amount": 1 } } }
        },
        dungeons: {
            // Tier 1-2: Level 5+
            "goblin_outpost": {
                "name": "⚔️ Markas Goblin",
                "minLevel": 5,
                "stages": [
                    { "monsterId": "4",  "count": 2 },
                    { "monsterId": "4",  "count": 3 },
                    { "monsterId": "11", "count": 2 }
                ],
                "boss": "17",
                "reward": { "exp": 250, "gold": 200, "item": { "id": "batu_kekuatan", "amount": 2 } }
            },
            // Tier 2-3: Level 8+
            "hutan_laba": {
                "name": "🕷️ Sarang Laba-laba",
                "minLevel": 8,
                "stages": [
                    { "monsterId": "9",  "count": 2 },
                    { "monsterId": "9",  "count": 3 },
                    { "monsterId": "13", "count": 1 }
                ],
                "boss": "15",
                "reward": { "exp": 400, "gold": 350, "item": { "id": "racun_laba", "amount": 5 } }
            },
            // Tier 3: Level 10+
            "reruntuhan_kuno": {
                "name": "🏚️ Reruntuhan Raja Zombie",
                "minLevel": 10,
                "stages": [
                    { "monsterId": "12", "count": 3 },
                    { "monsterId": "24", "count": 2 },
                    { "monsterId": "22", "count": 2 }
                ],
                "boss": "30",
                "reward": { "exp": 550, "gold": 480, "item": { "id": "permata", "amount": 2 } }
            },
            // Tier 4: Level 13+
            "gua_es": {
                "name": "❄️ Gua Es Abadi",
                "minLevel": 13,
                "stages": [
                    { "monsterId": "27", "count": 2 },
                    { "monsterId": "32", "count": 2 },
                    { "monsterId": "37", "count": 1 }
                ],
                "boss": "37",
                "reward": { "exp": 700, "gold": 600, "item": { "id": "kristal_es", "amount": 3 } }
            },
            // Tier 5: Level 17+
            "kuil_ifrit": {
                "name": "🔥 Kuil Ifrit",
                "minLevel": 17,
                "stages": [
                    { "monsterId": "26", "count": 2 },
                    { "monsterId": "39", "count": 2 },
                    { "monsterId": "40", "count": 2 }
                ],
                "boss": "39",
                "reward": { "exp": 1000, "gold": 900, "item": { "id": "bulu_phoenix", "amount": 2 } }
            },
            // Tier 6: Level 20+
            "menara_lich": {
                "name": "💀 Menara Lich",
                "minLevel": 20,
                "stages": [
                    { "monsterId": "33", "count": 2 },
                    { "monsterId": "41", "count": 1 },
                    { "monsterId": "44", "count": 1 }
                ],
                "boss": "42",
                "reward": { "exp": 2000, "gold": 1500, "item": { "id": "orichalcum", "amount": 2 } }
            },
            // Tier 7: Level 25+
            "gerbang_neraka": {
                "name": "🌑 Gerbang Neraka",
                "minLevel": 25,
                "stages": [
                    { "monsterId": "46", "count": 2 },
                    { "monsterId": "49", "count": 2 },
                    { "monsterId": "51", "count": 1 }
                ],
                "boss": "47",
                "reward": { "exp": 4000, "gold": 3500, "item": { "id": "orichalcum", "amount": 5 } }
            },
            // Tier 8: Level 30+
            "istana_titan": {
                "name": "⚡ Istana Titan",
                "minLevel": 30,
                "stages": [
                    { "monsterId": "52", "count": 1 },
                    { "monsterId": "53", "count": 1 },
                    { "monsterId": "54", "count": 1 }
                ],
                "boss": "55",
                "reward": { "exp": 7000, "gold": 6500, "item": { "id": "mithril", "amount": 8 } }
            },
            // Tier 9: Level 40+
            "singgasana_dewa": {
                "name": "👁️ Singgasana Para Dewa",
                "minLevel": 40,
                "stages": [
                    { "monsterId": "56", "count": 1 },
                    { "monsterId": "57", "count": 1 },
                    { "monsterId": "58", "count": 1 }
                ],
                "boss": "59",
                "reward": { "exp": 12000, "gold": 11000, "item": { "id": "orichalcum", "amount": 10 } }
            },
            // Tier 10: Level 55+
            "akhir_zaman": {
                "name": "🌌 Pertempuran Akhir Zaman",
                "minLevel": 55,
                "stages": [
                    { "monsterId": "60", "count": 1 },
                    { "monsterId": "61", "count": 1 },
                    { "monsterId": "62", "count": 1 }
                ],
                "boss": "63",
                "reward": { "exp": 25000, "gold": 20000, "item": { "id": "orichalcum", "amount": 20 } }
            }
        },
        petData: {
            "🐱 TIER F — PEMULA": {},
            "kucing_liar":      { "name": "🐱 Kucing Liar",         "attack": 2,  "defense": 1,  "cost": 5000,           "tier": "F", "description": "Kucing kampung yang setia nemenin petualangan." },
            "kelinci":          { "name": "🐇 Kelinci Putih",       "attack": 1,  "defense": 3,  "cost": 8000,           "tier": "F", "description": "Kelinci cepat yang sedikit meningkatkan pertahanan." },
            "musang":           { "name": "🦡 Musang Berbulu",      "attack": 3,  "defense": 2,  "cost": 12000,          "tier": "F", "description": "Musang lincah yang gesit menghindar." },
            "🐺 TIER E — BIASA": {},
            "serigala":         { "name": "🐺 Serigala",            "attack": 5,  "defense": 2,  "cost": 50000,          "tier": "E", "description": "Serigala setia dengan taring tajam." },
            "kura_kura":        { "name": "🐢 Kura-kura Baja",      "attack": 1,  "defense": 6,  "cost": 40000,          "tier": "E", "description": "Tempurung baja yang meningkatkan pertahanan." },
            "ular_piton":       { "name": "🐍 Ular Piton",          "attack": 6,  "defense": 1,  "cost": 60000,          "tier": "E", "description": "Lilitan maut dari piton peliharaan." },
            "🦊 TIER D — LANGKA": {},
            "rubah_salju":      { "name": "🦊 Rubah Salju",         "attack": 7,  "defense": 4,  "cost": 250000,         "tier": "D", "description": "Rubah es cepat dengan keseimbangan attack & defense." },
            "harimau":          { "name": "🐯 Harimau Bengal",      "attack": 9,  "defense": 3,  "cost": 300000,         "tier": "D", "description": "Raja hutan dengan serangan yang mematikan." },
            "beruang_kutub":    { "name": "🐻 Beruang Kutub",       "attack": 6,  "defense": 8,  "cost": 350000,         "tier": "D", "description": "Beruang kutub raksasa dengan pertahanan tebal." },
            "🦅 TIER C — KEREN": {},
            "elang_api":        { "name": "🦅 Elang Api",           "attack": 12, "defense": 3,  "cost": 1500000,        "tier": "C", "description": "Elang berapi dengan serangan angin panas." },
            "panther_gelap":    { "name": "🐆 Panther Gelap",       "attack": 14, "defense": 5,  "cost": 2000000,        "tier": "C", "description": "Panther hitam misterius dari hutan kelam." },
            "singa_emas":       { "name": "🦁 Singa Emas",          "attack": 13, "defense": 6,  "cost": 2500000,        "tier": "C", "description": "Singa bermahkota emas, simbol keberanian." },
            "🦋 TIER B — EPIK": {},
            "naga_mini":        { "name": "🐲 Naga Mini",           "attack": 18, "defense": 7,  "cost": 10000000,       "tier": "B", "description": "Naga kecil dari telur langka, hembus api mini." },
            "fenrir":           { "name": "🌑 Fenrir",              "attack": 20, "defense": 8,  "cost": 15000000,       "tier": "B", "description": "Serigala raksasa dari dimensi kegelapan." },
            "unicorn":          { "name": "🦄 Unicorn",             "attack": 15, "defense": 12, "cost": 20000000,       "tier": "B", "description": "Kuda bertanduk perak yang memancarkan sihir." },
            "⚡ TIER A — LEGENDARIS": {},
            "gryphon":          { "name": "🦁🦅 Gryphon",           "attack": 25, "defense": 12, "cost": 75000000,       "tier": "A", "description": "Campuran singa dan elang, raja udara dan darat." },
            "thunderbird":      { "name": "⚡ Thunderbird",          "attack": 28, "defense": 10, "cost": 100000000,      "tier": "A", "description": "Burung petir legendaris, setiap serangan mengandung listrik." },
            "cerberus":         { "name": "🔱 Cerberus",            "attack": 22, "defense": 18, "cost": 150000000,      "tier": "A", "description": "Anjing berkepala tiga penjaga neraka." },
            "🔥 TIER S — MYTHIC": {},
            "phoenix":          { "name": "🔥 Phoenix",             "attack": 35, "defense": 15, "cost": 500000000,      "tier": "S", "description": "Burung api abadi yang bangkit dari abu, membakar semua musuh." },
            "leviathan_mini":   { "name": "🌊 Leviathan Mini",      "attack": 30, "defense": 25, "cost": 750000000,      "tier": "S", "description": "Naga laut purba dari kedalaman samudra." },
            "manticore":        { "name": "🦂 Manticore",           "attack": 40, "defense": 18, "cost": 1000000000,     "tier": "S", "description": "Singa bertubuh kalajengking, racun mematikan." },
            "🌟 TIER SS — DEWA": {},
            "bahamut":          { "name": "🐉 Bahamut",             "attack": 55, "defense": 30, "cost": 5000000000,     "tier": "SS", "description": "Naga dewa legendaris, penguasa langit dan bumi." },
            "jormungandr":      { "name": "🌀 Jormungandr",         "attack": 50, "defense": 35, "cost": 7500000000,     "tier": "SS", "description": "Ular raksasa melilit dunia, tiada yang lolos." },
            "⭐ TIER SSS — GOD": {},
            "celestial_dragon": { "name": "✨ Celestial Dragon",    "attack": 75, "defense": 50, "cost": 50000000000,    "tier": "SSS", "description": "Naga surgawi dari dimensi ke-7, melampaui semua makhluk." },
            "void_beast":       { "name": "🕳️ Void Beast",          "attack": 80, "defense": 55, "cost": 100000000000,   "tier": "SSS", "description": "Makhluk dari kekosongan abadi, menghancurkan realita." },
            "god_dragon":       { "name": "🌠 God Dragon",          "attack": 99, "defense": 75, "cost": 999000000000,   "tier": "SSS", "description": "ULTIMATE PET — Naga Tuhan, kekuatan tak tertandingi di semesta!" }
        }
    }
    fs.writeFileSync(rpgDBPath, JSON.stringify(defaultRPG, null, 2))
} else {
    // Sync: pastikan items, monsters, dungeons, petData selalu up-to-date di rpg.json
    try {
        const existingRPG = JSON.parse(fs.readFileSync(rpgDBPath))
        let needsSave = false

        const defaultItems = {
            // ── Potion & Elixir ──
            "potion":             { "name": "Potion",              "type": "heal",        "value": 40,  "price": 2000 },
            "potion_besar":       { "name": "Potion Besar",        "type": "heal",        "value": 100, "price": 8000 },
            "potion_super":       { "name": "Super Potion",        "type": "heal",        "value": 200, "price": 25000 },
            "elixir_hidup":       { "name": "Elixir Kehidupan",    "type": "heal",        "value": 999, "price": 150000 },
            "megapotion":         { "name": "Mega Potion",         "type": "heal",        "value": 400, "price": 500000 },
            "divinepotion":       { "name": "Divine Potion",       "type": "heal",        "value": 999, "price": 5000000 },
            "elixir":             { "name": "Elixir",              "type": "mana",        "value": 30,  "price": 3000 },
            "elixir_besar":       { "name": "Elixir Besar",        "type": "mana",        "value": 80,  "price": 12000 },
            "elixir_mana_penuh":  { "name": "Mana Crystal",        "type": "mana",        "value": 999, "price": 100000 },
            "megaelixir":         { "name": "Mega Elixir",         "type": "mana",        "value": 400, "price": 500000 },
            "divineelixir":       { "name": "Divine Elixir",       "type": "mana",        "value": 999, "price": 5000000 },
            // ── Bot Feature ──
            "limit_bot_10":       { "name": "10 Limit Bot",        "type": "bot_feature", "value": 10,  "price": 1000000 },
            "limit_bot_50":       { "name": "50 Limit Bot",        "type": "bot_feature", "value": 50,  "price": 4000000 },
            "limit_bot_100":      { "name": "100 Limit Bot",       "type": "bot_feature", "value": 100, "price": 7000000 },
            "limit_bot_500":      { "name": "500 Limit Bot",       "type": "bot_feature", "value": 500, "price": 25000000 },
            // ── Senjata — makin mahal makin tinggi ATK ──
            "pedang_kayu":        { "name": "Pedang Kayu",         "type": "weapon", "attack": 3,  "price": 3000 },
            "busur_kayu":         { "name": "Busur Kayu",          "type": "weapon", "attack": 5,  "price": 5000 },
            "pedang_besi":        { "name": "Pedang Besi",         "type": "weapon", "attack": 8,  "price": 30000 },
            "busur_besi":         { "name": "Busur Besi",          "type": "weapon", "attack": 12, "price": 60000 },
            "tongkat_sihir":      { "name": "Tongkat Sihir",       "type": "weapon", "attack": 10, "price": 50000 },
            "pedang_baja":        { "name": "Pedang Baja",         "type": "weapon", "attack": 18, "price": 400000 },
            "tongkat_kuno":       { "name": "Tongkat Kuno",        "type": "weapon", "attack": 25, "price": 800000 },
            "busur_elven":        { "name": "Busur Elven",         "type": "weapon", "attack": 30, "price": 1000000 },
            "pedang_mithril":     { "name": "Pedang Mithril",      "type": "weapon", "attack": 38, "price": 5000000 },
            "pedang_naga":        { "name": "Pedang Naga",         "type": "weapon", "attack": 48, "price": 25000000 },
            "tongkat_dewa":       { "name": "Tongkat Dewa",        "type": "weapon", "attack": 55, "price": 40000000 },
            "busur_abadi":        { "name": "Busur Abadi",         "type": "weapon", "attack": 58, "price": 45000000 },
            "katana_jiwa":        { "name": "Katana Jiwa",         "type": "weapon", "attack": 60, "price": 50000000 },
            "tombak_halilintar":  { "name": "Tombak Halilintar",   "type": "weapon", "attack": 65, "price": 60000000 },
            "pedang_dewa":        { "name": "Pedang Dewa",         "type": "weapon", "attack": 70, "price": 70000000 },
            // ── Armor — makin mahal makin tinggi DEF ──
            "baju_kain":          { "name": "Baju Kain",           "type": "armor", "defense": 2,  "price": 1500 },
            "perisai_kayu":       { "name": "Perisai Kayu",        "type": "armor", "defense": 3,  "price": 3000 },
            "zirah_kulit":        { "name": "Zirah Kulit",         "type": "armor", "defense": 5,  "price": 20000 },
            "perisai_besi":       { "name": "Perisai Besi",        "type": "armor", "defense": 8,  "price": 50000 },
            "jubah_penyihir":     { "name": "Jubah Penyihir",      "type": "armor", "defense": 10, "price": 150000 },
            "zirah_besi":         { "name": "Zirah Besi",          "type": "armor", "defense": 14, "price": 200000 },
            "zirah_baja":         { "name": "Zirah Baja",          "type": "armor", "defense": 22, "price": 2000000 },
            "zirah_mithril":      { "name": "Zirah Mithril",       "type": "armor", "defense": 32, "price": 15000000 },
            "perisai_naga":       { "name": "Perisai Naga",        "type": "armor", "defense": 45, "price": 43000000 },
            "jubah_lich":         { "name": "Jubah Lich King",     "type": "armor", "defense": 50, "price": 28500000 },
            "zirah_orichalcum":   { "name": "Zirah Orichalcum",    "type": "armor", "defense": 55, "price": 60000000 },
            "zirah_dewa":         { "name": "Zirah Dewa",          "type": "armor", "defense": 60, "price": 70000000 },
            // ── Material ──
            "batu":               { "name": "Batu",                "type": "material", "price": 150 },
            "rumput_liar":        { "name": "Rumput Liar",         "type": "material", "price": 250 },
            "kulit_goblin":       { "name": "Kulit Goblin",        "type": "material", "price": 300 },
            "taring_goblin":      { "name": "Taring Goblin",       "type": "material", "price": 700 },
            "batu_bara":          { "name": "Batu Bara",           "type": "material", "price": 1500 },
            "kulit_orc":          { "name": "Kulit Orc",           "type": "material", "price": 2000 },
            "racun_laba":         { "name": "Racun Laba-laba",     "type": "material", "price": 3000 },
            "bijih_besi":         { "name": "Bijih Besi",          "type": "material", "price": 4000 },
            "bunga_langka":       { "name": "Bunga Langka",        "type": "material", "price": 8000 },
            "batu_kekuatan":      { "name": "Batu Kekuatan",       "type": "material", "price": 8000 },
            "jamur_ajaib":        { "name": "Jamur Ajaib",         "type": "material", "price": 15000 },
            "nikel":              { "name": "Nikel",               "type": "material", "price": 15000 },
            "kristal_es":         { "name": "Kristal Es",          "type": "material", "price": 30000 },
            "sisik_naga":         { "name": "Sisik Naga",          "type": "material", "price": 50000 },
            "permata":            { "name": "Permata",             "type": "material", "price": 80000 },
            "tulang_naga":        { "name": "Tulang Naga",         "type": "material", "price": 300000 },
            "emas":               { "name": "Emas",               "type": "material", "price": 500000 },
            "bulu_phoenix":       { "name": "Bulu Phoenix",        "type": "material", "price": 500000 },
            "berlian":            { "name": "Berlian",             "type": "material", "price": 2000000 },
            "mithril":            { "name": "Mithril",             "type": "material", "price": 4000000 },
            "orichalcum":         { "name": "Orichalcum",          "type": "material", "price": 12500000 }
        }
        const defaultMonsters = {
            "1": { "name": "Goblin", "hp": 30, "attack": 5, "defense": 2, "exp": 15, "gold": 10, "level": 1, "drops": { "kulit_goblin": 0.7, "taring_goblin": 0.3 } },
            "2": { "name": "Orc", "hp": 50, "attack": 8, "defense": 4, "exp": 25, "gold": 20, "level": 3, "drops": { "kulit_orc": 0.6, "batu_kekuatan": 0.1 } },
            "3": { "name": "Naga", "hp": 100, "attack": 15, "defense": 8, "exp": 60, "gold": 50, "level": 10, "drops": { "sisik_naga": 0.5, "tulang_naga": 0.2, "batu_kekuatan": 0.3 } },
            "4": { "name": "Goblin Jendral", "hp": 80, "attack": 12, "defense": 6, "exp": 70, "gold": 60, "level": 7, "drops": { "batu_kekuatan": 0.5, "taring_goblin": 0.8 } },
            "5": { "name": "Laba-laba Raksasa", "hp": 45, "attack": 7, "defense": 3, "exp": 20, "gold": 15, "level": 4, "drops": { "racun_laba": 0.6, "kulit_goblin": 0.2 } },
            "6": { "name": "Troll Hutan", "hp": 70, "attack": 10, "defense": 5, "exp": 35, "gold": 30, "level": 6, "drops": { "kulit_orc": 0.4, "batu_kekuatan": 0.2 } },
            "7": { "name": "Serigala Roh", "hp": 55, "attack": 9, "defense": 3, "exp": 30, "gold": 25, "level": 5, "drops": { "kristal_es": 0.3, "batu_kekuatan": 0.15 } },
            "8": { "name": "Phoenix", "hp": 120, "attack": 18, "defense": 10, "exp": 90, "gold": 80, "level": 12, "drops": { "bulu_phoenix": 0.4, "sisik_naga": 0.2 } },
            "9": { "name": "Ice Drake", "hp": 140, "attack": 20, "defense": 12, "exp": 110, "gold": 100, "level": 15, "drops": { "kristal_es": 0.6, "tulang_naga": 0.3 } },
            "10": { "name": "Lich King", "hp": 200, "attack": 25, "defense": 15, "exp": 200, "gold": 200, "level": 20, "drops": { "orichalcum": 0.3, "bulu_phoenix": 0.2, "mithril": 0.5 } }
        }
        const defaultDungeons = {
            "goblin_outpost": { "name": "Markas Goblin", "minLevel": 5, "stages": [{ "monsterId": "1", "count": 2 }, { "monsterId": "1", "count": 3 }], "boss": "4", "reward": { "exp": 250, "gold": 200, "item": { "id": "batu_kekuatan", "amount": 2 } } },
            "hutan_laba": { "name": "Sarang Laba-laba", "minLevel": 8, "stages": [{ "monsterId": "5", "count": 2 }, { "monsterId": "5", "count": 3 }, { "monsterId": "6", "count": 1 }], "boss": "5", "reward": { "exp": 400, "gold": 350, "item": { "id": "racun_laba", "amount": 5 } } },
            "gua_es": { "name": "Gua Es Abadi", "minLevel": 13, "stages": [{ "monsterId": "7", "count": 2 }, { "monsterId": "9", "count": 1 }], "boss": "9", "reward": { "exp": 700, "gold": 600, "item": { "id": "kristal_es", "amount": 3 } } },
            "menara_lich": { "name": "Menara Lich", "minLevel": 20, "stages": [{ "monsterId": "3", "count": 2 }, { "monsterId": "8", "count": 1 }, { "monsterId": "9", "count": 1 }], "boss": "10", "reward": { "exp": 2000, "gold": 1500, "item": { "id": "orichalcum", "amount": 2 } } }
        }
        const defaultPetData = {
            "kucing_liar":      { "name": "🐱 Kucing Liar",         "attack": 2,  "defense": 1,  "cost": 5000,           "tier": "F",   "description": "Kucing kampung yang setia nemenin petualangan." },
            "kelinci":          { "name": "🐇 Kelinci Putih",       "attack": 1,  "defense": 3,  "cost": 8000,           "tier": "F",   "description": "Kelinci cepat yang sedikit meningkatkan pertahanan." },
            "musang":           { "name": "🦡 Musang Berbulu",      "attack": 3,  "defense": 2,  "cost": 12000,          "tier": "F",   "description": "Musang lincah yang gesit menghindar." },
            "serigala":         { "name": "🐺 Serigala",            "attack": 5,  "defense": 2,  "cost": 50000,          "tier": "E",   "description": "Serigala setia dengan taring tajam." },
            "kura_kura":        { "name": "🐢 Kura-kura Baja",      "attack": 1,  "defense": 6,  "cost": 40000,          "tier": "E",   "description": "Tempurung baja yang meningkatkan pertahanan." },
            "ular_piton":       { "name": "🐍 Ular Piton",          "attack": 6,  "defense": 1,  "cost": 60000,          "tier": "E",   "description": "Lilitan maut dari piton peliharaan." },
            "rubah_salju":      { "name": "🦊 Rubah Salju",         "attack": 7,  "defense": 4,  "cost": 250000,         "tier": "D",   "description": "Rubah es cepat dengan keseimbangan attack & defense." },
            "harimau":          { "name": "🐯 Harimau Bengal",      "attack": 9,  "defense": 3,  "cost": 300000,         "tier": "D",   "description": "Raja hutan dengan serangan yang mematikan." },
            "beruang_kutub":    { "name": "🐻 Beruang Kutub",       "attack": 6,  "defense": 8,  "cost": 350000,         "tier": "D",   "description": "Beruang kutub raksasa dengan pertahanan tebal." },
            "elang_api":        { "name": "🦅 Elang Api",           "attack": 12, "defense": 3,  "cost": 1500000,        "tier": "C",   "description": "Elang berapi dengan serangan angin panas." },
            "panther_gelap":    { "name": "🐆 Panther Gelap",       "attack": 14, "defense": 5,  "cost": 2000000,        "tier": "C",   "description": "Panther hitam misterius dari hutan kelam." },
            "singa_emas":       { "name": "🦁 Singa Emas",          "attack": 13, "defense": 6,  "cost": 2500000,        "tier": "C",   "description": "Singa bermahkota emas, simbol keberanian." },
            "naga_mini":        { "name": "🐲 Naga Mini",           "attack": 18, "defense": 7,  "cost": 10000000,       "tier": "B",   "description": "Naga kecil dari telur langka, hembus api mini." },
            "fenrir":           { "name": "🌑 Fenrir",              "attack": 20, "defense": 8,  "cost": 15000000,       "tier": "B",   "description": "Serigala raksasa dari dimensi kegelapan." },
            "unicorn":          { "name": "🦄 Unicorn",             "attack": 15, "defense": 12, "cost": 20000000,       "tier": "B",   "description": "Kuda bertanduk perak yang memancarkan sihir." },
            "gryphon":          { "name": "🦁🦅 Gryphon",           "attack": 25, "defense": 12, "cost": 75000000,       "tier": "A",   "description": "Campuran singa dan elang, raja udara dan darat." },
            "thunderbird":      { "name": "⚡ Thunderbird",          "attack": 28, "defense": 10, "cost": 100000000,      "tier": "A",   "description": "Burung petir legendaris, setiap serangan mengandung listrik." },
            "cerberus":         { "name": "🔱 Cerberus",            "attack": 22, "defense": 18, "cost": 150000000,      "tier": "A",   "description": "Anjing berkepala tiga penjaga neraka." },
            "phoenix":          { "name": "🔥 Phoenix",             "attack": 35, "defense": 15, "cost": 500000000,      "tier": "S",   "description": "Burung api abadi yang bangkit dari abu, membakar semua musuh." },
            "leviathan_mini":   { "name": "🌊 Leviathan Mini",      "attack": 30, "defense": 25, "cost": 750000000,      "tier": "S",   "description": "Naga laut purba dari kedalaman samudra." },
            "manticore":        { "name": "🦂 Manticore",           "attack": 40, "defense": 18, "cost": 1000000000,     "tier": "S",   "description": "Singa bertubuh kalajengking, racun mematikan." },
            "bahamut":          { "name": "🐉 Bahamut",             "attack": 55, "defense": 30, "cost": 5000000000,     "tier": "SS",  "description": "Naga dewa legendaris, penguasa langit dan bumi." },
            "jormungandr":      { "name": "🌀 Jormungandr",         "attack": 50, "defense": 35, "cost": 7500000000,     "tier": "SS",  "description": "Ular raksasa melilit dunia, tiada yang lolos." },
            "celestial_dragon": { "name": "✨ Celestial Dragon",    "attack": 75, "defense": 50, "cost": 50000000000,    "tier": "SSS", "description": "Naga surgawi dari dimensi ke-7, melampaui semua makhluk." },
            "void_beast":       { "name": "🕳️ Void Beast",          "attack": 80, "defense": 55, "cost": 100000000000,   "tier": "SSS", "description": "Makhluk dari kekosongan abadi, menghancurkan realita." },
            "god_dragon":       { "name": "🌠 God Dragon",          "attack": 99, "defense": 75, "cost": 999000000000,   "tier": "SSS", "description": "ULTIMATE PET — Naga Tuhan, kekuatan tak tertandingi di semesta!" }
        }

        if (!existingRPG.items) { existingRPG.items = {}; needsSave = true }
        for (const [id, item] of Object.entries(defaultItems)) {
            // Selalu update harga, stats, dan value — agar perubahan langsung aktif tanpa reset DB
            existingRPG.items[id] = item
            needsSave = true
        }
        if (!existingRPG.monsters) { existingRPG.monsters = {}; needsSave = true }
        for (const [id, mon] of Object.entries(defaultMonsters)) {
            if (!existingRPG.monsters[id]) { existingRPG.monsters[id] = mon; needsSave = true }
        }
        if (!existingRPG.dungeons) { existingRPG.dungeons = {}; needsSave = true }
        for (const [id, dun] of Object.entries(defaultDungeons)) {
            if (!existingRPG.dungeons[id]) { existingRPG.dungeons[id] = dun; needsSave = true }
        }
        if (!existingRPG.petData) { existingRPG.petData = {}; needsSave = true }
        for (const [id, pet] of Object.entries(defaultPetData)) {
            if (!existingRPG.petData[id]) { existingRPG.petData[id] = pet; needsSave = true }
        }
        if (!existingRPG.craftingRecipes) { existingRPG.craftingRecipes = {}; needsSave = true }
        const defaultRecipes = {
            "potion_kuat":          { "name": "Potion Besar (craft)",    "result": "potion_besar",    "amount": 2, "materials": { "bunga_langka": 2, "jamur_ajaib": 1 } },
            "super_potion_craft":   { "name": "Super Potion (craft)",    "result": "potion_super",    "amount": 1, "materials": { "bunga_langka": 5, "jamur_ajaib": 3, "kristal_es": 1 } },
            "elixir_hidup_craft":   { "name": "Elixir Kehidupan (craft)","result": "elixir_hidup",   "amount": 1, "materials": { "bulu_phoenix": 1, "bunga_langka": 8, "jamur_ajaib": 5 } },
            "elixir_mana_craft":    { "name": "Elixir Besar (craft)",    "result": "elixir_besar",    "amount": 2, "materials": { "jamur_ajaib": 3, "rumput_liar": 5 } },
            "mana_crystal_craft":   { "name": "Mana Crystal (craft)",    "result": "elixir_mana_penuh","amount": 1,"materials": { "kristal_es": 3, "jamur_ajaib": 5, "bunga_langka": 3 } },
            "mega_potion_craft":    { "name": "Mega Potion (craft)",     "result": "megapotion",      "amount": 1, "materials": { "bulu_phoenix": 2, "sisik_naga": 3, "bunga_langka": 10, "jamur_ajaib": 8 } },
            "divine_potion_craft":  { "name": "Divine Potion (craft)",   "result": "divinepotion",    "amount": 1, "materials": { "orichalcum": 1, "bulu_phoenix": 3, "kristal_es": 5, "bunga_langka": 15 } },
            "mega_elixir_craft":    { "name": "Mega Elixir (craft)",     "result": "megaelixir",      "amount": 1, "materials": { "kristal_es": 5, "racun_laba": 3, "jamur_ajaib": 10, "bunga_langka": 8 } },
            "divine_elixir_craft":  { "name": "Divine Elixir (craft)",   "result": "divineelixir",    "amount": 1, "materials": { "orichalcum": 1, "kristal_es": 8, "bulu_phoenix": 2, "jamur_ajaib": 15 } },
            "pedang_goblin":        { "name": "Pedang Goblin (craft)",   "result": "pedang_kayu",     "amount": 1, "materials": { "kulit_goblin": 5, "taring_goblin": 2 } },
            "busur_goblin":         { "name": "Busur Goblin (craft)",    "result": "busur_kayu",      "amount": 1, "materials": { "kulit_goblin": 3, "taring_goblin": 3 } },
            "pedang_orc":           { "name": "Pedang Besi (craft)",     "result": "pedang_besi",     "amount": 1, "materials": { "bijih_besi": 5, "kulit_orc": 3, "taring_goblin": 2 } },
            "tongkat_orc":          { "name": "Tongkat Sihir (craft)",   "result": "tongkat_sihir",   "amount": 1, "materials": { "batu_kekuatan": 3, "kulit_orc": 2, "batu_bara": 3 } },
            "busur_orc":            { "name": "Busur Besi (craft)",      "result": "busur_besi",      "amount": 1, "materials": { "bijih_besi": 4, "kulit_orc": 4, "taring_goblin": 1 } },
            "pedang_besi_tempa":    { "name": "Pedang Baja (craft)",     "result": "pedang_baja",     "amount": 1, "materials": { "bijih_besi": 10, "batu_bara": 5, "nikel": 2 } },
            "tongkat_kuno_craft":   { "name": "Tongkat Kuno (craft)",    "result": "tongkat_kuno",    "amount": 1, "materials": { "batu_kekuatan": 8, "sisik_naga": 3, "permata": 2 } },
            "pedang_racun":         { "name": "Pedang Racun (craft)",    "result": "pedang_baja",     "amount": 1, "materials": { "racun_laba": 5, "bijih_besi": 8, "kulit_goblin": 4 } },
            "busur_elven_craft":    { "name": "Busur Elven (craft)",     "result": "busur_elven",     "amount": 1, "materials": { "kristal_es": 5, "bulu_phoenix": 1, "batu_kekuatan": 5, "mithril": 2 } },
            "pedang_mithril_craft": { "name": "Pedang Mithril (craft)",  "result": "pedang_mithril",  "amount": 1, "materials": { "mithril": 5, "batu_kekuatan": 3, "sisik_naga": 2 } },
            "tongkat_mithril":      { "name": "Tongkat Mithril (craft)", "result": "pedang_mithril",  "amount": 1, "materials": { "mithril": 4, "kristal_es": 4, "batu_kekuatan": 5 } },
            "pedang_naga_craft":    { "name": "Pedang Naga (craft)",     "result": "pedang_naga",     "amount": 1, "materials": { "tulang_naga": 3, "sisik_naga": 10, "orichalcum": 2, "bulu_phoenix": 1 } },
            "tombak_halilintar_c":  { "name": "Tombak Halilintar (craft)","result": "tombak_halilintar","amount": 1,"materials": { "orichalcum": 3, "tulang_naga": 5, "bulu_phoenix": 3, "kristal_es": 5 } },
            "katana_jiwa_craft":    { "name": "Katana Jiwa (craft)",     "result": "katana_jiwa",     "amount": 1, "materials": { "mithril": 8, "tulang_naga": 4, "sisik_naga": 8, "batu_kekuatan": 10 } },
            "busur_abadi_craft":    { "name": "Busur Abadi (craft)",     "result": "busur_abadi",     "amount": 1, "materials": { "orichalcum": 2, "bulu_phoenix": 4, "mithril": 6, "kristal_es": 8 } },
            "tongkat_dewa_craft":   { "name": "Tongkat Dewa (craft)",    "result": "tongkat_dewa",    "amount": 1, "materials": { "orichalcum": 4, "bulu_phoenix": 5, "sisik_naga": 10, "kristal_es": 10 } },
            "pedang_dewa_craft":    { "name": "Pedang Dewa (craft)",     "result": "pedang_dewa",     "amount": 1, "materials": { "orichalcum": 10, "tulang_naga": 8, "bulu_phoenix": 8, "mithril": 10, "sisik_naga": 15 } },
            "baju_kulit_goblin":    { "name": "Zirah Kulit (craft)",     "result": "zirah_kulit",     "amount": 1, "materials": { "kulit_goblin": 8, "taring_goblin": 3 } },
            "perisai_goblin":       { "name": "Perisai Kayu (craft)",    "result": "perisai_kayu",    "amount": 1, "materials": { "kulit_goblin": 4, "taring_goblin": 1 } },
            "zirah_kulit_kuat":     { "name": "Zirah Besi (craft)",      "result": "zirah_besi",      "amount": 1, "materials": { "bijih_besi": 8, "kulit_orc": 3 } },
            "perisai_orc":          { "name": "Perisai Besi (craft)",    "result": "perisai_besi",    "amount": 1, "materials": { "bijih_besi": 5, "kulit_orc": 4, "batu_bara": 3 } },
            "jubah_penyihir_craft": { "name": "Jubah Penyihir (craft)",  "result": "jubah_penyihir",  "amount": 1, "materials": { "racun_laba": 4, "kulit_orc": 5, "bunga_langka": 5 } },
            "zirah_baja_craft":     { "name": "Zirah Baja (craft)",      "result": "zirah_baja",      "amount": 1, "materials": { "bijih_besi": 12, "batu_bara": 8, "nikel": 5, "kulit_orc": 4 } },
            "zirah_mithril_craft":  { "name": "Zirah Mithril (craft)",   "result": "zirah_mithril",   "amount": 1, "materials": { "mithril": 8, "sisik_naga": 5, "kristal_es": 2 } },
            "jubah_lich_craft":     { "name": "Jubah Lich (craft)",      "result": "jubah_lich",      "amount": 1, "materials": { "orichalcum": 3, "tulang_naga": 5, "kristal_es": 8, "mithril": 5 } },
            "perisai_naga_craft":   { "name": "Perisai Naga (craft)",    "result": "perisai_naga",    "amount": 1, "materials": { "sisik_naga": 10, "tulang_naga": 5, "batu_kekuatan": 8, "mithril": 4 } },
            "zirah_orichal_craft":  { "name": "Zirah Orichalcum (craft)","result": "zirah_orichalcum","amount": 1, "materials": { "orichalcum": 6, "mithril": 8, "sisik_naga": 12, "tulang_naga": 5 } },
            "zirah_dewa_craft":     { "name": "Zirah Dewa (craft)",      "result": "zirah_dewa",      "amount": 1, "materials": { "orichalcum": 12, "mithril": 15, "bulu_phoenix": 8, "sisik_naga": 15, "tulang_naga": 8 } },
            "permata_craft":        { "name": "Permata (dari batu)",     "result": "permata",         "amount": 1, "materials": { "batu": 20, "batu_bara": 5, "bijih_besi": 3 } },
            "nikel_craft":          { "name": "Nikel (craft)",           "result": "nikel",           "amount": 2, "materials": { "batu": 15, "batu_bara": 8, "bijih_besi": 5 } },
            "kristal_es_craft":     { "name": "Kristal Es (craft)",      "result": "kristal_es",      "amount": 1, "materials": { "batu": 10, "racun_laba": 3, "bunga_langka": 3 } },
            "batu_kekuatan_craft":  { "name": "Batu Kekuatan (craft)",   "result": "batu_kekuatan",   "amount": 1, "materials": { "batu": 12, "batu_bara": 5, "nikel": 2, "permata": 1 } },
            "racun_perkuat":        { "name": "Racun Kuat (craft)",      "result": "racun_laba",      "amount": 3, "materials": { "jamur_ajaib": 4, "rumput_liar": 8, "bunga_langka": 2 } },
            "bulu_phoenix_craft":   { "name": "Bulu Phoenix (craft)",    "result": "bulu_phoenix",    "amount": 1, "materials": { "sisik_naga": 5, "kristal_es": 3, "batu_kekuatan": 5 } },
            "sisik_naga_craft":     { "name": "Sisik Naga (craft)",      "result": "sisik_naga",      "amount": 2, "materials": { "kulit_orc": 5, "batu_kekuatan": 3, "batu_bara": 5 } },
            "tulang_naga_craft":    { "name": "Tulang Naga (craft)",     "result": "tulang_naga",     "amount": 1, "materials": { "sisik_naga": 8, "batu_kekuatan": 5, "orichalcum": 1 } },
            "mithril_craft":        { "name": "Mithril (craft)",         "result": "mithril",         "amount": 1, "materials": { "permata": 5, "batu_kekuatan": 8, "bijih_besi": 15, "nikel": 5 } },
            "orichalcum_craft":     { "name": "Orichalcum (craft)",      "result": "orichalcum",      "amount": 1, "materials": { "mithril": 5, "bulu_phoenix": 3, "sisik_naga": 10, "permata": 8 } }
        }
        for (const [id, recipe] of Object.entries(defaultRecipes)) {
            if (!existingRPG.craftingRecipes[id]) { existingRPG.craftingRecipes[id] = recipe; needsSave = true }
        }
        if (!existingRPG.quests) { existingRPG.quests = {}; needsSave = true }
        if (!existingRPG.players) { existingRPG.players = {}; needsSave = true }

        // Selalu sync locations agar data monster di tiap lokasi selalu benar
        const defaultLocations = {
            "desa": { "name": "Desa Pemula", "monsters": [1], "minLevel": 1, "maxLevel": 5 },
            "hutan": { "name": "Hutan Gelap", "monsters": [1, 2, 5], "minLevel": 3, "maxLevel": 8 },
            "gua": { "name": "Gua Naga", "monsters": [2, 3, 6], "minLevel": 8, "maxLevel": 15 },
            "pegunungan": { "name": "Pegunungan Es", "monsters": [7, 9], "minLevel": 12, "maxLevel": 20 },
            "kuil_api": { "name": "Kuil Api Abadi", "monsters": [8, 10], "minLevel": 18, "maxLevel": 50 },
            "tambang": { "name": "Tambang Terbengkalai", "minLevel": 5, "maxLevel": 20, "ores": { "batu": 0.8, "batu_bara": 0.5, "bijih_besi": 0.2, "permata": 0.05, "mithril": 0.02, "orichalcum": 0.005 } },
            "padang_rumput": { "name": "Padang Rumput Liar", "minLevel": 2, "maxLevel": 20, "herbs": { "rumput_liar": 0.9, "bunga_langka": 0.3, "jamur_ajaib": 0.1, "kristal_es": 0.05 } }
        }
        if (!existingRPG.locations) existingRPG.locations = {}
        for (const [id, loc] of Object.entries(defaultLocations)) {
            existingRPG.locations[id] = loc
        }
        needsSave = true

        if (needsSave) fs.writeFileSync(rpgDBPath, JSON.stringify(existingRPG, null, 2))
    } catch(e) {
        console.error('RPG sync error:', e)
    }
}

if (!fs.existsSync(marketDBPath)) {
    fs.mkdirSync('./library/database', { recursive: true })
    const defaultMarket = {
        saham: {
            "ALIP":     { name: "PT Alip Tbk",           price: 500000,    change: 0, lastUpdate: Date.now(), category: "teknologi",   basePrice: 500000    },
            "NAGA":     { name: "Naga Corp",              price: 1200000,   change: 0, lastUpdate: Date.now(), category: "energi",      basePrice: 1200000   },
            "GOBLIN":   { name: "Goblin Inc",             price: 250000,    change: 0, lastUpdate: Date.now(), category: "retail",      basePrice: 250000    },
            "EMAS":     { name: "Tambang Emas Tbk",       price: 2500000,   change: 0, lastUpdate: Date.now(), category: "tambang",     basePrice: 2500000   },
            "DRAGON":   { name: "Dragon Air",             price: 750000,    change: 0, lastUpdate: Date.now(), category: "transportasi",basePrice: 750000    },
            "MITHRIL":  { name: "Mithril Resources",      price: 1800000,   change: 0, lastUpdate: Date.now(), category: "tambang",     basePrice: 1800000   },
            "DUNGEON":  { name: "Dungeon Explore Tbk",    price: 950000,    change: 0, lastUpdate: Date.now(), category: "hiburan",     basePrice: 950000    },
            "POTION":   { name: "Potion Pharma",          price: 450000,    change: 0, lastUpdate: Date.now(), category: "farmasi",     basePrice: 450000    },
            "RUNE":     { name: "Rune Tech",              price: 1100000,   change: 0, lastUpdate: Date.now(), category: "teknologi",   basePrice: 1100000   },
            "FISH":     { name: "Ocean Fish Corp",        price: 320000,    change: 0, lastUpdate: Date.now(), category: "konsumsi",    basePrice: 320000    },
            "ARMA":     { name: "Armament Kingdom",       price: 3500000,   change: 0, lastUpdate: Date.now(), category: "pertahanan",  basePrice: 3500000   },
            "HERB":     { name: "Herbal Nature Co",       price: 680000,    change: 0, lastUpdate: Date.now(), category: "farmasi",     basePrice: 680000    },
            "CRYSTAL":  { name: "Crystal Mine Corp",      price: 4200000,   change: 0, lastUpdate: Date.now(), category: "tambang",     basePrice: 4200000   },
            "ORICHAL":  { name: "Orichalcum Industries",  price: 8500000,   change: 0, lastUpdate: Date.now(), category: "tambang",     basePrice: 8500000   },
            "PHOENIX":  { name: "Phoenix Energy Tbk",     price: 5000000,   change: 0, lastUpdate: Date.now(), category: "energi",      basePrice: 5000000   },
            "SHADOW":   { name: "Shadow Corp",            price: 2700000,   change: 0, lastUpdate: Date.now(), category: "teknologi",   basePrice: 2700000   },
            "LICH":     { name: "Lich King Holdings",     price: 9900000,   change: 0, lastUpdate: Date.now(), category: "keuangan",    basePrice: 9900000   },
            "KRAKEN":   { name: "Kraken Shipping Lines",  price: 6600000,   change: 0, lastUpdate: Date.now(), category: "transportasi",basePrice: 6600000   },
            "ELVWOOD":  { name: "Elven Wood Industries",  price: 1500000,   change: 0, lastUpdate: Date.now(), category: "properti",    basePrice: 1500000   },
            "GODBLESS": { name: "God Blessing Fund",      price: 25000000,  change: 0, lastUpdate: Date.now(), category: "keuangan",    basePrice: 25000000  },
            // ── SAHAM ULTRA PREMIUM ──
            "VOID":     { name: "Void Dimension Corp",    price: 75000000,  change: 0, lastUpdate: Date.now(), category: "teknologi",   basePrice: 75000000  },
            "DRAGONX":  { name: "DragonX Holdings",       price: 150000000, change: 0, lastUpdate: Date.now(), category: "energi",      basePrice: 150000000 },
            "DIVINECO": { name: "Divine Corp Ltd",         price: 500000000, change: 0, lastUpdate: Date.now(), category: "keuangan",    basePrice: 500000000 },
            "OMEGAX":   { name: "OmegaX Syndicate",        price: 1000000000,change: 0, lastUpdate: Date.now(), category: "pertahanan",  basePrice: 1000000000},
            "GALACTA":  { name: "Galacta Universe Fund",   price: 2500000000,change: 0, lastUpdate: Date.now(), category: "keuangan",    basePrice: 2500000000}
        },
        properti: {
            "warung":          { name: "Warung Makan",         price: 5000000,      description: "Warung sederhana pinggir jalan",              passive: 50000      },
            "rumah_kecil":     { name: "Rumah Kecil",          price: 25000000,     description: "Rumah 1 kamar di pinggiran kota",              passive: 200000     },
            "kos_kosan":       { name: "Kos-kosan",            price: 80000000,     description: "10 kamar kos strategis deket kampus",          passive: 800000     },
            "apartemen":       { name: "Apartemen Studio",     price: 150000000,    description: "Apartemen studio di pusat kota",               passive: 1500000    },
            "gudang":          { name: "Gudang Logistik",      price: 200000000,    description: "Gudang 500m² dekat pelabuhan",                 passive: 1200000    },
            "ruko":            { name: "Ruko Komersial",       price: 350000000,    description: "Ruko 2 lantai lokasi premium",                 passive: 3000000    },
            "rumah_mewah":     { name: "Rumah Mewah",          price: 750000000,    description: "Rumah 4 kamar + kolam renang + taman",         passive: 5000000    },
            "villa":           { name: "Villa Tepi Pantai",    price: 1500000000,   description: "Villa eksklusif view laut langsung",           passive: 10000000   },
            "hotel_bintang":   { name: "Hotel Bintang 3",      price: 3000000000,   description: "Hotel 30 kamar di jantung kota",               passive: 30000000   },
            "mall_mini":       { name: "Mini Mall",            price: 5000000000,   description: "Mini mall 2 lantai 20+ tenant",                passive: 60000000   },
            "menara_kantor":   { name: "Menara Kantor",        price: 8000000000,   description: "Gedung perkantoran 10 lantai",                 passive: 90000000   },
            "pulau_pribadi":   { name: "Pulau Pribadi",        price: 50000000000,  description: "Pulau kecil eksklusif milik sendiri",          passive: 500000000  },
            "pabrik_senjata":  { name: "Pabrik Senjata",       price: 12000000000,  description: "Pabrik produksi senjata & armor",              passive: 150000000  },
            "kebun_raya":      { name: "Kebun Raya Herbal",    price: 2000000000,   description: "Kebun herbal seluas 50 hektar",                passive: 20000000   },
            "kastil":          { name: "Kastil Megah",         price: 100000000000, description: "Kastil legendaris dengan 50 ruangan",          passive: 1000000000 },
            // ── PROPERTI ULTRA PREMIUM ──
            "kota_buatan":     { name: "Kota Buatan Sendiri",  price: 500000000000, description: "Kota mini dengan 100.000 penduduk",            passive: 5000000000 },
            "istana_dewa":     { name: "Istana Dewa",          price: 1000000000000,description: "Istana surgawi di awan, satu-satunya di dunia", passive: 10000000000},
            "benua_pribadi":   { name: "Benua Pribadi",        price: 5000000000000,description: "Benua seluas Eropa, milik sendiri",             passive: 50000000000},
            "planet_buatan":   { name: "Planet Buatan",        price: 99000000000000,description: "Planet artifisial berteknologi terdepan",      passive: 999000000000}
        },
        kendaraan: {
            "motor":              { name: "Motor Biasa",           price: 3000000,       description: "Motor matic 125cc",                           passive: 0            },
            "motor_listrik":      { name: "Motor Listrik",         price: 8000000,       description: "Motor listrik ramah lingkungan",              passive: 0            },
            "mobil_city":         { name: "Mobil City Car",        price: 25000000,      description: "Mobil kecil irit BBM",                        passive: 0            },
            "pickup":             { name: "Pickup Truck",          price: 60000000,      description: "Pickup double cabin serba guna",              passive: 500000       },
            "truk":               { name: "Truk Pengiriman",       price: 150000000,     description: "Truk angkutan barang 10 ton",                 passive: 2000000      },
            "mobil_sport":        { name: "Mobil Sport",           price: 500000000,     description: "Supercar 600hp",                              passive: 0            },
            "bus_mini":           { name: "Bus Mini",              price: 350000000,     description: "Angkutan umum 20 penumpang",                  passive: 5000000      },
            "kapal_cargo":        { name: "Kapal Cargo",           price: 2000000000,    description: "Kapal pengiriman antar pulau",                passive: 20000000     },
            "helikopter":         { name: "Helikopter",            price: 3500000000,    description: "Heli pribadi 4 penumpang",                    passive: 0            },
            "yacht":              { name: "Yacht Mewah",           price: 8000000000,    description: "Kapal pesiar pribadi mewah",                  passive: 0            },
            "jet_pribadi":        { name: "Jet Pribadi",           price: 15000000000,   description: "Jet mewah kapasitas 8 orang",                 passive: 0            },
            "kapal_perang":       { name: "Kapal Perang",          price: 50000000000,   description: "Fregat bersenjata lengkap",                   passive: 50000000     },
            "tank_tempur":        { name: "Tank Tempur",           price: 25000000000,   description: "Main battle tank berlapis baja",              passive: 0            },
            "pesawat_tempur":     { name: "Pesawat Tempur",        price: 80000000000,   description: "Fighter jet generasi terbaru",                passive: 0            },
            "kapal_luar_angkasa": { name: "Kapal Luar Angkasa",    price: 999000000000,  description: "Roket interplanet buatan sendiri",            passive: 0            },
            // ── KENDARAAN ULTRA PREMIUM ──
            "kapal_induk":        { name: "Kapal Induk",           price: 5000000000000, description: "Aircraft carrier lengkap dgn 80 pesawat",     passive: 500000000    },
            "stasiun_luar_angkasa":{ name: "Stasiun Luar Angkasa", price: 20000000000000,description: "Space station orbit bumi, kapasitas 100 org",  passive: 1000000000   },
            "death_star":         { name: "Death Star Mini",       price: 100000000000000,description: "Senjata orbital terkuat di galaksi",          passive: 0            },
            "thor_hammer":        { name: "Kapal Thor Hammer",     price: 999000000000000,description: "THE ULTIMATE VEHICLE — melampaui segalanya",  passive: 10000000000  }
        },
        listings: []
    }
    fs.writeFileSync(marketDBPath, JSON.stringify(defaultMarket, null, 2))
}

function getMarketDB() {
    try { return JSON.parse(fs.readFileSync(marketDBPath)) }
    catch { return { saham: {}, properti: {}, kendaraan: {}, listings: [] } }
}

function saveMarketDB(data) {
    fs.writeFileSync(marketDBPath, JSON.stringify(data, null, 2))
}

// Sync item market baru ke market.json yang sudah ada
;(function syncRPGData() {
    try {
        if (!fs.existsSync(rpgDBPath)) return // defaultRPG sudah handle ini
        const db = JSON.parse(fs.readFileSync(rpgDBPath))
        let changed = false

        // ── Monsters baru ──────────────────────────────────────────────
        const newMonsters = {
            "1":  { "name": "🐀 Tikus Got",         "hp": 18,  "attack": 3,  "defense": 1,  "exp": 8,   "gold": 5,   "level": 1,  "tier": 1, "drops": { "kulit_goblin": 0.4 } },
            "2":  { "name": "🐛 Ulat Beracun",       "hp": 22,  "attack": 4,  "defense": 1,  "exp": 10,  "gold": 7,   "level": 1,  "tier": 1, "drops": { "racun_laba": 0.5, "rumput_liar": 0.6 } },
            "3":  { "name": "🐸 Katak Raksasa",      "hp": 28,  "attack": 5,  "defense": 2,  "exp": 14,  "gold": 10,  "level": 2,  "tier": 1, "drops": { "kulit_goblin": 0.5, "jamur_ajaib": 0.2 } },
            "4":  { "name": "👺 Goblin",              "hp": 30,  "attack": 5,  "defense": 2,  "exp": 15,  "gold": 10,  "level": 2,  "tier": 1, "drops": { "kulit_goblin": 0.7, "taring_goblin": 0.3 } },
            "5":  { "name": "🐺 Serigala Kecil",     "hp": 35,  "attack": 6,  "defense": 2,  "exp": 18,  "gold": 12,  "level": 3,  "tier": 1, "drops": { "kulit_goblin": 0.4, "taring_goblin": 0.2 } },
            "6":  { "name": "🦎 Kadal Pasir",        "hp": 32,  "attack": 6,  "defense": 3,  "exp": 16,  "gold": 11,  "level": 3,  "tier": 1, "drops": { "kulit_goblin": 0.5, "batu": 0.8 } },
            "7":  { "name": "🐝 Lebah Raksasa",      "hp": 25,  "attack": 7,  "defense": 1,  "exp": 13,  "gold": 9,   "level": 2,  "tier": 1, "drops": { "racun_laba": 0.4, "bunga_langka": 0.3 } },
            "8":  { "name": "🌿 Tanaman Berjalan",   "hp": 40,  "attack": 4,  "defense": 4,  "exp": 17,  "gold": 8,   "level": 3,  "tier": 1, "drops": { "rumput_liar": 0.9, "bunga_langka": 0.2 } },
            "9":  { "name": "🕷️ Laba-laba Raksasa",  "hp": 45,  "attack": 7,  "defense": 3,  "exp": 20,  "gold": 15,  "level": 4,  "tier": 2, "drops": { "racun_laba": 0.6, "kulit_goblin": 0.2 } },
            "10": { "name": "🐗 Babi Hutan Liar",    "hp": 55,  "attack": 8,  "defense": 4,  "exp": 25,  "gold": 18,  "level": 5,  "tier": 2, "drops": { "kulit_orc": 0.4, "batu_kekuatan": 0.1 } },
            "11": { "name": "💀 Goblin Pemanah",     "hp": 48,  "attack": 9,  "defense": 3,  "exp": 22,  "gold": 17,  "level": 5,  "tier": 2, "drops": { "taring_goblin": 0.7, "batu_bara": 0.3 } },
            "12": { "name": "🧟 Zombie Prajurit",    "hp": 60,  "attack": 8,  "defense": 5,  "exp": 28,  "gold": 20,  "level": 5,  "tier": 2, "drops": { "kulit_orc": 0.3, "batu_kekuatan": 0.1 } },
            "13": { "name": "🐊 Buaya Sungai",       "hp": 65,  "attack": 10, "defense": 6,  "exp": 30,  "gold": 22,  "level": 6,  "tier": 2, "drops": { "kulit_orc": 0.5, "racun_laba": 0.2 } },
            "14": { "name": "🧌 Orc Prajurit",       "hp": 70,  "attack": 10, "defense": 5,  "exp": 32,  "gold": 25,  "level": 6,  "tier": 2, "drops": { "kulit_orc": 0.6, "batu_kekuatan": 0.15 } },
            "15": { "name": "🦂 Kalajengking Bara",  "hp": 58,  "attack": 11, "defense": 4,  "exp": 27,  "gold": 20,  "level": 6,  "tier": 2, "drops": { "racun_laba": 0.7, "batu_bara": 0.4 } },
            "16": { "name": "🐻 Beruang Hutan",      "hp": 80,  "attack": 9,  "defense": 6,  "exp": 35,  "gold": 28,  "level": 7,  "tier": 2, "drops": { "kulit_orc": 0.5, "taring_goblin": 0.3 } },
            "17": { "name": "👹 Goblin Jendral",     "hp": 80,  "attack": 12, "defense": 6,  "exp": 70,  "gold": 60,  "level": 7,  "tier": 3, "drops": { "batu_kekuatan": 0.5, "taring_goblin": 0.8 } },
            "18": { "name": "🌊 Troll Rawa",         "hp": 90,  "attack": 13, "defense": 7,  "exp": 55,  "gold": 45,  "level": 8,  "tier": 3, "drops": { "kulit_orc": 0.6, "batu_kekuatan": 0.25 } },
            "19": { "name": "🦁 Singa Berbisa",      "hp": 95,  "attack": 14, "defense": 6,  "exp": 60,  "gold": 50,  "level": 8,  "tier": 3, "drops": { "racun_laba": 0.5, "batu_kekuatan": 0.3 } },
            "20": { "name": "🌲 Troll Hutan",        "hp": 100, "attack": 13, "defense": 8,  "exp": 65,  "gold": 55,  "level": 9,  "tier": 3, "drops": { "kulit_orc": 0.4, "batu_kekuatan": 0.2 } },
            "21": { "name": "🐍 Ular Raksasa Biru",  "hp": 88,  "attack": 15, "defense": 5,  "exp": 62,  "gold": 52,  "level": 9,  "tier": 3, "drops": { "racun_laba": 0.8, "kristal_es": 0.15 } },
            "22": { "name": "🧙 Penyihir Gelap",     "hp": 75,  "attack": 16, "defense": 4,  "exp": 68,  "gold": 58,  "level": 10, "tier": 3, "drops": { "batu_kekuatan": 0.4, "permata": 0.1 } },
            "23": { "name": "🦅 Elang Api Kecil",    "hp": 85,  "attack": 14, "defense": 5,  "exp": 60,  "gold": 50,  "level": 9,  "tier": 3, "drops": { "bulu_phoenix": 0.15, "batu_kekuatan": 0.3 } },
            "24": { "name": "⚔️ Ksatria Mati",       "hp": 110, "attack": 15, "defense": 9,  "exp": 75,  "gold": 65,  "level": 10, "tier": 3, "drops": { "bijih_besi": 0.6, "batu_kekuatan": 0.35 } },
            "25": { "name": "🐲 Naga Kecil",         "hp": 130, "attack": 17, "defense": 9,  "exp": 90,  "gold": 80,  "level": 11, "tier": 4, "drops": { "sisik_naga": 0.4, "batu_kekuatan": 0.3 } },
            "26": { "name": "🌋 Elemental Api",      "hp": 120, "attack": 19, "defense": 8,  "exp": 95,  "gold": 85,  "level": 12, "tier": 4, "drops": { "batu_kekuatan": 0.5, "permata": 0.2 } },
            "27": { "name": "❄️ Elemental Es",       "hp": 115, "attack": 18, "defense": 10, "exp": 90,  "gold": 80,  "level": 12, "tier": 4, "drops": { "kristal_es": 0.6, "batu_kekuatan": 0.25 } },
            "28": { "name": "🦈 Hiu Daratan",        "hp": 125, "attack": 20, "defense": 7,  "exp": 98,  "gold": 88,  "level": 13, "tier": 4, "drops": { "kulit_orc": 0.3, "tulang_naga": 0.1 } },
            "29": { "name": "🧿 Beholder",           "hp": 140, "attack": 18, "defense": 11, "exp": 105, "gold": 95,  "level": 13, "tier": 4, "drops": { "permata": 0.3, "batu_kekuatan": 0.4 } },
            "30": { "name": "🦴 Raja Zombie",        "hp": 145, "attack": 19, "defense": 10, "exp": 110, "gold": 100, "level": 14, "tier": 4, "drops": { "tulang_naga": 0.15, "mithril": 0.05 } },
            "31": { "name": "🌪️ Djinn Badai",        "hp": 130, "attack": 22, "defense": 8,  "exp": 115, "gold": 105, "level": 14, "tier": 4, "drops": { "kristal_es": 0.4, "permata": 0.25 } },
            "32": { "name": "🐯 Harimau Roh",        "hp": 135, "attack": 21, "defense": 9,  "exp": 108, "gold": 98,  "level": 13, "tier": 4, "drops": { "batu_kekuatan": 0.45, "kristal_es": 0.2 } },
            "33": { "name": "🐉 Naga",               "hp": 160, "attack": 23, "defense": 12, "exp": 140, "gold": 130, "level": 15, "tier": 5, "drops": { "sisik_naga": 0.5, "tulang_naga": 0.2, "batu_kekuatan": 0.3 } },
            "34": { "name": "🦊 Serigala Roh",       "hp": 150, "attack": 22, "defense": 10, "exp": 130, "gold": 120, "level": 15, "tier": 5, "drops": { "kristal_es": 0.4, "batu_kekuatan": 0.2 } },
            "35": { "name": "🌑 Wraith Kegelapan",   "hp": 145, "attack": 25, "defense": 9,  "exp": 145, "gold": 135, "level": 16, "tier": 5, "drops": { "permata": 0.4, "mithril": 0.08 } },
            "36": { "name": "🗿 Golem Batu",         "hp": 200, "attack": 20, "defense": 18, "exp": 155, "gold": 145, "level": 17, "tier": 5, "drops": { "batu_kekuatan": 0.6, "mithril": 0.1, "permata": 0.2 } },
            "37": { "name": "🧊 Ice Drake",          "hp": 185, "attack": 24, "defense": 15, "exp": 165, "gold": 155, "level": 17, "tier": 5, "drops": { "kristal_es": 0.6, "tulang_naga": 0.3 } },
            "38": { "name": "🌊 Leviathan Kecil",    "hp": 195, "attack": 23, "defense": 14, "exp": 170, "gold": 160, "level": 18, "tier": 5, "drops": { "sisik_naga": 0.4, "tulang_naga": 0.25 } },
            "39": { "name": "🔥 Ifrit",              "hp": 175, "attack": 27, "defense": 12, "exp": 160, "gold": 150, "level": 17, "tier": 5, "drops": { "bulu_phoenix": 0.3, "permata": 0.3 } },
            "40": { "name": "⚡ Raksasa Petir",      "hp": 190, "attack": 26, "defense": 13, "exp": 158, "gold": 148, "level": 18, "tier": 5, "drops": { "kristal_es": 0.5, "mithril": 0.1 } },
            "41": { "name": "🦅 Phoenix",            "hp": 220, "attack": 28, "defense": 15, "exp": 200, "gold": 190, "level": 20, "tier": 6, "drops": { "bulu_phoenix": 0.5, "sisik_naga": 0.3 } },
            "42": { "name": "👑 Lich King",          "hp": 300, "attack": 32, "defense": 18, "exp": 280, "gold": 260, "level": 22, "tier": 6, "drops": { "orichalcum": 0.2, "bulu_phoenix": 0.3, "mithril": 0.5 } },
            "43": { "name": "🐲 Naga Tua",           "hp": 280, "attack": 30, "defense": 17, "exp": 250, "gold": 230, "level": 21, "tier": 6, "drops": { "sisik_naga": 0.6, "tulang_naga": 0.4, "mithril": 0.15 } },
            "44": { "name": "🕯️ Overlord Sihir",     "hp": 260, "attack": 35, "defense": 14, "exp": 270, "gold": 250, "level": 22, "tier": 6, "drops": { "permata": 0.5, "mithril": 0.2, "orichalcum": 0.08 } },
            "45": { "name": "🦂 Kalajengking Raksasa","hp": 290, "attack": 29, "defense": 20, "exp": 240, "gold": 220, "level": 21, "tier": 6, "drops": { "racun_laba": 0.8, "mithril": 0.1, "permata": 0.3 } },
            "46": { "name": "🌀 Void Walker",        "hp": 270, "attack": 33, "defense": 16, "exp": 260, "gold": 240, "level": 23, "tier": 6, "drops": { "mithril": 0.25, "orichalcum": 0.1 } },
            "47": { "name": "🌑 Demon Lord",         "hp": 380, "attack": 40, "defense": 22, "exp": 400, "gold": 380, "level": 25, "tier": 7, "drops": { "orichalcum": 0.25, "mithril": 0.4, "tulang_naga": 0.5 } },
            "48": { "name": "🐉 Naga Merah Purba",   "hp": 420, "attack": 38, "defense": 24, "exp": 450, "gold": 420, "level": 27, "tier": 7, "drops": { "sisik_naga": 0.8, "tulang_naga": 0.6, "orichalcum": 0.2 } },
            "49": { "name": "⚔️ Ksatria Iblis",      "hp": 360, "attack": 42, "defense": 20, "exp": 420, "gold": 400, "level": 26, "tier": 7, "drops": { "mithril": 0.5, "orichalcum": 0.15, "permata": 0.4 } },
            "50": { "name": "🌊 Leviathan",          "hp": 450, "attack": 36, "defense": 26, "exp": 480, "gold": 450, "level": 28, "tier": 7, "drops": { "tulang_naga": 0.7, "orichalcum": 0.2, "kristal_es": 0.5 } },
            "51": { "name": "🦴 Necromancer Agung",  "hp": 340, "attack": 45, "defense": 18, "exp": 460, "gold": 440, "level": 27, "tier": 7, "drops": { "orichalcum": 0.3, "mithril": 0.45, "bulu_phoenix": 0.4 } },
            "52": { "name": "🌋 Titan Api",          "hp": 550, "attack": 50, "defense": 30, "exp": 650, "gold": 620, "level": 30, "tier": 8, "drops": { "orichalcum": 0.35, "bulu_phoenix": 0.5, "mithril": 0.6 } },
            "53": { "name": "❄️ Titan Es",           "hp": 560, "attack": 48, "defense": 33, "exp": 680, "gold": 650, "level": 32, "tier": 8, "drops": { "kristal_es": 0.8, "orichalcum": 0.3, "mithril": 0.55 } },
            "54": { "name": "🌑 Abyssal Horror",     "hp": 600, "attack": 55, "defense": 28, "exp": 750, "gold": 720, "level": 33, "tier": 8, "drops": { "orichalcum": 0.4, "mithril": 0.65, "permata": 0.5 } },
            "55": { "name": "🐲 Naga Hitam Kuno",    "hp": 620, "attack": 52, "defense": 35, "exp": 780, "gold": 750, "level": 35, "tier": 8, "drops": { "sisik_naga": 1.0, "tulang_naga": 0.8, "orichalcum": 0.35 } },
            "56": { "name": "👁️ Dewa Kegelapan",     "hp": 800, "attack": 65, "defense": 40, "exp": 1100,"gold": 1050,"level": 38, "tier": 9, "drops": { "orichalcum": 0.5, "mithril": 0.8, "bulu_phoenix": 0.6 } },
            "57": { "name": "🔱 Poseidon Palsu",     "hp": 850, "attack": 60, "defense": 45, "exp": 1200,"gold": 1150,"level": 40, "tier": 9, "drops": { "orichalcum": 0.55, "tulang_naga": 1.0, "kristal_es": 0.7 } },
            "58": { "name": "☄️ Meteor Golem",       "hp": 900, "attack": 58, "defense": 50, "exp": 1300,"gold": 1250,"level": 42, "tier": 9, "drops": { "orichalcum": 0.6, "permata": 0.8, "mithril": 0.9 } },
            "59": { "name": "🌑 Void Dragon",        "hp": 950, "attack": 70, "defense": 42, "exp": 1400,"gold": 1350,"level": 45, "tier": 9, "drops": { "orichalcum": 0.65, "sisik_naga": 1.0, "tulang_naga": 1.0 } },
            "60": { "name": "⚡ Zeus Terlarang",     "hp": 1200,"attack": 80, "defense": 55, "exp": 2000,"gold": 1950,"level": 50, "tier": 10,"drops": { "orichalcum": 0.8, "mithril": 1.0, "bulu_phoenix": 0.9 } },
            "61": { "name": "🔥 Surtr Sang Api",     "hp": 1400,"attack": 85, "defense": 50, "exp": 2200,"gold": 2150,"level": 52, "tier": 10,"drops": { "orichalcum": 0.85, "bulu_phoenix": 1.0, "tulang_naga": 1.0 } },
            "62": { "name": "💀 Azrael Si Maut",     "hp": 1600,"attack": 90, "defense": 58, "exp": 2500,"gold": 2450,"level": 55, "tier": 10,"drops": { "orichalcum": 1.0, "mithril": 1.0, "permata": 1.0, "bulu_phoenix": 1.0 } },
            "63": { "name": "🌌 Chaos Dragon",      "hp": 2000,"attack": 100,"defense": 65, "exp": 3000,"gold": 2950,"level": 60, "tier": 10,"drops": { "orichalcum": 1.0, "mithril": 1.0, "sisik_naga": 1.0, "tulang_naga": 1.0, "bulu_phoenix": 1.0 } }
        }
        if (!db.monsters) { db.monsters = {}; changed = true }
        for (const [k, v] of Object.entries(newMonsters)) {
            if (!db.monsters[k]) { db.monsters[k] = v; changed = true }
            else { db.monsters[k] = { ...v, ...db.monsters[k], tier: v.tier } ; changed = true } // update tier tanpa hapus data lama
        }

        // ── Lokasi baru ────────────────────────────────────────────────
        const newLocations = {
            "desa":         { "name": "🏡 Desa Pemula",        "monsters": [1,2,3,4,5,6,7,8],         "minLevel": 1,  "maxLevel": 5  },
            "hutan":        { "name": "🌲 Hutan Gelap",        "monsters": [4,5,8,9,10,11,12],         "minLevel": 3,  "maxLevel": 9  },
            "rawa":         { "name": "🌿 Rawa Beracun",       "monsters": [9,11,13,15,16],             "minLevel": 5,  "maxLevel": 10 },
            "gua":          { "name": "⛏️ Gua Naga",           "monsters": [14,17,18,19,20,21,22,23,24],"minLevel": 8,  "maxLevel": 16 },
            "padang_api":   { "name": "🌋 Padang Api",         "monsters": [15,22,23,26,31],            "minLevel": 10, "maxLevel": 18 },
            "pegunungan":   { "name": "🏔️ Pegunungan Es",      "monsters": [27,29,31,32,34,37],         "minLevel": 12, "maxLevel": 20 },
            "reruntuhan":   { "name": "🏚️ Reruntuhan Kuno",    "monsters": [24,28,29,30,36],            "minLevel": 13, "maxLevel": 20 },
            "kuil_api":     { "name": "🔥 Kuil Api Abadi",     "monsters": [33,35,39,40,41],            "minLevel": 16, "maxLevel": 24 },
            "laut_dalam":   { "name": "🌊 Laut Dalam",         "monsters": [34,38,40,43,50],            "minLevel": 17, "maxLevel": 25 },
            "menara_sihir": { "name": "🗼 Menara Sihir",       "monsters": [42,44,46,47,51],            "minLevel": 20, "maxLevel": 30 },
            "hutan_iblis":  { "name": "😈 Hutan Iblis",        "monsters": [43,45,47,48,49],            "minLevel": 22, "maxLevel": 32 },
            "neraka_atas":  { "name": "🌑 Gerbang Neraka",     "monsters": [47,48,49,50,51,52],         "minLevel": 25, "maxLevel": 35 },
            "samudera_void":{ "name": "🌀 Samudera Void",      "monsters": [46,50,53,54,55],            "minLevel": 28, "maxLevel": 38 },
            "gunung_titan": { "name": "⚡ Gunung Titan",       "monsters": [52,53,54,55,56],            "minLevel": 30, "maxLevel": 45 },
            "alam_dewa":    { "name": "👁️ Alam Para Dewa",     "monsters": [56,57,58,59],               "minLevel": 38, "maxLevel": 52 },
            "kekacauan":    { "name": "🌌 Dimensi Kekacauan",  "monsters": [60,61,62,63],               "minLevel": 50, "maxLevel": 999 },
            "tambang":      { "name": "⛏️ Tambang Terbengkalai","minLevel": 5, "maxLevel": 30, "ores": { "batu": 0.8, "batu_bara": 0.5, "bijih_besi": 0.2, "permata": 0.05, "mithril": 0.02, "orichalcum": 0.005 } },
            "padang_rumput":{ "name": "🌾 Padang Rumput Liar", "minLevel": 2, "maxLevel": 20, "herbs": { "rumput_liar": 0.9, "bunga_langka": 0.3, "jamur_ajaib": 0.1, "kristal_es": 0.05 } }
        }
        if (!db.locations) { db.locations = {}; changed = true }
        for (const [k, v] of Object.entries(newLocations)) {
            db.locations[k] = v; changed = true // selalu update lokasi agar monster list terbaru
        }

        if (changed) fs.writeFileSync(rpgDBPath, JSON.stringify(db, null, 2))
    } catch(e) { console.error('syncRPGData error:', e) }
})()

;(function syncMarketNew() {
    try {
        const mdb = getMarketDB()
        let changed = false
        const newSaham = {
            "VOID":     { name: "Void Dimension Corp",    price: 75000000,   change: 0, lastUpdate: Date.now(), category: "teknologi",  basePrice: 75000000   },
            "DRAGONX":  { name: "DragonX Holdings",       price: 150000000,  change: 0, lastUpdate: Date.now(), category: "energi",     basePrice: 150000000  },
            "DIVINECO": { name: "Divine Corp Ltd",         price: 500000000,  change: 0, lastUpdate: Date.now(), category: "keuangan",   basePrice: 500000000  },
            "OMEGAX":   { name: "OmegaX Syndicate",        price: 1000000000, change: 0, lastUpdate: Date.now(), category: "pertahanan", basePrice: 1000000000 },
            "GALACTA":  { name: "Galacta Universe Fund",   price: 2500000000, change: 0, lastUpdate: Date.now(), category: "keuangan",   basePrice: 2500000000 }
        }
        const newProperti = {
            "kota_buatan":   { name: "Kota Buatan Sendiri",  price: 500000000000,  description: "Kota mini dengan 100.000 penduduk",            passive: 5000000000  },
            "istana_dewa":   { name: "Istana Dewa",          price: 1000000000000, description: "Istana surgawi di awan, satu-satunya di dunia", passive: 10000000000 },
            "benua_pribadi": { name: "Benua Pribadi",        price: 5000000000000, description: "Benua seluas Eropa, milik sendiri",             passive: 50000000000 },
            "planet_buatan": { name: "Planet Buatan",        price: 99000000000000,description: "Planet artifisial berteknologi terdepan",       passive: 999000000000}
        }
        const newKendaraan = {
            "kapal_induk":         { name: "Kapal Induk",            price: 5000000000000,  description: "Aircraft carrier lengkap dgn 80 pesawat",    passive: 500000000   },
            "stasiun_luar_angkasa":{ name: "Stasiun Luar Angkasa",   price: 20000000000000, description: "Space station orbit bumi, kapasitas 100 org", passive: 1000000000  },
            "death_star":          { name: "Death Star Mini",        price: 100000000000000,description: "Senjata orbital terkuat di galaksi",          passive: 0           },
            "thor_hammer":         { name: "Kapal Thor Hammer",      price: 999000000000000,description: "THE ULTIMATE VEHICLE — melampaui segalanya",  passive: 10000000000 }
        }
        if (!mdb.saham) { mdb.saham = {}; changed = true }
        for (const [k,v] of Object.entries(newSaham)) { if (!mdb.saham[k]) { mdb.saham[k] = v; changed = true } }
        if (!mdb.properti) { mdb.properti = {}; changed = true }
        for (const [k,v] of Object.entries(newProperti)) { if (!mdb.properti[k]) { mdb.properti[k] = v; changed = true } }
        if (!mdb.kendaraan) { mdb.kendaraan = {}; changed = true }
        for (const [k,v] of Object.entries(newKendaraan)) { if (!mdb.kendaraan[k]) { mdb.kendaraan[k] = v; changed = true } }
        if (!mdb.listings) { mdb.listings = []; changed = true }
        if (changed) saveMarketDB(mdb)
    } catch(e) { console.error('syncMarketNew error:', e) }
})()

function fluctuateSaham(marketDB) {
    const now = Date.now()
    for (const [ticker, saham] of Object.entries(marketDB.saham)) {
        if (now - saham.lastUpdate > 5 * 60 * 1000) {
            const pct = (Math.random() * 20 - 10) / 100
            const oldPrice = saham.price
            saham.price = Math.max(100, Math.floor(saham.price * (1 + pct)))
            saham.change = Math.round((saham.price - oldPrice) / oldPrice * 100 * 10) / 10
            saham.lastUpdate = now
        }
    }
    return marketDB
}

function calcTotalAssets(player, marketDB) {
    let total = (player.gold || 0) + (player.bank?.balance || 0)
    const walletAssets = player.assets || {}
    const bankAssets = player.bankAssets || {}
    for (const cat of ['saham', 'properti', 'kendaraan']) {
        const w = walletAssets[cat] || {}
        const b = bankAssets[cat] || {}
        const allKeys = new Set([...Object.keys(w), ...Object.keys(b)])
        for (const key of allKeys) {
            const qty = (w[key] || 0) + (b[key] || 0)
            if (qty <= 0) continue
            if (cat === 'saham' && marketDB.saham[key]) total += marketDB.saham[key].price * qty
            else if (marketDB[cat]?.[key]) total += marketDB[cat][key].price * qty
        }
    }
    return total
}

function initPlayerRPG(jid, className = "warrior") {
    const classes = {
        "warrior": { hp: 100, mp: 30, attack: 15, defense: 10, agility: 5 },
        "mage": { hp: 60, mp: 100, attack: 20, defense: 5, agility: 8 },
        "archer": { hp: 80, mp: 50, attack: 12, defense: 7, agility: 15 }
    }
    const selectedClass = classes[className] || classes["warrior"]
    return {
        jid: jid,
        class: className,
        level: 1,
        exp: 0,
        expToNextLevel: 100,
        maxHp: selectedClass.hp,
        hp: selectedClass.hp,
        maxMp: selectedClass.mp,
        mp: selectedClass.mp,
        attack: selectedClass.attack,
        defense: selectedClass.defense,
        agility: selectedClass.agility,
        gold: 50,
        inventory: { "potion": 3, "pedang_kayu": 1, "baju_kain": 1 },
        equipment: { weapon: null, armor: null },
        location: "desa",
        battles: 0,
        monstersDefeated: 0,
        lastBattle: 0,
        activeQuest: null,
        questProgress: 0,
        lastDaily: 0,
        lastPvp: 0,
        pvpWins: 0,
        pvpLosses: 0,
        fishing: null,
        pet: null,
        dungeonState: null,
        miningState: null,
        lastForage: 0,
        bank: { balance: 0, totalDeposited: 0, totalWithdrawn: 0 },
        lastWeekly: 0,
        lastMonthly: 0,
        lastYearly: 0,
        lastSlot: 0,
        lastPassive: 0,
        assets: { saham: {}, properti: {}, kendaraan: {} },
        bankAssets: { saham: {}, properti: {}, kendaraan: {} },
        fishing: { lastCatch: 0, totalCatch: 0, equippedRod: 'starter_rod', equippedBait: null }
    }
}

function getRandomMonster(location, playerLevel) {
    const rpgDB = JSON.parse(fs.readFileSync(rpgDBPath))
    const locationData = rpgDB.locations[location]
    if (!locationData || !locationData.monsters || locationData.monsters.length === 0) return null

    const plvl = playerLevel || 1

    // Filter monster yang sesuai level player (±4 level dari player, tidak lebih rendah 3)
    const suitable = locationData.monsters.filter(id => {
        const m = rpgDB.monsters[String(id)]
        if (!m) return false
        const diff = m.level - plvl
        return diff >= -3 && diff <= 4
    })

    // Jika tidak ada yang cocok, ambil yang paling dekat levelnya
    const pool = suitable.length > 0 ? suitable : locationData.monsters

    // Weighted random: monster yang levelnya lebih dekat ke player lebih sering muncul
    const weights = pool.map(id => {
        const m = rpgDB.monsters[String(id)]
        if (!m) return 1
        const diff = Math.abs(m.level - plvl)
        return Math.max(1, 10 - diff)
    })
    const totalWeight = weights.reduce((a, b) => a + b, 0)
    let rand = Math.random() * totalWeight
    let chosen = pool[0]
    for (let i = 0; i < pool.length; i++) {
        rand -= weights[i]
        if (rand <= 0) { chosen = pool[i]; break }
    }

    const monsterId = String(chosen)
    const monster = rpgDB.monsters[monsterId]
    if (!monster) return null

    // Scale HP/ATK/DEF ringan berdasarkan selisih level player vs monster
    const levelDiff = Math.max(0, plvl - monster.level)
    const scale = 1 + (levelDiff * 0.05) // +5% per level di atas monster
    return {
        ...monster,
        id: monsterId,
        hp:      Math.floor(monster.hp      * scale),
        attack:  Math.floor(monster.attack  * scale),
        defense: Math.floor(monster.defense * scale),
        exp:     Math.floor(monster.exp     * Math.max(1, scale * 0.8)),
        gold:    Math.floor(monster.gold    * Math.max(1, scale * 0.8))
    }
}

function getPlayerTotalStats(player) {
    const rpgDB = JSON.parse(fs.readFileSync(rpgDBPath))
    let totalStats = { attack: player.attack || 0, defense: player.defense || 0 }
    if (!player.equipment) player.equipment = { weapon: null, armor: null }
    if (player.equipment?.weapon) {
        const weapon = rpgDB.items[player.equipment.weapon]
        if (weapon) totalStats.attack += weapon.attack || 0
    }
    if (player.equipment?.armor) {
        const armor = rpgDB.items[player.equipment.armor]
        if (armor) totalStats.defense += armor.defense || 0
    }
    return totalStats
}

function calculateDamage(attacker, defender) {
    const isPlayerAttacker = !!attacker.class
    const attackerStats = isPlayerAttacker ? getPlayerTotalStats(attacker) : { attack: attacker.attack, defense: attacker.defense }
    const defenderStats = !isPlayerAttacker ? getPlayerTotalStats(defender) : { attack: defender.attack, defense: defender.defense }

    const rawDamage = attackerStats.attack - defenderStats.defense
    let damage
    if (!isPlayerAttacker) {
        // Monster: minimal damage = 15% attack monster, tidak bisa di-tank sempurna
        const minDmg = Math.max(1, Math.floor(attackerStats.attack * 0.15))
        // Penetrasi armor berbasis level monster (tiap 5 level = +2 damage tembus)
        const monsterLevel = attacker.level || 1
        const penetration = Math.floor(monsterLevel / 5) * 2
        damage = Math.max(minDmg, Math.floor(rawDamage + penetration))
    } else {
        damage = Math.max(1, Math.floor(rawDamage))
    }
    const isCritical = Math.random() < ((attacker.agility || 5) / 100)
    return { damage: isCritical ? Math.floor(damage * 2) : damage, isCritical }
}

function gainExp(player, exp) {
    if (!player) return false
    if (!player.expToNextLevel || player.expToNextLevel <= 0) player.expToNextLevel = 100
    player.exp = (player.exp || 0) + exp
    let leveledUp = false
    while (player.exp >= player.expToNextLevel) {
        player.level = (player.level || 1) + 1
        player.exp -= player.expToNextLevel
        player.expToNextLevel = Math.floor(player.expToNextLevel * 1.5)
        player.maxHp = (player.maxHp || 100) + 10
        player.hp = player.maxHp
        player.maxMp = (player.maxMp || 30) + 5
        player.mp = player.maxMp
        player.attack = (player.attack || 10) + 2
        player.defense = (player.defense || 5) + 1
        player.agility = (player.agility || 5) + 1
        leveledUp = true
    }
    return leveledUp
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min
}

function msToTime(ms) {
    if (ms < 0) return '0 detik'
    let seconds = Math.floor(ms / 1000)
    let minutes = Math.floor(seconds / 60)
    let hours = Math.floor(minutes / 60)
    let days = Math.floor(hours / 24)
    seconds = seconds % 60
    minutes = minutes % 60
    hours = hours % 24
    let result = []
    if (days > 0) result.push(`${days} hari`)
    if (hours > 0) result.push(`${hours} jam`)
    if (minutes > 0) result.push(`${minutes} menit`)
    if (seconds > 0 && result.length === 0) result.push(`${seconds} detik`)
    return result.join(' ') || 'sebentar lagi'
}


// ═══════════════════════════════════════════════════════════
//  RPG PROCESS ANIMATION + MINIMARKET HELPERS (SAFE ADDON)
// ═══════════════════════════════════════════════════════════
const sleepRPG = (ms) => new Promise(resolve => setTimeout(resolve, ms))

async function sendRpgProcess(Reply, title = 'PROSES RPG') {
    if (typeof Reply !== 'function') return
    const frames = [
        `╭─────────────────────❏\n│▣  ⏳  ${title}\n╰─────────────────────❏\n│▣ ▰▱▱▱▱ 20%\n│▣ Menyiapkan data...`,
        `╭─────────────────────❏\n│▣  ⚙️  ${title}\n╰─────────────────────❏\n│▣ ▰▰▱▱▱ 40%\n│▣ Mengacak hasil...`,
        `╭─────────────────────❏\n│▣  🎲  ${title}\n╰─────────────────────❏\n│▣ ▰▰▰▱▱ 60%\n│▣ Sistem lagi muter...`,
        `╭─────────────────────❏\n│▣  ✨  ${title}\n╰─────────────────────❏\n│▣ ▰▰▰▰▱ 80%\n│▣ Hampir selesai...`,
        `╭─────────────────────❏\n│▣  ✅  ${title}\n╰─────────────────────❏\n│▣ ▰▰▰▰▰ 100%\n│▣ Hasil keluar!`
    ]
    for (const frame of frames) {
        await Reply(frame)
        await sleepRPG(450)
    }
}

const MINIMARKET_BASE_NAMES = [
    'Es Krim Vanilla','Es Krim Coklat','Es Krim Stroberi','Minyak Goreng','Beras Premium','Gula Pasir','Garam Dapur','Tepung Terigu','Mie Instan','Roti Tawar',
    'Susu Kotak','Kopi Sachet','Teh Celup','Coklat Batang','Permen Mint','Keripik Kentang','Biskuit Kaleng','Wafer Coklat','Air Mineral','Soda Jeruk',
    'Jus Apel','Jus Mangga','Sirup Merah','Sarden Kaleng','Kornet Sapi','Telur Ayam','Keju Slice','Mentega','Saus Sambal','Kecap Manis',
    'Mayones','Nugget Ayam','Sosis Sapi','Bakso Frozen','Ayam Frozen','Ikan Kaleng','Sayur Kaleng','Kacang Atom','Popcorn','Cereal Gandum',
    'Oatmeal','Madu Hutan','Selai Stroberi','Selai Coklat','Pasta Gigi','Sikat Gigi','Sabun Mandi','Shampoo Herbal','Deterjen Bubuk','Pewangi Pakaian',
    'Tisu Basah','Tisu Gulung','Masker Wajah','Hand Sanitizer','Obat Nyamuk','Korek Api','Baterai AA','Lampu LED','Payung Lipat','Jas Hujan',
    'Sendal Jepit','Kaos Polos','Topi Petualang','Sarung Tangan','Botol Minum','Kotak Makan','Panci Mini','Wajan Mini','Pisau Dapur','Sendok Garpu',
    'Piring Plastik','Gelas Plastik','Kantong Sampah','Sapu Mini','Pel Lantai','Kemoceng','Buku Tulis','Pulpen Biru','Pensil Kayu','Penghapus',
    'Penggaris','Lem Kertas','Amplop','Kartu Pos','Mainan Yoyo','Kartu RPG','Dadu Petualang','Kompas Murah','Peta Desa','Tali Tambang',
    'Obor Kecil','Lilin Aromatik','Kain Lap','Plester Luka','Vitamin Anak','Makanan Kucing','Makanan Ikan','Bibit Cabai','Bibit Tomat','Pupuk Mini'
]

const MINIMARKET_SIMPLE_IDS = [
    'eskrim','eskrimcoklat','eskrimstroberi','minyak','beras','gula','garam','tepung','mie','roti',
    'susu','kopi','teh','coklat','permen','keripik','biskuit','wafer','air','soda',
    'jusapel','jusmangga','sirup','sarden','kornet','telur','keju','mentega','saus','kecap',
    'mayones','nugget','sosis','bakso','ayam','ikankaleng','sayurkaleng','kacang','popcorn','cereal',
    'oatmeal','madu','selai','selaicoklat','pastagigi','sikatgigi','sabun','shampoo','deterjen','pewangi',
    'tisubasah','tisu','masker','handsanitizer','obatnyamuk','korek','baterai','lampu','payung','jashujan',
    'sendal','kaos','topi','sarungtangan','botol','kotakmakan','panci','wajan','pisau','sendok',
    'piring','gelas','sampah','sapu','pel','kemoceng','buku','pulpen','pensil','penghapus',
    'penggaris','lem','amplop','kartupos','yoyo','karturpg','dadu','kompas','peta','tali',
    'obor','lilin','kainlap','plester','vitamin','makanankucing','makananikan','bibitcabai','bibittomat','pupuk'
]

function slugMinimarketName(name, idx) {
    return MINIMARKET_SIMPLE_IDS[idx] || name.toLowerCase().replace(/[^a-z0-9]+/g, '').replace(/^_|_$/g, '')
}

function getMinimarketItems() {
    return MINIMARKET_BASE_NAMES.map((name, idx) => ({
        id: slugMinimarketName(name, idx),
        no: idx + 1,
        name,
        type: 'minimarket',
        price: 500 + (idx * 250) + ((idx % 7) * 125),
        value: Math.max(1, Math.floor((idx + 5) / 5)),
        emoji: ['🍦','🛢️','🍚','🍜','🥛','🍪','🧼','🧻','🔋','🎲'][idx % 10]
    }))
}

function ensureMinimarketInRPG(rpgDB) {
    if (!rpgDB.items) rpgDB.items = {}
    let changed = false
    for (const it of getMinimarketItems()) {
        if (!rpgDB.items[it.id]) {
            rpgDB.items[it.id] = { name: it.name, type: it.type, value: it.value, price: it.price }
            changed = true
        }
    }
    return changed
}

function findMinimarketItem(query) {
    const q = String(query || '').trim().toLowerCase()
    if (!q) return null
    const items = getMinimarketItems()
    const byNo = items.find(it => String(it.no) === q)
    if (byNo) return byNo
    const norm = q.replace(/\s+/g, '_')
    return items.find(it => it.id === q || it.id.endsWith('_' + norm) || it.name.toLowerCase() === q || it.name.toLowerCase().includes(q)) || null
}

function ensureMinimarketCart(player) {
    if (!player.minimarketCart || typeof player.minimarketCart !== 'object' || Array.isArray(player.minimarketCart)) player.minimarketCart = {}
    return player.minimarketCart
}

function renderMinimarketCart(player) {
    const cart = ensureMinimarketCart(player)
    const rows = []
    let total = 0
    for (const [id, qtyRaw] of Object.entries(cart)) {
        const qty = Number(qtyRaw) || 0
        if (qty <= 0) continue
        const item = getMinimarketItems().find(x => x.id === id)
        if (!item) continue
        const sub = item.price * qty
        total += sub
        rows.push(`│▣ ${item.emoji} *${item.name}* x${qty}
│▣    ${toRupiah(item.price)} × ${qty} = *${toRupiah(sub)}*`)
    }
    return { rows, total, count: rows.length }
}

function renderOwnedMinimarketItems(player, rpgDB) {
    const rows = []
    let totalQty = 0
    let totalValue = 0
    const inv = player.inventory || {}
    for (const it of getMinimarketItems()) {
        const qty = Number(inv[it.id] || 0)
        if (qty <= 0) continue
        const price = rpgDB.items?.[it.id]?.price || it.price || 0
        totalQty += qty
        totalValue += price * qty
        rows.push(`│▣ ${it.emoji} ${it.name} x${qty} = ${toRupiah(price * qty)}`)
    }
    return { rows, totalQty, totalValue }
}


// ═══════════════════════════════════════════════════════════
//  NELAYAN RPG HELPERS (SAFE ADDON)
// ═══════════════════════════════════════════════════════════
const NELAYAN_PERAHU = [
    { id: 'rakit_bambu', name: 'Rakit Bambu', emoji: '🪵', price: 2500, capacity: 8, power: 1, tier: 'Pemula' },
    { id: 'sampan_kecil', name: 'Sampan Kecil', emoji: '🛶', price: 6000, capacity: 12, power: 2, tier: 'Pemula' },
    { id: 'perahu_dayung', name: 'Perahu Dayung', emoji: '🚣', price: 12000, capacity: 18, power: 3, tier: 'Nelayan Baru' },
    { id: 'perahu_kayu', name: 'Perahu Kayu', emoji: '⛵', price: 25000, capacity: 25, power: 4, tier: 'Nelayan Baru' },
    { id: 'jukung_pesisir', name: 'Jukung Pesisir', emoji: '🛶', price: 50000, capacity: 35, power: 5, tier: 'Pesisir' },
    { id: 'kapal_mini', name: 'Kapal Mini', emoji: '🚤', price: 85000, capacity: 48, power: 6, tier: 'Pesisir' },
    { id: 'perahu_layar', name: 'Perahu Layar', emoji: '⛵', price: 140000, capacity: 65, power: 7, tier: 'Laut Dangkal' },
    { id: 'speedboat_tua', name: 'Speedboat Tua', emoji: '🚤', price: 225000, capacity: 85, power: 8, tier: 'Laut Dangkal' },
    { id: 'kapal_jaring', name: 'Kapal Jaring', emoji: '🛥️', price: 350000, capacity: 110, power: 10, tier: 'Profesional' },
    { id: 'kapal_es', name: 'Kapal Es', emoji: '🚢', price: 525000, capacity: 140, power: 12, tier: 'Profesional' },
    { id: 'kapal_tuna', name: 'Kapal Tuna', emoji: '🚢', price: 800000, capacity: 180, power: 14, tier: 'Samudera' },
    { id: 'kapal_udang', name: 'Kapal Udang', emoji: '🛳️', price: 1200000, capacity: 230, power: 17, tier: 'Samudera' },
    { id: 'kapal_baja', name: 'Kapal Baja', emoji: '🛳️', price: 1800000, capacity: 300, power: 20, tier: 'Elite' },
    { id: 'kapal_sonar', name: 'Kapal Sonar', emoji: '🚢', price: 2750000, capacity: 390, power: 24, tier: 'Elite' },
    { id: 'trawler_merah', name: 'Trawler Merah', emoji: '🚢', price: 4200000, capacity: 520, power: 29, tier: 'Juragan' },
    { id: 'kapal_beku', name: 'Kapal Beku', emoji: '🛳️', price: 6500000, capacity: 700, power: 35, tier: 'Juragan' },
    { id: 'armada_karang', name: 'Armada Karang', emoji: '🚢', price: 10000000, capacity: 950, power: 42, tier: 'Legenda' },
    { id: 'kapal_mutiara', name: 'Kapal Mutiara', emoji: '🛳️', price: 16000000, capacity: 1300, power: 50, tier: 'Legenda' },
    { id: 'leviathan_hunter', name: 'Leviathan Hunter', emoji: '🚢', price: 25000000, capacity: 1800, power: 62, tier: 'Mitos' },
    { id: 'bahtera_dewa_laut', name: 'Bahtera Dewa Laut', emoji: '🛳️', price: 50000000, capacity: 2600, power: 80, tier: 'Dewa Laut' }
]

const NELAYAN_IKAN = [
    { id: 'teri', name: 'Ikan Teri', emoji: '🐟', price: 120, weight: 1 },
    { id: 'kembung', name: 'Ikan Kembung', emoji: '🐟', price: 220, weight: 2 },
    { id: 'lele', name: 'Ikan Lele', emoji: '🐟', price: 300, weight: 3 },
    { id: 'nila', name: 'Ikan Nila', emoji: '🐠', price: 450, weight: 4 },
    { id: 'gurame', name: 'Ikan Gurame', emoji: '🐠', price: 700, weight: 5 },
    { id: 'tongkol', name: 'Ikan Tongkol', emoji: '🐟', price: 1200, weight: 8 },
    { id: 'tuna', name: 'Tuna Sirip Biru', emoji: '🐟', price: 2800, weight: 14 },
    { id: 'lobster', name: 'Lobster Merah', emoji: '🦞', price: 4500, weight: 18 },
    { id: 'mutiara', name: 'Kerang Mutiara', emoji: '🦪', price: 9000, weight: 25 },
    { id: 'ikan_emas_laut', name: 'Ikan Emas Laut', emoji: '🐡', price: 18000, weight: 40 }
]

function getPerahuNelayan(query) {
    const q = String(query || '').trim().toLowerCase()
    if (!q) return null
    const byNo = NELAYAN_PERAHU.find((p, i) => String(i + 1) === q)
    if (byNo) return byNo
    const norm = q.replace(/\s+/g, '_')
    return NELAYAN_PERAHU.find(p => p.id === norm || p.id === q || p.name.toLowerCase() === q || p.name.toLowerCase().includes(q)) || null
}

function ensureNelayan(player) {
    if (!player.nelayan) player.nelayan = {}
    if (!player.nelayan.perahu) player.nelayan.perahu = {}
    if (!player.nelayan.ikan) player.nelayan.ikan = {}
    if (!player.nelayan.storage) player.nelayan.storage = {}
    if (!player.nelayan.activeBoat) player.nelayan.activeBoat = null
    if (!player.nelayan.trip) player.nelayan.trip = null
    return player.nelayan
}

function nelayanLoad(ikanObj) {
    let total = 0
    for (const [id, qty] of Object.entries(ikanObj || {})) {
        const fish = NELAYAN_IKAN.find(f => f.id === id)
        total += (fish?.weight || 1) * (Number(qty) || 0)
    }
    return total
}

function nelayanCatch(power) {
    const result = {}
    const rolls = Math.max(3, Math.min(18, 3 + Math.floor(power / 4)))
    for (let i = 0; i < rolls; i++) {
        const maxIndex = Math.min(NELAYAN_IKAN.length - 1, Math.floor(power / 8) + 3)
        const idx = Math.floor(Math.pow(Math.random(), 1.6) * (maxIndex + 1))
        const fish = NELAYAN_IKAN[idx]
        const qty = 1 + Math.floor(Math.random() * Math.max(2, Math.ceil(power / 10)))
        result[fish.id] = (result[fish.id] || 0) + qty
    }
    return result
}

function formatNelayanIkan(ikanObj) {
    const rows = []
    for (const [id, qty] of Object.entries(ikanObj || {}).filter(([, q]) => q > 0)) {
        const fish = NELAYAN_IKAN.find(f => f.id === id)
        rows.push(`│▣ ${fish?.emoji || '🐟'} ${fish?.name || id} x${qty}`)
    }
    return rows.length ? rows.join('\n') : '│▣ Kosong. Laut aja lebih produktif dari lu.'
}

function addNelayanItems(target, source) {
    for (const [id, qty] of Object.entries(source || {})) {
        target[id] = (target[id] || 0) + qty
    }
}

function sellNelayanItems(player, source) {
    let total = 0
    for (const [id, qty] of Object.entries(source || {})) {
        const fish = NELAYAN_IKAN.find(f => f.id === id)
        total += (fish?.price || 0) * (Number(qty) || 0)
    }
    player.gold = (player.gold || 0) + total
    return total
}

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR HELPERS
// ═══════════════════════════════════════════════════════════

function getHarmoniBar(nilai) {
    const filled = Math.floor(nilai / 10)
    const empty = 10 - filled
    let color = '❤️'
    if (nilai <= 30) color = '🖤'
    else if (nilai <= 60) color = '🧡'
    else if (nilai <= 80) color = '💛'
    else color = '❤️'
    return color + ' [' + '█'.repeat(filled) + '░'.repeat(empty) + '] ' + nilai + '/100'
}

function hitungAnniversary(tanggalNikah) {
    if (!tanggalNikah) return null
    const parts = tanggalNikah.split('/')
    if (parts.length < 3) return null
    const nikah = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]))
    const now = new Date()
    const tahun = now.getFullYear() - nikah.getFullYear()
    const samaBulan = now.getMonth() === nikah.getMonth()
    const samaHari = now.getDate() === nikah.getDate()
    return { tahun, isAnniversary: samaBulan && samaHari && tahun > 0 }
}

function getBakatLabel(bakat) {
    const map = {
        'pejuang':  '⚔️ Pejuang (ATK+5 saat bantu battle)',
        'penyihir': '🔮 Penyihir (MP+ bonus saat rawat)',
        'pedagang': '💰 Pedagang (diskon belanja 5%)',
        'seniman':  '🎨 Seniman (bisa jual karya)',
        'petani':   '🌾 Petani (drop foraging +10%)',
        'tabib':    '💊 Tabib (potion effect +20%)'
    }
    return map[bakat] || bakat
}

function randomBakat() {
    const list = ['pejuang', 'penyihir', 'pedagang', 'seniman', 'petani', 'tabib']
    return list[Math.floor(Math.random() * list.length)]
}

function getJenjangLabel(jenjang) {
    const map = {
        'sd':     '🏫 SD (Sekolah Dasar)',
        'smp':    '🏫 SMP (Sekolah Menengah Pertama)',
        'sma':    '🏫 SMA (Sekolah Menengah Atas)',
        'kuliah': '🎓 Kuliah (Universitas)',
        'lulus':  '✅ Sudah Lulus Semua'
    }
    return map[jenjang] || jenjang
}

function getRumahLabel(tier) {
    const map = {
        'kontrakan':   '🏚️ Kontrakan',
        'rumah_biasa': '🏠 Rumah Biasa',
        'rumah_mewah': '🏡 Rumah Mewah',
        'villa':       '🏰 Villa',
        'istana':      '🏯 Istana'
    }
    return map[tier] || tier
}

function getRumahBonus(tier) {
    const map = {
        'kontrakan':   'Tidak ada bonus.',
        'rumah_biasa': 'Regenerasi HP +5/jam.',
        'rumah_mewah': 'Keharmonisan +2/hari otomatis.',
        'villa':       'Cooldown rawat anak -1 jam.',
        'istana':      'Semua bonus + passive income Rp 1jt/hari.'
    }
    return map[tier] || '-'
}

function tickKeluarga(player, rpgDB) {
    const now = Date.now()
    const HARI_MS = 24 * 60 * 60 * 1000

    // ── Keharmonisan auto naik kalau rumah mewah/villa/istana ──
    if (player.pasangan && player.rumahKeluarga) {
        if (['rumah_mewah', 'villa', 'istana'].includes(player.rumahKeluarga.tier)) {
            const lastTick = player.lastHarmoniTick || 0
            if (now - lastTick >= HARI_MS) {
                player.harmoni = Math.min(100, (player.harmoni || 50) + 2)
                player.lastHarmoniTick = now
            }
        }
    }

    // ── Passive income anak yang sudah lulus & bekerja ──
    const anakList = player.anak || []
    anakList.forEach(a => {
        if (a.pendidikan === 'lulus' && a.bekerja) {
            const lastTransfer = a.lastTransfer || 0
            const jamBerlalu = Math.floor((now - lastTransfer) / (60 * 60 * 1000))
            if (jamBerlalu > 0) {
                const income = jamBerlalu * 5000
                player.gold = (player.gold || 0) + income
                a.lastTransfer = now
                a.totalKiriman = (a.totalKiriman || 0) + income
            }
        }
    })

    // ── Passive income istana ──
    if (player.rumahKeluarga && player.rumahKeluarga.tier === 'istana') {
        const lastIstana = player.lastIstanaTick || 0
        const jamBerlalu = Math.floor((now - lastIstana) / (60 * 60 * 1000))
        if (jamBerlalu > 0) {
            player.gold = (player.gold || 0) + (jamBerlalu * Math.floor(1000000 / 24))
            player.lastIstanaTick = now
        }
    }
}

function getWIBTime() {
    const now = new Date()
    return new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }))
}

function safeReadJSON(path, fallback) {
    try {
        return JSON.parse(fs.readFileSync(path))
    } catch {
        fs.writeFileSync(path, JSON.stringify(fallback, null, 2))
        return fallback
    }
}

function addLimitToBonus(jid, amount) {
    try {
        const bonusDB = safeReadJSON(limitBonusPath, {})
        const today = getWIBTime().toISOString().split('T')[0]
        if (!bonusDB[jid] || bonusDB[jid].date !== today) {
            bonusDB[jid] = { bonus: 0, date: today }
        }
        bonusDB[jid].bonus += amount
        fs.writeFileSync(limitBonusPath, JSON.stringify(bonusDB, null, 2))
    } catch (e) {
        console.error('Error adding limit bonus:', e)
    }
}

// ============================================================
//  FISH TRADE NEGOTIATION — disimpan di rpgDB.fishDeals
//  Key = sellerJid (konsisten, tidak terpengaruh format JID)
//  { sellerJid, buyerJid, fishKey, fishDisp, qty, price, lastOfferBy, expiresAt }
// ============================================================
const FISH_DEAL_TTL = 5 * 60 * 1000 // 5 menit

function getDeals(rpgDB) {
    if (!rpgDB.fishDeals) rpgDB.fishDeals = {}
    return rpgDB.fishDeals
}

function cleanExpiredDeals(rpgDB) {
    const deals = getDeals(rpgDB)
    const now = Date.now()
    for (const key of Object.keys(deals)) {
        if (now > deals[key].expiresAt) delete deals[key]
    }
}

// Cari deal sebagai PEMBELI — scan semua deal, cocokkan buyerJid dengan resolusi format
function findDealAsBuyer(rpgDB, jid) {
    const deals = getDeals(rpgDB)
    const alt = jid.includes('@lid')
        ? jid.replace('@lid', '@s.whatsapp.net')
        : jid.replace('@s.whatsapp.net', '@lid')
    for (const [key, deal] of Object.entries(deals)) {
        if (deal.buyerJid === jid || deal.buyerJid === alt) return { key, deal }
    }
    return null
}

// Cari deal sebagai PENJUAL — key IS sellerJid, tapi tetap cek format alternatif
function findDealAsSeller(rpgDB, jid) {
    const deals = getDeals(rpgDB)
    const alt = jid.includes('@lid')
        ? jid.replace('@lid', '@s.whatsapp.net')
        : jid.replace('@s.whatsapp.net', '@lid')
    if (deals[jid]) return { key: jid, deal: deals[jid] }
    if (deals[alt]) return { key: alt, deal: deals[alt] }
    return null
}

// ══════════════════════════════════════════════════════
//  🏆 TITLE / PRESTASI SYSTEM
// ══════════════════════════════════════════════════════
const TITLE_DATA = {
    'petualang_baru':   { name: '🌱 Petualang Baru',     desc: 'Mulai petualanganmu.',                  cond: p => (p.level||1) >= 1 },
    'pemula_sejati':    { name: '⚔️ Pemula Sejati',      desc: 'Capai Level 5.',                        cond: p => (p.level||1) >= 5 },
    'pejuang':          { name: '🗡️ Pejuang',            desc: 'Capai Level 10.',                       cond: p => (p.level||1) >= 10 },
    'ksatria':          { name: '🛡️ Ksatria',            desc: 'Capai Level 20.',                       cond: p => (p.level||1) >= 20 },
    'legenda':          { name: '👑 Legenda',             desc: 'Capai Level 30.',                       cond: p => (p.level||1) >= 30 },
    'pahlawan_dunia':   { name: '🌟 Pahlawan Dunia',     desc: 'Capai Level 50.',                       cond: p => (p.level||1) >= 50 },
    'dewa_pertempuran': { name: '⚡ Dewa Pertempuran',   desc: 'Capai Level 70.',                       cond: p => (p.level||1) >= 70 },
    'pemburu':          { name: '🏹 Pemburu',             desc: 'Kalahkan 50 monster.',                  cond: p => (p.monstersDefeated||0) >= 50 },
    'jagal':            { name: '🩸 Jagal',               desc: 'Kalahkan 200 monster.',                 cond: p => (p.monstersDefeated||0) >= 200 },
    'pembantai':        { name: '💀 Pembantai',           desc: 'Kalahkan 500 monster.',                 cond: p => (p.monstersDefeated||0) >= 500 },
    'pembasmi':         { name: '☠️ Pembasmi',            desc: 'Kalahkan 1000 monster.',                cond: p => (p.monstersDefeated||0) >= 1000 },
    'kolektor_koin':    { name: '🪙 Kolektor Koin',       desc: 'Punya 1 juta gold.',                    cond: p => (p.gold||0) >= 1000000 },
    'saudagar':         { name: '💰 Saudagar',            desc: 'Punya 10 juta gold.',                   cond: p => (p.gold||0) >= 10000000 },
    'konglomerat':      { name: '🏦 Konglomerat',         desc: 'Punya 100 juta gold.',                  cond: p => (p.gold||0) >= 100000000 },
    'petarung':         { name: '🥊 Petarung',            desc: 'Menang 10 PVP.',                        cond: p => (p.pvpWins||0) >= 10 },
    'gladiator':        { name: '⚔️ Gladiator',          desc: 'Menang 50 PVP.',                        cond: p => (p.pvpWins||0) >= 50 },
    'raja_arena':       { name: '🏆 Raja Arena',          desc: 'Menang 100 PVP.',                       cond: p => (p.pvpWins||0) >= 100 },
    'pemancing':        { name: '🎣 Pemancing',           desc: 'Tangkap 50 ikan.',                      cond: p => (p.fishing?.totalCatch||0) >= 50 },
    'nelayan_handal':   { name: '⚓ Nelayan Handal',      desc: 'Tangkap 200 ikan.',                     cond: p => (p.fishing?.totalCatch||0) >= 200 },
    'master_mancing':   { name: '🐟 Master Mancing',     desc: 'Tangkap 500 ikan.',                     cond: p => (p.fishing?.totalCatch||0) >= 500 },
    'pembunuh_boss':    { name: '💥 Pembunuh Boss',       desc: 'Ikut dan menang 1 Boss Event.',         cond: p => (p.bossKills||0) >= 1 },
    'boss_slayer':      { name: '🔱 Boss Slayer',         desc: 'Menang 5 Boss Event.',                  cond: p => (p.bossKills||0) >= 5 },
    'legend_boss':      { name: '🌌 Legend Slayer',       desc: 'Menang 20 Boss Event.',                 cond: p => (p.bossKills||0) >= 20 },
    'kaya_raya':        { name: '💎 Kaya Raya',           desc: 'Net Worth 1 miliar gold.',              cond: p => ((p.gold||0)+(p.bank?.balance||0)) >= 1000000000 },
    'rajin_kerja':      { name: '🛠️ Rajin Kerja',         desc: 'Kerja/job 50 kali.',                    cond: p => (p.totalJobs||0) >= 50 },
    'workaholic':       { name: '📋 Workaholic',          desc: 'Kerja/job 200 kali.',                   cond: p => (p.totalJobs||0) >= 200 },
}

function checkNewTitles(player) {
    if (!player.titles)        player.titles = []
    if (!player.equippedTitle) player.equippedTitle = null
    const newTitles = []
    for (const [id, t] of Object.entries(TITLE_DATA)) {
        if (!player.titles.includes(id) && t.cond(player)) {
            player.titles.push(id)
            newTitles.push(t.name)
        }
    }
    return newTitles
}

// ══════════════════════════════════════════════════════
//  🔥 BOSS EVENT SYSTEM
// ══════════════════════════════════════════════════════
const BOSS_EVENT_MONSTERS = {
    'naga_event':  { name: '🐉 Naga Purba',          hp: 2500, attack: 55, defense: 20, level: 25, exp: 3000, gold: 2500, drops: { sisik_naga: 1.0, tulang_naga: 0.8, bulu_phoenix: 0.4 } },
    'titan_event': { name: '🌋 Titan Penjaga',        hp: 3500, attack: 65, defense: 25, level: 30, exp: 4500, gold: 4000, drops: { orichalcum: 0.8, mithril: 1.0, permata: 0.6 } },
    'void_event':  { name: '🌀 Void Overlord',        hp: 5000, attack: 80, defense: 30, level: 40, exp: 7000, gold: 6000, drops: { orichalcum: 1.0, mithril: 1.0, bulu_phoenix: 0.8, sisik_naga: 1.0 } },
    'lich_event':  { name: '💀 Lich Dewa Kematian',   hp: 4000, attack: 72, defense: 28, level: 35, exp: 5500, gold: 5000, drops: { orichalcum: 0.9, mithril: 1.0, tulang_naga: 1.0 } },
    'chaos_event': { name: '🌌 Chaos Ancient',        hp: 8000, attack: 100,defense: 40, level: 55, exp: 12000,gold: 10000,drops: { orichalcum: 1.0, mithril: 1.0, bulu_phoenix: 1.0, sisik_naga: 1.0, tulang_naga: 1.0 } }
}
let activeBossEvent = null
const BOSS_EVENT_DURATION_MS = 30 * 60 * 1000

// ============================================================
//  FISHING SYSTEM — DATA TABLES (module scope, accessible everywhere)
// ============================================================
const FISH_DATA = {
    // ══════════════════════════════════════════════════
    //  🟤 COMMON (basePrice: 151–300)
    // ══════════════════════════════════════════════════
    clownfish:              { name: 'Clownfish',              rarity: 'COMMON',     emoji: '🐠', basePrice: 236,      baseExp: 10  },
    azure_damsel:           { name: 'Azure Damsel',           rarity: 'COMMON',     emoji: '🐟', basePrice: 210,      baseExp: 9   },
    pygmy_goby:             { name: 'Pygmy Goby',             rarity: 'COMMON',     emoji: '🐟', basePrice: 166,      baseExp: 7   },
    white_tang:             { name: 'White Tang',             rarity: 'COMMON',     emoji: '🐡', basePrice: 271,      baseExp: 11  },
    herring:                { name: 'Herring',                rarity: 'COMMON',     emoji: '🐟', basePrice: 151,      baseExp: 7   },
    strawberry_dotty:       { name: 'Strawberry Dotty',       rarity: 'COMMON',     emoji: '🐠', basePrice: 298,     baseExp: 12  },
    copperband_butterfly:   { name: 'Copperband Butterfly',   rarity: 'COMMON',     emoji: '🐠', basePrice: 359,     baseExp: 13  },
    watanabei_angelfish:    { name: 'Watanabei Angelfish',    rarity: 'COMMON',     emoji: '🐠', basePrice: 333,     baseExp: 12  },
    blue_chromis:           { name: 'Blue Chromis',           rarity: 'COMMON',     emoji: '🐟', basePrice: 193,      baseExp: 8   },
    green_chromis:          { name: 'Green Chromis',          rarity: 'COMMON',     emoji: '🐟', basePrice: 193,      baseExp: 8   },
    yellowtail_damselfish:  { name: 'Yellowtail Damselfish',  rarity: 'COMMON',     emoji: '🐟', basePrice: 228,      baseExp: 9   },
    coral_fish:             { name: 'Coral Fish',             rarity: 'COMMON',     emoji: '🐠', basePrice: 254,      baseExp: 10  },
    reef_minnow:            { name: 'Reef Minnow',            rarity: 'COMMON',     emoji: '🐟', basePrice: 151,      baseExp: 7   },
    sand_goby:              { name: 'Sand Goby',              rarity: 'COMMON',     emoji: '🐟', basePrice: 166,      baseExp: 7   },
    small_anchovy:          { name: 'Small Anchovy',          rarity: 'COMMON',     emoji: '🐟', basePrice: 151,      baseExp: 6   },
    baby_tuna:              { name: 'Baby Tuna',              rarity: 'COMMON',     emoji: '🐟', basePrice: 271,      baseExp: 11  },
    mini_carp:              { name: 'Mini Carp',              rarity: 'COMMON',     emoji: '🐟', basePrice: 184,      baseExp: 8   },
    glass_fish:             { name: 'Glass Fish',             rarity: 'COMMON',     emoji: '🐟', basePrice: 210,      baseExp: 9   },
    ocean_guppy:            { name: 'Ocean Guppy',            rarity: 'COMMON',     emoji: '🐠', basePrice: 184,      baseExp: 8   },
    tiny_shrimp:            { name: 'Tiny Shrimp',            rarity: 'COMMON',     emoji: '🦐', basePrice: 151,      baseExp: 6   },
    // ── NEW COMMON ──
    reef_minnow2:           { name: 'Reef Minnow',            rarity: 'COMMON',     emoji: '🐟', basePrice: 156,      baseExp: 7   },
    coral_goby:             { name: 'Coral Goby',             rarity: 'COMMON',     emoji: '🐠', basePrice: 173,      baseExp: 7   },
    sea_guppy:              { name: 'Sea Guppy',              rarity: 'COMMON',     emoji: '🐠', basePrice: 166,      baseExp: 7   },
    little_damsel:          { name: 'Little Damsel',          rarity: 'COMMON',     emoji: '🐟', basePrice: 184,      baseExp: 8   },
    pebble_fish:            { name: 'Pebble Fish',            rarity: 'COMMON',     emoji: '🐟', basePrice: 172,      baseExp: 7   },

    // ══════════════════════════════════════════════════
    //  🟢 UNCOMMON (basePrice: 901–1500)
    // ══════════════════════════════════════════════════
    sunfish:                { name: 'Sunfish',                rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1199,     baseExp: 35  },
    gar_fish:               { name: 'Gar Fish',               rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1138,     baseExp: 32  },
    yellow_damselfish:      { name: 'Yellow Damselfish',      rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1050,     baseExp: 30  },
    bandit_angelfish:       { name: 'Bandit Angelfish',       rarity: 'UNCOMMON',   emoji: '🐠', basePrice: 1496,     baseExp: 40  },
    flame_angelfish:        { name: 'Flame Angelfish',        rarity: 'UNCOMMON',   emoji: '🐠', basePrice: 1558,     baseExp: 42  },
    sand_mackerel:          { name: 'Sand Mackerel',          rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1050,     baseExp: 30  },
    blue_triggerfish:       { name: 'Blue Triggerfish',       rarity: 'UNCOMMON',   emoji: '🐡', basePrice: 1348,     baseExp: 38  },
    striped_surgeonfish:    { name: 'Striped Surgeonfish',    rarity: 'UNCOMMON',   emoji: '🐠', basePrice: 1286,     baseExp: 36  },
    needlefish:             { name: 'Needlefish',             rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1138,     baseExp: 32  },
    catfish:                { name: 'Catfish',                rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1260,     baseExp: 36  },
    river_carp:             { name: 'River Carp',             rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1076,     baseExp: 30  },
    silver_bass:            { name: 'Silver Bass',            rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1199,     baseExp: 34  },
    ocean_perch:            { name: 'Ocean Perch',            rarity: 'UNCOMMON',   emoji: '🐠', basePrice: 1321,     baseExp: 37  },
    yellow_snapper:         { name: 'Yellow Snapper',         rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1383,     baseExp: 38  },
    rockfish:               { name: 'Rockfish',               rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1111,     baseExp: 31  },
    sea_bream:              { name: 'Sea Bream',              rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1173,     baseExp: 33  },
    ribbon_fish:            { name: 'Ribbon Fish',            rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1444,     baseExp: 40  },
    flatfish:               { name: 'Flatfish',               rarity: 'UNCOMMON',   emoji: '🐡', basePrice: 1050,     baseExp: 30  },
    pike:                   { name: 'Pike',                   rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1496,     baseExp: 42  },
    barramundi:             { name: 'Barramundi',             rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1558,     baseExp: 43  },
    // ── NEW UNCOMMON ──
    coral_grouper:          { name: 'Coral Grouper',          rarity: 'UNCOMMON',   emoji: '🐠', basePrice: 1444,     baseExp: 40  },
    silver_tang:            { name: 'Silver Tang',            rarity: 'UNCOMMON',   emoji: '🐡', basePrice: 1383,     baseExp: 38  },
    azure_wrasse:           { name: 'Azure Wrasse',           rarity: 'UNCOMMON',   emoji: '🐠', basePrice: 1286,     baseExp: 36  },
    spotted_goby:           { name: 'Spotted Goby',           rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1111,     baseExp: 31  },
    mangrove_snapper:       { name: 'Mangrove Snapper',       rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1470,     baseExp: 41  },

    // ══════════════════════════════════════════════════
    //  🔵 RARE (basePrice: 6038–10000)
    // ══════════════════════════════════════════════════
    barracuda:              { name: 'Barracuda',              rarity: 'RARE',       emoji: '🦈', basePrice: 7525,    baseExp: 100 },
    ballina_angelfish:      { name: 'Ballina Angelfish',      rarity: 'RARE',       emoji: '🐠', basePrice: 6563,    baseExp: 90  },
    korean_angelfish:       { name: 'Korean Angelfish',       rarity: 'RARE',       emoji: '🐠', basePrice: 6913,    baseExp: 92  },
    darwin_clownfish:       { name: 'Darwin Clownfish',       rarity: 'RARE',       emoji: '🐠', basePrice: 6300,    baseExp: 88  },
    frog_fish:              { name: 'Frog Fish',              rarity: 'RARE',       emoji: '🐸', basePrice: 7175,    baseExp: 95  },
    red_koi:                { name: 'Red Koi',                rarity: 'RARE',       emoji: '🐟', basePrice: 9013,    baseExp: 110 },
    marble_tuna:            { name: 'Marble Tuna',            rarity: 'RARE',       emoji: '🐟', basePrice: 10500,    baseExp: 120 },
    bluefin_tuna:           { name: 'Bluefin Tuna',           rarity: 'RARE',       emoji: '🐟', basePrice: 11988,    baseExp: 130 },
    giant_carp:             { name: 'Giant Carp',             rarity: 'RARE',       emoji: '🐟', basePrice: 8400,    baseExp: 108 },
    electric_catfish:       { name: 'Electric Catfish',       rarity: 'RARE',       emoji: '⚡', basePrice: 9625,    baseExp: 115 },
    spotted_ray:            { name: 'Spotted Ray',            rarity: 'RARE',       emoji: '🐟', basePrice: 11375,    baseExp: 125 },
    reef_shark:             { name: 'Reef Shark',             rarity: 'RARE',       emoji: '🦈', basePrice: 4463,    baseExp: 145 },
    moray_eel:              { name: 'Moray Eel',              rarity: 'RARE',       emoji: '🐍', basePrice: 10763,    baseExp: 120 },
    swordfish:              { name: 'Swordfish',              rarity: 'RARE',       emoji: '🗡️', basePrice: 13475,    baseExp: 135 },
    king_salmon:            { name: 'King Salmon',            rarity: 'RARE',       emoji: '🐟', basePrice: 12600,    baseExp: 132 },
    arctic_char:            { name: 'Arctic Char',            rarity: 'RARE',       emoji: '❄️', basePrice: 11113,    baseExp: 122 },
    golden_carp:            { name: 'Golden Carp',            rarity: 'RARE',       emoji: '🟡', basePrice: 5425,    baseExp: 155 },
    tiger_fish:             { name: 'Tiger Fish',             rarity: 'RARE',       emoji: '🐅', basePrice: 16538,    baseExp: 148 },
    peacock_bass:           { name: 'Peacock Bass',           rarity: 'RARE',       emoji: '🐟', basePrice: 14438,    baseExp: 140 },
    stingray:               { name: 'Stingray',               rarity: 'RARE',       emoji: '🐟', basePrice: 15575,    baseExp: 145 },
    // ── NEW RARE ──
    neon_tetra_giant:       { name: 'Neon Tetra Giant',       rarity: 'RARE',       emoji: '🐠', basePrice: 7788,    baseExp: 102 },
    vampire_squid:          { name: 'Vampire Squid',          rarity: 'RARE',       emoji: '🦑', basePrice: 11725,    baseExp: 126 },
    biolume_jellyfish:      { name: 'Biolume Jellyfish',      rarity: 'RARE',       emoji: '🪼', basePrice: 10238,    baseExp: 116 },
    deep_eel:               { name: 'Deep Eel',               rarity: 'RARE',       emoji: '🐍', basePrice: 12338,    baseExp: 131 },
    ancient_carp:           { name: 'Ancient Carp',           rarity: 'RARE',       emoji: '🐟', basePrice: 14088,    baseExp: 138 },

    // ══════════════════════════════════════════════════
    //  🟣 EPIC (basePrice: 18375–13000)
    // ══════════════════════════════════════════════════
    unicorn_tang:           { name: 'Unicorn Tang',           rarity: 'EPIC',       emoji: '🦄', basePrice: 18375,    baseExp: 300 },
    dorhey_tang:            { name: 'Dorhey Tang',            rarity: 'EPIC',       emoji: '🐠', basePrice: 5775,    baseExp: 310 },
    golden_dorado:          { name: 'Golden Dorado',          rarity: 'EPIC',       emoji: '✨', basePrice: 7175,    baseExp: 340 },
    crystal_squid:          { name: 'Crystal Squid',          rarity: 'EPIC',       emoji: '💎', basePrice: 21875,    baseExp: 320 },
    electric_jellyfish:     { name: 'Electric Jellyfish',     rarity: 'EPIC',       emoji: '⚡', basePrice: 6125,    baseExp: 315 },
    lava_pike:              { name: 'Lava Pike',              rarity: 'EPIC',       emoji: '🔥', basePrice: 7963,    baseExp: 350 },
    flame_eel:              { name: 'Flame Eel',              rarity: 'EPIC',       emoji: '🔥', basePrice: 6825,    baseExp: 330 },
    ice_barracuda:          { name: 'Ice Barracuda',          rarity: 'EPIC',       emoji: '❄️', basePrice: 7525,    baseExp: 345 },
    thunder_tuna:           { name: 'Thunder Tuna',           rarity: 'EPIC',       emoji: '⚡', basePrice: 8663,    baseExp: 360 },
    shadow_carp:            { name: 'Shadow Carp',            rarity: 'EPIC',       emoji: '🌑', basePrice: 21875,    baseExp: 320 },
    neon_shark:             { name: 'Neon Shark',             rarity: 'EPIC',       emoji: '🦈', basePrice: 10763,    baseExp: 380 },
    phantom_eel:            { name: 'Phantom Eel',            rarity: 'EPIC',       emoji: '👻', basePrice: 10063,    baseExp: 370 },
    magma_fish:             { name: 'Magma Fish',             rarity: 'EPIC',       emoji: '🌋', basePrice: 8663,    baseExp: 355 },
    frost_pike:             { name: 'Frost Pike',             rarity: 'EPIC',       emoji: '❄️', basePrice: 7175,    baseExp: 338 },
    toxic_catfish:          { name: 'Toxic Catfish',          rarity: 'EPIC',       emoji: '☠️', basePrice: 8313,    baseExp: 352 },
    spirit_fish:            { name: 'Spirit Fish',            rarity: 'EPIC',       emoji: '👻', basePrice: 12600,    baseExp: 395 },
    ember_koi:              { name: 'Ember Koi',              rarity: 'EPIC',       emoji: '🔥', basePrice: 9713,    baseExp: 365 },
    storm_ray:              { name: 'Storm Ray',              rarity: 'EPIC',       emoji: '⛈️', basePrice: 11550,   baseExp: 385 },
    plasma_fish:            { name: 'Plasma Fish',            rarity: 'EPIC',       emoji: '🌀', basePrice: 14438,    baseExp: 405 },
    venom_eel:              { name: 'Venom Eel',              rarity: 'EPIC',       emoji: '🐍', basePrice: 41125,   baseExp: 395 },
    // ── NEW EPIC ──
    void_pike:              { name: 'Void Pike',              rarity: 'EPIC',       emoji: '🕳️', basePrice: 31500,    baseExp: 410 },
    crystal_eel:            { name: 'Crystal Eel',            rarity: 'EPIC',       emoji: '💎', basePrice: 34125,    baseExp: 425 },
    celestial_ray:          { name: 'Celestial Ray',          rarity: 'EPIC',       emoji: '🌠', basePrice: 36750,   baseExp: 440 },
    abyssal_catfish:        { name: 'Abyssal Catfish',        rarity: 'EPIC',       emoji: '🌊', basePrice: 27125,    baseExp: 400 },
    aurora_koi:             { name: 'Aurora Koi',             rarity: 'EPIC',       emoji: '🌌', basePrice: 42875,   baseExp: 460 },

    // ══════════════════════════════════════════════════
    //  🟡 LEGENDARY (basePrice: 79625–60000)
    // ══════════════════════════════════════════════════
    yellowfin_tuna:         { name: 'Yellowfin Tuna',         rarity: 'LEGENDARY',  emoji: '🐟', basePrice: 20125,    baseExp: 800  },
    lined_cardinal:         { name: 'Lined Cardinal',         rarity: 'LEGENDARY',  emoji: '🐠', basePrice: 21875,    baseExp: 820  },
    blue_lobster:           { name: 'Blue Lobster',           rarity: 'LEGENDARY',  emoji: '🦞', basePrice: 23625,    baseExp: 840  },
    abyssal_king:           { name: 'Abyssal King',           rarity: 'LEGENDARY',  emoji: '👑', basePrice: 35875,    baseExp: 920  },
    pink_dolphin:           { name: 'Pink Dolphin',           rarity: 'LEGENDARY',  emoji: '🐬', basePrice: 29750,    baseExp: 880  },
    lake_sturgeon:          { name: 'Lake Sturgeon',          rarity: 'LEGENDARY',  emoji: '🐟', basePrice: 26250,    baseExp: 855  },
    ruby_tuna:              { name: 'Ruby Tuna',              rarity: 'LEGENDARY',  emoji: '🔴', basePrice: 40250,   baseExp: 950  },
    chrome_tuna:            { name: 'Chrome Tuna',            rarity: 'LEGENDARY',  emoji: '⚙️', basePrice: 37625,    baseExp: 935  },
    golden_shark:           { name: 'Golden Shark',           rarity: 'LEGENDARY',  emoji: '🌟', basePrice: 49875,   baseExp: 1000 },
    ice_whale:              { name: 'Ice Whale',              rarity: 'LEGENDARY',  emoji: '❄️', basePrice: 43750,   baseExp: 970  },
    fire_dolphin:           { name: 'Fire Dolphin',           rarity: 'LEGENDARY',  emoji: '🔥', basePrice: 34125,    baseExp: 910  },
    thunder_whale:          { name: 'Thunder Whale',          rarity: 'LEGENDARY',  emoji: '⚡', basePrice: 48125,   baseExp: 990  },
    crystal_lobster:        { name: 'Crystal Lobster',        rarity: 'LEGENDARY',  emoji: '💎', basePrice: 56000,   baseExp: 1020 },
    shadow_dolphin:         { name: 'Shadow Dolphin',         rarity: 'LEGENDARY',  emoji: '🌑', basePrice: 32375,    baseExp: 900  },
    frost_sturgeon:         { name: 'Frost Sturgeon',         rarity: 'LEGENDARY',  emoji: '❄️', basePrice: 28875,    baseExp: 870  },
    ember_tuna:             { name: 'Ember Tuna',             rarity: 'LEGENDARY',  emoji: '🔥', basePrice: 36750,    baseExp: 928  },
    toxic_whale:            { name: 'Toxic Whale',            rarity: 'LEGENDARY',  emoji: '☠️', basePrice: 42000,   baseExp: 960  },
    spirit_dolphin:         { name: 'Spirit Dolphin',         rarity: 'LEGENDARY',  emoji: '👻', basePrice: 51625,   baseExp: 1010 },
    plasma_shark:           { name: 'Plasma Shark',           rarity: 'LEGENDARY',  emoji: '🌀', basePrice: 60375,   baseExp: 1050 },
    venom_whale:            { name: 'Venom Whale',            rarity: 'LEGENDARY',  emoji: '🐍', basePrice: 46375,   baseExp: 975  },
    // ── NEW LEGENDARY ──
    jade_dragon_fish:       { name: 'Jade Dragon Fish',       rarity: 'LEGENDARY',  emoji: '🐲', basePrice: 63875,   baseExp: 1060 },
    lunar_shark:            { name: 'Lunar Shark',            rarity: 'LEGENDARY',  emoji: '🌕', basePrice: 54250,   baseExp: 1015 },
    solar_tuna:             { name: 'Solar Tuna',             rarity: 'LEGENDARY',  emoji: '☀️', basePrice: 57750,   baseExp: 1035 },
    storm_whale:            { name: 'Storm Whale',            rarity: 'LEGENDARY',  emoji: '⛈️', basePrice: 51625,   baseExp: 1005 },
    cosmic_lobster:         { name: 'Cosmic Lobster',         rarity: 'LEGENDARY',  emoji: '🦞', basePrice: 70000,   baseExp: 1080 },

    // ══════════════════════════════════════════════════
    //  🔴 MYTHIC (basePrice: 350000–400000)
    // ══════════════════════════════════════════════════
    dotted_stingray:        { name: 'Dotted Stingray',        rarity: 'MYTHIC',     emoji: '🐟', basePrice: 70000,   baseExp: 3000 },
    manta_ray:              { name: 'Manta Ray',              rarity: 'MYTHIC',     emoji: '🐟', basePrice: 79625,   baseExp: 3200 },
    hammerhead_shark:       { name: 'Hammerhead Shark',       rarity: 'MYTHIC',     emoji: '🦈', basePrice: 88375,   baseExp: 3500 },
    great_white_shark:      { name: 'Great White Shark',      rarity: 'MYTHIC',     emoji: '🦈', basePrice: 105875,   baseExp: 3800 },
    oarfish:                { name: 'Oarfish',                rarity: 'MYTHIC',     emoji: '🐟', basePrice: 132125,   baseExp: 4200 },
    colossal_squid:         { name: 'Colossal Squid',         rarity: 'MYTHIC',     emoji: '🦑', basePrice: 123375,   baseExp: 4000 },
    voltfish:               { name: 'Voltfish',               rarity: 'MYTHIC',     emoji: '⚡', basePrice: 97125,   baseExp: 3600 },
    blueflame_ray:          { name: 'Blueflame Ray',          rarity: 'MYTHIC',     emoji: '🔵', basePrice: 114625,   baseExp: 3900 },
    abyss_shark:            { name: 'Abyss Shark',            rarity: 'MYTHIC',     emoji: '🦈', basePrice: 140875,   baseExp: 4400 },
    phantom_whale:          { name: 'Phantom Whale',          rarity: 'MYTHIC',     emoji: '👻', basePrice: 158375,   baseExp: 4800 },
    shadow_leviathan:       { name: 'Shadow Leviathan',       rarity: 'MYTHIC',     emoji: '🌑', basePrice: 175000,   baseExp: 5000 },
    inferno_shark:          { name: 'Inferno Shark',          rarity: 'MYTHIC',     emoji: '🔥', basePrice: 149625,   baseExp: 4600 },
    frost_leviathan:        { name: 'Frost Leviathan',        rarity: 'MYTHIC',     emoji: '❄️', basePrice: 192500,   baseExp: 5200 },
    thunder_leviathan:      { name: 'Thunder Leviathan',      rarity: 'MYTHIC',     emoji: '⚡', basePrice: 210000,   baseExp: 5500 },
    toxic_kraken:           { name: 'Toxic Kraken',           rarity: 'MYTHIC',     emoji: '☠️', basePrice: 227500,   baseExp: 5800 },
    spirit_leviathan:       { name: 'Spirit Leviathan',       rarity: 'MYTHIC',     emoji: '👻', basePrice: 262500,   baseExp: 6200 },
    plasma_leviathan:       { name: 'Plasma Leviathan',       rarity: 'MYTHIC',     emoji: '🌀', basePrice: 280000,   baseExp: 6500 },
    venom_kraken:           { name: 'Venom Kraken',           rarity: 'MYTHIC',     emoji: '🐍', basePrice: 245000,   baseExp: 6000 },
    crystal_leviathan:      { name: 'Crystal Leviathan',      rarity: 'MYTHIC',     emoji: '💎', basePrice: 306250,   baseExp: 6800 },
    void_shark:             { name: 'Void Shark',             rarity: 'MYTHIC',     emoji: '🕳️', basePrice: 350000,   baseExp: 7200 },
    // ── NEW MYTHIC ──
    nebula_leviathan:       { name: 'Nebula Leviathan',       rarity: 'MYTHIC',     emoji: '🌌', basePrice: 385000,   baseExp: 7600 },
    chaos_kraken:           { name: 'Chaos Kraken',           rarity: 'MYTHIC',     emoji: '🌀', basePrice: 315000,   baseExp: 6900 },
    divine_ray:             { name: 'Divine Ray',             rarity: 'MYTHIC',     emoji: '✨', basePrice: 420000,   baseExp: 8000 },
    omega_shark:            { name: 'Omega Shark',            rarity: 'MYTHIC',     emoji: '🔱', basePrice: 437500,  baseExp: 8400 },
    aurora_leviathan:       { name: 'Aurora Leviathan',       rarity: 'MYTHIC',     emoji: '🌠', basePrice: 481250,  baseExp: 9000 },

    // ══════════════════════════════════════════════════
    //  ⚫ SECRET / ENDGAME (basePrice: 2800000–5000000)
    // ══════════════════════════════════════════════════
    orca:                   { name: 'Orca',                   rarity: 'SECRET',     emoji: '🐳', basePrice: 420000,    baseExp: 12000 },
    crystal_crab:           { name: 'Crystal Crab',           rarity: 'SECRET',     emoji: '💎', basePrice: 472500,    baseExp: 13000 },
    lochness_monster:       { name: 'Lochness Monster',       rarity: 'SECRET',     emoji: '🦕', basePrice: 630000,    baseExp: 16000 },
    armor_shark:            { name: 'Armor Shark',            rarity: 'SECRET',     emoji: '🦈', basePrice: 525000,    baseExp: 14000 },
    eerie_shark:            { name: 'Eerie Shark',            rarity: 'SECRET',     emoji: '👁️', basePrice: 577500,    baseExp: 15000 },
    monster_shark:          { name: 'Monster Shark',          rarity: 'SECRET',     emoji: '🦈', basePrice: 682500,    baseExp: 17000 },
    great_whale:            { name: 'Great Whale',            rarity: 'SECRET',     emoji: '🐋', basePrice: 787500,   baseExp: 18500 },
    frostborn_shark:        { name: 'Frostborn Shark',        rarity: 'SECRET',     emoji: '❄️', basePrice: 735000,   baseExp: 17800 },
    worm_fish:              { name: 'Worm Fish',              rarity: 'SECRET',     emoji: '🪱', basePrice: 437500,    baseExp: 12500 },
    ghost_shark:            { name: 'Ghost Shark',            rarity: 'SECRET',     emoji: '👻', basePrice: 840000,   baseExp: 19000 },
    megalogon:              { name: 'Megalogon',              rarity: 'SECRET',     emoji: '🦈', basePrice: 1312500,   baseExp: 25000 },
    skeleton_narwhal:       { name: 'Skeleton Narwhal',       rarity: 'SECRET',     emoji: '🦴', basePrice: 1050000,   baseExp: 22000 },
    queen_crab:             { name: 'Queen Crab',             rarity: 'SECRET',     emoji: '🦀', basePrice: 945000,   baseExp: 20500 },
    leviathan_king:         { name: 'Leviathan King',         rarity: 'SECRET',     emoji: '👑', basePrice: 1837500,   baseExp: 32000 },
    abyss_god:              { name: 'Abyss God',              rarity: 'SECRET',     emoji: '👁️', basePrice: 2625000,   baseExp: 42000 },
    phantom_kraken:         { name: 'Phantom Kraken',         rarity: 'SECRET',     emoji: '👻', basePrice: 2100000,   baseExp: 36000 },
    void_leviathan:         { name: 'Void Leviathan',         rarity: 'SECRET',     emoji: '🕳️', basePrice: 3150000,   baseExp: 50000 },
    chaos_shark:            { name: 'Chaos Shark',            rarity: 'SECRET',     emoji: '🌀', basePrice: 2362500,   baseExp: 38000 },
    eternal_whale:          { name: 'Eternal Whale',          rarity: 'SECRET',     emoji: '♾️', basePrice: 3937500,   baseExp: 60000 },
    celestial_fish:         { name: 'Celestial Fish',         rarity: 'SECRET',     emoji: '🌠', basePrice: 5250000,  baseExp: 80000 },
    // ── NEW SECRET (MAX 2.000.000) ──
    abyss_emperor:          { name: 'Abyss Emperor',          rarity: 'SECRET',     emoji: '👑', basePrice: 6300000,  baseExp: 90000 },
    void_dragon:            { name: 'Void Dragon',            rarity: 'SECRET',     emoji: '🐉', basePrice: 8400000, baseExp: 110000 },
    cosmos_whale:           { name: 'Cosmos Whale',           rarity: 'SECRET',     emoji: '🌌', basePrice: 10500000, baseExp: 130000 },
    omega_leviathan:        { name: 'Omega Leviathan',        rarity: 'SECRET',     emoji: '🔱', basePrice: 12600000, baseExp: 160000 },
    god_fish:               { name: 'God Fish',               rarity: 'SECRET',     emoji: '✨', basePrice: 14000000, baseExp: 200000 },

    // ══════════════════════════════════════════════════
    //  🗑️ COMMON — TRASH / JUNK (basePrice: 0–50)
    // ══════════════════════════════════════════════════
    boot:                   { name: 'Boot',                   rarity: 'COMMON',     emoji: '👟', basePrice: 11,        baseExp: 1   },
    seaweed:                { name: 'Seaweed',                rarity: 'COMMON',     emoji: '🌿', basePrice: 19,       baseExp: 1   },
    rusty_fish:             { name: 'Rusty Fish',             rarity: 'COMMON',     emoji: '🐟', basePrice: 40,       baseExp: 2   },

    // ══════════════════════════════════════════════════
    //  🟤 COMMON — BASIC (basePrice: 121–150)
    // ══════════════════════════════════════════════════
    minnow:                 { name: 'Minnow',                 rarity: 'COMMON',     emoji: '🐟', basePrice: 130,       baseExp: 5   },
    tiny_catfish:           { name: 'Tiny Catfish',           rarity: 'COMMON',     emoji: '🐟', basePrice: 140,       baseExp: 6   },
    small_carp:             { name: 'Small Carp',             rarity: 'COMMON',     emoji: '🐟', basePrice: 159,       baseExp: 7   },

    // ══════════════════════════════════════════════════
    //  🟢 UNCOMMON — BASIC (basePrice: 901–900)
    // ══════════════════════════════════════════════════
    carp:                   { name: 'Carp',                   rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 963,      baseExp: 28  },
    bass:                   { name: 'Bass',                   rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1024,      baseExp: 29  },
    tilapia:                { name: 'Tilapia',                rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 989,      baseExp: 28  },
    mackerel:               { name: 'Mackerel',               rarity: 'UNCOMMON',   emoji: '🐟', basePrice: 1076,      baseExp: 31  },

    // ══════════════════════════════════════════════════
    //  🔵 RARE — BASIC (basePrice: 6038–8000)
    // ══════════════════════════════════════════════════
    salmon:                 { name: 'Salmon',                 rarity: 'RARE',       emoji: '🐟', basePrice: 7788,     baseExp: 102 },
    tuna:                   { name: 'Tuna',                   rarity: 'RARE',       emoji: '🐟', basePrice: 9013,     baseExp: 112 },
    red_snapper:            { name: 'Red Snapper',            rarity: 'RARE',       emoji: '🐟', basePrice: 10238,     baseExp: 118 },
    pufferfish:             { name: 'Pufferfish',             rarity: 'RARE',       emoji: '🐡', basePrice: 11988,     baseExp: 128 },

    // ══════════════════════════════════════════════════
    //  🟣 EPIC — BASIC (basePrice: 18375–20000)
    // ══════════════════════════════════════════════════
    giant_catfish:          { name: 'Giant Catfish',          rarity: 'EPIC',       emoji: '🐟', basePrice: 20125,     baseExp: 308 },
    electric_eel:           { name: 'Electric Eel',           rarity: 'EPIC',       emoji: '⚡', basePrice: 25375,    baseExp: 335 },

    // ══════════════════════════════════════════════════
    //  🟡 LEGENDARY — BASIC (basePrice: 29750–40000)
    // ══════════════════════════════════════════════════
    shark:                  { name: 'Shark',                  rarity: 'LEGENDARY',  emoji: '🦈', basePrice: 32375,    baseExp: 895 },
    golden_tuna:            { name: 'Golden Tuna',            rarity: 'LEGENDARY',  emoji: '🌟', basePrice: 46375,    baseExp: 980 },
    mythic_carp:            { name: 'Mythic Carp',            rarity: 'LEGENDARY',  emoji: '🐟', basePrice: 56000,    baseExp: 1025 },

    // ══════════════════════════════════════════════════
    //  ⚫ SECRET — ENDGAME
    // ══════════════════════════════════════════════════
    dragon_fish:            { name: 'Dragon Fish',            rarity: 'SECRET',     emoji: '🐉', basePrice: 1575000,   baseExp: 28000 },
    phantom_shark:          { name: 'Phantom Shark',          rarity: 'SECRET',     emoji: '👻', basePrice: 892500,   baseExp: 19500 },
    leviathan:              { name: 'Leviathan',              rarity: 'SECRET',     emoji: '🌊', basePrice: 1680000,   baseExp: 30000 },
    void_fish:              { name: 'Void Fish',              rarity: 'SECRET',     emoji: '🕳️', basePrice: 1050000,   baseExp: 21000 },
    kraken:                 { name: 'Kraken',                 rarity: 'SECRET',     emoji: '🦑', basePrice: 2187500,  baseExp: 40000 },
}

const MUTATION_DATA = {
    // ══════════════════════════════════════════════════
    //  🟤 COMMON MUTATIONS (BASIC tier)
    // ══════════════════════════════════════════════════
    stone:          { name: 'Stone',          tier: 'BASIC',     emoji: '🪨', multiplier: 1.20,  desc: '+20% harga' },
    albino:         { name: 'Albino',         tier: 'BASIC',     emoji: '🤍', multiplier: 1.40,  desc: '+40% harga' },
    big:            { name: 'Big',            tier: 'BASIC',     emoji: '🔷', multiplier: 1.20,  desc: '1.2x ukuran' },
    huge:           { name: 'Huge',           tier: 'BASIC',     emoji: '⬛', multiplier: 1.50,  desc: '1.5x ukuran' },
    frozen:         { name: 'Frozen',         tier: 'BASIC',     emoji: '🧊', multiplier: 1.60,  desc: 'Membeku sempurna' },
    festive:        { name: 'Festive',        tier: 'BASIC',     emoji: '🎄', multiplier: 1.45,  desc: 'Edisi perayaan' },

    // ══════════════════════════════════════════════════
    //  🟢 UNCOMMON – RARE MUTATIONS (ADVANCED tier)
    // ══════════════════════════════════════════════════
    ghost:          { name: 'Ghost',          tier: 'ADVANCED',  emoji: '👻', multiplier: 2.50,  desc: '+150% harga' },
    shiny_low:      { name: 'Shiny',          tier: 'ADVANCED',  emoji: '✨', multiplier: 1.80,  desc: '1.8x harga' },
    shiny_high:     { name: 'Shiny+',         tier: 'ADVANCED',  emoji: '💫', multiplier: 4.00,  desc: '4x harga' },
    gold:           { name: 'Gold',           tier: 'ADVANCED',  emoji: '🌟', multiplier: 10.00, desc: '10x harga' },
    electric:       { name: 'Electric',       tier: 'ADVANCED',  emoji: '⚡', multiplier: 6.00,  desc: '6x harga' },
    dark:           { name: 'Dark',           tier: 'ADVANCED',  emoji: '🌑', multiplier: 3.50,  desc: 'Aura kegelapan' },

    // ══════════════════════════════════════════════════
    //  🔵 HIGH MUTATIONS (RARE tier)
    // ══════════════════════════════════════════════════
    radioactive:    { name: 'Radioactive',    tier: 'RARE',      emoji: '☢️', multiplier: 3.00,  desc: '+200% harga' },
    lightning:      { name: 'Lightning',      tier: 'RARE',      emoji: '🌩️', multiplier: 3.20,  desc: '+220% harga' },
    fairy:          { name: 'Fairy',          tier: 'RARE',      emoji: '🧚', multiplier: 2.80,  desc: '+180% harga' },
    holographic:    { name: 'Holographic',    tier: 'RARE',      emoji: '🌈', multiplier: 4.50,  desc: 'Visual hologram' },
    color_burn:     { name: 'Color Burn',     tier: 'RARE',      emoji: '🔥', multiplier: 5.00,  desc: 'Warna terbakar' },

    // ══════════════════════════════════════════════════
    //  🟣 ENDGAME MUTATIONS (LEGENDARY tier)
    // ══════════════════════════════════════════════════
    midnight:       { name: 'Midnight',       tier: 'LEGENDARY', emoji: '🌙', multiplier: 3.80,  desc: '+280% harga' },
    gemstone:       { name: 'Gemstone',       tier: 'LEGENDARY', emoji: '💎', multiplier: 3.80,  desc: '+280% harga' },
    galaxy:         { name: 'Galaxy',         tier: 'LEGENDARY', emoji: '🌌', multiplier: 5.50,  desc: '+450% harga' },
    rainbow:        { name: 'Rainbow',        tier: 'LEGENDARY', emoji: '🌈', multiplier: 75.00, desc: '50x–100x harga' },
    translucent:    { name: 'Translucent',    tier: 'LEGENDARY', emoji: '🫧', multiplier: 6.00,  desc: 'Transparan langka' },

    // ══════════════════════════════════════════════════
    //  🔴 EVENT / SPECIAL MUTATIONS (GODLY tier)
    // ══════════════════════════════════════════════════
    leviathan_rage: { name: 'Leviathan Rage', tier: 'GODLY',     emoji: '🌊', multiplier: 20.00, desc: 'Amukan Leviathan' },
    pumpkin:        { name: 'Pumpkin',        tier: 'GODLY',     emoji: '🎃', multiplier: 12.00, desc: 'Event Halloween' },
    christmas:      { name: 'Christmas',      tier: 'GODLY',     emoji: '🎅', multiplier: 15.00, desc: 'Event Christmas' },
    crystalized:    { name: 'Crystalized',    tier: 'GODLY',     emoji: '🔮', multiplier: 25.00, desc: 'Mengkristal total' }
}


const ROD_DATA = {
    starter_rod:      { name: 'Starter Rod',      tier: 'C',   emoji: '🎣', price: 500,        boost: 0,   desc: 'Joran pemula, buat yang baru mulai.' },
    lava_rod:         { name: 'Lava Rod',          tier: 'C',   emoji: '🔴', price: 2500,       boost: 5,   desc: 'Joran lava, sedikit lebih kuat.' },
    lucky_rod:        { name: 'Lucky Rod',         tier: 'B',   emoji: '🍀', price: 10000,      boost: 12,  desc: 'Hoki-nya lumayan, ikan rare lebih mudah.' },
    midnight_rod:     { name: 'Midnight Rod',      tier: 'B',   emoji: '🌙', price: 25000,      boost: 18,  desc: 'Cocok buat mancing tengah malam.' },
    steampunk_rod:    { name: 'Steampunk Rod',     tier: 'A',   emoji: '⚙️', price: 80000,      boost: 28,  desc: 'Teknologi canggih, ikan epic sering muncul.' },
    hazmat_rod:       { name: 'Hazmat Rod',        tier: 'A',   emoji: '☣️', price: 150000,     boost: 35,  desc: 'Bisa menarik ikan beracun dan langka.' },
    ares_rod:         { name: 'Ares Rod',          tier: 'S',   emoji: '⚔️', price: 500000,     boost: 50,  desc: 'Joran perang, legendary lebih sering.' },
    ghostfinn_rod:    { name: 'Ghostfinn Rod',     tier: 'S',   emoji: '👻', price: 800000,     boost: 60,  desc: 'Bisa menarik ikan hantu dan phantom.' },
    element_rod:      { name: 'Element Rod',       tier: 'S+',  emoji: '🌪️', price: 3000000,    boost: 75,  desc: 'Elemental power, mythic lebih mudah.' },
    diamond_rod:      { name: 'Diamond Rod',       tier: 'S+',  emoji: '💎', price: 5000000,    boost: 90,  desc: 'TERKUAT! Ikan mythic dan secret bisa muncul.' },
    // ── NEW PREMIUM RODS ──
    celestial_rod:    { name: 'Celestial Rod',     tier: 'SS',  emoji: '🌠', price: 25000000,   boost: 105, desc: 'Joran surgawi, mutasi Godly lebih sering.' },
    abyssal_rod:      { name: 'Abyssal Rod',       tier: 'SS',  emoji: '🌊', price: 50000000,   boost: 115, desc: 'Dari kedalaman samudra, Leviathan terjangkau.' },
    god_rod:          { name: 'God Rod',           tier: 'SSS', emoji: '⚡', price: 150000000,  boost: 130, desc: 'Joran dewa, Kraken & Dragon Fish pasti muncul.' },
    eternal_rod:      { name: 'Eternal Rod',       tier: 'SSS', emoji: '🔱', price: 500000000,  boost: 150, desc: 'ULTIMATE ROD! Semua ikan bisa tertangkap.' }
}

const BAIT_DATA = {
    basic_bait:       { name: 'Basic Bait',       tier: 'B',   emoji: '🪱', price: 200,        mutBoost: 0,   desc: 'Umpan biasa buat sehari-hari.' },
    lava_bait:        { name: 'Lava Bait',        tier: 'B',   emoji: '🔥', price: 800,        mutBoost: 5,   desc: 'Meningkatkan sedikit peluang mutasi.' },
    midnight_bait:    { name: 'Midnight Bait',    tier: 'A',   emoji: '🌙', price: 3000,       mutBoost: 12,  desc: 'Umpan malam, mutasi basic lebih mudah.' },
    chroma_bait:      { name: 'Chroma Bait',      tier: 'S',   emoji: '🌈', price: 20000,      mutBoost: 25,  desc: 'Warna-warni, mutasi advanced teratribusi.' },
    corrupt_bait:     { name: 'Corrupt Bait',     tier: 'S',   emoji: '💀', price: 50000,      mutBoost: 35,  desc: 'Corrupted energy, rare mutation naik.' },
    aether_bait:      { name: 'Aether Bait',      tier: 'S+',  emoji: '🌠', price: 200000,     mutBoost: 50,  desc: 'Energi alam semesta, legendary mutation.' },
    singularity_bait: { name: 'Singularity Bait', tier: 'S+',  emoji: '🕳️', price: 500000,     mutBoost: 70,  desc: 'BEST BAIT! Godly mutation bisa muncul.' },
    // ── NEW PREMIUM BAITS ──
    nebula_bait:      { name: 'Nebula Bait',      tier: 'SS',  emoji: '🌌', price: 2000000,    mutBoost: 85,  desc: 'Energi nebula, Celestial mutation lebih sering.' },
    void_bait:        { name: 'Void Bait',        tier: 'SS',  emoji: '🕳️', price: 5000000,    mutBoost: 95,  desc: 'Dari kegelapan void, mutasi tertinggi.' },
    divine_bait:      { name: 'Divine Bait',      tier: 'SSS', emoji: '✨', price: 20000000,   mutBoost: 110, desc: 'Umpan ilahi! Semua mutasi Godly bisa muncul.' },
    omega_bait:       { name: 'Omega Bait',       tier: 'SSS', emoji: '🔱', price: 100000000,  mutBoost: 130, desc: 'ULTIMATE BAIT! Max mutasi, max ikan langka.' }
}

function pickFishRarity(rodBoost) {
    const b = Math.min(rodBoost, 150)
    const r = Math.random() * 10000

    // ══════════════════════════════════════════════════════
    //  SISTEM RARITY — Hard-lock berdasarkan tier pancingan
    //
    //  Rod C  (boost 0–5)  : COMMON & UNCOMMON saja
    //  Rod B  (boost 12–18): + RARE (sangat jarang ~3%)
    //  Rod A  (boost 28–35): + EPIC (jarang ~5%)
    //  Rod S  (boost 50–60): + LEGENDARY (~4%)
    //  Rod S+ (boost 75–90): + MYTHIC (~3%)
    //  Rod SS (boost 105)  : + SECRET rendah (~2%)
    //  Rod SSS(boost 130+) : + SECRET tinggi (~4%)
    // ══════════════════════════════════════════════════════

    // Hard cap: jika boost terlalu rendah, kembalikan paksa ke bawah
    // Rod C: max UNCOMMON — sudah dikurangi rate-nya
    if (b < 10) {
        return r < 7000 ? 'COMMON' : 'UNCOMMON'
    }
    // Rod B: bisa RARE tapi sangat langka (~1.5%)
    if (b < 25) {
        if (r < 5500) return 'COMMON'
        if (r < 8500) return 'UNCOMMON'
        return 'RARE' // ~1.5%
    }
    // Rod A: bisa EPIC tapi jarang (~3%), LEGENDARY tidak bisa
    if (b < 45) {
        if (r < 5000) return 'COMMON'
        if (r < 7500) return 'UNCOMMON'
        if (r < 9200) return 'RARE'
        if (r < 9700) return 'EPIC'
        return 'EPIC' // max Rod A ~3%
    }
    // Rod S: bisa LEGENDARY tapi jarang (~2.5%), MYTHIC tidak bisa
    if (b < 70) {
        if (r < 4500) return 'COMMON'
        if (r < 6800) return 'UNCOMMON'
        if (r < 8400) return 'RARE'
        if (r < 9500) return 'EPIC'
        if (r < 9750) return 'LEGENDARY'
        return 'LEGENDARY' // max Rod S ~2.5%
    }
    // Rod S+: bisa MYTHIC tapi langka (~2%), SECRET tidak bisa
    if (b < 100) {
        if (r < 4000) return 'COMMON'
        if (r < 6200) return 'UNCOMMON'
        if (r < 7900) return 'RARE'
        if (r < 9100) return 'EPIC'
        if (r < 9700) return 'LEGENDARY'
        if (r < 9800) return 'MYTHIC'
        return 'MYTHIC' // max Rod S+ ~2%
    }
    // Rod SS: bisa SECRET tapi sangat langka (~2%)
    if (b < 125) {
        if (r < 2200) return 'COMMON'
        if (r < 4200) return 'UNCOMMON'
        if (r < 6200) return 'RARE'
        if (r < 7900) return 'EPIC'
        if (r < 8900) return 'LEGENDARY'
        if (r < 9500) return 'MYTHIC'
        if (r < 9800) return 'SECRET'
        return 'SECRET'
    }
    // Rod SSS (boost 125–150): semua bisa, SECRET lebih sering (~6%)
    if (r < 1800) return 'COMMON'
    if (r < 3800) return 'UNCOMMON'
    if (r < 5800) return 'RARE'
    if (r < 7500) return 'EPIC'
    if (r < 8600) return 'LEGENDARY'
    if (r < 9300) return 'MYTHIC'
    return 'SECRET'
}

function pickRandomFishByRarity(rarity) {
    const pool = Object.entries(FISH_DATA).filter(([,f]) => f.rarity === rarity)
    if (!pool.length) return null
    const [id, data] = pool[Math.floor(Math.random() * pool.length)]
    return { id, ...data }
}

function rollMutation(mutBoost) {
    const b = Math.min(mutBoost, 130)
    const mutChance = 150 + b * 5
    if (Math.random() * 1000 > mutChance) return null
    const tier_r = Math.random() * 1000
    let tierKey
    if (tier_r < 400)                tierKey = 'BASIC'
    else if (tier_r < 680)           tierKey = 'ADVANCED'
    else if (tier_r < 860)           tierKey = 'RARE'
    else if (tier_r < 960 + b * 0.3) tierKey = 'LEGENDARY'
    else                             tierKey = 'GODLY'
    const pool = Object.entries(MUTATION_DATA).filter(([,m]) => m.tier === tierKey)
    if (!pool.length) return null
    const [mid, mdata] = pool[Math.floor(Math.random() * pool.length)]
    return { id: mid, ...mdata }
}

function calcFishPrice(fish, mutation) {
    return mutation ? Math.floor(fish.basePrice * mutation.multiplier) : fish.basePrice
}

function getFishInventoryKey(fishId, mutationId) {
    return mutationId ? `fish_${fishId}_${mutationId}` : `fish_${fishId}`
}

function getFishDisplayName(fish, mutation) {
    return mutation ? `${mutation.emoji} ${mutation.name} ${fish.emoji} ${fish.name}` : `${fish.emoji} ${fish.name}`
}

function getRarityEmoji(rarity) {
    const map = {
        COMMON:    '🟤',
        UNCOMMON:  '🟢',
        RARE:      '🔵',
        EPIC:      '🟣',
        LEGENDARY: '🟡',
        MYTHIC:    '🔴',
        SECRET:    '⚫'
    }
    return map[rarity] || '⬜'
}

function parseFishKey(key) {
    const stripped = key.replace('fish_', '')
    const parts = stripped.split('_')
    let fishId = null, mutationId = null
    for (let i = parts.length; i >= 1; i--) {
        const tryFish = parts.slice(0, i).join('_')
        const tryMut  = parts.slice(i).join('_')
        if (FISH_DATA[tryFish]) { fishId = tryFish; mutationId = tryMut || null; break }
    }
    return { fishId, mutationId }
}

module.exports = async (m, { alip, command, args, isCreator, isPremium, Reply, text, prefix } = {}) => {
    try {
        // Safety guard: beberapa loader bot kadang tidak mengirim args/text/mentionedJid.
        // Kalau ini kosong lalu kode baca [0], bot langsung meledak. Jadi dinormalisasi dulu.
        m = m || {}
        m.mentionedJid = Array.isArray(m.mentionedJid) ? m.mentionedJid : []
        args = Array.isArray(args) ? args : []
        text = typeof text === 'string' ? text : args.join(' ')
        command = String(command || '').toLowerCase()
        prefix = prefix || '.'
        Reply = typeof Reply === 'function' ? Reply : async () => {}
        const isRegistered = (jid) => {
            try {
                if (!fs.existsSync(userDBPath)) return false
                const userDB = JSON.parse(fs.readFileSync(userDBPath))
                return userDB.some(user => {
                    const userJid = user.jid?.replace('@lid', '@s.whatsapp.net')
                    const targetJid = jid.replace('@lid', '@s.whatsapp.net')
                    return userJid === targetJid
                })
            } catch {
                return false
            }
        }

        if (!global.mess) global.mess = { prem: '❌ Fitur ini khusus premium!' }

        const checkLimit = () => {
            if (isCreator || isPremium) return false
            const user = global.db?.users?.[m.sender]
            if (!user) return false
            const today = new Date().toDateString()
            if (user.lastLimit !== today) {
                user.limitUsed = 0
                user.lastLimit = today
            }
            return user.limitUsed >= 15
        }

        let rpgDB = {}
        try {
            rpgDB = JSON.parse(fs.readFileSync(rpgDBPath))
        } catch (e) {
            rpgDB = { players: {} }
        }
        if (!rpgDB.players) rpgDB.players = {}
        const _minimarketSynced = ensureMinimarketInRPG(rpgDB)
        if (_minimarketSynced) fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

        // ── Normalisasi JID (@lid ↔ @s.whatsapp.net) ─────────────────
        function resolvePlayerJid(rawJid) {
            if (!rawJid) return rawJid
            // Cek langsung
            if (rpgDB.players[rawJid]) return rawJid
            // Cek format alternatif
            let alt
            if (rawJid.endsWith('@lid')) {
                alt = rawJid.replace('@lid', '@s.whatsapp.net')
            } else if (rawJid.endsWith('@s.whatsapp.net')) {
                alt = rawJid.replace('@s.whatsapp.net', '@lid')
            }
            if (alt && rpgDB.players[alt]) return alt
            // Fallback: selalu gunakan @s.whatsapp.net sebagai format standar
            if (rawJid.endsWith('@lid')) {
                return rawJid.replace('@lid', '@s.whatsapp.net')
            }
            return rawJid
        }
        // Normalize semua proposal keys ke @s.whatsapp.net saat load
        if (rpgDB.proposals) {
            const normalizedProposals = {}
            for (const [key, val] of Object.entries(rpgDB.proposals)) {
                const normKey = key.endsWith('@lid') ? key.replace('@lid', '@s.whatsapp.net') : key
                const normFrom = val.from && val.from.endsWith('@lid') ? val.from.replace('@lid', '@s.whatsapp.net') : val.from
                normalizedProposals[normKey] = { ...val, from: normFrom }
            }
            rpgDB.proposals = normalizedProposals
        }
        // Normalize semua player keys ke @s.whatsapp.net (merge jika ada duplikat @lid)
        const normalizedPlayers = {}
        let needSave = false
        for (const [key, val] of Object.entries(rpgDB.players)) {
            const normKey = key.endsWith('@lid') ? key.replace('@lid', '@s.whatsapp.net') : key
            if (normKey !== key) needSave = true // ada @lid yang perlu diubah
            if (val.jid && val.jid.endsWith('@lid')) { val.jid = val.jid.replace('@lid', '@s.whatsapp.net'); needSave = true }
            if (val.pasangan && val.pasangan.endsWith('@lid')) { val.pasangan = val.pasangan.replace('@lid', '@s.whatsapp.net'); needSave = true }
            if (!normalizedPlayers[normKey]) {
                normalizedPlayers[normKey] = val
            } else {
                // Merge: prioritaskan yang punya data lebih lengkap (level lebih tinggi)
                if ((val.level || 0) > (normalizedPlayers[normKey].level || 0)) {
                    normalizedPlayers[normKey] = val
                }
            }
        }
        rpgDB.players = normalizedPlayers
        // Simpan hasil normalisasi ke file agar tidak perlu ulang terus
        if (needSave) {
            try { fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2)) } catch(e) {}
        }

        // ── Resolve mention/tag JID dari grup (handle @lid) ──────────
        function resolveMentionJid(rawJid) {
            if (!rawJid) return rawJid
            // Jika @lid, coba cari nomor asli dari participants grup
            if (rawJid.endsWith('@lid') && m.isGroup && m.metadata && m.metadata.participants) {
                const p = m.metadata.participants.find(x => x.lid === rawJid || x.id === rawJid)
                if (p) {
                    const real = p.jid || p.id
                    if (real && !real.endsWith('@lid')) return real
                }
            }
            // Fallback ke resolvePlayerJid (cek DB + normalize)
            return resolvePlayerJid(rawJid)
        }

        const senderJid = resolvePlayerJid(m.sender)

        // GLOBAL BAN CHECK - blokir SEMUA command RPG jika terbanned
        const _BYPASS_CMDS = ['cekbanned']
        if (!_BYPASS_CMDS.includes(command)) {
            const _bi = _getBanInfo ? _getBanInfo(senderJid) : null
            if (_bi) {
                const _tgl = _bi.tanggalStr || '-'
                const _olh = _bi.oleh || 'admin'
                const _als = _bi.alasan || '-'
                return Reply(
                    '╭─────────────────────❄\n'
                    + '│▣  🚫  AKSES RPG DIBLOKIR  🚫\n'
                    + '╰─────────────────────❄\n'
                    + '╭─❄\n'
                    + '│▣ ❌ Akunmu diblokir dari semua fitur RPG!\n'
                    + '│▣\n'
                    + '│▣ 📋 *Alasan:*\n'
                    + `│▣ _${_als}_\n`
                    + '│▣\n'
                    + `│▣ 📅 Sejak  : ${_tgl}\n`
                    + `│▣ 👮 Oleh   : ${_olh}\n`
                    + '│▣\n'
                    + '│▣ ──────────────────\n'
                    + '│▣ ⛔ Semua fitur RPG dinonaktifkan!\n'
                    + '│▣ Hubungi admin jika ada kesalahan.\n'
                    + '╰──────────❄'
                )
            }
        }

        if (command === 'adduang') {
            if (!isCreator) return Reply(`❌ *Khusus owner bot!*`)
            let targetJid = null
            if (m.isGroup) {
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    targetJid = m.mentionedJid[0]
                    if (targetJid.endsWith('@lid')) {
                        if (m.metadata && m.metadata.participants) {
                            let p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                            if (p && p.jid) targetJid = p.jid
                        }
                    }
                } else if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            } else {
                if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            }

            if (!targetJid) {
                return Reply(`Tag atau reply user yang ingin ditambahkan uang!\nContoh: .adduang 1000 @user`)
            }

            const textParts = text ? text.trim().split(' ') : []
            const amount = parseInt(textParts[0])

            if (isNaN(amount) || amount <= 0) {
                return Reply(`Masukkan jumlah uang yang valid!\nContoh: .adduang 1000 @user`)
            }

            if (!rpgDB.players[targetJid]) {
                rpgDB.players[targetJid] = {
                    gold: 0,
                    level: 1,
                    exp: 0,
                    hp: 100,
                    maxHp: 100,
                    energy: 100,
                    maxEnergy: 100,
                    location: 'desa',
                    class: 'warrior'
                }
            }

            rpgDB.players[targetJid].gold += amount
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`
╭─────────────────────❏
│▣  💵  UANG DITAMBAH  💵
╰─────────────────────❏
╭─❏
│▣ 👤 Penerima  : @${targetJid.split('@')[0]}
│▣ 💵 Jumlah    : ${toRupiah(amount)}
│▣ ──────────────────
│▣ 💰 Total     : ${toRupiah(rpgDB.players[targetJid].gold)}
╰──────────❏
jajan yang bener ya, jangan lupa bagi-bagi~ 🤑`)
        }

        if (command === 'cekuang') {
            
                

            let targetJid = m.sender

            if (m.isGroup) {
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    targetJid = m.mentionedJid[0]
                    if (targetJid.endsWith('@lid')) {
                        if (m.metadata && m.metadata.participants) {
                            let p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                            if (p && p.jid) targetJid = p.jid
                        }
                    }
                } else if (m.quoted) {
                    targetJid = m.quoted.sender
                } else if (text) {
                    const phoneNumber = text.replace(/[^0-9]/g, '')
                    if (phoneNumber.length > 3) {
                        targetJid = phoneNumber + '@s.whatsapp.net'
                    }
                }
            } else {
                if (m.quoted) {
                    targetJid = m.quoted.sender
                } else if (text) {
                    const phoneNumber = text.replace(/[^0-9]/g, '')
                    if (phoneNumber.length > 3) {
                        targetJid = phoneNumber + '@s.whatsapp.net'
                    }
                }
            }

            if (!rpgDB.players[targetJid]) {
                return Reply(`❌ User ${targetJid === m.sender ? 'kamu' : 'tersebut'} belum memulai petualangan RPG! Gunakan .rpgstart untuk memulai.`)
            }

            const player = rpgDB.players[targetJid]
            const mention = targetJid !== m.sender ? `@${targetJid.split('@')[0]}\n\n` : ''
            
            let message = `
╭─────────────────────❏
│▣  💵  CEK UANG  💵
╰─────────────────────❏
╭─❏
│▣ 👤 Pemilik  : ${mention ? '' : 'kamu'}${mention}
│▣ 💰 Total    : *${toRupiah(player.gold)}*
╰──────────❏
`
            
            if (targetJid === m.sender) {
                message += `
⚔️ *STATUS KARAKTER*
╭─❏
│▣ 🏅 Level    : ${player.level || 1}
│▣ ❤️  HP       : ${player.hp || 100}/${player.maxHp || 100}
│▣ ⚡ Energy   : ${player.energy || 100}/${player.maxEnergy || 100}
╰──────────❏`
            }

            return yonz.sendMessage(m.chat, { 
                text: message, 
                mentions: targetJid !== m.sender ? [targetJid] : [] 
            }, { quoted: m })
        }

        if (command === 'topgold') {
            
                

            const players = Object.entries(rpgDB.players)
            
            if (players.length < 1) {
                return Reply("❌ Belum ada petualang yang terdaftar.")
            }

            const sortedByGold = players
                .filter(([_, player]) => player && player.gold > 0)
                .sort(([,a], [,b]) => (b.gold || 0) - (a.gold || 0))
                .slice(0, 10)

            if (sortedByGold.length === 0) {
                return Reply("❌ Belum ada data gold. Jadilah sultan pertama!")
            }

            let goldLbText = `╭─────────────────────❏\n│▣  🏆  TOP 10 TERKAYA  🏆\n╰─────────────────────❏\n`
            goldLbText += `╭─❏\n`
            
            let mentions = []
            
            sortedByGold.forEach(([jid, player], index) => {
                const medals = ['🥇','🥈','🥉']
                const medal = medals[index] || `${index + 1}.`
                goldLbText += `│▣ ${medal} @${jid.split('@')[0]} — *${toRupiah(player.gold || 0)}* 💵\n`
                mentions.push(jid)
            })

            goldLbText += `╰──────────❏\nsultan-sultan sini wajib traktir~ 😏`

            return yonz.sendMessage(m.chat, { 
                text: goldLbText, 
                mentions: mentions 
            }, { quoted: m })
        }
        
        
        // ═══════════════ 🌴 SISTEM SAWIT 🌴 ═══════════════

        if ([
            'sawit',
            'tanamsawit',
            'panensawit',
            'ceksawit',
            'topsawit',
            'jualsawit',
            'transfersawit'
        ].includes(command)) {

            if (!rpgDB.players[senderJid]) {
                return Reply('❌ Ketik *.rpgstart* dulu')
            }

            const player = rpgDB.players[senderJid]

            if (!player.sawit) {
                player.sawit = {
                    pohon: 0,
                    buah: 0,
                    totalPanen: 0,
                    lastPanen: 0
                }
            }

            if (command === 'sawit') {

                let statusPanen = 'Siap panen!'
                let cooldown = 3600000
                let diff = Date.now() - player.sawit.lastPanen

                if (diff < cooldown) {
                    let sisa = cooldown - diff
                    let menit = Math.floor(sisa / 60000)
                    statusPanen = `${menit} menit`
                }

                return Reply(`╭─────────────────────❏
│▣  🌴  KEBUN SAWIT  🌴
╰─────────────────────❏
╭─❏
│▣ 🌱 Pohon Sawit : *${player.sawit.pohon || 0} pohon*
│▣ 🧺 Tandan      : *${player.sawit.buah || 0} buah*
│▣ 📦 Total Panen : *${player.sawit.totalPanen || 0} buah*
│▣ 💵 Uang RPG    : *${toRupiah(player.gold || 0)}*
│▣ ⏳ Panen Lagi  : *${statusPanen}*
╰──────────❏`)
            }

            if (command === 'tanamsawit') {

                let jumlah = parseInt(text) || 1
                let harga = jumlah * 25000

                if ((player.gold || 0) < harga)
                    return Reply('❌ Gold kurang')

                player.gold -= harga
                player.sawit.pohon += jumlah

                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return Reply(`🌱 Berhasil menanam ${jumlah} pohon sawit`)
            }

            if (command === 'panensawit') {

                let cooldown = 3600000

                if (Date.now() - player.sawit.lastPanen < cooldown) {
                    return Reply('⏳ Sawit belum siap dipanen')
                }

                let hasil = (player.sawit.pohon || 0) * (Math.floor(Math.random() * 10) + 1)

                player.sawit.buah += hasil
                player.sawit.totalPanen += hasil
                player.sawit.lastPanen = Date.now()

                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return Reply(`🧺 Berhasil panen ${hasil} buah sawit`)
            }

            if (command === 'jualsawit') {

                let jumlah = text === 'semua'
                    ? player.sawit.buah
                    : parseInt(text) || 1

                if ((player.sawit.buah || 0) < jumlah)
                    return Reply('❌ Sawit kurang')

                let uang = jumlah * 8000

                player.sawit.buah -= jumlah
                player.gold += uang

                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return Reply(`💸 Berhasil menjual ${jumlah} sawit`)
            }

            if (command === 'ceksawit') {
                return Reply(`🌴 Pohon: ${player.sawit.pohon || 0}
🧺 Buah: ${player.sawit.buah || 0}`)
            }

            if (command === 'topsawit') {

                let users = Object.entries(rpgDB.players)
                .sort((a,b)=>
                    ((b[1].sawit?.totalPanen)||0) -
                    ((a[1].sawit?.totalPanen)||0)
                )
                .slice(0,10)

                let teks = '🏆 TOP SAWIT\n\n'

                users.forEach((u,i)=>{
                    teks += `${i+1}. @${u[0].split('@')[0]} — ${u[1].sawit?.totalPanen || 0}\n`
                })

                return yonz.sendMessage(m.chat,{
                    text: teks,
                    mentions: users.map(v=>v[0])
                },{quoted:m})
            }

            if (command === 'transfersawit') {

                let target = m.mentionedJid?.[0]

                if (!target)
                    return Reply('❌ Tag target')

                let jumlah = parseInt(text.replace(/[^0-9]/g,'')) || 1

                if (!rpgDB.players[target])
                    return Reply('❌ Target belum daftar RPG')

                if (!rpgDB.players[target].sawit) {
                    rpgDB.players[target].sawit = {
                        pohon:0,
                        buah:0,
                        totalPanen:0,
                        lastPanen:0
                    }
                }

                if ((player.sawit.buah || 0) < jumlah)
                    return Reply('❌ Sawit kurang')

                player.sawit.buah -= jumlah
                rpgDB.players[target].sawit.buah += jumlah

                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return Reply('✅ Transfer sawit berhasil')
            }
        }

        // ═══════════════════════════════════════════════════



        const _animatedGameCommands = new Set([
            'judionline','begal','maling','ngojek','ngaji','kerja','jobkerja','berkebun','mulung','nambang','adventure','berburu','mancing','aduikan','ngedokter','ngajar','streaming','dagang','ojol','kurir','masak','nguli','ngamen','openbo','ngelonte','ngocok','rawatanak','buatanak','rpgexplore','attack','rpgattack','skill','rpgskill','flee','rpgflee','bossattack','bossevent','nelayanstart','turunkanjaring','naikanjaring','jualikannelayan','masukanikan'
        ])
        if (_animatedGameCommands.has(command)) {
            await sendRpgProcess(Reply, String(command || 'game').toUpperCase())
        }

        if (command === 'rpgstart') {
            
                

            if (rpgDB.players[senderJid]) {
                return Reply(`✅ Kamu sudah jadi petualang! Ketik *.rpgstats* untuk cek stat.`)
            }
            if (!text) {
                return Reply(`
╭─────────────────────❏
│▣  🎮  PILIH KARAKTER  🎮
╰─────────────────────❏
╭─❏
│▣ ⚔️  *Warrior*  — HP & Defense tinggi, tank sejati
│▣ 🔥  *Mage*     — Serangan sihir dahsyat
│▣ 🏹  *Archer*   — Agility & Critical strike tinggi
╰──────────❏
Cara daftar: *.rpgstart warrior* / *mage* / *archer*`)
            }
            const classChoice = text.toLowerCase()
            if (!['warrior', 'mage', 'archer'].includes(classChoice)) {
                return Reply(`❌ class "${text}" gak ada cuy! pilih: warrior, mage, atau archer.`)
            }
            // Selalu gunakan format @s.whatsapp.net sebagai kunci standar
            const saveJid = senderJid.endsWith('@lid') ? senderJid.replace('@lid', '@s.whatsapp.net') : senderJid
            rpgDB.players[saveJid] = initPlayerRPG(saveJid, classChoice)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            return Reply(`
╭─────────────────────❏
│▣  🎉  SELAMAT DATANG!  🎉
╰─────────────────────❏
╭─❏
│▣ 🏅 Class     : *${classChoice.toUpperCase()}*
│▣ ✅ Status    : Aktif
│▣ 📍 Lokasi    : Desa Pemula 🏡
│▣ 💵 Modal     : Rp. 50
╰──────────❏
Ketik *.rpghelp* untuk lihat semua command.
Selamat berpetualang — jangan mati ya~ ⚔️`)
        }

        if (command === 'rpgstats') {
            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            const player = rpgDB.players[senderJid]
            // Sanitasi field kosong
            if (!player.equipment)              player.equipment         = { weapon: null, armor: null }
            if (!player.equipment.weapon)       player.equipment.weapon  = null
            if (!player.equipment.armor)        player.equipment.armor   = null
            if (!player.inventory)              player.inventory         = {}
            if (!player.bank)                   player.bank              = { balance: 0 }
            if (!player.fishing)                player.fishing           = { equippedRod: 'starter_rod', equippedBait: null, totalCatch: 0 }
            if (player.hp           == null)    player.hp                = player.maxHp  || 100
            if (player.maxHp        == null)    player.maxHp             = 100
            if (player.mp           == null)    player.mp                = player.maxMp  || 30
            if (player.maxMp        == null)    player.maxMp             = 30
            if (player.attack       == null)    player.attack            = 10
            if (player.defense      == null)    player.defense           = 5
            if (player.exp          == null)    player.exp               = 0
            if (player.expToNextLevel == null)  player.expToNextLevel    = 100
            if (!player.class)                  player.class             = 'warrior'
            const totalStats = getPlayerTotalStats(player)
            const weaponItem = player.equipment?.weapon ? rpgDB.items[player.equipment.weapon] : null
            const armorItem  = player.equipment?.armor  ? rpgDB.items[player.equipment.armor]  : null
            const weaponName = weaponItem ? `${weaponItem.name} (+${weaponItem.attack} atk)` : '— tidak ada'
            const armorName  = armorItem  ? `${armorItem.name} (+${armorItem.defense} def)` : '— tidak ada'

            // ── Fishing stats — safe fallback karena ROD_DATA/BAIT_DATA belum tentu terdefinisi di sini
            const _ROD_STATIC = {
                starter_rod:   { name: 'Starter Rod',   tier: 'C',  emoji: '🎣' },
                lava_rod:      { name: 'Lava Rod',       tier: 'C',  emoji: '🔴' },
                lucky_rod:     { name: 'Lucky Rod',      tier: 'B',  emoji: '🍀' },
                midnight_rod:  { name: 'Midnight Rod',   tier: 'B',  emoji: '🌙' },
                steampunk_rod: { name: 'Steampunk Rod',  tier: 'A',  emoji: '⚙️' },
                hazmat_rod:    { name: 'Hazmat Rod',     tier: 'A',  emoji: '☣️' },
                ares_rod:      { name: 'Ares Rod',       tier: 'S',  emoji: '⚔️' },
                ghostfinn_rod: { name: 'Ghostfinn Rod',  tier: 'S',  emoji: '👻' },
                element_rod:   { name: 'Element Rod',    tier: 'S+', emoji: '🌪️' },
                diamond_rod:   { name: 'Diamond Rod',    tier: 'S+', emoji: '💎' }
            }
            const _BAIT_STATIC = {
                basic_bait:       { name: 'Basic Bait',       tier: 'B',  emoji: '🪱' },
                lava_bait:        { name: 'Lava Bait',        tier: 'B',  emoji: '🔥' },
                midnight_bait:    { name: 'Midnight Bait',    tier: 'A',  emoji: '🌙' },
                chroma_bait:      { name: 'Chroma Bait',      tier: 'S',  emoji: '🌈' },
                corrupt_bait:     { name: 'Corrupt Bait',     tier: 'S',  emoji: '💀' },
                aether_bait:      { name: 'Aether Bait',      tier: 'S+', emoji: '🌠' },
                singularity_bait: { name: 'Singularity Bait', tier: 'S+', emoji: '🕳️' }
            }

            const fishRodId   = player.fishing?.equippedRod || 'starter_rod'
            const fishBaitId  = player.fishing?.equippedBait || null
            const fishRodData = _ROD_STATIC[fishRodId]  || { name: fishRodId,  tier: '?', emoji: '🎣' }
            const fishBaitData= fishBaitId ? (_BAIT_STATIC[fishBaitId] || { name: fishBaitId, tier: '?', emoji: '🪱' }) : null
            const totalFishCatch = player.fishing?.totalCatch || 0
            const totalFishTypes = Object.keys(player.inventory || {}).filter(k => k.startsWith('fish_') && player.inventory[k] > 0).length

            // ── Progress bar helper
            const progressBar = (cur, max, len = 12) => {
                const pct  = Math.min(Math.floor((cur / max) * len), len)
                return '█'.repeat(pct) + '░'.repeat(len - pct)
            }

            const hpBar  = progressBar(player.hp,  player.maxHp)
            const mpBar  = progressBar(player.mp,  player.maxMp)
            const expBar = progressBar(player.exp, player.expToNextLevel)

            const atkBonus = totalStats.attack  - player.attack
            const defBonus = totalStats.defense - player.defense

            // ── Class badge
            const classBadge = { warrior: '⚔️ WARRIOR', mage: '🔥 MAGE', archer: '🏹 ARCHER' }[player.class] || player.class.toUpperCase()

            // ── Pet info
            const petInfo = player.pet ? `${player.pet.name} (atk +${player.pet.attack || 0} / def +${player.pet.defense || 0})` : '— tidak ada'

            // ── Market data & asset calculation
            let passivePerHari = 0
            let nilaiSaham = 0
            let nilaiProperti = 0
            let nilaiKendaraan = 0
            let sahamLines = []
            let propertiLines = []
            let kendaraanLines = []
            let _mktDB = null
            try {
                _mktDB = getMarketDB()

                // Saham (wallet + bank)
                const allSahamKeys = new Set([
                    ...Object.keys(player.assets?.saham || {}),
                    ...Object.keys(player.bankAssets?.saham || {})
                ])
                for (const ticker of allSahamKeys) {
                    const qtyW = player.assets?.saham?.[ticker] || 0
                    const qtyB = player.bankAssets?.saham?.[ticker] || 0
                    const qtyTotal = qtyW + qtyB
                    if (qtyTotal <= 0) continue
                    const harga = _mktDB.saham[ticker]?.price || 0
                    const nilai = harga * qtyTotal
                    const change = _mktDB.saham[ticker]?.change || 0
                    const arrow = change > 0 ? '📈' : change < 0 ? '📉' : '➡️'
                    nilaiSaham += nilai
                    sahamLines.push(`│▣   ${arrow} ${ticker} ×${qtyTotal} lot = *${toRupiah(nilai)}*`)
                }

                // Properti
                const allPropKeys = new Set([
                    ...Object.keys(player.assets?.properti || {}),
                    ...Object.keys(player.bankAssets?.properti || {})
                ])
                for (const id of allPropKeys) {
                    const qtyW = player.assets?.properti?.[id] || 0
                    const qtyB = player.bankAssets?.properti?.[id] || 0
                    const qtyTotal = qtyW + qtyB
                    if (qtyTotal <= 0) continue
                    const item = _mktDB.properti[id]
                    if (!item) continue
                    const nilai = item.price * qtyTotal
                    nilaiProperti += nilai
                    if (item.passive) passivePerHari += item.passive * qtyTotal
                    propertiLines.push(`│▣   🏠 ${item.name}${qtyTotal > 1 ? ` ×${qtyTotal}` : ''} = *${toRupiah(nilai)}*`)
                }

                // Kendaraan
                const allKenKeys = new Set([
                    ...Object.keys(player.assets?.kendaraan || {}),
                    ...Object.keys(player.bankAssets?.kendaraan || {})
                ])
                for (const id of allKenKeys) {
                    const qtyW = player.assets?.kendaraan?.[id] || 0
                    const qtyB = player.bankAssets?.kendaraan?.[id] || 0
                    const qtyTotal = qtyW + qtyB
                    if (qtyTotal <= 0) continue
                    const item = _mktDB.kendaraan[id]
                    if (!item) continue
                    const nilai = item.price * qtyTotal
                    nilaiKendaraan += nilai
                    if (item.passive) passivePerHari += item.passive * qtyTotal
                    kendaraanLines.push(`│▣   🚗 ${item.name}${qtyTotal > 1 ? ` ×${qtyTotal}` : ''} = *${toRupiah(nilai)}*`)
                }
            } catch(_) {}

            const nilaiDompet = player.gold || 0
            const nilaiBank   = player.bank?.balance || 0
            const netWorth    = nilaiDompet + nilaiBank + nilaiSaham + nilaiProperti + nilaiKendaraan

            // ── Build kekayaan section
            let kekayaanSection = `\n💰 *KEKAYAAN*\n╭─❏\n`
            kekayaanSection += `│▣ 💵  Dompet     : *${toRupiah(nilaiDompet)}*\n`
            kekayaanSection += `│▣ 🏦  Bank       : *${toRupiah(nilaiBank)}*\n`

            if (sahamLines.length > 0) {
                kekayaanSection += `│▣\n│▣ 📊 *Saham* (${toRupiah(nilaiSaham)})\n`
                kekayaanSection += sahamLines.join('\n') + '\n'
            }
            if (propertiLines.length > 0) {
                kekayaanSection += `│▣\n│▣ 🏠 *Properti* (${toRupiah(nilaiProperti)})\n`
                kekayaanSection += propertiLines.join('\n') + '\n'
            }
            if (kendaraanLines.length > 0) {
                kekayaanSection += `│▣\n│▣ 🚗 *Kendaraan* (${toRupiah(nilaiKendaraan)})\n`
                kekayaanSection += kendaraanLines.join('\n') + '\n'
            }
            if (passivePerHari > 0) {
                kekayaanSection += `│▣\n│▣ 💹  Passive    : *+${toRupiah(passivePerHari)}/hari*\n`
            }
            kekayaanSection += `│▣\n│▣ 💎  NET WORTH  : *${toRupiah(netWorth)}*\n╰──────────❏`

            const statsText = `╭─────────────────────❏
│▣   ⚔️  RPG  STATS  ⚔️
╰─────────────────────❏

👤 *${classBadge}*  •  Lv.*${player.level}*
${player.equippedTitle && TITLE_DATA[player.equippedTitle] ? '🎖️ ' + TITLE_DATA[player.equippedTitle].name : ''}
📍 ${rpgDB.locations[player.location]?.name || 'Desa Pemula'}
⚔️ Battle: ${player.monstersDefeated || 0} monster tumbang

━━━━━━━━━━━━━━━━━━━
❤️  HP   [${hpBar}] ${player.hp}/${player.maxHp}
🔵  MP   [${mpBar}] ${player.mp}/${player.maxMp}
⭐  EXP  [${expBar}] ${player.exp}/${player.expToNextLevel}
━━━━━━━━━━━━━━━━━━━

⚡ *STATS TEMPUR*
╭─❏
│▣ ⚔️  Attack   : *${player.attack}* ${atkBonus > 0 ? `(+${atkBonus} equip)` : ''}
│▣ 🛡️  Defense  : *${player.defense}* ${defBonus > 0 ? `(+${defBonus} equip)` : ''}
│▣ 🌀  Agility  : *${player.agility}*
│▣ 🏆  PVP      : ${player.pvpWins || 0}W / ${player.pvpLosses || 0}L
╰──────────❏
${kekayaanSection}

🗡️ *EQUIPMENT*
╭─❏
│▣ ⚔️  Senjata  : ${weaponName}
│▣ 🛡️  Zirah    : ${armorName}
│▣ 🐾  Pet      : ${petInfo}
╰──────────❏

🎣 *FISHING*
╭─❏
│▣ 🎣  Joran    : ${fishRodData.emoji} ${fishRodData.name} [Tier ${fishRodData.tier}]
│▣ 🪱  Umpan    : ${fishBaitData ? `${fishBaitData.emoji} ${fishBaitData.name}` : '❌ tidak ada'}
│▣ 🐟  Tangkap  : ${totalFishCatch} ekor | ${totalFishTypes} jenis
╰──────────❏`

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(statsText)
        }

        if (command === 'rpgexplore') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (Date.now() - (player.lastBattle || 0) < 30000) {
                const cooldown = Math.ceil((30000 - (Date.now() - (player.lastBattle || 0))) / 1000)
                return Reply(`⏳ Tunggu ${cooldown} detik lagi untuk eksplorasi berikutnya.`)
            }
            const monster = getRandomMonster(player.location, player.level)
            if (!monster) return Reply(`🌫️ Tidak ada monster di sini. Coba pindah lokasi dulu!`)
            player.battleState = {
                monster: monster,
                monsterHp: monster.hp,
                inBattle: true
            }
            player.lastBattle = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            const tierStars = '⭐'.repeat(Math.min(monster.tier || 1, 10))
            const tierLabel = ['','🟢 MUDAH','🟡 NORMAL','🟠 SEDANG','🔴 KUAT','🔴 SANGAT KUAT','💀 BOSS','💀 ELITE','☠️ LEGENDA','💥 MITOLOGI','🌟 DEWA'][Math.min(monster.tier || 1, 10)]
            const lvlDiff = monster.level - player.level
            const diffHint = lvlDiff >= 5 ? '⚠️ MONSTER JAUH LEBIH KUAT!' : lvlDiff >= 2 ? '⚠️ Hati-hati, lebih kuat dari lu!' : lvlDiff <= -3 ? '😏 Monster lebih lemah dari lu' : '⚔️ Pertarungan seimbang'
            const hpBar = '█'.repeat(10) + '░'.repeat(0)

            const battleText = `╭─────────────────────❏
│▣   ⚔️  MONSTER DITEMUKAN!  ⚔️
╰─────────────────────❏
╭─❏
│▣ 👾 *${monster.name}*
│▣ 🎚️ Level   : ${monster.level}  ${tierStars}
│▣ 🏷️ Tier    : ${tierLabel}
│▣ ❤️  HP      : [${hpBar}] ${monster.hp}
│▣ ⚔️  Attack  : ${monster.attack}
│▣ 🛡️ Defense : ${monster.defense}
│▣
│▣ ${diffHint}
╰──────────❏

⚡ *Aksi tersedia:*
╭─❏
│▣ *.attack* — serangan biasa
│▣ *.skill*  — skill spesial class (butuh MP)
│▣ *.flee*   — kabur dari pertarungan
│▣ *.item*   — pakai item dari inventory
╰──────────❏`
            return Reply(battleText)
        }

        if (command === 'attack') {
            
                

            if (!rpgDB.players[senderJid]?.battleState?.inBattle) return Reply(`❌ Kamu tidak sedang bertarung! Ketik *.rpgexplore* untuk cari musuh.`)
            const player = rpgDB.players[senderJid]
            const battleState = player.battleState
            const mkHpBar = (cur, max, len = 8) => { const p = Math.min(Math.floor((Math.max(0,cur)/Math.max(1,max))*len),len); return '█'.repeat(p)+'░'.repeat(len-p) }
            const playerDamage = calculateDamage(player, battleState.monster)
            battleState.monsterHp -= playerDamage.damage
            let battleLog = [`╭─────────────────────❏\n│▣   ⚔️  SERANGAN!  ⚔️\n╰─────────────────────❏\n╭─❏`]
            battleLog.push(`│▣ 🗡️ lu nyerang *${battleState.monster.name}*`)
            battleLog.push(`│▣    damage: *${playerDamage.damage}*${playerDamage.isCritical ? ' 💥 *CRITICAL!*' : ''}`)
            if (player.pet?.attack > 0) {
                const petDamage = player.pet.attack
                battleState.monsterHp -= petDamage
                battleLog.push(`│▣ 🐾 *${player.pet.name}* ikut nyerang! +${petDamage} dmg`)
            }
            if (battleState.monsterHp <= 0) {
                battleLog.push(`╰──────────❏`)
                battleLog.push(``)
                battleLog.push(`🎉 *MENANG! ${battleState.monster.name} tumbang!*`)
                battleLog.push(`╭─❏`)
                player.gold += battleState.monster.gold
                const leveledUp = gainExp(player, battleState.monster.exp)
                player.monstersDefeated = (player.monstersDefeated || 0) + 1
                battleLog.push(`│▣ 💵 +${toRupiah(battleState.monster.gold)}`)
                battleLog.push(`│▣ ⭐ +${battleState.monster.exp} EXP`)
                if (battleState.monster.drops) {
                    if (!player.inventory) player.inventory = {}
                    for (const [itemId, chance] of Object.entries(battleState.monster.drops)) {
                        if (Math.random() < chance) {
                            player.inventory[itemId] = (player.inventory[itemId] || 0) + 1
                            battleLog.push(`│▣ 🎁 drop: *${rpgDB.items[itemId]?.name || itemId}*`)
                        }
                    }
                }
                if (leveledUp) battleLog.push(`│▣ 🎊 *LEVEL UP! ➜ Lv.${player.level}!*`)
                if (player.activeQuest) {
                    const quest = rpgDB.quests[player.activeQuest]
                    if (quest && quest.type === 'kill' && quest.target === battleState.monster.name) {
                        player.questProgress = (player.questProgress || 0) + 1
                        battleLog.push(`│▣ 📜 quest: *${player.questProgress}/${quest.count}*`)
                        if (player.questProgress >= quest.count) {
                            player.gold += quest.reward.gold
                            gainExp(player, quest.reward.exp)
                            if (quest.reward.item) {
                                if (!player.inventory) player.inventory = {}
                                player.inventory[quest.reward.item.id] = (player.inventory[quest.reward.item.id] || 0) + quest.reward.item.amount
                            }
                            battleLog.push(`│▣ 🏆 *QUEST SELESAI!* +${toRupiah(quest.reward.gold)} +${quest.reward.exp}exp`)
                            player.activeQuest = null
                            player.questProgress = 0
                        }
                    }
                }
                battleLog.push(`╰──────────❏`)
                const newBattleTitles = checkNewTitles(player)
                if (newBattleTitles.length > 0) battleLog.push(`│▣ 🎖️ Title baru: ${newBattleTitles.join(', ')}`)
                delete player.battleState
            } else {
                const monsterDamage = calculateDamage(battleState.monster, player)
                player.hp = Math.max(0, player.hp - monsterDamage.damage)
                battleLog.push(`│▣ 👾 ${battleState.monster.name} balas! -*${monsterDamage.damage}* HP`)
                battleLog.push(`╰──────────❏`)
                battleLog.push(``)
                battleLog.push(`📊 *STATUS*`)
                battleLog.push(`╭─❏`)
                const pBar = mkHpBar(player.hp, player.maxHp)
                const mBar = mkHpBar(battleState.monsterHp, battleState.monster.hp)
                battleLog.push(`│▣ 🫵 [${pBar}] ${player.hp}/${player.maxHp} HP`)
                battleLog.push(`│▣ 👾 [${mBar}] ${Math.max(0,battleState.monsterHp)}/${battleState.monster.hp} HP`)
                battleLog.push(`╰──────────❏`)
                if (player.hp <= 0) {
                    const goldLoss = Math.max(10, Math.floor(player.gold * 0.05))
                    battleLog.push(``)
                    battleLog.push(`💀 *KALAH...*`)
                    battleLog.push(`╭─❏`)
                    player.hp = 1
                    player.gold = Math.max(0, player.gold - goldLoss)
                    battleLog.push(`│▣ 💸 -${toRupiah(goldLoss)} (5% gold hilang)`)
                    battleLog.push(`│▣ 💵 Sisa: ${toRupiah(player.gold)}`)
                    battleLog.push(`╰──────────❏`)
                    delete player.battleState
                }
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(battleLog.join('\n'))
        }

        if (command === 'skill') {
            
                

            if (!rpgDB.players[senderJid]?.battleState?.inBattle) return Reply(`❌ Kamu tidak sedang bertarung! Ketik *.rpgexplore* untuk cari musuh.`)
            const player = rpgDB.players[senderJid]
            const battleState = player.battleState
            let battleLog = [`╭─────────────────────❏\n│▣   ✨  SKILL DILEPAS!  ✨\n╰─────────────────────❏\n╭─❏`]
            let skillUsed = false
            switch (player.class) {
                case 'warrior':
                    if (player.mp < 15) {
                        battleLog.push(`│▣ 🔵 mp kurang! butuh 15 mp`)
                        battleLog.push(`╰──────────❏`)
                        return Reply(battleLog.join('\n'))
                    }
                    player.mp -= 15
                    player.hp -= 5
                    const warriorDamage = Math.floor(getPlayerTotalStats(player).attack * 2.5)
                    battleState.monsterHp -= warriorDamage
                    skillUsed = true
                    battleLog.push(`│▣ ⚔️ *RAGE SLASH!* lu ngeluarin jurus pamungkas!`)
                    battleLog.push(`│▣ 💥 damage: *${warriorDamage}* ke ${battleState.monster.name}!`)
                    battleLog.push(`│▣ 💔 tapi lu kena efek samping: -5 hp`)
                    break
                case 'mage':
                    if (player.mp < 20) {
                        battleLog.push(`│▣ 🔵 mp kurang! butuh 20 mp`)
                        battleLog.push(`╰──────────❏`)
                        return Reply(battleLog.join('\n'))
                    }
                    player.mp -= 20
                    const mageDamage = Math.floor(getPlayerTotalStats(player).attack * 2)
                    battleState.monsterHp -= mageDamage
                    skillUsed = true
                    battleLog.push(`│▣ 🔥 *FIREBALL!* api berkobar dari tangan lu!`)
                    battleLog.push(`│▣ 💥 damage: *${mageDamage}* ke ${battleState.monster.name}!`)
                    break
                case 'archer':
                    if (player.mp < 15) {
                        battleLog.push(`│▣ 🔵 mp kurang! butuh 15 mp`)
                        battleLog.push(`╰──────────❏`)
                        return Reply(battleLog.join('\n'))
                    }
                    player.mp -= 15
                    const isCritical = Math.random() < 0.75
                    const archerStats = getPlayerTotalStats(player)
                    let archerDamage = Math.max(1, Math.floor(archerStats.attack - battleState.monster.defense))
                    if (isCritical) archerDamage *= 2
                    battleState.monsterHp -= archerDamage
                    skillUsed = true
                    battleLog.push(`│▣ 🏹 *PRECISION SHOT!* bidikan presisi melesat!`)
                    if (isCritical) battleLog.push(`│▣ 💥 *CRITICAL HIT!*`)
                    battleLog.push(`│▣ 💥 damage: *${archerDamage}* ke ${battleState.monster.name}!`)
                    break
            }
            if (skillUsed) {
                if (player.pet?.attack > 0 && battleState.monsterHp > 0) {
                    const petDamage = player.pet.attack
                    battleState.monsterHp -= petDamage
                    battleLog.push(`│▣ 🐾 *${player.pet.name}* ikutan nyerang! +${petDamage} dmg!`)
                }
                battleLog.push(`╰──────────❏`)
                const mkHpBar2 = (cur, max, len = 8) => { const p = Math.min(Math.floor((Math.max(0,cur)/Math.max(1,max))*len),len); return '█'.repeat(p)+'░'.repeat(len-p) }
                if (battleState.monsterHp <= 0) {
                    battleLog.push(``)
                    battleLog.push(`🎉 *VICTORY! Skill pamungkas menghancurkan musuh!*`)
                    battleLog.push(`╭─❏`)
                    player.gold += battleState.monster.gold
                    const leveledUp = gainExp(player, battleState.monster.exp)
                    player.monstersDefeated = (player.monstersDefeated || 0) + 1
                    battleLog.push(`│▣ 💵 +${toRupiah(battleState.monster.gold)}`)
                    battleLog.push(`│▣ ⭐ +${battleState.monster.exp} EXP`)
                    if (battleState.monster.drops) {
                        if (!player.inventory) player.inventory = {}
                        for (const [itemId, chance] of Object.entries(battleState.monster.drops)) {
                            if (Math.random() < chance) {
                                player.inventory[itemId] = (player.inventory[itemId] || 0) + 1
                                battleLog.push(`│▣ 🎁 drop: *${rpgDB.items[itemId]?.name || itemId}*`)
                            }
                        }
                    }
                    if (leveledUp) battleLog.push(`│▣ 🎊 *LEVEL UP! ➜ Lv.${player.level}!*`)
                    if (player.activeQuest) {
                        const quest = rpgDB.quests[player.activeQuest]
                        if (quest && quest.type === 'kill' && quest.target === battleState.monster.name) {
                            player.questProgress = (player.questProgress || 0) + 1
                            battleLog.push(`│▣ 📜 quest: *${player.questProgress}/${quest.count}*`)
                            if (player.questProgress >= quest.count) {
                                player.gold += quest.reward.gold
                                gainExp(player, quest.reward.exp)
                                if (quest.reward.item) {
                                    if (!player.inventory) player.inventory = {}
                                    player.inventory[quest.reward.item.id] = (player.inventory[quest.reward.item.id] || 0) + quest.reward.item.amount
                                }
                                battleLog.push(`│▣ 🏆 *QUEST SELESAI!* +${toRupiah(quest.reward.gold)} +${quest.reward.exp}exp`)
                                player.activeQuest = null
                                player.questProgress = 0
                            }
                        }
                    }
                    battleLog.push(`╰──────────❏`)
                    delete player.battleState
                } else {
                    const monsterDamage = calculateDamage(battleState.monster, player)
                    player.hp = Math.max(0, player.hp - monsterDamage.damage)
                    battleLog.push(``)
                    battleLog.push(`👾 ${battleState.monster.name} balas! -*${monsterDamage.damage}* HP`)
                    battleLog.push(`📊 *STATUS*`)
                    battleLog.push(`╭─❏`)
                    battleLog.push(`│▣ 🫵 [${mkHpBar2(player.hp, player.maxHp)}] ${player.hp}/${player.maxHp}`)
                    battleLog.push(`│▣ 👾 [${mkHpBar2(battleState.monsterHp, battleState.monster.hp)}] ${Math.max(0,battleState.monsterHp)}/${battleState.monster.hp}`)
                    battleLog.push(`╰──────────❏`)
                    if (player.hp <= 0) {
                        const goldLoss = Math.max(10, Math.floor(player.gold * 0.05))
                        battleLog.push(``)
                        battleLog.push(`💀 *DEFEAT... Skillnya gak cukup kuat...*`)
                        battleLog.push(`╭─❏`)
                        player.hp = 1
                        player.gold = Math.max(0, player.gold - goldLoss)
                        battleLog.push(`│▣ 💸 -${toRupiah(goldLoss)} | Sisa: ${toRupiah(player.gold)}`)
                        battleLog.push(`╰──────────❏`)
                        delete player.battleState
                    }
                }
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(battleLog.join('\n'))
            }
        }

        if (command === 'flee') {
            
                

            if (!rpgDB.players[senderJid] || !rpgDB.players[senderJid].battleState || !rpgDB.players[senderJid].battleState.inBattle) {
                return Reply(`❌ Kamu tidak sedang bertarung! Ketik *.rpgexplore* untuk cari musuh.`)
            }
            const player = rpgDB.players[senderJid]
            const monster = player.battleState.monster
            const fleeChance = (player.agility / (player.agility + monster.level * 5))
            if (Math.random() < fleeChance) {
                delete player.battleState
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                
                return Reply(`
╭─────────────────────❏
│▣   🏃‍♂️  KABUR BERHASIL!  🏃‍♂️
╰─────────────────────❏
╭─❏
│▣ 👾 ${monster.name} cuma bisa melongo lihat lu kabur
│▣ 🏃‍♂️ Skill kabur lu level dewa!
╰──────────❏
Tapi inget, kabur terus gak akan bikin lu kuat~ 💪`)
            } else {
                const monsterDamage = calculateDamage(monster, player)
                player.hp -= monsterDamage.damage
                let battleLog = [`
╭─────────────────────❏
│▣   ❌  GAGAL KABUR!  ❌
╰─────────────────────❏
╭─❏
│▣ 👾 ${monster.name} nyerang dari belakang!
│▣ 💥 Damage : ${monsterDamage.damage}
╰──────────❏`]
                if (player.hp <= 0) {
                    battleLog.push(``)
                    battleLog.push(`💀 *TE WAS...*`)
                    battleLog.push(`💀 Sial, mati pas kabur!`)
                    battleLog.push(`╭─❏`)
                    player.hp = 1
                    player.gold = Math.max(0, player.gold - 20)
                    battleLog.push(`│▣ 💵 -Rp.20 | Sisa: ${toRupiah(player.gold)}`)
                    battleLog.push(`╰──────────❏`)
                    delete player.battleState
                }
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                
                return Reply(battleLog.join('\n'))
            }
        }

        if (command === 'rpgmove') {
            
                

            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            if (!text) {
                const player = rpgDB.players[senderJid]
                const plvl = player.level || 1
                // Pisahkan lokasi combat dan resource
                const combatLocs = Object.entries(rpgDB.locations).filter(([,loc]) => loc.monsters)
                const resourceLocs = Object.entries(rpgDB.locations).filter(([,loc]) => !loc.monsters)

                let locMsg = `╭─────────────────────❏\n│▣   🗺️  PETA DUNIA  🗺️\n╰─────────────────────❏\n╭─❏\n│▣ 👤 Level kamu: *${plvl}*\n│▣\n│▣ ⚔️ *ZONA PERTEMPURAN*\n`
                for (const [id, loc] of combatLocs) {
                    const canAccess = plvl >= loc.minLevel
                    const isCurrent = player.location === id
                    const lvlDiff = plvl - loc.minLevel
                    const zoneHint = !canAccess ? '🔒' : lvlDiff >= 10 ? '😏 terlalu mudah' : lvlDiff >= 5 ? '✅ cocok' : lvlDiff >= 0 ? '⚠️ menantang' : '🔒'
                    locMsg += `│▣ ${isCurrent ? '📍' : canAccess ? '✅' : '❌'} *${loc.name}* ${isCurrent ? '(di sini)' : ''}\n`
                    locMsg += `│▣    Level ${loc.minLevel}–${loc.maxLevel} ${zoneHint}\n`
                    if (canAccess) locMsg += `│▣    *.rpgmove ${id}*\n`
                    locMsg += `│▣\n`
                }
                locMsg += `│▣ 🏗️ *ZONA RESOURCE*\n`
                for (const [id, loc] of resourceLocs) {
                    const canAccess = plvl >= loc.minLevel
                    const isCurrent = player.location === id
                    locMsg += `│▣ ${isCurrent ? '📍' : canAccess ? '✅' : '❌'} *${loc.name}* ${isCurrent ? '(di sini)' : ''}\n`
                    locMsg += `│▣    Level min ${loc.minLevel} | *.rpgmove ${id}*\n│▣\n`
                }
                locMsg += `╰──────────❏`
                return Reply(locMsg)
            }
            const player = rpgDB.players[senderJid]
            const locationId = text.toLowerCase()
            if (!rpgDB.locations[locationId]) {
                return Reply(`❌ lokasi "${text}" gak ada di peta! cek *.rpgmove* buat liat daftarnya.`)
            }
            const targetLocation = rpgDB.locations[locationId]
            if (player.level < targetLocation.minLevel) {
                return Reply(`❌ level lu kurang! butuh level ${targetLocation.minLevel} buat masuk ${targetLocation.name}.`)
            }
            player.location = locationId
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            return Reply(`
╭─────────────────────❏
│▣   🚶‍♂️  PINDAH LOKASI  🚶‍♂️
╰─────────────────────❏
╭─❏
│▣ 📍 Lokasi   : *${targetLocation.name}*
│▣ 🎯 Level    : ${targetLocation.minLevel}–${targetLocation.maxLevel}
╰──────────❏
Hati-hati, monster di sini gak segan-segan~ ⚠️`)
        }

        if (command === 'rpginv' || command === 'rpg inventory') {
            
                

            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            const player = rpgDB.players[senderJid]

            // Helper inline (safe to call here — FISH_DATA etc defined above in same scope run)
            const _invFish = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('fish_') && v > 0)
            const _invRods = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('rod_') && v > 0)
            const _invBaits = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('bait_') && v > 0)
            const _invOther = Object.entries(player.inventory || {}).filter(([k,v]) => !k.startsWith('fish_') && !k.startsWith('rod_') && !k.startsWith('bait_') && v > 0)

            let inventoryText = `╭─────────────────────❏\n│▣   🎒  INVENTORY  🎒\n╰─────────────────────❏\n╭─❏\n`

            // ── Item biasa
            if (_invOther.length > 0) {
                inventoryText += `│▣ 📦 *ITEM*\n`
                for (const [itemId, quantity] of _invOther) {
                    if (rpgDB.items[itemId]) {
                        inventoryText += `│▣   ${rpgDB.items[itemId].name} x${quantity}\n`
                    }
                }
            }

            // ── Joran
            if (_invRods.length > 0) {
                inventoryText += `│▣\n│▣ 🎣 *JORAN*\n`
                for (const [k, qty] of _invRods) {
                    const rid = k.replace('rod_', '')
                    const rd  = ROD_DATA[rid]
                    if (rd) inventoryText += `│▣   ${rd.emoji} ${rd.name} [${rd.tier}] x${qty}\n`
                }
            }

            // ── Umpan
            if (_invBaits.length > 0) {
                inventoryText += `│▣\n│▣ 🪱 *UMPAN*\n`
                for (const [k, qty] of _invBaits) {
                    const bid = k.replace('bait_', '')
                    const bt  = BAIT_DATA[bid]
                    if (bt) inventoryText += `│▣   ${bt.emoji} ${bt.name} [${bt.tier}] x${qty}\n`
                }
            }

            // ── Ikan
            if (_invFish.length > 0) {
                inventoryText += `│▣\n│▣ 🐟 *IKAN* (${_invFish.length} jenis)\n`
                let fishVal = 0
                for (const [k, qty] of _invFish.slice(0, 8)) {
                    const { fishId, mutationId } = parseFishKey(k)
                    if (!fishId) {
                        inventoryText += `│▣   ⬜ ❓ ${k.replace('fish_','')} x${qty}\n`
                        continue
                    }
                    const fdata = FISH_DATA[fishId] || { name: fishId, emoji: '🐟', rarity: 'COMMON', basePrice: 0 }
                    const mdata = mutationId ? MUTATION_DATA[mutationId] : null
                    const price = calcFishPrice(fdata, mdata)
                    fishVal += price * qty
                    inventoryText += `│▣   ${getRarityEmoji(fdata.rarity)} ${getFishDisplayName(fdata, mdata)} x${qty}\n`
                }
                if (_invFish.length > 8) inventoryText += `│▣   ... dan ${_invFish.length - 8} jenis lagi\n`
                inventoryText += `│▣   💼 Est. nilai ikan: ${toRupiah(fishVal)}\n`
                inventoryText += `│▣   ↳ *.tasikan* untuk detail | *.jualikanbot* jual\n`
            }

            if (_invOther.length === 0 && _invRods.length === 0 && _invBaits.length === 0 && _invFish.length === 0) {
                inventoryText += `│▣ kosong melompong...\n`
            }

            inventoryText += `╰──────────❏\n\n`
            inventoryText += `💵 *KEUANGAN & EQUIPMENT*\n╭─❏\n`
            inventoryText += `│▣ 💰 saldo: *${toRupiah(player.gold || 0)}*\n`
            if (player.equipment?.weapon) inventoryText += `│▣ ⚔️ senjata: ${rpgDB.items[player.equipment.weapon]?.name || 'unknown'}\n`
            if (player.equipment?.armor)  inventoryText += `│▣ 🛡️ armor: ${rpgDB.items[player.equipment.armor]?.name || 'unknown'}\n`

            // Fishing equip status
            if (player.fishing) {
                const eRod  = ROD_DATA[player.fishing.equippedRod || 'starter_rod']
                const eBait = player.fishing.equippedBait ? BAIT_DATA[player.fishing.equippedBait] : null
                inventoryText += `│▣\n│▣ 🎣 Joran aktif : ${eRod?.emoji || '🎣'} ${eRod?.name || 'Starter Rod'}\n`
                inventoryText += `│▣ 🪱 Umpan aktif : ${eBait ? `${eBait.emoji} ${eBait.name}` : 'Tidak ada'}\n`
                inventoryText += `│▣ 🎯 Total tangkap: ${player.fishing.totalCatch || 0} ekor\n`
            }

            inventoryText += `╰──────────❏`
            
            return Reply(inventoryText)
        }

        if (command === 'rpgshop') {
            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            const player = rpgDB.players[senderJid]
            const _shopArgs = text ? text.trim().split(' ') : []
            const shopSub = _shopArgs[0]?.toLowerCase()

            const consumables = Object.entries(rpgDB.items).filter(([,i]) => i.type === 'heal' || i.type === 'mana')
            const botFeats    = Object.entries(rpgDB.items).filter(([,i]) => i.type === 'bot_feature')

            if (!shopSub || shopSub === 'menu') {
                return Reply(`
╭─────────────────────❏
│▣   🛒  TOKO PETUALANG  🛒
╰─────────────────────❏
╭─❏
│▣ *.rpgshop senjata*   — ⚔️  Senjata (8 tier s/d God Tier)
│▣ *.rpgshop armor*     — 🛡️  Armor & Perisai (8 tier)
│▣ *.rpgshop potion*    — 🧪  Potion & Elixir (inc. Divine)
│▣ *.rpgshop material*  — 🪨  Daftar harga material
│▣ *.rpgshop fitur*     — 🤖  Fitur bot (s/d 500 limit)
╰──────────❏
💵 Saldo: ${toRupiah(player.gold)}
🛒 Beli: *.buy [id_item] [qty]*  ·  💸 Jual: *.sell [id_item] [qty]*
💡 Contoh: *.buy elixir_hidup 1*  |  *.buy potion 5*`)
            }

            if (shopSub === 'senjata') {
                const weaponTiers = [
                    { tier: "⚔️ Pemula", ids: ["pedang_kayu","busur_kayu"] },
                    { tier: "🗡️ Menengah", ids: ["pedang_besi","busur_besi","tongkat_sihir"] },
                    { tier: "⚡ Mahir", ids: ["pedang_baja","tongkat_kuno","busur_elven"] },
                    { tier: "💠 Langka", ids: ["pedang_mithril"] },
                    { tier: "🔥 Legendaris", ids: ["pedang_naga"] },
                    { tier: "🌟 Ultra", ids: ["tongkat_dewa","busur_abadi","katana_jiwa"] },
                    { tier: "⚡ Epik Dewa", ids: ["tombak_halilintar"] },
                    { tier: "🔱 GOD TIER", ids: ["pedang_dewa"] }
                ]
                let t = `╭─────────────────────❏\n│▣   ⚔️  DAFTAR SENJATA  ⚔️\n╰─────────────────────❏\n╭─❏\n`
                for (const { tier, ids } of weaponTiers) {
                    t += `│▣ ${tier}\n`
                    for (const id of ids) {
                        const item = rpgDB.items[id]
                        if (!item) continue
                        t += `│▣  • *${item.name}* — ${toRupiah(item.price)}\n`
                        t += `│▣    ↳ atk +${item.attack} | ${toRupiah(item.price)} | *.buy ${id}*\n`
                    }
                    t += `│▣\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            if (shopSub === 'armor') {
                const armorTiers = [
                    { tier: "🧥 Pemula", ids: ["baju_kain","perisai_kayu"] },
                    { tier: "🛡️ Menengah", ids: ["zirah_kulit","perisai_besi"] },
                    { tier: "⚙️ Mahir", ids: ["zirah_besi","jubah_penyihir"] },
                    { tier: "💠 Kuat", ids: ["zirah_baja"] },
                    { tier: "🔥 Legendaris", ids: ["zirah_mithril"] },
                    { tier: "🌟 Ultra", ids: ["perisai_naga","jubah_lich"] },
                    { tier: "💎 Dewa", ids: ["zirah_orichalcum"] },
                    { tier: "🔱 GOD TIER", ids: ["zirah_dewa"] }
                ]
                let t = `╭─────────────────────❏\n│▣   🛡️  ARMOR & PERISAI  🛡️\n╰─────────────────────❏\n╭─❏\n`
                for (const { tier, ids } of armorTiers) {
                    t += `│▣ ${tier}\n`
                    for (const id of ids) {
                        const item = rpgDB.items[id]
                        if (!item) continue
                        t += `│▣  • *${item.name}* — ${toRupiah(item.price)}\n`
                        t += `│▣    ↳ def +${item.defense} | ${toRupiah(item.price)} | *.buy ${id}*\n`
                    }
                    t += `│▣\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            if (shopSub === 'potion') {
                let t = `╭─────────────────────❏\n│▣   🧪  POTION & ELIXIR  🧪\n╰─────────────────────❏\n╭─❏\n`
                for (const [id, item] of consumables) {
                    t += `│▣ *${item.name}* — ${toRupiah(item.price)}\n`
                    t += `│▣   ↳ +${item.value >= 999 ? 'FULL' : item.value} ${item.type === 'heal' ? 'hp ❤️' : 'mp 🔵'} | Harga: ${toRupiah(item.price)} | *.buy ${id} [qty]*\n\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            if (shopSub === 'material') {
                const materials = Object.entries(rpgDB.items).filter(([,i]) => i.type === 'material')
                let t = `╭─────────────────────❏\n│▣   🪨  HARGA MATERIAL  🪨\n╰─────────────────────❏\n╭─❏\n│▣ (jual dengan *.sell [id] [qty]* atau *.jualbot item [id]*)\n│▣ 💡 Harga jual = 40% dari harga referensi\n│▣\n`
                for (const [id, item] of materials) {
                    const sellPrice = Math.floor(item.price * 0.4)
                    t += `│▣ *${item.name}* → jual ${toRupiah(sellPrice)}/pcs | id: ${id}\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            if (shopSub === 'fitur') {
                let t = `╭─────────────────────❏\n│▣   🤖  FITUR BOT  🤖\n╰─────────────────────❏\n╭─❏\n`
                for (const [id, item] of botFeats) {
                    t += `│▣ *${item.name}* — ${toRupiah(item.price)}\n`
                    t += `│▣   ↳ +${item.value} limit hari ini | ${toRupiah(item.price)} | *.buy ${id} [qty]*\n\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            return Reply(`❌ kategori gak ada! ketik *.rpgshop* untuk lihat menu.`)
        }

        if (command === 'buy') {
            
                

            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            if (!text) {
                return Reply(`Gunakan: .buy [nama_item]\nContoh: .buy potion`)
            }
            const player = rpgDB.players[senderJid]
            // FIX: parse argumen dengan benar — "elixir_hidup 2" → itemId="elixir_hidup", qty=2
            const buyParts = text.trim().split(/\s+/)
            const itemId   = buyParts[0].toLowerCase()
            const buyQty   = Math.max(1, parseInt(buyParts[1]) || 1)

            // FIX: cari item secara fleksibel — coba exact match dulu, lalu fuzzy (spasi → underscore)
            const itemIdNorm = itemId.replace(/-/g, '_')
            if (!rpgDB.items[itemIdNorm]) {
                // Coba cari berdasarkan nama (jika user ketik nama bukan id)
                const matchByName = Object.entries(rpgDB.items).find(([,it]) =>
                    it.name.toLowerCase() === text.trim().toLowerCase() ||
                    it.name.toLowerCase().replace(/\s+/g, '_') === itemIdNorm
                )
                if (!matchByName) {
                    // Saran item terdekat
                    const allIds = Object.keys(rpgDB.items)
                    const similar = allIds.filter(id => id.includes(itemIdNorm) || itemIdNorm.includes(id.split('_')[0]))
                    const saranText = similar.length ? `\n💡 Maksud kamu: *${similar.slice(0,3).join(', ')}*?` : ''
                    return Reply(`❌ Item *${itemId}* tidak ada di toko! Cek *.rpgshop*${saranText}`)
                }
                // Gunakan match yang ditemukan
                const [foundId, foundItem] = matchByName
                if (player.gold < foundItem.price * buyQty) {
                    return Reply(`❌ Uang kurang! Butuh ${toRupiah(foundItem.price * buyQty)}, punya ${toRupiah(player.gold)}\n💸 Kurang: ${toRupiah(foundItem.price * buyQty - player.gold)}`)
                }
                player.gold -= foundItem.price * buyQty
                if (!player.inventory) player.inventory = {}
                player.inventory[foundId] = (player.inventory[foundId] || 0) + buyQty
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣  ✅  PEMBELIAN BERHASIL!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🛍️ Item   : ${foundItem.name} x${buyQty}\n│▣ 💵 Harga  : ${toRupiah(foundItem.price * buyQty)}\n│▣ 💰 Sisa   : ${toRupiah(player.gold)}\n╰──────────❏`)
            }
            const item     = rpgDB.items[itemIdNorm]
            const totalHarga = item.price * buyQty
            if (player.gold < totalHarga) {
                return Reply(`❌ Uang kurang! Butuh ${toRupiah(totalHarga)}, punya ${toRupiah(player.gold)}\n💸 Kurang: ${toRupiah(totalHarga - player.gold)}`)
            }
            player.gold -= totalHarga
            if (item.type === 'bot_feature') {
                // bot_feature tidak support beli banyak sekaligus
                addLimitToBonus(m.sender, item.value * buyQty)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣  ✅  PEMBELIAN BERHASIL!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🛍️ Item   : ${item.name} x${buyQty}\n│▣ 💵 Harga  : ${toRupiah(totalHarga)}\n│▣ 🎁 Bonus  : +${item.value * buyQty} limit bot hari ini\n╰──────────❏`)
            } else {
                if (!player.inventory) player.inventory = {}
                player.inventory[itemIdNorm] = (player.inventory[itemIdNorm] || 0) + buyQty
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣  ✅  PEMBELIAN BERHASIL!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🛍️ Item   : ${item.name} x${buyQty}\n│▣ 💵 Harga  : ${toRupiah(totalHarga)}\n│▣ 💰 Sisa   : ${toRupiah(player.gold)}\n╰──────────❏`)
            }
        }

        if (command === 'sell') {
            
                

            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            if (!text) {
                return Reply(`Gunakan: .sell [nama_item] [jumlah]\nContoh: .sell potion 1\nCek inventory di *.rpginv*`)
            }
            const player = rpgDB.players[senderJid]
            const sellParts = text.trim().split(/\s+/)
            // FIX: jika arg terakhir angka → qty, sisanya adalah item_id
            let sellItemId, sellAmount
            const lastArg = sellParts[sellParts.length - 1]
            if (sellParts.length > 1 && /^\d+$/.test(lastArg)) {
                sellAmount = parseInt(lastArg)
                sellItemId = sellParts.slice(0, -1).join('_').toLowerCase()
            } else {
                sellAmount = 1
                sellItemId = sellParts.join('_').toLowerCase()
            }
            const itemId = sellItemId
            const amount = Math.max(1, sellAmount)

            // Fungsi hitung harga jual berdasarkan tipe item
            function getSellMultiplier(itemKey, itemData) {
                if (!itemData) return 0.4
                // Material dari drop monster/mining → 40%
                if (itemData.type === 'material') return 0.4
                // Weapon/armor dari shop (bisa dibeli langsung) → 50%
                // Weapon/armor dari craft → 35% (karena bahan-bahan sudah gratis dari drop)
                if (itemData.type === 'weapon' || itemData.type === 'armor') {
                    // Cek apakah ada di crafting recipes sebagai hasil
                    const isCrafted = Object.values(rpgDB.craftingRecipes || {}).some(r => r.result === itemKey)
                    return isCrafted ? 0.35 : 0.50
                }
                // Potion/elixir → 30% (banyak harganya murah, jangan abuse sell)
                if (itemData.type === 'heal' || itemData.type === 'mana') return 0.30
                return 0.40
            }

            if (!rpgDB.items[itemId]) {
                // Coba cari tanpa normalisasi
                const byName = Object.entries(rpgDB.items).find(([,it]) => it.name.toLowerCase() === text.replace(/\s*\d+$/, '').trim().toLowerCase())
                if (!byName) return Reply(`❌ Item *${itemId}* tidak ada!\n💡 Cek inventory: *.rpginv* | Cek ID item: *.rpgshop*`)
                const [foundSellId, foundSellItem] = byName
                if (!player.inventory?.[foundSellId] || player.inventory[foundSellId] < amount) {
                    return Reply(`❌ Item kurang! Punya: ${player.inventory?.[foundSellId] || 0}, mau jual: ${amount}`)
                }
                const mult = getSellMultiplier(foundSellId, foundSellItem)
                const foundSellPrice = Math.floor(foundSellItem.price * mult) * amount
                player.gold += foundSellPrice
                player.inventory[foundSellId] -= amount
                if (player.inventory[foundSellId] <= 0) delete player.inventory[foundSellId]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣  💰  ITEM TERJUAL!  💰\n╰─────────────────────❏\n╭─❏\n│▣ 🛍️ Item   : ${foundSellItem.name} x${amount}\n│▣ 💵 Dapet  : ${toRupiah(foundSellPrice)} (${Math.round(mult*100)}% harga)\n│▣ 💰 Saldo  : ${toRupiah(player.gold)}\n╰──────────❏`)
            }
            if (!player.inventory || !player.inventory[itemId] || player.inventory[itemId] < amount) {
                return Reply(`❌ lu gak punya ${itemId} x${amount} di inventory! punya: ${player.inventory?.[itemId] || 0}`)
            }
            const item = rpgDB.items[itemId]
            const mult = getSellMultiplier(itemId, item)
            const sellPrice = Math.floor(item.price * mult) * amount
            player.gold += sellPrice
            player.inventory[itemId] -= amount
            if (player.inventory[itemId] <= 0) {
                delete player.inventory[itemId]
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            return Reply(`
╭─────────────────────❏
│▣  💰  ITEM TERJUAL!  💰
╰─────────────────────❏
╭─❏
│▣ 🛍️ Item   : ${item.name} x${amount}
│▣ 💵 Dapet  : ${toRupiah(sellPrice)} (${Math.round(mult*100)}% harga)
│▣ 💰 Saldo  : ${toRupiah(player.gold)}
╰──────────❏`)
        }

        // ─── JUALBOT — Jual semua jenis barang ke sistem bot ────────────────
        if (command === 'jualbot') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]

            // ── Tampilkan menu jika tidak ada argumen ──
            if (!text) {
                // Hitung ringkasan inventori untuk preview
                const invItems  = Object.entries(player.inventory || {}).filter(([k,v]) => !k.startsWith('fish_') && !k.startsWith('rod_') && !k.startsWith('bait_') && v > 0 && rpgDB.items[k])
                const invFish   = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('fish_') && v > 0)
                const invRods   = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('rod_') && v > 0)
                const invBaits  = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('bait_') && v > 0)
                const hasPet    = !!player.pet
                const equippedRod  = player.fishing?.equippedRod
                const equippedBait = player.fishing?.equippedBait
                // Hitung estimasi total nilai
                let estTotal = 0
                for (const [k,v] of invItems) {
                    const price = rpgDB.items[k]?.price || 0
                    estTotal += Math.floor(price * 0.5) * v
                }
                for (const [k,v] of invFish) {
                    const { fishId: baseId, mutationId: mutId } = parseFishKey(k)
                    const fishDat = baseId ? FISH_DATA[baseId] : null
                    const mutDat  = mutId ? MUTATION_DATA[mutId] : null
                    const price  = fishDat ? (mutDat ? Math.floor(fishDat.basePrice * mutDat.multiplier) : fishDat.basePrice) : 0
                    estTotal += price * v
                }
                for (const [k,v] of invRods) {
                    const rodId = k.replace('rod_', '')
                    if (rodId === equippedRod) continue // skip yang sedang diequip
                    const rodPrice = ROD_DATA[rodId]?.price || 0
                    estTotal += Math.floor(rodPrice * 0.4) * v
                }
                for (const [k,v] of invBaits) {
                    const baitId = k.replace('bait_', '')
                    if (baitId === equippedBait) continue
                    const baitPrice = BAIT_DATA[baitId]?.price || 0
                    estTotal += Math.floor(baitPrice * 0.4) * v
                }
                if (hasPet) {
                    const petSellPrice = rpgDB.petData[player.pet?.id]?.cost || 0
                    estTotal += Math.floor(petSellPrice * 0.3)
                }
                let menuText = `╭─────────────────────❏
│▣   🏪  JUAL KE BOT  🏪
╰─────────────────────❏
╭─❏
│▣ Pilih kategori yang mau dijual:
│▣
│▣ 📦 *.jualbot item [id] [qty]*
│▣    Jual weapon/armor/potion/material
│▣    Harga: 50% dari harga beli
│▣
│▣ 🎣 *.jualbot pancing [id] [qty]*
│▣    Jual joran dari inventory
│▣    (Joran aktif tidak bisa dijual)
│▣    Harga: 40% dari harga beli
│▣
│▣ 🪱 *.jualbot umpan [id] [qty]*
│▣    Jual umpan dari inventory
│▣    (Umpan aktif tidak bisa dijual)
│▣    Harga: 40% dari harga beli
│▣
│▣ 🐾 *.jualbot pet*
│▣    Jual hewan peliharaan
│▣    Harga: 30% dari harga adopsi
│▣
│▣ 🐟 *.jualbot ikan*
│▣    Jual semua ikan (sama dengan .jualikanbot)
│▣    Harga: nilai pasar ikan
│▣
│▣ 💰 *.jualbot semua*
│▣    Jual SEMUA barang sekaligus!
│▣    (kecuali item yg sedang diequip)
│▣
╰──────────❏
📊 *Estimasi total jika jual semua: ${toRupiah(estTotal)}*
📦 Item: ${invItems.length} jenis | 🎣 Joran: ${invRods.length} | 🪱 Umpan: ${invBaits.length}
🐟 Ikan: ${invFish.length} jenis | 🐾 Pet: ${hasPet ? player.pet.name : 'tidak ada'}`
                return Reply(menuText)
            }

            const jualArgs = text.trim().split(' ')
            const jualKategori = jualArgs[0].toLowerCase()

            // ── JUAL ITEM (weapon/armor/potion/material) ──────────────────
            if (jualKategori === 'item') {
                if (!jualArgs[1]) {
                    // Tampilkan semua item yang bisa dijual
                    const sellableItems = Object.entries(player.inventory || {}).filter(([k,v]) => {
                        return v > 0 && rpgDB.items[k] && 
                               k !== player.equipment?.weapon &&
                               k !== player.equipment?.armor
                    })
                    if (sellableItems.length === 0) return Reply(`❌ Tidak ada item di inventory yang bisa dijual!\n(Item yang sedang diequip tidak bisa dijual)`)
                    let listTxt = `╭─────────────────────❏\n│▣   📦  DAFTAR ITEM BISA DIJUAL  📦\n╰─────────────────────❏\n╭─❏\n`
                    let totalEst = 0
                    for (const [k, v] of sellableItems) {
                        const it = rpgDB.items[k]
                        const isCrafted = Object.values(rpgDB.craftingRecipes || {}).some(r => r.result === k)
                        let m = it.type === 'material' ? 0.4 : (it.type === 'weapon' || it.type === 'armor') ? (isCrafted ? 0.35 : 0.50) : (it.type === 'heal' || it.type === 'mana') ? 0.30 : 0.40
                        const unitPrice = Math.floor((it.price || 0) * m)
                        const total = unitPrice * v
                        totalEst += total
                        listTxt += `│▣ ${it.name} x${v} → ${toRupiah(total)} (${Math.round(m*100)}%)\n`
                    }
                    listTxt += `╰──────────❏\n💰 Total estimasi: *${toRupiah(totalEst)}*\n`
                    listTxt += `▶ *.jualbot item [id] [qty]* — jual spesifik\n▶ *.jualbot item semua* — jual semua item`
                    return Reply(listTxt)
                }
                if (jualArgs[1] === 'semua') {
                    // Jual semua item kecuali yang diequip
                    const sellItems = Object.entries(player.inventory || {}).filter(([k,v]) => {
                        return v > 0 && rpgDB.items[k] &&
                               k !== player.equipment?.weapon &&
                               k !== player.equipment?.armor
                    })
                    if (sellItems.length === 0) return Reply(`❌ Tidak ada item yang bisa dijual!`)
                    let totalGold = 0
                    let soldList = []
                    for (const [k, v] of sellItems) {
                        const it = rpgDB.items[k]
                        const isCrafted = Object.values(rpgDB.craftingRecipes || {}).some(r => r.result === k)
                        let m = it.type === 'material' ? 0.4 : (it.type === 'weapon' || it.type === 'armor') ? (isCrafted ? 0.35 : 0.50) : (it.type === 'heal' || it.type === 'mana') ? 0.30 : 0.40
                        const earned = Math.floor((it.price || 0) * m) * v
                        totalGold += earned
                        soldList.push(`${it.name} x${v} → ${toRupiah(earned)}`)
                        delete player.inventory[k]
                    }
                    player.gold += totalGold
                    fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                    let resTxt = `╭─────────────────────❏\n│▣   💰  SEMUA ITEM TERJUAL!  💰\n╰─────────────────────❏\n╭─❏\n`
                    soldList.slice(0, 10).forEach(s => resTxt += `│▣ ✅ ${s}\n`)
                    if (soldList.length > 10) resTxt += `│▣ ... dan ${soldList.length - 10} item lainnya\n`
                    resTxt += `│▣\n│▣ 💵 Total Dapet : *${toRupiah(totalGold)}*\n│▣ 💰 Saldo      : *${toRupiah(player.gold)}*\n╰──────────❏`
                    return Reply(resTxt)
                }
                // Jual item spesifik
                const jualItemId = jualArgs[1].toLowerCase()
                const jualQty    = parseInt(jualArgs[2]) || 1
                if (!rpgDB.items[jualItemId]) return Reply(`❌ Item *${jualItemId}* tidak ditemukan!\n💡 Cek inventory: *.rpginv*`)
                if (jualItemId === player.equipment?.weapon) return Reply(`❌ *${rpgDB.items[jualItemId].name}* sedang diequip sebagai senjata!\nLepas dulu: *.unequip weapon*`)
                if (jualItemId === player.equipment?.armor)  return Reply(`❌ *${rpgDB.items[jualItemId].name}* sedang diequip sebagai armor!\nLepas dulu: *.unequip armor*`)
                if (!player.inventory?.[jualItemId] || player.inventory[jualItemId] < jualQty) {
                    return Reply(`❌ Item tidak cukup! Punya: ${player.inventory?.[jualItemId] || 0}, mau jual: ${jualQty}`)
                }
                const jualIt   = rpgDB.items[jualItemId]
                const jualIsCrafted = Object.values(rpgDB.craftingRecipes || {}).some(r => r.result === jualItemId)
                const jualMult = jualIt.type === 'material' ? 0.4 : (jualIt.type === 'weapon' || jualIt.type === 'armor') ? (jualIsCrafted ? 0.35 : 0.50) : (jualIt.type === 'heal' || jualIt.type === 'mana') ? 0.30 : 0.40
                const jualEarned = Math.floor((jualIt.price || 0) * jualMult) * jualQty
                player.inventory[jualItemId] -= jualQty
                if (player.inventory[jualItemId] <= 0) delete player.inventory[jualItemId]
                player.gold += jualEarned
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   💰  ITEM TERJUAL!  💰\n╰─────────────────────❏\n╭─❏\n│▣ 📦 Item   : *${jualIt.name}* x${jualQty}\n│▣ 💵 Dapet  : *${toRupiah(jualEarned)}* (${Math.round(jualMult*100)}%)\n│▣ 💰 Saldo  : *${toRupiah(player.gold)}*\n╰──────────❏`)
            }

            // ── JUAL PANCING / JORAN ──────────────────────────────────────
            if (jualKategori === 'pancing' || jualKategori === 'joran') {
                const equippedRodId = player.fishing?.equippedRod || 'starter_rod'
                if (!jualArgs[1]) {
                    const ownedRods = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('rod_') && v > 0)
                    if (ownedRods.length === 0) return Reply(`❌ Tidak ada joran di inventory!`)
                    let listTxt = `╭─────────────────────❏\n│▣   🎣  DAFTAR JORAN BISA DIJUAL  🎣\n╰─────────────────────❏\n╭─❏\n│▣ 🎣 Aktif: *${ROD_DATA[equippedRodId]?.name || 'Starter Rod'}* (tidak bisa dijual)\n│▣\n`
                    let estTotal = 0
                    for (const [k, v] of ownedRods) {
                        const rodId = k.replace('rod_', '')
                        if (rodId === equippedRodId) { listTxt += `│▣ ⛔ ${ROD_DATA[rodId]?.emoji || '🎣'} ${ROD_DATA[rodId]?.name || rodId} x${v} (sedang dipakai)\n`; continue }
                        const rod = ROD_DATA[rodId]
                        const unitPrice = Math.floor((rod?.price || 0) * 0.4)
                        const total = unitPrice * v
                        estTotal += total
                        listTxt += `│▣ ${rod?.emoji || '🎣'} *${rod?.name || rodId}* x${v} → ${toRupiah(total)}\n`
                        listTxt += `│▣     ↳ *.jualbot pancing ${rodId} ${v}*\n`
                    }
                    listTxt += `╰──────────❏\n💰 Est. total: *${toRupiah(estTotal)}*\n▶ *.jualbot pancing semua* — jual semua (kecuali aktif)`
                    return Reply(listTxt)
                }
                if (jualArgs[1] === 'semua') {
                    const rodEntries = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('rod_') && v > 0 && k.replace('rod_','') !== equippedRodId)
                    if (rodEntries.length === 0) return Reply(`❌ Tidak ada joran yang bisa dijual (joran aktif tidak bisa dijual)!`)
                    let totalGold = 0; let soldList = []
                    for (const [k, v] of rodEntries) {
                        const rodId = k.replace('rod_', '')
                        const rod = ROD_DATA[rodId]
                        const earned = Math.floor((rod?.price || 0) * 0.4) * v
                        totalGold += earned
                        soldList.push(`${rod?.emoji || '🎣'} ${rod?.name || rodId} x${v} → ${toRupiah(earned)}`)
                        delete player.inventory[k]
                    }
                    player.gold += totalGold
                    fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                    let resTxt = `╭─────────────────────❏\n│▣   🎣  JORAN TERJUAL!  🎣\n╰─────────────────────❏\n╭─❏\n`
                    soldList.forEach(s => resTxt += `│▣ ✅ ${s}\n`)
                    resTxt += `│▣\n│▣ 💵 Total Dapet : *${toRupiah(totalGold)}*\n│▣ 💰 Saldo      : *${toRupiah(player.gold)}*\n╰──────────❏`
                    return Reply(resTxt)
                }
                const jualRodId  = jualArgs[1].toLowerCase()
                const jualRodQty = parseInt(jualArgs[2]) || 1
                if (jualRodId === equippedRodId) return Reply(`❌ *${ROD_DATA[jualRodId]?.name || jualRodId}* sedang dipakai! Ganti joran aktif dulu di *.shoprod pasang [id]*`)
                if (!ROD_DATA[jualRodId]) return Reply(`❌ Joran *${jualRodId}* tidak dikenal!`)
                const rodInvKey = `rod_${jualRodId}`
                if (!player.inventory?.[rodInvKey] || player.inventory[rodInvKey] < jualRodQty) {
                    return Reply(`❌ Joran tidak cukup! Punya: ${player.inventory?.[rodInvKey] || 0}, mau jual: ${jualRodQty}`)
                }
                const rodData   = ROD_DATA[jualRodId]
                const rodEarned = Math.floor((rodData.price || 0) * 0.4) * jualRodQty
                player.inventory[rodInvKey] -= jualRodQty
                if (player.inventory[rodInvKey] <= 0) delete player.inventory[rodInvKey]
                player.gold += rodEarned
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   🎣  JORAN TERJUAL!  🎣\n╰─────────────────────❏\n╭─❏\n│▣ 🎣 Joran  : *${rodData.emoji} ${rodData.name}* x${jualRodQty}\n│▣ 💵 Dapet  : *${toRupiah(rodEarned)}*\n│▣ 💰 Saldo  : *${toRupiah(player.gold)}*\n╰──────────❏`)
            }

            // ── JUAL UMPAN / BAIT ─────────────────────────────────────────
            if (jualKategori === 'umpan' || jualKategori === 'bait') {
                const equippedBaitId = player.fishing?.equippedBait || null
                if (!jualArgs[1]) {
                    const ownedBaits = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('bait_') && v > 0)
                    if (ownedBaits.length === 0) return Reply(`❌ Tidak ada umpan di inventory!`)
                    let listTxt = `╭─────────────────────❏\n│▣   🪱  DAFTAR UMPAN BISA DIJUAL  🪱\n╰─────────────────────❏\n╭─❏\n`
                    if (equippedBaitId) listTxt += `│▣ 🪱 Aktif: *${BAIT_DATA[equippedBaitId]?.name || equippedBaitId}* (tidak bisa dijual)\n│▣\n`
                    let estTotal = 0
                    for (const [k, v] of ownedBaits) {
                        const baitId = k.replace('bait_', '')
                        if (baitId === equippedBaitId) { listTxt += `│▣ ⛔ ${BAIT_DATA[baitId]?.emoji || '🪱'} ${BAIT_DATA[baitId]?.name || baitId} x${v} (aktif)\n`; continue }
                        const bait = BAIT_DATA[baitId]
                        const unitPrice = Math.floor((bait?.price || 0) * 0.4)
                        const total = unitPrice * v
                        estTotal += total
                        listTxt += `│▣ ${bait?.emoji || '🪱'} *${bait?.name || baitId}* x${v} → ${toRupiah(total)}\n`
                        listTxt += `│▣     ↳ *.jualbot umpan ${baitId} ${v}*\n`
                    }
                    listTxt += `╰──────────❏\n💰 Est. total: *${toRupiah(estTotal)}*\n▶ *.jualbot umpan semua* — jual semua (kecuali aktif)`
                    return Reply(listTxt)
                }
                if (jualArgs[1] === 'semua') {
                    const baitEntries = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('bait_') && v > 0 && k.replace('bait_','') !== equippedBaitId)
                    if (baitEntries.length === 0) return Reply(`❌ Tidak ada umpan yang bisa dijual (umpan aktif tidak bisa dijual)!`)
                    let totalGold = 0; let soldList = []
                    for (const [k, v] of baitEntries) {
                        const baitId = k.replace('bait_', '')
                        const bait = BAIT_DATA[baitId]
                        const earned = Math.floor((bait?.price || 0) * 0.4) * v
                        totalGold += earned
                        soldList.push(`${bait?.emoji || '🪱'} ${bait?.name || baitId} x${v} → ${toRupiah(earned)}`)
                        delete player.inventory[k]
                    }
                    player.gold += totalGold
                    fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                    let resTxt = `╭─────────────────────❏\n│▣   🪱  UMPAN TERJUAL!  🪱\n╰─────────────────────❏\n╭─❏\n`
                    soldList.forEach(s => resTxt += `│▣ ✅ ${s}\n`)
                    resTxt += `│▣\n│▣ 💵 Total Dapet : *${toRupiah(totalGold)}*\n│▣ 💰 Saldo      : *${toRupiah(player.gold)}*\n╰──────────❏`
                    return Reply(resTxt)
                }
                const jualBaitId  = jualArgs[1].toLowerCase()
                const jualBaitQty = parseInt(jualArgs[2]) || 1
                if (jualBaitId === equippedBaitId) return Reply(`❌ *${BAIT_DATA[jualBaitId]?.name || jualBaitId}* sedang dipakai! Lepas umpan aktif dulu di *.shopbomber lepas*`)
                if (!BAIT_DATA[jualBaitId]) return Reply(`❌ Umpan *${jualBaitId}* tidak dikenal!`)
                const baitInvKey = `bait_${jualBaitId}`
                if (!player.inventory?.[baitInvKey] || player.inventory[baitInvKey] < jualBaitQty) {
                    return Reply(`❌ Umpan tidak cukup! Punya: ${player.inventory?.[baitInvKey] || 0}, mau jual: ${jualBaitQty}`)
                }
                const baitData   = BAIT_DATA[jualBaitId]
                const baitEarned = Math.floor((baitData.price || 0) * 0.4) * jualBaitQty
                player.inventory[baitInvKey] -= jualBaitQty
                if (player.inventory[baitInvKey] <= 0) delete player.inventory[baitInvKey]
                player.gold += baitEarned
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   🪱  UMPAN TERJUAL!  🪱\n╰─────────────────────❏\n╭─❏\n│▣ 🪱 Umpan  : *${baitData.emoji} ${baitData.name}* x${jualBaitQty}\n│▣ 💵 Dapet  : *${toRupiah(baitEarned)}*\n│▣ 💰 Saldo  : *${toRupiah(player.gold)}*\n╰──────────❏`)
            }

            // ── JUAL PET / HEWAN PELIHARAAN ───────────────────────────────
            if (jualKategori === 'pet' || jualKategori === 'peliharaan') {
                if (!player.pet) return Reply(`❌ Kamu tidak punya hewan peliharaan!\n💡 Adopsi pet: *.adopsipet*`)
                const petRef     = rpgDB.petData[player.pet.id]
                const petCost    = petRef?.cost || 0
                const petSellPrice = Math.floor(petCost * 0.3)
                const petName    = player.pet.name
                const petTier    = petRef?.tier || '?'
                // Konfirmasi jual (jika ada argumen 'ya' / 'yes')
                if (!jualArgs[1] || (jualArgs[1] !== 'ya' && jualArgs[1] !== 'yes' && jualArgs[1] !== 'confirm')) {
                    return Reply(`╭─────────────────────❏
│▣   🐾  JUAL PET?  🐾
╰─────────────────────❏
╭─❏
│▣ 🐾 Pet     : *${petName}*
│▣ 🏷️  Tier    : ${petTier}
│▣ ⚔️  ATK     : +${player.pet.attack || 0}
│▣ 🛡️  DEF     : +${player.pet.defense || 0}
│▣ 📈 Level   : ${player.pet.level || 1}
│▣
│▣ 💰 Harga beli : ${toRupiah(petCost)}
│▣ 💵 Harga jual : *${toRupiah(petSellPrice)}* (30%)
╰──────────❏
⚠️ Pet yang dijual TIDAK BISA dikembalikan!
Ketik *.jualbot pet ya* untuk konfirmasi.`)
                }
                player.gold += petSellPrice
                delete player.pet
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏
│▣   🐾  PET TERJUAL!  🐾
╰─────────────────────❏
╭─❏
│▣ 🐾 Pet    : *${petName}*
│▣ 💵 Dapet  : *${toRupiah(petSellPrice)}*
│▣ 💰 Saldo  : *${toRupiah(player.gold)}*
╰──────────❏
😢 Selamat tinggal, ${petName}...`)
            }

            // ── JUAL IKAN ─────────────────────────────────────────────────
            if (jualKategori === 'ikan' || jualKategori === 'fish') {
                const fishEntries = Object.entries(player.inventory || {}).filter(([k,v]) => k.startsWith('fish_') && v > 0)
                if (fishEntries.length === 0) return Reply(`❌ Tidak ada ikan di inventory!\n🎣 Mulai mancing: *.mancing*`)
                let totalGold = 0; let soldCount = 0; let soldList = []
                for (const [k, v] of fishEntries) {
                    const { fishId: baseId, mutationId: mutId } = parseFishKey(k)
                    const fishDat = baseId ? FISH_DATA[baseId] : null
                    const mutDat  = mutId ? MUTATION_DATA[mutId] : null
                    const price   = fishDat ? (mutDat ? Math.floor(fishDat.basePrice * mutDat.multiplier) : fishDat.basePrice) : 0
                    const earned  = price * v
                    totalGold += earned; soldCount += v
                    soldList.push(`${fishDat?.emoji || '🐟'} ${fishDat?.name || baseId}${mutDat ? ' ['+mutDat.name+']' : ''} x${v} → ${toRupiah(earned)}`)
                    delete player.inventory[k]
                }
                player.gold += totalGold
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                let resTxt = `╭─────────────────────❏\n│▣   🐟  IKAN TERJUAL!  🐟\n╰─────────────────────❏\n╭─❏\n`
                soldList.slice(0, 10).forEach(s => resTxt += `│▣ ✅ ${s}\n`)
                if (soldList.length > 10) resTxt += `│▣ ... dan ${soldList.length - 10} jenis lainnya\n`
                resTxt += `│▣\n│▣ 🐟 Total ikan  : ${soldCount} ekor\n│▣ 💵 Total Dapet  : *${toRupiah(totalGold)}*\n│▣ 💰 Saldo        : *${toRupiah(player.gold)}*\n╰──────────❏`
                return Reply(resTxt)
            }

            // ── JUAL SEMUA SEKALIGUS ──────────────────────────────────────
            if (jualKategori === 'semua') {
                const equippedRodId  = player.fishing?.equippedRod || 'starter_rod'
                const equippedBaitId = player.fishing?.equippedBait || null
                let grandTotal = 0; let soldSummary = {}

                // Jual semua item biasa (kecuali yang diequip)
                for (const [k, v] of Object.entries(player.inventory || {})) {
                    if (v <= 0) continue
                    if (k === player.equipment?.weapon || k === player.equipment?.armor) continue
                    if (k.startsWith('fish_')) {
                        const { fishId: baseId, mutationId: mutId } = parseFishKey(k)
                        const fishDat = baseId ? FISH_DATA[baseId] : null
                        const mutDat  = mutId ? MUTATION_DATA[mutId] : null
                        const price   = fishDat ? (mutDat ? Math.floor(fishDat.basePrice * mutDat.multiplier) : fishDat.basePrice) : 0
                        grandTotal += price * v
                        soldSummary['ikan'] = (soldSummary['ikan'] || 0) + v
                        delete player.inventory[k]
                    } else if (k.startsWith('rod_')) {
                        const rodId = k.replace('rod_', '')
                        if (rodId === equippedRodId) continue
                        const earned = Math.floor((ROD_DATA[rodId]?.price || 0) * 0.4) * v
                        grandTotal += earned
                        soldSummary['joran'] = (soldSummary['joran'] || 0) + v
                        delete player.inventory[k]
                    } else if (k.startsWith('bait_')) {
                        const baitId = k.replace('bait_', '')
                        if (baitId === equippedBaitId) continue
                        const earned = Math.floor((BAIT_DATA[baitId]?.price || 0) * 0.4) * v
                        grandTotal += earned
                        soldSummary['umpan'] = (soldSummary['umpan'] || 0) + v
                        delete player.inventory[k]
                    } else if (rpgDB.items[k]) {
                        const earned = Math.floor((rpgDB.items[k].price || 0) * 0.5) * v
                        grandTotal += earned
                        soldSummary['item'] = (soldSummary['item'] || 0) + v
                        delete player.inventory[k]
                    }
                }
                player.gold += grandTotal
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                let resTxt = `╭─────────────────────❏\n│▣   💰  JUAL SEMUA SELESAI!  💰\n╰─────────────────────❏\n╭─❏\n`
                if (soldSummary.item)  resTxt += `│▣ 📦 Item       : ${soldSummary.item} pcs terjual\n`
                if (soldSummary.joran) resTxt += `│▣ 🎣 Joran      : ${soldSummary.joran} pcs terjual\n`
                if (soldSummary.umpan) resTxt += `│▣ 🪱 Umpan      : ${soldSummary.umpan} pcs terjual\n`
                if (soldSummary.ikan)  resTxt += `│▣ 🐟 Ikan       : ${soldSummary.ikan} ekor terjual\n`
                if (!Object.keys(soldSummary).length) { resTxt += `│▣ ❌ Tidak ada yang bisa dijual!\n│▣ (Item yang diequip tidak ikut terjual)\n` }
                resTxt += `│▣\n│▣ 💵 Total Dapet : *${toRupiah(grandTotal)}*\n│▣ 💰 Saldo      : *${toRupiah(player.gold)}*\n╰──────────❏`
                if (soldSummary.item || soldSummary.joran || soldSummary.umpan || soldSummary.ikan) {
                    resTxt += `\n⚠️ Equipment yang diequip tidak ikut terjual.`
                }
                return Reply(resTxt)
            }

            // Argumen tidak dikenal
            return Reply(`❌ Kategori tidak dikenal: *${jualKategori}*\n\nPilihan: *item*, *pancing*, *umpan*, *pet*, *ikan*, *semua*\nKetik *.jualbot* untuk lihat menu lengkap.`)
        }

        if (command === 'use') {
            
                

            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            if (!text) {
                return Reply(`Gunakan: .use [nama_item]\nContoh: .use potion`)
            }
            const player = rpgDB.players[senderJid]
            const itemId = text.toLowerCase()
            if (!player.inventory || !player.inventory[itemId] || player.inventory[itemId] < 1) {
                return Reply(`❌ lu gak punya "${itemId}" di inventory!`)
            }
            if (!rpgDB.items[itemId]) {
                return Reply(`❌ item "${itemId}" gak valid!`)
            }
            const item = rpgDB.items[itemId]
            // Validasi tipe item sebelum dipakai (FIX: item tidak berkurang jika tidak valid)
            if (item.type === 'weapon' || item.type === 'armor') {
                return Reply(`⚔️ *${item.name}* adalah equipment!\n💡 Gunakan *.equip ${itemId}* untuk memakainya.`)
            }
            if (item.type === 'material') {
                return Reply(`🪨 *${item.name}* adalah material crafting!\n💡 Gunakan *.craft* untuk membuat item dari bahan ini.`)
            }
            if (item.type === 'bot_feature') {
                return Reply(`🤖 *${item.name}* adalah item fitur bot!\n💡 Item ini hanya bisa diaktifkan melalui sistem bot secara otomatis.`)
            }
            if (item.type !== 'heal' && item.type !== 'mana') {
                return Reply(`❌ Item *${item.name}* (tipe: ${item.type}) tidak bisa dipakai langsung!`)
            }
            let useText = `╭─────────────────────❏\n│▣   ✨  PAKAI ITEM  ✨\n╰─────────────────────❏\n╭─❏\n│▣ 🧪 Item   : *${item.name}*\n`
            switch (item.type) {
                case 'heal': {
                    const hpBefore = player.hp
                    player.hp = Math.min(player.maxHp, player.hp + item.value)
                    const hpGained = player.hp - hpBefore
                    useText += `│▣ ❤️ HP pulih +${hpGained} point!\n│▣ 🫵 HP sekarang: ${player.hp}/${player.maxHp}\n`
                    break
                }
                case 'mana': {
                    const mpBefore = player.mp
                    player.mp = Math.min(player.maxMp, player.mp + item.value)
                    const mpGained = player.mp - mpBefore
                    useText += `│▣ 🔵 MP pulih +${mpGained} point!\n│▣ 🫵 MP sekarang: ${player.mp}/${player.maxMp}\n`
                    break
                }
            }
            useText += `╰──────────❏`
            player.inventory[itemId] -= 1
            if (player.inventory[itemId] <= 0) {
                delete player.inventory[itemId]
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            return Reply(useText)
        }

        // ─── BUANG / DROP ITEM ───────────────────────────────────────────
        if (command === 'drop' || command === 'buang') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            if (!text) return Reply(`Gunakan: .drop [item_id] [jumlah]\nContoh: .drop potion 2\nAtau: .drop kulit_goblin 5\n\nCek inventory: *.rpginv*`)
            const player = rpgDB.players[senderJid]
            const dropArgs = text.trim().split(' ')
            const dropItemId = dropArgs[0].toLowerCase()
            const dropAmount = parseInt(dropArgs[1]) || 1

            if (dropAmount <= 0 || isNaN(dropAmount)) return Reply(`❌ Jumlah harus lebih dari 0!`)

            if (!player.inventory || !player.inventory[dropItemId] || player.inventory[dropItemId] < 1) {
                return Reply(`❌ Kamu tidak punya item *${dropItemId}* di inventory!\n💡 Cek inventory dengan *.rpginv*`)
            }
            if (player.inventory[dropItemId] < dropAmount) {
                return Reply(`❌ Kamu hanya punya *${dropItemId}* x${player.inventory[dropItemId]}, tidak cukup untuk dibuang ${dropAmount}x!`)
            }
            // Cegah buang item yang sedang diequip
            if (player.equipment) {
                if (player.equipment.weapon === dropItemId) return Reply(`❌ Item *${dropItemId}* sedang dipakai sebagai senjata!\n💡 Lepas dulu dengan *.unequip weapon*`)
                if (player.equipment.armor === dropItemId) return Reply(`❌ Item *${dropItemId}* sedang dipakai sebagai armor!\n💡 Lepas dulu dengan *.unequip armor*`)
            }

            const dropItemData = rpgDB.items[dropItemId]
            const dropItemName = dropItemData ? dropItemData.name : dropItemId

            player.inventory[dropItemId] -= dropAmount
            if (player.inventory[dropItemId] <= 0) delete player.inventory[dropItemId]

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣   🗑️  ITEM DIBUANG  🗑️
╰─────────────────────❏
╭─❏
│▣ 📦 Item   : *${dropItemName}*
│▣ 🔢 Jumlah : ${dropAmount}x
│▣ 🗑️ Status : Item berhasil dibuang!
╰──────────❏
⚠️ Item yang dibuang tidak bisa dikembalikan!`)
        }

        // ─── GIVE / BERIKAN ITEM KE PLAYER LAIN ─────────────────────────
        if (command === 'give' || command === 'berikan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)

            // Cari target dari mention atau reply
            let giveTargetJid = null
            if (m.isGroup) {
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    for (let id of m.mentionedJid) {
                        if (id.endsWith('@lid')) {
                            if (m.metadata && m.metadata.participants) {
                                let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
                                if (p && p.jid) { giveTargetJid = p.jid; break }
                            }
                        } else { giveTargetJid = id; break }
                    }
                } else if (m.quoted) {
                    giveTargetJid = m.quoted.sender
                }
            } else {
                if (m.quoted) giveTargetJid = m.quoted.sender
            }

            if (!giveTargetJid) return Reply(`❌ Tag atau reply user yang mau dikasih item!\nContoh: .give potion 2 @user\nAtau reply pesan user lalu: .give potion 2`)
            if (giveTargetJid === senderJid) return Reply(`❌ Tidak bisa memberikan item ke diri sendiri!`)
            if (!rpgDB.players[giveTargetJid]) return Reply(`❌ User tersebut belum mulai RPG! Suruh ketik *.rpgstart* dulu.`)

            if (!text) return Reply(`Gunakan: .give [item_id] [jumlah] @user\nContoh: .give potion 3 @user\n\nCek inventory: *.rpginv*`)

            const senderPlayer = rpgDB.players[senderJid]
            const targetPlayer = rpgDB.players[giveTargetJid]

            // Parse args (hapus mention @xxx dari text)
            const giveText = text.replace(/@\d+/g, '').trim()
            const giveArgs = giveText.trim().split(' ').filter(x => x)
            const giveItemId = giveArgs[0] ? giveArgs[0].toLowerCase() : null
            const giveAmount = parseInt(giveArgs[1]) || 1

            if (!giveItemId) return Reply(`❌ Sebutkan nama item yang mau diberikan!\nContoh: .give potion 3 @user`)
            if (giveAmount <= 0 || isNaN(giveAmount)) return Reply(`❌ Jumlah harus lebih dari 0!`)

            if (!senderPlayer.inventory || !senderPlayer.inventory[giveItemId] || senderPlayer.inventory[giveItemId] < 1) {
                return Reply(`❌ Kamu tidak punya item *${giveItemId}* di inventory!\n💡 Cek inventory dengan *.rpginv*`)
            }
            if (senderPlayer.inventory[giveItemId] < giveAmount) {
                return Reply(`❌ Kamu hanya punya *${giveItemId}* x${senderPlayer.inventory[giveItemId]}, tidak cukup untuk diberikan ${giveAmount}x!`)
            }
            // Cegah give item yang sedang diequip
            if (senderPlayer.equipment) {
                if (senderPlayer.equipment.weapon === giveItemId) return Reply(`❌ Item *${giveItemId}* sedang dipakai sebagai senjata!\n💡 Lepas dulu dengan *.unequip weapon*`)
                if (senderPlayer.equipment.armor === giveItemId) return Reply(`❌ Item *${giveItemId}* sedang dipakai sebagai armor!\n💡 Lepas dulu dengan *.unequip armor*`)
            }

            const giveItemData = rpgDB.items[giveItemId]
            const giveItemName = giveItemData ? giveItemData.name : giveItemId

            // Transfer item
            senderPlayer.inventory[giveItemId] -= giveAmount
            if (senderPlayer.inventory[giveItemId] <= 0) delete senderPlayer.inventory[giveItemId]

            if (!targetPlayer.inventory) targetPlayer.inventory = {}
            targetPlayer.inventory[giveItemId] = (targetPlayer.inventory[giveItemId] || 0) + giveAmount

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const targetName = targetPlayer.name || giveTargetJid.split('@')[0]
            const senderName = senderPlayer.name || senderJid.split('@')[0]

            return Reply(`╭─────────────────────❏
│▣   🎁  ITEM DIBERIKAN!  🎁
╰─────────────────────❏
╭─❏
│▣ 📦 Item    : *${giveItemName}*
│▣ 🔢 Jumlah  : ${giveAmount}x
│▣ 👤 Dari    : ${senderName}
│▣ 🎯 Ke      : ${targetName}
╰──────────❏
✅ Item berhasil ditransfer!`)
        }

        if (command === 'equip') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            if (!text) return Reply(`Gunakan: .equip [nama item]\nLihat item di *.rpginv*`)
            const player = rpgDB.players[senderJid]
            const itemId = text.toLowerCase().replace(/ /g, '_')
            if (!player.inventory || !player.inventory[itemId] || player.inventory[itemId] < 1) return Reply(`❌ lu gak punya item "${text}"!`)
            const item = rpgDB.items[itemId]
            if (!item || (item.type !== 'weapon' && item.type !== 'armor')) return Reply(`"${text}" bukan item yang bisa di equip.`)
            const itemType = item.type
            if (!player.equipment) player.equipment = { weapon: null, armor: null }
            if (player.equipment[itemType]) {
                const oldItemId = player.equipment[itemType]
                player.inventory[oldItemId] = (player.inventory[oldItemId] || 0) + 1
            }
            player.equipment[itemType] = itemId
            player.inventory[itemId] -= 1
            if (player.inventory[itemId] <= 0) delete player.inventory[itemId]
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            return Reply(`
╭─────────────────────❏
│▣   ✅  EQUIP BERHASIL!  ✅
╰─────────────────────❏
╭─❏
│▣ 🏷️  Item   : *${item.name}*
│▣ ${item.type == 'weapon' ? '⚔️  ATK    : +' + item.attack : '🛡️  DEF    : +' + item.defense}
╰──────────❏`)
        }

        if (command === 'unequip') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            if (!text || !['weapon', 'armor'].includes(text.toLowerCase())) return Reply(`Gunakan: .unequip [weapon/armor]`)
            const player = rpgDB.players[senderJid]
            const slot = text.toLowerCase()
            if (!player.equipment || !player.equipment[slot]) return Reply(`Tidak ada ${slot} yang sedang dipakai.`)
            const itemId = player.equipment[slot]
            const item = rpgDB.items[itemId]
            if (!player.inventory) player.inventory = {}
            player.inventory[itemId] = (player.inventory[itemId] || 0) + 1
            player.equipment[slot] = null
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            return Reply(`
╭─────────────────────❏
│▣   🔄  UNEQUIP BERHASIL  🔄
╰─────────────────────❏
╭─❏
│▣ 🏷️  Item   : *${item.name}*
│▣ 📦 Status  : Kembali ke inventory
╰──────────❏`)
        }

        if (command === 'item') {

            if (!rpgDB.players[senderJid]) {
                return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            }
            const player = rpgDB.players[senderJid]
            const inBattle = !!(player.battleState && player.battleState.inBattle)

            // ── Tampilkan daftar item jika tidak ada argumen ──────────────
            if (!text) {
                // Kumpulkan semua item yang bisa dipakai (heal & mana)
                const usableItems = Object.keys(player.inventory || {}).filter(id => {
                    const d = rpgDB.items[id]
                    return d && (d.type === 'heal' || d.type === 'mana')
                })

                if (usableItems.length === 0) {
                    return Reply(
                        `╭─────────────────────❏\n` +
                        `│▣   🎒  ITEM PAKAI  🎒\n` +
                        `╰─────────────────────❏\n` +
                        `╭─❏\n` +
                        `│▣ ❌ Tidak ada item yang bisa dipakai!\n` +
                        `│▣ Beli item di *.rpgshop potion*\n` +
                        `╰──────────❏`
                    )
                }

                // Pisah per tipe untuk tampilan lebih rapi
                const healItems = usableItems.filter(id => rpgDB.items[id].type === 'heal')
                const manaItems = usableItems.filter(id => rpgDB.items[id].type === 'mana')

                let listTxt =
                    `╭─────────────────────❏\n` +
                    `│▣   🎒  DAFTAR ITEM PAKAI  🎒\n` +
                    `╰─────────────────────❏\n` +
                    `╭─❏\n` +
                    `│▣ ${inBattle ? '⚔️ Mode: *SAAT BERTARUNG* (musuh balas menyerang)' : '🏕️ Mode: *LUAR PERTARUNGAN* (aman)'}\n` +
                    `│▣\n`

                if (healItems.length > 0) {
                    listTxt += `│▣ ❤️ *POTION (HP)*\n`
                    healItems.forEach(id => {
                        const it = rpgDB.items[id]
                        const jumlah = player.inventory[id]
                        const efek = it.value >= 999 ? 'FULL HP' : `+${it.value} HP`
                        listTxt +=
                            `│▣   • *${it.name}* x${jumlah}\n` +
                            `│▣     🔑 Key: \`${id}\` | Efek: ${efek}\n` +
                            `│▣     ↳ *.item ${id}*\n`
                    })
                    listTxt += `│▣\n`
                }

                if (manaItems.length > 0) {
                    listTxt += `│▣ 🔵 *ELIXIR (MP)*\n`
                    manaItems.forEach(id => {
                        const it = rpgDB.items[id]
                        const jumlah = player.inventory[id]
                        const efek = it.value >= 999 ? 'FULL MP' : `+${it.value} MP`
                        listTxt +=
                            `│▣   • *${it.name}* x${jumlah}\n` +
                            `│▣     🔑 Key: \`${id}\` | Efek: ${efek}\n` +
                            `│▣     ↳ *.item ${id}*\n`
                    })
                    listTxt += `│▣\n`
                }

                listTxt +=
                    `│▣ ❤️ HP: ${player.hp}/${player.maxHp} | 🔵 MP: ${player.mp}/${player.maxMp}\n` +
                    `╰──────────❏\n` +
                    `💡 Cara pakai: *.item [key_item]*\n` +
                    `Contoh: *.item potion* atau *.item elixir_hidup*`

                return Reply(listTxt)
            }

            // ── Pakai item spesifik ───────────────────────────────────────
            const itemId = text.trim().split(/\s+/)[0].toLowerCase()

            if (!player.inventory || !player.inventory[itemId] || player.inventory[itemId] < 1) {
                // Coba cari item yg mirip dari inventory user
                const allUsable = Object.keys(player.inventory || {}).filter(id => {
                    const d = rpgDB.items[id]
                    return d && (d.type === 'heal' || d.type === 'mana')
                })
                const hint = allUsable.length
                    ? `\n💡 Item kamu: ${allUsable.map(id => `*${id}*`).join(', ')}\nKetik *.item* untuk lihat daftar lengkap.`
                    : `\n💡 Beli item di *.rpgshop potion*`
                return Reply(`❌ Item *${itemId}* tidak ada di inventory!${hint}`)
            }

            const item = rpgDB.items[itemId]
            if (!item) return Reply(`❌ Item *${itemId}* tidak dikenal!`)
            if (item.type !== 'heal' && item.type !== 'mana') {
                if (item.type === 'weapon' || item.type === 'armor') {
                    return Reply(`⚔️ *${item.name}* adalah equipment, gunakan *.equip ${itemId}*`)
                }
                if (item.type === 'material') {
                    return Reply(`🪨 *${item.name}* adalah material crafting, gunakan *.craft*`)
                }
                return Reply(`❌ *${item.name}* tidak bisa dipakai langsung!`)
            }

            // ── Hitung efek item ──────────────────────────────────────────
            let resultLines = [
                `╭─────────────────────❏`,
                `│▣   ✨  PAKAI ITEM  ✨`,
                `╰─────────────────────❏`,
                `╭─❏`,
                `│▣ 🧪 Item  : *${item.name}*`,
                `│▣ 🔑 Key   : \`${itemId}\``,
            ]

            if (item.type === 'heal') {
                const hpBefore = player.hp
                player.hp = Math.min(player.maxHp, player.hp + item.value)
                const hpGained = player.hp - hpBefore
                resultLines.push(`│▣ ❤️ HP    : +${hpGained} → *${player.hp}/${player.maxHp}*`)
                if (hpGained < item.value) resultLines.push(`│▣ ℹ️ HP sudah hampir penuh`)
            } else {
                const mpBefore = player.mp
                player.mp = Math.min(player.maxMp, player.mp + item.value)
                const mpGained = player.mp - mpBefore
                resultLines.push(`│▣ 🔵 MP    : +${mpGained} → *${player.mp}/${player.maxMp}*`)
                if (mpGained < item.value) resultLines.push(`│▣ ℹ️ MP sudah hampir penuh`)
            }

            player.inventory[itemId] -= 1
            if (player.inventory[itemId] <= 0) delete player.inventory[itemId]

            // ── Jika DALAM pertarungan — musuh balas menyerang ───────────
            if (inBattle) {
                const battleState = player.battleState
                resultLines.push(`╰──────────❏`)
                resultLines.push(``)
                resultLines.push(`⚔️ *GILIRAN MUSUH*`)
                resultLines.push(`🗡️ ${battleState.monster.name} balas menyerang!`)

                const monsterDamage = calculateDamage(battleState.monster, player)
                player.hp -= monsterDamage.damage

                resultLines.push(`╭─❏`)
                resultLines.push(`│▣ 💥 damage: ${monsterDamage.damage}`)
                resultLines.push(`│▣ ❤️ HP kamu: ${Math.max(0, player.hp)}/${player.maxHp}`)
                resultLines.push(`╰──────────❏`)

                if (player.hp <= 0) {
                    resultLines.push(``)
                    resultLines.push(`💀 *TE WAS...*`)
                    resultLines.push(`💀 Item gak cukup menolong...`)
                    resultLines.push(`╭─❏`)
                    player.hp = 1
                    player.gold = Math.max(0, player.gold - 20)
                    resultLines.push(`│▣ 💵 -Rp.20 | Sisa: ${toRupiah(player.gold)}`)
                    resultLines.push(`╰──────────❏`)
                    delete player.battleState
                }
            } else {
                // ── Di luar pertarungan — langsung selesai ────────────────
                const sisaItem = player.inventory[itemId] || 0
                resultLines.push(`│▣ 📦 Sisa  : ${sisaItem > 0 ? `${sisaItem}x` : 'Habis!'}`)
                resultLines.push(`╰──────────❏`)
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(resultLines.join('\n'))
        }

        if (command === 'rpghelp') {
            
                

            const helpText = `
╭─────────────────────❏
│▣   🎮  MENU BANTUAN RPG  🎮
╰─────────────────────❏

⚔️ *DASAR*
╭─❏
│▣ .rpgstart    — mulai petualangan
│▣ .rpgstats    — lihat stat karakter
│▣ .rpginv      — inventory & equipment
│▣ .rpgshop     — buka toko (senjata/armor/potion)
│▣ .rpgmove     — pindah lokasi
│▣ .rpgexplore  — cari musuh
╰──────────❏

🎒 *PERLENGKAPAN*
╭─❏
│▣ .equip [item]              — pasang senjata/armor
│▣ .unequip [weapon/armor]    — lepas equipment
│▣ .buy [item]                — beli item
│▣ .sell [item] [qty]         — jual item biasa ke bot
│▣ .use [item]                — pakai potion/elixir
│▣ .drop [item] [qty]         — buang/hapus item dari tas
│▣ .give [item] [qty] @user   — berikan item ke player lain
╰──────────❏

🏪 *JUAL KE BOT (LENGKAP)*
╭─❏
│▣ .jualbot                   — menu jual semua barang
│▣ .jualbot item [id] [qty]   — jual weapon/armor/material
│▣ .jualbot item semua        — jual semua item sekaligus
│▣ .jualbot pancing [id]      — jual joran pancing
│▣ .jualbot pancing semua     — jual semua joran (kecuali aktif)
│▣ .jualbot umpan [id]        — jual umpan/bait
│▣ .jualbot umpan semua       — jual semua umpan (kecuali aktif)
│▣ .jualbot pet               — jual hewan peliharaan
│▣ .jualbot ikan              — jual semua ikan
│▣ .jualbot semua             — jual SEMUA barang sekaligus!
╰──────────❏

⚡ *PERTEMPURAN*
╭─❏
│▣ .attack    — serang biasa
│▣ .skill     — serangan spesial class
│▣ .flee      — kabur dari pertempuran
│▣ .item      — pakai item saat bertarung
│▣ .pvp       — tantang player lain
│▣ .dungeon   — masuk dungeon
╰──────────❏

💵 *EKONOMI & KERJA*
╭─❏
│▣ .kerja               — kerja biasa
│▣ .jobkerja            — kerja part time
│▣ .berkebun            — berkebun & panen
│▣ .ngojek              — ojek online
│▣ .maling / .begal     — kriminal (ada risiko!)
│▣ .judionline          — judi (hati-hati!)
│▣ .tfuang [jml] @user  — transfer uang
╰──────────❏

⛏️ *TAMBANG & MERAMU*
╭─❏
│▣ .tambang → .besi → .nikel → .emas → .berlian
│▣ .meramu / .foraging  — cari bahan herbal
╰──────────❏

🎣 *SISTEM MANCING*
╭─❏
│▣ .mancing                           — lempar kail
│▣ .mancingstart                      — cek setup joran & umpan
│▣ .tasikan                           — inventori ikan
│▣ .jualikanbot                       — jual semua ikan ke bot
│▣ .jualikanbot [key] [qty]           — jual ikan spesifik
│▣ .jualikan @user [key] [qty] [hrg]  — jual ke player
│▣ .shoprod                           — toko joran (Tier C → SSS)
│▣ .shopbomber                        — toko umpan/bomber
│▣ .topmancing                        — leaderboard pemancing
╰──────────❏

🐠 *AKUARIUM & PELIHARA IKAN*
╭─❏
│▣ .peliharaikan [fishkey]             — pelihara ikan dari inventori
│▣ .akuarium                           — lihat ikan peliharaan
│▣ .makankanikan [slot] [food] [qty]   — beri makan ikan
│▣ .lepaskan [slot]                    — keluarkan ikan dari akuarium
│▣ .aduikan @user [namaikan]           — adu ikan (lawan random)
│▣ .infoaduikan                        — panduan adu ikan
│▣ .shopfood                           — toko makanan ikan
│▣ .shopfood beli [id] [qty]           — beli makanan ikan
╰──────────❏

🥚 *LEVEL IKAN (bertahap — Max Lv.20)*
╭─❏
│▣ Lv.1  🥚 Baby           — awal peliharaan
│▣ Lv.2  🐟 Tiny           — EXP 100
│▣ Lv.3  🐠 Small          — EXP 300
│▣ Lv.4  🐡 Normal         — EXP 700
│▣ Lv.5  🦐 Sprout         — EXP 1.500
│▣ Lv.6  🦑 Feeder         — EXP 3.000
│▣ Lv.7  🐙 Fighter        — EXP 5.500
│▣ Lv.8  🦈 Hunter         — EXP 9.000
│▣ Lv.9  🐊 Predator       — EXP 14.000
│▣ Lv.10 🦁 Alpha          — EXP 21.000
│▣ Lv.11 🌊 Tidal          — EXP 30.000
│▣ Lv.12 ⚡ Storm          — EXP 42.000
│▣ Lv.13 🔥 Blaze          — EXP 58.000
│▣ Lv.14 ❄️ Frost           — EXP 78.000
│▣ Lv.15 🌑 Shadow         — EXP 103.000
│▣ Lv.16 💎 Crystal        — EXP 133.000
│▣ Lv.17 🌟 Astral         — EXP 170.000
│▣ Lv.18 👑 Royal          — EXP 215.000
│▣ Lv.19 🐉 Mythic         — EXP 270.000
│▣ Lv.20 ✨ Legendary God  — EXP 340.000 (MAX)
│▣ 💡 Beri makan rutin untuk naikkan level!
│▣ 💡 Ikan level tinggi lebih kuat saat adu!
╰──────────❏

🏦 *BANK*
╭─❏
│▣ .bank         — cek saldo rekening
│▣ .setor [jml]  — setor ke bank
│▣ .tarik [jml]  — tarik dari bank
│▣ .topbank      — leaderboard nasabah
╰──────────❏

📈 *MARKET & INVESTASI*
╭─❏
│▣ .market                           — buka market
│▣ .beli saham [TICKER] [lot]        — beli saham
│▣ .jualsaham [TICKER] [lot]         — jual saham
│▣ .jualaset [cat] [id] [qty] [hrg]  — jual ke player
│▣ .jualasetbot [cat] [id] [qty]     — jual ke bot
│▣ .batallisting [no]                — batalkan listing
│▣ .ceksaham [TICKER]                — detail saham
│▣ .portofolio                       — ringkasan investasi
│▣ .pasifincome                      — klaim passive income
│▣ .market listings                  — listing player
│▣ .simpanaset / .tarikaset          — simpan/tarik aset bank
│▣ .topkaya                          — top 10 terkaya
╰──────────❏

🎯 *LAINNYA*
╭─❏
│▣ .quest         — ambil quest
│▣ .craft         — buat item dari material
│▣ .daily         — klaim hadiah harian
│▣ .leaderboardrpg — top player RPG
│▣ .adopsipet     — adopsi pet
│▣ .infopet       — info pet
╰──────────❏`
            
            return Reply(helpText)
        }

        if (command === 'tfuang') {
            let targetJid = null
            if (m.isGroup) {
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    for (let id of m.mentionedJid) {
                        if (id.endsWith('@lid')) {
                            if (m.metadata && m.metadata.participants) {
                                let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
                                if (p && p.jid) {
                                    targetJid = p.jid
                                    break
                                }
                            }
                        } else {
                            targetJid = id
                            break
                        }
                    }
                } else if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            } else {
                if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            }

            if (!targetJid) {
                return Reply(`Tag atau reply user yang mau transfer uang!\nContoh: .tfuang 100 @user`)
            }

            if (targetJid === m.sender) {
                return Reply("❌ gak bisa transfer ke diri sendiri!")
            }

            if (!rpgDB.players[targetJid]) {
                return Reply("❌ user itu belum mulai RPG!")
            }

            const args = text.trim().split(' ')
            const amount = parseInt(args[0])

            if (isNaN(amount) || amount <= 0) {
                return Reply(`Masukkan jumlah uang yang valid!\nContoh: .tfuang 100 @user`)
            }

            const senderPlayer = rpgDB.players[senderJid]
            const targetPlayer = rpgDB.players[targetJid]

            if (senderPlayer.gold < amount) {
                return Reply(`💵 saldo kurang! punya: ${toRupiah(senderPlayer.gold)}
`)
            }

            senderPlayer.gold -= amount
            targetPlayer.gold += amount

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            

return Reply(`
╭─────────────────────❏
│▣  💸  TRANSFER UANG  💸
╰─────────────────────❏
╭─❏
│▣ 👤 Penerima  : @${targetJid.split('@')[0]}
│▣ 💵 Jumlah    : ${toRupiah(amount)}
│▣ ──────────────────
│▣ 💰 Sisa      : ${toRupiah(senderPlayer.gold)}
╰──────────❏
Makasih udah dermawan, jangan lupa minta traktir~ 😄`, [targetJid])
        }


        // ─────────────────────────────────────────────
        // COMMAND: .bank — cek saldo rekening
        // ─────────────────────────────────────────────
        if (command === 'bank') {
            if (!isRegistered(m.sender) && !isCreator)
                return Reply(global.mess.verifikasi)
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (!player.bank) player.bank = { balance: 0, totalDeposited: 0, totalWithdrawn: 0 }
            const dompet = player.gold || 0
            const tabungan = player.bank.balance || 0
            const totalAsset = dompet + tabungan
            return Reply(`
╭─────────────────────❏
│▣  🏦  INFO REKENING  🏦
╰─────────────────────❏
╭─❏
│▣ 💵 Dompet    : *${toRupiah(dompet)}*
│▣ 🏦 Tabungan  : *${toRupiah(tabungan)}*
│▣ ──────────────────
│▣ 💎 Total     : *${toRupiah(totalAsset)}*
╰──────────❏
📌 *.setor [jml]* simpan ke bank  |  *.tarik [jml]* ambil dari bank
Saldo bank *aman* dari PVP, begal & maling~ 🔐`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .setor [jumlah]
        // ─────────────────────────────────────────────
        if (command === 'setor') {
            if (!isRegistered(m.sender) && !isCreator)
                return Reply(global.mess.verifikasi)
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (!player.bank) player.bank = { balance: 0, totalDeposited: 0, totalWithdrawn: 0 }
            if (!text) {
                return Reply(`
╭─────────────────────❏
│▣  🏦  SETOR KE BANK  🏦
╰─────────────────────❏
╭─❏
│▣ 💵 Dompet    : *${toRupiah(player.gold)}*
│▣ 🏦 Tabungan  : *${toRupiah(player.bank.balance)}*
╰──────────❏
Gunakan: *.setor [jumlah]*  contoh: *.setor 500*`)
            }
            const jumlah = parseInt(text.trim())
            if (isNaN(jumlah) || jumlah <= 0)
                return Reply(`❌ Jumlah tidak valid! Masukkan angka lebih dari 0.
Contoh: *.setor 500*`)
            if (jumlah > player.gold) {
                return Reply(`
❌ *SALDO DOMPET KURANG!*
╭─❏
│▣ 💵 Dompet    : *${toRupiah(player.gold)}*
│▣ 📤 Mau Setor : *${toRupiah(jumlah)}*
│▣ ❗ Kurang     : *${toRupiah(jumlah - player.gold)}*
╰──────────❏`)
            }
            player.gold -= jumlah
            player.bank.balance += jumlah
            player.bank.totalDeposited = (player.bank.totalDeposited || 0) + jumlah
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  🏦  SETOR BERHASIL!  🏦
╰─────────────────────❏
╭─❏
│▣ 📤 Disetor   : *+${toRupiah(jumlah)}*
│▣ 💵 Dompet    : *${toRupiah(player.gold)}*
│▣ 🏦 Tabungan  : *${toRupiah(player.bank.balance)}*
╰──────────❏
Saldo lu aman di bank, gak bakal kecolongan~ 🔐`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .tarik [jumlah]
        // ─────────────────────────────────────────────
        if (command === 'tarik') {
            if (!isRegistered(m.sender) && !isCreator)
                return Reply(global.mess.verifikasi)
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (!player.bank) player.bank = { balance: 0, totalDeposited: 0, totalWithdrawn: 0 }
            if (!text) {
                return Reply(`
╭─────────────────────❏
│▣  🏦  TARIK DARI BANK  🏦
╰─────────────────────❏
╭─❏
│▣ 🏦 Tabungan  : *${toRupiah(player.bank.balance)}*
│▣ 💵 Dompet    : *${toRupiah(player.gold)}*
╰──────────❏
Gunakan: *.tarik [jumlah]*  contoh: *.tarik 200*`)
            }
            const jumlah = parseInt(text.trim())
            if (isNaN(jumlah) || jumlah <= 0)
                return Reply(`❌ Jumlah tidak valid! Masukkan angka lebih dari 0.
Contoh: *.tarik 200*`)
            if (jumlah > player.bank.balance) {
                return Reply(`
❌ *SALDO BANK KURANG!*
╭─❏
│▣ 🏦 Tabungan  : *${toRupiah(player.bank.balance)}*
│▣ 📥 Mau Tarik : *${toRupiah(jumlah)}*
│▣ ❗ Kurang     : *${toRupiah(jumlah - player.bank.balance)}*
╰──────────❏`)
            }
            player.bank.balance -= jumlah
            player.gold += jumlah
            player.bank.totalWithdrawn = (player.bank.totalWithdrawn || 0) + jumlah
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  🏦  TARIK BERHASIL!  🏦
╰─────────────────────❏
╭─❏
│▣ 📥 Ditarik   : *+${toRupiah(jumlah)}*
│▣ 💵 Dompet    : *${toRupiah(player.gold)}*
│▣ 🏦 Tabungan  : *${toRupiah(player.bank.balance)}*
╰──────────❏
Hati-hati bawa cash di luar, bisa dibegal~ ⚠️`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .topbank — leaderboard tabungan
        // ─────────────────────────────────────────────
        if (command === 'topbank') {
            if (!isRegistered(m.sender) && !isCreator)
                return Reply(global.mess.verifikasi)
            const players = Object.entries(rpgDB.players)
            if (players.length < 1)
                return Reply(`❌ Belum ada petualang yang terdaftar.`)
            const sortedByBank = players
                .filter(([_, p]) => p && p.bank && p.bank.balance > 0)
                .sort(([, a], [, b]) => (b.bank?.balance || 0) - (a.bank?.balance || 0))
                .slice(0, 10)
            if (sortedByBank.length === 0)
                return Reply(`❌ Belum ada nasabah. Jadilah yang pertama nabung!`)
            let tbText = `╭─────────────────────❏\n│▣  🏦  TOP 10 NASABAH BANK  🏦\n╰─────────────────────❏\n`
            tbText += `╭─❏\n`
            let mentions = []
            sortedByBank.forEach(([jid, p], index) => {
                const medals = ['🥇','🥈','🥉']
                const medal = medals[index] || `${index + 1}.`
                tbText += `│▣ ${medal} @${jid.split('@')[0]} — *${toRupiah(p.bank.balance)}* 🏦\n`
                mentions.push(jid)
            })
            tbText += `╰──────────❏\nNabung itu keren, gak bakal kecolongan~ 🔐`
            return yonz.sendMessage(m.chat, { text: tbText, mentions }, { quoted: m })
        }

        if (command === 'tambang' || command === 'mining') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.location !== 'tambang') return Reply('⛏️ lu harus ke *.rpgmove tambang* dulu buat nambang!')
            if (!player.miningState) {
                player.miningState = { stage: 'permukaan', lastMine: 0 }
            }
            const cooldown = 3 * 60 * 1000
            if (Date.now() - player.miningState.lastMine < cooldown) {
                const timeLeft = msToTime(cooldown - (Date.now() - player.miningState.lastMine))
                return Reply(`💪 istirahat dulu, capek! coba lagi ${timeLeft} lagi.`)
            }
            const expGained = generateRandomNumber(5, 15)
            const batuGained = generateRandomNumber(1, 5)
            gainExp(player, expGained)
            if (!player.inventory) player.inventory = {}
            player.inventory["batu"] = (player.inventory["batu"] || 0) + batuGained
            player.miningState.stage = 'besi'
            player.miningState.lastMine = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   ⛏️  HASIL TAMBANG  ⛏️
╰─────────────────────❏
╭─❏
│▣ 🗺️  Lapisan  : Permukaan
│▣ 🪨 Batu      : x${batuGained}
│▣ ⭐ EXP       : +${expGained}
╰──────────❏
Nemu jalur ke lapisan bijih besi! Ketik *.besi* ⛓️`)
            return
        }

        if (command === 'besi') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.miningState || player.miningState.stage !== 'besi') {
                return Reply("⛏️ belum nemu lapisan bijih besi. mulai dari *.tambang* dulu.")
            }
            const cooldown = 3 * 60 * 1000
            if (Date.now() - player.miningState.lastMine < cooldown) {
                const timeLeft = msToTime(cooldown - (Date.now() - player.miningState.lastMine))
                return Reply(`💪 istirahat dulu, capek! coba lagi ${timeLeft} lagi.`)
            }
            const expGained = generateRandomNumber(15, 30)
            const itemGained = generateRandomNumber(1, 3)
            gainExp(player, expGained)
            if (!player.inventory) player.inventory = {}
            player.inventory["bijih_besi"] = (player.inventory["bijih_besi"] || 0) + itemGained
            player.miningState.stage = 'nikel'
            player.miningState.lastMine = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   ⛏️  HASIL TAMBANG  ⛏️
╰─────────────────────❏
╭─❏
│▣ 🗺️  Lapisan  : Bijih Besi
│▣ ⛓️  Bijih Besi: x${itemGained}
│▣ ⭐ EXP       : +${expGained}
╰──────────❏
Nemu lapisan nikel! Ketik *.nikel* 🔩`)
            return
        }

        if (command === 'nikel') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.miningState || player.miningState.stage !== 'nikel') {
                return Reply("⛏️ belum nemu lapisan nikel. selesaikan *.besi* dulu.")
            }
            const cooldown = 4 * 60 * 1000
            if (Date.now() - player.miningState.lastMine < cooldown) {
                const timeLeft = msToTime(cooldown - (Date.now() - player.miningState.lastMine))
                return Reply(`💪 istirahat dulu, capek! coba lagi ${timeLeft} lagi.`)
            }
            const expGained = generateRandomNumber(25, 45)
            const itemGained = generateRandomNumber(1, 2)
            gainExp(player, expGained)
            if (!player.inventory) player.inventory = {}
            player.inventory["nikel"] = (player.inventory["nikel"] || 0) + itemGained
            player.miningState.stage = 'emas'
            player.miningState.lastMine = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   ⛏️  HASIL TAMBANG  ⛏️
╰─────────────────────❏
╭─❏
│▣ 🗺️  Lapisan  : Nikel
│▣ 🔩 Nikel     : x${itemGained}
│▣ ⭐ EXP       : +${expGained}
╰──────────❏
Kilauan emas di depan mata! Ketik *.emas* ✨`)
            return
        }

        if (command === 'emas') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.miningState || player.miningState.stage !== 'emas') {
                return Reply("⛏️ belum nemu lapisan emas. selesaikan *.nikel* dulu.")
            }
            const cooldown = 5 * 60 * 1000
            if (Date.now() - player.miningState.lastMine < cooldown) {
                const timeLeft = msToTime(cooldown - (Date.now() - player.miningState.lastMine))
                return Reply(`💪 istirahat dulu, capek! coba lagi ${timeLeft} lagi.`)
            }
            const expGained = generateRandomNumber(40, 70)
            const itemGained = 1
            gainExp(player, expGained)
            if (!player.inventory) player.inventory = {}
            player.inventory["emas"] = (player.inventory["emas"] || 0) + itemGained
            player.miningState.stage = 'berlian'
            player.miningState.lastMine = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   ⛏️  HASIL TAMBANG  ⛏️
╰─────────────────────❏
╭─❏
│▣ 🗺️  Lapisan  : Emas
│▣ 🥇 Emas      : x${itemGained}
│▣ ⭐ EXP       : +${expGained}
╰──────────❏
Dasar tambang! Kilauan berlian di depan, ketik *.berlian* 💎`)
            return
        }

        if (command === 'berlian') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.miningState || player.miningState.stage !== 'berlian') {
                return Reply("⛏️ belum sampai dasar tambang. selesaikan *.emas* dulu.")
            }
            const cooldown = 7 * 60 * 1000
            if (Date.now() - player.miningState.lastMine < cooldown) {
                const timeLeft = msToTime(cooldown - (Date.now() - player.miningState.lastMine))
                return Reply(`💪 istirahat dulu, capek! coba lagi ${timeLeft} lagi.`)
            }
            const expGained = generateRandomNumber(80, 150)
            const itemGained = 1
            gainExp(player, expGained)
            if (!player.inventory) player.inventory = {}
            player.inventory["berlian"] = (player.inventory["berlian"] || 0) + itemGained
            player.miningState.stage = 'besi'
            player.miningState.lastMine = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   💎  DASAR TAMBANG!  💎
╰─────────────────────❏
╭─❏
│▣ 🗺️  Lapisan  : Berlian (PALING DALAM!)
│▣ 💎 Berlian   : x${itemGained}
│▣ ⭐ EXP       : +${expGained}
╰──────────❏
LANGKA BANGET! Tambang reset, mulai lagi dari *.besi* ⛏️`)
            return
        }

        if (command === 'meramu' || command === 'foraging') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.location !== 'padang_rumput') return Reply('🌿 lu harus ke *.rpgmove padang_rumput* dulu buat meramu!')
            const cooldown = 5 * 60 * 1000
            if (Date.now() - (player.lastForage || 0) < cooldown) {
                const timeLeft = msToTime(cooldown - (Date.now() - player.lastForage))
                return Reply(`🌱 tanaman belum tumbuh! coba lagi ${timeLeft} lagi.`)
            }
            const locationData = rpgDB.locations.padang_rumput
            if (!locationData.herbs) return Reply(`🌿 gada bahan yang bisa diramu di sini!`)
            let gainedHerbs = []
            if (!player.inventory) player.inventory = {}
            for (const [herb, chance] of Object.entries(locationData.herbs)) {
                if (Math.random() < chance) {
                    const amount = generateRandomNumber(1, 4)
                    player.inventory[herb] = (player.inventory[herb] || 0) + amount
                    gainedHerbs.push(`${rpgDB.items[herb]?.name || herb} xRp.${toRupiah(amount)}
`)
                }
            }
            if (gainedHerbs.length === 0) {
                gainedHerbs.push("Rumput Liar x2")
                player.inventory["rumput_liar"] = (player.inventory["rumput_liar"] || 0) + 2
            }
            const expGained = generateRandomNumber(8, 20)
            gainExp(player, expGained)
            player.lastForage = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   🌿  HASIL MERAMU  🌿
╰─────────────────────❏
╭─❏
│▣ ${gainedHerbs.join('\n│▣ ')}
│▣ ──────────────────
│▣ ⭐ EXP  : +${expGained}
╰──────────❏`)
            return
        }

        if (command === 'dungeon') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.dungeonState?.inDungeon) {
                const dungeon = rpgDB.dungeons[player.dungeonState.id]
                let monster
                if (player.dungeonState.stage < dungeon.stages.length) {
                    const stageInfo = dungeon.stages[player.dungeonState.stage]
                    monster = rpgDB.monsters[stageInfo.monsterId]
                    const monsterMaxHp = monster.hp * (stageInfo.count || 1)
                    const monsterCurrentHp = player.dungeonState.monsterHp != null ? player.dungeonState.monsterHp : monsterMaxHp
                    return Reply(`
╭─────────────────────❏
│▣   🔥  DUNGEON BATTLE  🔥
╰─────────────────────❏
╭─❏
│▣ 🏰 Dungeon  : ${dungeon.name}
│▣ 📍 Stage    : ${player.dungeonState.stage + 1}
│▣ ──────────────────
│▣ 👾 Musuh    : ${monster.name}
│▣ ❤️  HP Musuh : ${Math.max(0, monsterCurrentHp)}/${monsterMaxHp}
│▣ 💙 HP Lu    : ${player.dungeonState.hp}/${player.maxHp}
╰──────────❏
Ketik *.dungeon attack* untuk menyerang! ⚔️`)
                } else {
                    monster = rpgDB.monsters[dungeon.boss]
                    const bossCurrentHp = player.dungeonState.monsterHp != null ? player.dungeonState.monsterHp : monster.hp
                    return Reply(`
╭─────────────────────❏
│▣   👑  BOSS FIGHT!  👑
╰─────────────────────❏
╭─❏
│▣ 🏰 Dungeon  : ${dungeon.name}
│▣ 👹 BOSS     : *${monster.name}*
│▣ ──────────────────
│▣ ❤️  HP Boss  : ${Math.max(0, bossCurrentHp)}/${monster.hp}
│▣ 💙 HP Lu    : ${player.dungeonState.hp}/${player.maxHp}
╰──────────❏
Lawan boss dengan *.dungeon attack*! 🗡️`)
                }
            }
            if (!text) {
                let dungeonList = `╭─────────────────────❏\n│▣   ⚔️  DAFTAR DUNGEON  ⚔️\n╰─────────────────────❏\n╭─❏\n`
                for (const [id, d] of Object.entries(rpgDB.dungeons)) {
                    dungeonList += `│▣ *${d.name}*  (min level ${d.minLevel})\n`
                    dungeonList += `│▣   ↳ *.dungeon start ${id}*\n│▣\n`
                }
                dungeonList += `╰──────────❏`
                return Reply(dungeonList)
            }
            const [action, dungeonId] = text.split(' ')
            if (action === 'start' && dungeonId) {
                const dungeon = rpgDB.dungeons[dungeonId]
                if (!dungeon) return Reply("❌ dungeon gak ada.")
                if (player.level < dungeon.minLevel) return Reply(`❌ level lu kurang! minimal level ${dungeon.minLevel}.`)
                player.dungeonState = {
                    inDungeon: true,
                    id: dungeonId,
                    stage: 0,
                    hp: player.hp
                }
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                
                return Reply(`
╭─────────────────────❏
│▣   🚪  MASUK DUNGEON!  🚪
╰─────────────────────❏
╭─❏
│▣ 🏰 Dungeon  : ${dungeon.name}
│▣ 👾 Stage    : ${dungeon.stages.length + 1} (termasuk boss)
╰──────────❏
Ketik *.dungeon attack* untuk mulai bertarung! ⚔️`)
            }
            if (action === 'attack') {
                if (!player.dungeonState?.inDungeon) return Reply("❌ lu lagi gak di dungeon.")
                const dungeon = rpgDB.dungeons[player.dungeonState.id]
                const currentStage = player.dungeonState.stage
                let monster, isBoss = false
                if (currentStage < dungeon.stages.length) {
                    const stageInfo = dungeon.stages[currentStage]
                    const baseMonster = rpgDB.monsters[stageInfo.monsterId]
                    const baseHp = baseMonster.hp * (stageInfo.count || 1)
                    if (player.dungeonState.monsterHp == null) player.dungeonState.monsterHp = baseHp
                    monster = { ...baseMonster, hp: player.dungeonState.monsterHp, maxHp: baseHp }
                } else {
                    const baseMonster = rpgDB.monsters[dungeon.boss]
                    if (player.dungeonState.monsterHp == null) player.dungeonState.monsterHp = baseMonster.hp
                    monster = { ...baseMonster, hp: player.dungeonState.monsterHp, maxHp: baseMonster.hp }
                    isBoss = true
                }
                // Gunakan hp dari dungeonState (bukan player.hp utama)
                const dungeonPlayerHp = player.dungeonState.hp
                const playerDamage = calculateDamage(player, monster)
                let totalPlayerDmg = playerDamage.damage
                // Pet bonus di dungeon
                if (player.pet?.attack > 0) totalPlayerDmg += player.pet.attack
                monster.hp -= totalPlayerDmg
                player.dungeonState.monsterHp = monster.hp

                let battleLog = [`⚔️ *SERANGAN DUNGEON*`]
                battleLog.push(`${isBoss ? '👑 BOSS: ' : '👾 '}${monster.name} menghadangmu!`)
                battleLog.push(`╭─❏`)
                battleLog.push(`│▣ 💥 damage: ${playerDamage.damage}${playerDamage.isCritical ? ' 💥 *CRITICAL!*' : ''}`)
                if (player.pet?.attack > 0) battleLog.push(`│▣ 🐾 ${player.pet.name}: +${player.pet.attack} damage`)
                battleLog.push(`│▣ ❤️ hp musuh: ${Math.max(0, monster.hp)}/${monster.maxHp}`)
                battleLog.push(`╰──────────❏`)

                if (monster.hp <= 0) {
                    if (isBoss) {
                        // Dungeon clear — update hp asli player
                        player.hp = Math.max(1, player.dungeonState.hp)
                        battleLog.push(``)
                        battleLog.push(`🏆 *DUNGEON CLEAR!*`)
                        battleLog.push(`🏆 *${dungeon.name}* berhasil ditaklukkan!`)
                        battleLog.push(`╭─❏`)
                        const reward = dungeon.reward
                        player.gold += reward.gold
                        const leveled = gainExp(player, reward.exp)
                        player.monstersDefeated = (player.monstersDefeated || 0) + 1
                        if (!player.inventory) player.inventory = {}
                        if (reward.item) {
                            player.inventory[reward.item.id] = (player.inventory[reward.item.id] || 0) + reward.item.amount
                            battleLog.push(`│▣ ⭐ exp: +${reward.exp}`)
                            battleLog.push(`│▣ 💵 gold: +${toRupiah(reward.gold)}`)
                            battleLog.push(`│▣ 🎁 item: ${rpgDB.items[reward.item.id]?.name || reward.item.id} x${reward.item.amount}`)
                        } else {
                            battleLog.push(`│▣ ⭐ exp: +${reward.exp}`)
                            battleLog.push(`│▣ 💵 gold: +${toRupiah(reward.gold)}`)
                        }
                        if (leveled) battleLog.push(`│▣ 🎊 *LEVEL UP!* sekarang level ${player.level}!`)
                        battleLog.push(`╰──────────❏`)
                        delete player.dungeonState
                    } else {
                        player.dungeonState.stage += 1
                        player.dungeonState.monsterHp = null
                        player.monstersDefeated = (player.monstersDefeated || 0) + 1
                        // Kecil heal antar stage
                        const healBonusStage = Math.floor(player.maxHp * 0.1)
                        player.dungeonState.hp = Math.min(player.maxHp, player.dungeonState.hp + healBonusStage)
                        battleLog.push(``)
                        battleLog.push(`✅ *STAGE CLEAR*`)
                        battleLog.push(`➡️ Lanjut ke stage berikutnya...`)
                        battleLog.push(`╭─❏`)
                        battleLog.push(`│▣ 🧭 stage: ${player.dungeonState.stage + 1}/${dungeon.stages.length + 1}`)
                        battleLog.push(`│▣ ❤️ hp: ${player.dungeonState.hp}/${player.maxHp} (+${healBonusStage} regen)`)
                        battleLog.push(`╰──────────❏`)
                    }
                } else {
                    // Monster balas serang — gunakan monster dengan hp yg sudah dikurangi
                    const monsterForCounter = { ...monster, hp: monster.hp, maxHp: monster.maxHp }
                    const monsterDamage = calculateDamage(monsterForCounter, player)
                    const newDungeonHp = dungeonPlayerHp - monsterDamage.damage
                    player.dungeonState.hp = newDungeonHp
                    battleLog.push(``)
                    battleLog.push(`🛡️ *SERANGAN BALIK*`)
                    battleLog.push(`╭─❏`)
                    battleLog.push(`│▣ 💥 damage terima: ${monsterDamage.damage}`)
                    battleLog.push(`│▣ ❤️ hp sisa: ${Math.max(0, newDungeonHp)}/${player.maxHp}`)
                    battleLog.push(`╰──────────❏`)
                    if (newDungeonHp <= 0) {
                        battleLog.push(``)
                        battleLog.push(`💀 *DUNGEON FAILED*`)
                        battleLog.push(`💀 Kamu gugur di dalam dungeon...`)
                        battleLog.push(`╭─❏`)
                        // Penalti gold 5%
                        const penalty = Math.floor(player.gold * 0.05)
                        player.gold = Math.max(0, player.gold - penalty)
                        player.hp = Math.floor(player.maxHp * 0.3)
                        battleLog.push(`│▣ ❤️ hp dipulihin ke 30%`)
                        if (penalty > 0) battleLog.push(`│▣ 💸 penalti: -${toRupiah(penalty)} gold`)
                        battleLog.push(`╰──────────❏`)
                        delete player.dungeonState
                    }
                }
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                
                return Reply(battleLog.join('\n'))
            }
        }

        if (command === 'adopsipet' || command === 'adoptpet') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.pet) return Reply(`❌ Kamu sudah punya pet *${player.pet.name}*, tidak bisa adopsi lagi.`)
            if (!text) {
                const tierInfo = {
                    'F':   '⬜ TIER F — Pemula',
                    'E':   '🟩 TIER E — Biasa',
                    'D':   '🔵 TIER D — Langka',
                    'C':   '🟣 TIER C — Keren',
                    'B':   '🟠 TIER B — Epik',
                    'A':   '🔴 TIER A — Legendaris',
                    'S':   '🌟 TIER S — Mythic',
                    'SS':  '💫 TIER SS — Dewa',
                    'SSS': '🔱 TIER SSS — GOD'
                }
                const grouped = {}
                for (const [id, pet] of Object.entries(rpgDB.petData)) {
                    if (!pet.cost) continue // skip header keys
                    const t = pet.tier || 'F'
                    if (!grouped[t]) grouped[t] = []
                    grouped[t].push([id, pet])
                }
                const tierOrder = ['F','E','D','C','B','A','S','SS','SSS']
                let petList = `╭─────────────────────❏\n│▣   🐾  PET SHOP  🐾\n╰─────────────────────❏\n╭─❏\n`
                for (const t of tierOrder) {
                    if (!grouped[t] || grouped[t].length === 0) continue
                    petList += `│▣\n│▣ ${tierInfo[t]}\n`
                    for (const [id, pet] of grouped[t]) {
                        const atkStr = pet.attack ? `⚔️+${pet.attack}` : ''
                        const defStr = pet.defense ? `🛡️+${pet.defense}` : ''
                        const stats = [atkStr, defStr].filter(Boolean).join(' ')
                        petList += `│▣  • *${pet.name}*  [${stats}]\n`
                        petList += `│▣    ${pet.description}\n`
                        petList += `│▣    💰 ${toRupiah(pet.cost)} | *.adopsipet ${id}*\n`
                    }
                }
                petList += `│▣\n╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(petList)
            }
            const petId = text.toLowerCase().trim()
            const petInfo = rpgDB.petData[petId]
            if (!petInfo || !petInfo.cost) return Reply("❌ pet gak ada! Ketik *.adopsipet* untuk lihat daftar.")
            if (player.gold < petInfo.cost) return Reply(`💵 uang lu kurang!\n╭─❏\n│▣ 💰 harga  : ${toRupiah(petInfo.cost)}\n│▣ 💵 saldo  : ${toRupiah(player.gold)}\n│▣ 🔴 kurang : ${toRupiah(petInfo.cost - player.gold)}\n╰──────────❏`)
            player.gold -= petInfo.cost
            player.pet = {
                id: petId,
                name: petInfo.name,
                level: 1,
                exp: 0,
                attack: petInfo.attack || 0,
                defense: petInfo.defense || 0
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   🎉  PET DIADOPSI!  🎉
╰─────────────────────❏
╭─❏
│▣ 🐾 Nama     : *${petInfo.name}*
│▣ 🏷️  Tier     : ${petInfo.tier || 'F'}
│▣ ⚔️  ATK      : +${petInfo.attack || 0}
│▣ 🛡️  DEF      : +${petInfo.defense || 0}
│▣ ──────────────────
│▣ 💰 Harga    : ${toRupiah(petInfo.cost)}
│▣ 💵 Sisa     : ${toRupiah(player.gold)}
╰──────────❏
🐾 *"${petInfo.description}"*`)
            return
        }

        if (command === 'infopet' || command === 'petinfo') {
            
                

            if (!rpgDB.players[senderJid]?.pet) return Reply(`❌ Belum punya pet! Adopsi dulu di *.adopsipet*`)
            const pet = rpgDB.players[senderJid].pet
            let petStats = `
╭─────────────────────❏
│▣   🐾  INFO PET  🐾
╰─────────────────────❏
╭─❏
│▣ 🐾 Nama    : *${pet.name}*
│▣ ⭐ Level   : ${pet.level}
│▣ 📈 EXP     : ${pet.exp}/100
`
            if (pet.attack > 0) petStats += `│▣ ⚔️  ATK     : +${pet.attack}\n`
            if (pet.defense > 0) petStats += `│▣ 🛡️  DEF     : +${pet.defense}\n`
            petStats += `╰──────────❏`
            
            Reply(petStats)
            return
        }

        if (command === 'quest') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.activeQuest) {
                const quest = rpgDB.quests[player.activeQuest]
                let progressText = `(${player.questProgress || 0}/${quest.count})`
                
                return Reply(`
╭─────────────────────❏
│▣   📜  QUEST AKTIF  📜
╰─────────────────────❏
╭─❏
│▣ 📋 Misi      : *${quest.title}*
│▣ 📝 Deskripsi : ${quest.description}
│▣ 📊 Progress  : ${progressText}
╰──────────❏`)
            }
            if (player.location !== 'desa') {
                return Reply('🏠 quest cuma bisa diambil di *Desa Pemula*.')
            }
            let questListText = `╭─────────────────────❏\n│▣   📜  QUEST TERSEDIA  📜\n╰─────────────────────❏\n╭─❏\n`
            for (const [id, quest] of Object.entries(rpgDB.quests)) {
                questListText += `│▣ 📋 *${quest.title}*\n`
                questListText += `│▣   ↳ 🎁 Reward: ${quest.reward.exp} EXP + ${toRupiah(quest.reward.gold)}\n`
                questListText += `│▣   ↳ *.quest ${id}*\n│▣\n`
            }
            questListText += `╰──────────❏`
            if (!text) return Reply(questListText)
            const questId = text.toLowerCase().trim()
            if (!rpgDB.quests[questId]) return Reply("❌ quest gak ada.")
            player.activeQuest = questId
            player.questProgress = 0
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   ✅  QUEST DITERIMA!  ✅
╰─────────────────────❏
╭─❏
│▣ 📋 Misi  : *${rpgDB.quests[questId].title}*
│▣ 🎯 Status : Aktif
╰──────────❏
Selamat berjuang, jangan sampai gagal! ⚔️`)
            return
        }

        if (command === 'craft') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]

            const craftCategories = {
                '🧪 Potion & Elixir': ['potion_kuat','super_potion_craft','elixir_hidup_craft','elixir_mana_craft','mana_crystal_craft','mega_potion_craft','divine_potion_craft','mega_elixir_craft','divine_elixir_craft'],
                '⚔️ Senjata Tier Rendah': ['pedang_goblin','busur_goblin','pedang_orc','tongkat_orc','busur_orc'],
                '🗡️ Senjata Tier Menengah': ['pedang_besi_tempa','tongkat_kuno_craft','pedang_racun','busur_elven_craft'],
                '💠 Senjata Tier Tinggi': ['pedang_mithril_craft','tongkat_mithril'],
                '🔥 Senjata Legendaris': ['pedang_naga_craft','tombak_halilintar_c','katana_jiwa_craft','busur_abadi_craft','tongkat_dewa_craft','pedang_dewa_craft'],
                '🛡️ Armor Tier Rendah': ['perisai_goblin','baju_kulit_goblin','zirah_kulit_kuat','perisai_orc','jubah_penyihir_craft'],
                '🔰 Armor Tier Menengah': ['zirah_baja_craft'],
                '💎 Armor Tier Tinggi': ['zirah_mithril_craft'],
                '🔱 Armor Legendaris': ['jubah_lich_craft','perisai_naga_craft','zirah_orichal_craft','zirah_dewa_craft'],
                '🪨 Material Olahan': ['permata_craft','nikel_craft','kristal_es_craft','batu_kekuatan_craft','racun_perkuat','sisik_naga_craft','bulu_phoenix_craft','tulang_naga_craft','mithril_craft','orichalcum_craft']
            }

            if (!text) {
                let recipeListText = `╭─────────────────────❏\n│▣   🛠️  DAFTAR RESEP CRAFT  🛠️\n╰─────────────────────❏\n╭─❏\n│▣ Ketik *.craft [id]* untuk craft\n│▣\n`
                for (const [cat, ids] of Object.entries(craftCategories)) {
                    const available = ids.filter(id => rpgDB.craftingRecipes[id])
                    if (!available.length) continue
                    recipeListText += `│▣\n│▣ ${cat}\n`
                    for (const id of available) {
                        const recipe = rpgDB.craftingRecipes[id]
                        const mats = Object.entries(recipe.materials).map(([mat, count]) => `${rpgDB.items[mat]?.name || mat} x${count}`).join(', ')
                        recipeListText += `│▣  • *${recipe.name}* (x${recipe.amount})\n`
                        recipeListText += `│▣    📦 ${mats}\n`
                        recipeListText += `│▣    ↳ *.craft ${id}*\n`
                    }
                }
                recipeListText += `│▣\n╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(recipeListText)
            }
            const recipeId = text.toLowerCase().trim()
            if (!rpgDB.craftingRecipes[recipeId]) return Reply("❌ resep gak ada.")
            const recipe = rpgDB.craftingRecipes[recipeId]
            for (const [material, required] of Object.entries(recipe.materials)) {
                if (!player.inventory || !player.inventory[material] || player.inventory[material] < required) {
                    return Reply(`❌ bahan kurang! butuh ${rpgDB.items[material]?.name || material} x${required} lagi.`)
                }
            }
            if (!player.inventory) player.inventory = {}
            for (const [material, required] of Object.entries(recipe.materials)) {
                player.inventory[material] -= required
                if (player.inventory[material] <= 0) delete player.inventory[material]
            }
            player.inventory[recipe.result] = (player.inventory[recipe.result] || 0) + recipe.amount
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣  🔨  CRAFT BERHASIL!  🔨
╰─────────────────────❏
╭─❏
│▣ 📦 Item    : ${recipe.name}
│▣ ✅ Qty     : x${recipe.amount}
│▣ 🎒 Status  : Masuk inventory
╰──────────❏`)
            return
        }

        if (command === 'daily') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const cooldown = 24 * 60 * 60 * 1000
            if (Date.now() - (player.lastDaily || 0) < cooldown) {
                const timeLeft = new Date((player.lastDaily || 0) + cooldown)
                return Reply(`⏳ Daily sudah diambil! Kembali jam ${timeLeft.toLocaleTimeString('id-ID')} nanti.`)
            }
            const goldReward = 100 + (player.level * 10)
            const expReward = 50 + (player.level * 5)
            player.gold += goldReward
            player.exp += expReward
            player.lastDaily = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣  🎁  DAILY REWARD  🎁
╰─────────────────────❏
╭─❏
│▣ 💵 Gold  : +${toRupiah(goldReward)}
│▣ ⭐ EXP   : +${expReward}
╰──────────❏
Kembali lagi besok untuk reward berikutnya! 🔔`)
            return
        }

        if (command === 'pvp') {
            
                

            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            let targetJid = null
            if (m.isGroup) {
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    for (let id of m.mentionedJid) {
                        if (id.endsWith('@lid')) {
                            if (m.metadata && m.metadata.participants) {
                                let p = m.metadata.participants.find(x => x.lid === id || x.id === id)
                                if (p && p.jid) {
                                    targetJid = p.jid
                                    break
                                }
                            }
                        } else {
                            targetJid = id
                            break
                        }
                    }
                } else if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            } else {
                if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            }
            if (!targetJid) return Reply(`Tag atau reply user yang mau diajak duel!\nContoh: .pvp @user`)
            if (targetJid === m.sender) return Reply("❌ gak bisa duel diri sendiri!")
            if (!rpgDB.players[targetJid]) return Reply("❌ lawan belum mulai RPG!")
            const player = rpgDB.players[senderJid]
            const opponent = rpgDB.players[targetJid]
            const cooldown = 5 * 60 * 1000
            if (Date.now() - (player.lastPvp || 0) < cooldown) {
                return Reply(`⏳ tunggu bentar, baru aja duel!`)
            }
            player.lastPvp = Date.now()
            let playerHp = player.hp
            let opponentHp = opponent.hp
            let battleLog = [`╭─────────────────────❏\n│▣   ⚔️  DUEL PVP  ⚔️\n╰─────────────────────❏`]
            battleLog.push(`⚔️ @${m.sender.split('@')[0]}  vs  @${targetJid.split('@')[0]}`)
            battleLog.push(`╭─❏`)
            let turn = player.agility > opponent.agility ? m.sender : targetJid
            while (playerHp > 0 && opponentHp > 0) {
                if (turn === m.sender) {
                    const damage = Math.max(1, getPlayerTotalStats(player).attack - getPlayerTotalStats(opponent).defense)
                    opponentHp -= damage
                    battleLog.push(`│▣ 🗡️ @${m.sender.split('@')[0]} nyerang: *${damage}* damage!`)
                    battleLog.push(`│▣ 🛡️ hp lawan sisa: ${opponentHp}`)
                    turn = targetJid
                } else {
                    const damage = Math.max(1, getPlayerTotalStats(opponent).attack - getPlayerTotalStats(player).defense)
                    playerHp -= damage
                    battleLog.push(`│▣ 🗡️ @${targetJid.split('@')[0]} balas nyerang: *${damage}* damage!`)
                    battleLog.push(`│▣ 🛡️ hp lu sisa: ${playerHp}`)
                    turn = m.sender
                }
                battleLog.push(`│▣ `)
            }
            battleLog.push(`╰──────────❏`)
            if (playerHp <= 0) {
                battleLog.push(``)
                battleLog.push(`💀 *KALAH*`)
                battleLog.push(`╭─❏`)
                player.pvpLosses += 1
                opponent.pvpWins += 1
                battleLog.push(`│▣ 😭 yah, kalah...`)
                battleLog.push(`╰──────────❏`)
            } else {
                battleLog.push(``)
                battleLog.push(`🏆 *MENANG!*`)
                battleLog.push(`╭─❏`)
                player.pvpWins += 1
                opponent.pvpLosses += 1
                const pvpNewTitles = checkNewTitles(player)
                if (pvpNewTitles.length > 0) battleLog.push(`│▣ 🎖️ Title baru: ${pvpNewTitles.join(', ')}`)
                const goldStolen = Math.floor(opponent.gold * 0.1)
                player.gold += goldStolen
                opponent.gold -= goldStolen
                battleLog.push(`│▣ 💵 Rampas: +${toRupiah(goldStolen)} dari lawan!`)
                battleLog.push(`╰──────────❏`)
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            await yonz.sendMessage(m.chat, { text: battleLog.join('\n') }, { quoted: m })
            return
        }

        if (command === 'leaderboardrpg' || command === 'lb_rpg') {
            
                

            const players = Object.entries(rpgDB.players)
            if (players.length < 1) return Reply("❌ Belum ada petualang yang terdaftar.")
            const sortedByLevel = players.sort(([,a], [,b]) => b.level - a.level || b.exp - a.exp).slice(0, 5)
            let levelLbText = `╭─────────────────────❏\n│▣  🏆  TOP 5 PETUALANG  🏆\n╰─────────────────────❏\n`
            levelLbText += `╭─❏\n`
            sortedByLevel.forEach(([jid, player], index) => {
                const medals = ['🥇','🥈','🥉']
                const medal = medals[index] || `${index + 1}.`
                levelLbText += `│▣ ${medal} @${jid.split('@')[0]} — Level *${player.level}*  ·  EXP ${player.exp}\n`
            })
            levelLbText += `╰──────────❏`
            
            await yonz.sendMessage(m.chat, { text: levelLbText }, { quoted: m })
            return
        }

        // ── Fishing data & helpers sudah didefinisikan di module scope atas ──

        // ── MANCINGSTART ──────────────────────────────────────────────
        if (command === 'mancingstart') {
            if (!rpgDB.players[senderJid]) rpgDB.players[senderJid] = initPlayerRPG(senderJid)
            const player = rpgDB.players[senderJid]
            if (!player.fishing) player.fishing = { lastCatch: 0, totalCatch: 0, equippedRod: 'starter_rod', equippedBait: null }
            const rod = ROD_DATA[player.fishing.equippedRod || 'starter_rod']
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣   🎣  SETUP MANCING  🎣
╰─────────────────────❏
╭─❏
│▣ 🎣 Joran   : ${rod.emoji} ${rod.name} [Tier ${rod.tier}]
│▣ 🪱 Umpan   : ${player.fishing.equippedBait ? BAIT_DATA[player.fishing.equippedBait]?.name : 'Tidak ada'}
│▣ 🎯 Boost   : +${rod.boost} ikan langka
╰──────────❏
Ketik *.mancing* untuk mulai narik! 🎣
*.shoprod* beli joran  ·  *.shopbomber* beli umpan`)
        }

        // ── MANCING ───────────────────────────────────────────────────
        if (command === 'mancing') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let player = rpgDB.players[senderJid]
            if (!player.fishing) player.fishing = { lastCatch: 0, totalCatch: 0, equippedRod: 'starter_rod', equippedBait: null }
            if (!player.inventory) player.inventory = {}

            const rodId = player.fishing.equippedRod || 'starter_rod'
            const rod = ROD_DATA[rodId] || ROD_DATA.starter_rod
            const baitId = player.fishing.equippedBait
            const bait = baitId ? BAIT_DATA[baitId] : null

            if (baitId && (!player.inventory[`bait_${baitId}`] || player.inventory[`bait_${baitId}`] <= 0)) {
                player.fishing.equippedBait = null
                Reply(`⚠️ Umpan *${bait?.name || baitId}* habis! Auto-unset. Lanjut tanpa umpan.`)
            }

            const cooldownMs = 60000
            const timeSinceLast = Date.now() - (player.fishing.lastCatch || 0)
            if (timeSinceLast < cooldownMs) {
                const sisa = Math.ceil((cooldownMs - timeSinceLast) / 1000)
                return Reply(`🎣 Sabar... kailnya belum kena! Tunggu *${sisa} detik* lagi.`)
            }

            const rodBoost = rod.boost || 0
            const mutBoost = bait ? (bait.mutBoost || 0) : 0
            const rarity  = pickFishRarity(rodBoost)
            const fish     = pickRandomFishByRarity(rarity)
            const mutation = rollMutation(mutBoost)

            if (!fish) return Reply('❌ Terjadi error saat mancing, coba lagi.')

            if (baitId && player.inventory[`bait_${baitId}`] > 0) {
                player.inventory[`bait_${baitId}`] -= 1
            }

            const invKey = getFishInventoryKey(fish.id, mutation?.id)
            player.inventory[invKey] = (player.inventory[invKey] || 0) + 1
            player.fishing.lastCatch  = Date.now()
            player.fishing.totalCatch = (player.fishing.totalCatch || 0) + 1

            const finalPrice = calcFishPrice(fish, mutation)
            const expGain    = mutation ? Math.floor(fish.baseExp * (mutation.multiplier * 0.5)) : fish.baseExp
            const leveledUp  = gainExp(player, expGain)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const displayName  = getFishDisplayName(fish, mutation)
            const rarityEmoji  = getRarityEmoji(rarity)

            let msg = `🎣 *HASIL MANCING*

╭─❏
│▣ ${rarityEmoji} *[${rarity}]* ${displayName}
│▣ 🎣 Joran  : ${rod.emoji} ${rod.name} [${rod.tier}]
${bait ? `│▣ 🪱 Umpan  : ${bait.emoji} ${bait.name}\n` : ''}${mutation
    ? `│▣ 🧬 Mutasi : ${mutation.emoji} *${mutation.name}* (${mutation.tier}) x${mutation.multiplier}\n`
    : `│▣ 🧬 Mutasi : ❌ Tidak ada\n`}│▣ 💰 Harga jual : ${toRupiah(finalPrice)}
│▣ ⭐ EXP    : +${expGain}
│▣ 🎯 Total tangkap : ${player.fishing.totalCatch}
╰──────────❏
💡 *.tasikan* lihat inventori | *.jualikanbot* jual ke bot`
            const newTitlesFromFishing = checkNewTitles(player)
            if (leveledUp) msg += `\n\n🎊 *LEVEL UP!* sekarang level ${player.level}!`
            if (newTitlesFromFishing.length > 0) msg += `\n🎖️ Title baru: ${newTitlesFromFishing.join(', ')}`
            return Reply(msg)
        }

        // ── TASIKAN ───────────────────────────────────────────────────
        if (command === 'tasikan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const inv = player.inventory || {}
            const fishEntries = Object.entries(inv).filter(([k, v]) => k.startsWith('fish_') && v > 0)

            if (!fishEntries.length) return Reply(`🎣 Inventori ikan kosong!\nMancing dulu dengan *.mancing*`)

            let txt = `╭─────────────────────❏\n│▣   🐟  INVENTORI IKAN  🐟\n╰─────────────────────❏\n╭─❏\n`
            let totalVal = 0
            for (const [key, qty] of fishEntries) {
                const { fishId, mutationId } = parseFishKey(key)
                if (!fishId) {
                    // Fallback: tampilkan ikan yang tidak dikenal agar tidak hilang
                    const rawId = key.replace('fish_', '')
                    txt += `│▣ ⬜ ❓ ${rawId} (data tidak ditemukan)\n`
                    txt += `│▣   ↳ x${qty} | 💰 Tidak bisa dinilai\n`
                    txt += `│▣   ↳ key: ${rawId}\n`
                    continue
                }
                const fish     = FISH_DATA[fishId] || { name: fishId, emoji: '🐟', rarity: 'COMMON', basePrice: 0 }
                const mutation = mutationId ? MUTATION_DATA[mutationId] : null
                const price    = calcFishPrice(fish, mutation)
                totalVal += price * qty
                txt += `│▣ ${getRarityEmoji(fish.rarity)} ${getFishDisplayName(fish, mutation)}\n`
                txt += `│▣   ↳ x${qty} | 💰 ${toRupiah(price)}/ekor\n`
                txt += `│▣   ↳ key: ${key.replace('fish_','')}\n`
            }
            txt += `│▣\n│▣ 💼 *Total nilai* : ${toRupiah(totalVal)}\n╰──────────❏\n`
            txt += `*.jualikanbot* — jual semua ke bot\n*.jualikanbot [key] [qty]* — jual spesifik\n*.jualikan @user [key] [qty] [harga]* — jual ke player`
            return Reply(txt)
        }

        // ── JUALIKANBOT ───────────────────────────────────────────────
        if (command === 'jualikanbot') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const inv = player.inventory || {}
            const fishEntries = Object.entries(inv).filter(([k, v]) => k.startsWith('fish_') && v > 0)
            if (!fishEntries.length) return Reply(`🎣 Gak ada ikan untuk dijual!\nMancing dulu dengan *.mancing*`)

            let totalGold = 0
            let soldList  = []
            const args2 = text ? text.trim().split(/\s+/) : []

            if (args2.length >= 1 && args2[0]) {
                const targetKey = `fish_${args2[0]}`
                const sellQty   = Math.min(parseInt(args2[1]) || (inv[targetKey] || 0), inv[targetKey] || 0)
                if (!inv[targetKey] || inv[targetKey] <= 0) return Reply(`❌ Ikan *${args2[0]}* gak ada di inventori!`)
                const { fishId, mutationId } = parseFishKey(targetKey)
                if (!fishId) return Reply(`❌ Key ikan tidak valid!`)
                const fish     = FISH_DATA[fishId]
                const mutation = mutationId ? MUTATION_DATA[mutationId] : null
                const earn     = calcFishPrice(fish, mutation) * sellQty
                inv[targetKey] -= sellQty
                player.gold    += earn
                totalGold       = earn
                soldList.push(`${getFishDisplayName(fish, mutation)} x${sellQty} = ${toRupiah(earn)}`)
            } else {
                for (const [key, qty] of fishEntries) {
                    const { fishId, mutationId } = parseFishKey(key)
                    if (!fishId) continue
                    const fish     = FISH_DATA[fishId]
                    const mutation = mutationId ? MUTATION_DATA[mutationId] : null
                    const earn     = calcFishPrice(fish, mutation) * qty
                    totalGold     += earn
                    soldList.push(`${getFishDisplayName(fish, mutation)} x${qty} = ${toRupiah(earn)}`)
                    inv[key] = 0
                }
                player.gold += totalGold
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            let txt = `╭─────────────────────❏\n│▣   🏪  JUAL IKAN KE BOT  🏪\n╰─────────────────────❏\n╭─❏\n`
            soldList.slice(0, 10).forEach(s => txt += `│▣ 🐟 ${s}\n`)
            if (soldList.length > 10) txt += `│▣ ... dan ${soldList.length - 10} ikan lagi\n`
            txt += `│▣\n│▣ 💰 *Total* : ${toRupiah(totalGold)}\n│▣ 💵 Saldo  : ${toRupiah(player.gold)}\n╰──────────❏`
            return Reply(txt)
        }

        // ── JUALIKAN (antar player) ───────────────────────────────────
        if (command === 'jualikan') {
            cleanExpiredDeals(rpgDB)
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const inv = player.inventory || {}

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetJid = m.mentionedJid[0]
                if (targetJid && targetJid.endsWith('@lid') && m.isGroup) {
                    const participants = m.metadata?.participants || []
                    const found = participants.find(p => p.lid === targetJid || p.id === targetJid)
                    if (found) targetJid = found.jid || found.id || targetJid
                }
            } else if (m.quoted) targetJid = m.quoted.sender
            if (targetJid) targetJid = resolvePlayerJid(targetJid)

            if (!targetJid) return Reply(`❌ Tag atau reply user penerima!\nFormat: *.jualikan @user [fishkey] [qty] [harga]*`)
            if (targetJid === senderJid) return Reply(`❌ Gak bisa jual ke diri sendiri!`)
            if (!rpgDB.players[targetJid]) return Reply(`❌ User tersebut belum daftar RPG!`)

            const argParts = text ? text.replace(/@\d+/g, '').trim().split(/\s+/) : []
            if (argParts.length < 3) return Reply(`❌ Format: *.jualikan @user [fishkey] [qty] [harga]*\nContoh: *.jualikan @user minnow 1 500*`)

            const fishKey = `fish_${argParts[0]}`
            const qty     = parseInt(argParts[1]) || 1
            const harga   = parseInt(argParts[2]) || 0

            if (!inv[fishKey] || inv[fishKey] < qty) return Reply(`❌ Ikan *${argParts[0]}* tidak cukup di inventori!\nKamu punya: ${inv[fishKey] || 0}`)
            if (harga <= 0) return Reply(`❌ Harga harus lebih dari 0!`)

            // Cek apakah penjual sudah punya deal aktif
            if (findDealAsSeller(rpgDB, senderJid)) return Reply(`⚠️ Kamu masih punya penawaran aktif!\nKetik *.batalkanikan* untuk membatalkan dulu.`)

            const { fishId: fid, mutationId: mid } = parseFishKey(fishKey)
            const fishDisp = fid ? getFishDisplayName(FISH_DATA[fid], mid ? MUTATION_DATA[mid] : null) : argParts[0]

            // Simpan ke rpgDB — key = senderJid (penjual), selalu konsisten
            getDeals(rpgDB)[senderJid] = {
                sellerJid: senderJid,
                buyerJid: targetJid,
                fishKey, fishDisp, qty,
                price: harga,
                lastOfferBy: 'seller',
                expiresAt: Date.now() + FISH_DEAL_TTL
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣   🐟  PENAWARAN IKAN  🐟\n╰─────────────────────❏\n╭─❏\n│▣ 📤 Penjual : @${senderJid.split('@')[0]}\n│▣ 📥 Pembeli : @${targetJid.split('@')[0]}\n│▣\n│▣ 🐟 Ikan    : *${fishDisp}* x${qty}\n│▣ 💰 Harga   : *${toRupiah(harga)}*\n╰──────────❏\n\n@${targetJid.split('@')[0]} Kamu mendapat penawaran ikan!\n\n✅ *.setujuikan* — terima\n❌ *.tolakikan* — tolak\n💬 *.tawarikan [harga]* — negosiasi harga\n\n⏳ Penawaran berlaku *5 menit*`,
                mentions: [senderJid, targetJid]
            }, { quoted: m })
        }

        // ── SETUJUIKAN ────────────────────────────────────────────────
        if (command === 'setujuikan') {
            cleanExpiredDeals(rpgDB)
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)

            const buyerFound = findDealAsBuyer(rpgDB, senderJid)
            if (!buyerFound) return Reply(`❌ Tidak ada penawaran ikan untukmu saat ini.`)
            const { key: dealKey, deal } = buyerFound
            if (Date.now() > deal.expiresAt) {
                delete getDeals(rpgDB)[dealKey]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`⌛ Penawaran sudah kadaluarsa!`)
            }

            const seller = rpgDB.players[deal.sellerJid]
            const buyer  = rpgDB.players[senderJid]
            if (!seller) return Reply(`❌ Penjual tidak ditemukan!`)

            const sellerInv = seller.inventory || {}
            if (!sellerInv[deal.fishKey] || sellerInv[deal.fishKey] < deal.qty) {
                delete getDeals(rpgDB)[dealKey]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`❌ Transaksi batal — stok ikan penjual sudah tidak cukup!`)
            }
            if ((buyer.gold || 0) < deal.price) {
                delete getDeals(rpgDB)[dealKey]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`❌ Uangmu tidak cukup!\nButuh ${toRupiah(deal.price)}, kamu punya ${toRupiah(buyer.gold || 0)}.`)
            }

            sellerInv[deal.fishKey] -= deal.qty
            if (!buyer.inventory) buyer.inventory = {}
            buyer.inventory[deal.fishKey] = (buyer.inventory[deal.fishKey] || 0) + deal.qty
            buyer.gold  -= deal.price
            seller.gold += deal.price
            delete getDeals(rpgDB)[dealKey]
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣   🤝  TRANSAKSI BERHASIL  🤝\n╰─────────────────────❏\n╭─❏\n│▣ 🐟 Ikan    : *${deal.fishDisp}* x${deal.qty}\n│▣ 💰 Harga   : *${toRupiah(deal.price)}*\n│▣ 📤 Penjual : @${deal.sellerJid.split('@')[0]}\n│▣ 📥 Pembeli : @${senderJid.split('@')[0]}\n╰──────────❏\n\n✅ Kesepakatan tercapai!`,
                mentions: [deal.sellerJid, senderJid]
            }, { quoted: m })
        }

        // ── TOLAKIKAN ─────────────────────────────────────────────────
        if (command === 'tolakikan') {
            cleanExpiredDeals(rpgDB)
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)

            const buyerFound = findDealAsBuyer(rpgDB, senderJid)
            if (buyerFound) {
                delete getDeals(rpgDB)[buyerFound.key]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return yonz.sendMessage(m.chat, {
                    text: `❌ @${senderJid.split('@')[0]} menolak penawaran ikan dari @${buyerFound.deal.sellerJid.split('@')[0]}.\n\nDeal dibatalkan.`,
                    mentions: [senderJid, buyerFound.deal.sellerJid]
                }, { quoted: m })
            }

            const sellerFound = findDealAsSeller(rpgDB, senderJid)
            if (sellerFound) {
                delete getDeals(rpgDB)[sellerFound.key]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return yonz.sendMessage(m.chat, {
                    text: `❌ @${senderJid.split('@')[0]} membatalkan penawaran ikan ke @${sellerFound.deal.buyerJid.split('@')[0]}.`,
                    mentions: [senderJid, sellerFound.deal.buyerJid]
                }, { quoted: m })
            }

            return Reply(`❌ Tidak ada penawaran ikan yang aktif untukmu.`)
        }

        // ── BATALKANIKAN ──────────────────────────────────────────────
        if (command === 'batalkanikan') {
            cleanExpiredDeals(rpgDB)
            const sellerFound = findDealAsSeller(rpgDB, senderJid)
            if (sellerFound) {
                delete getDeals(rpgDB)[sellerFound.key]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return yonz.sendMessage(m.chat, {
                    text: `🚫 Penawaran ikan ke @${sellerFound.deal.buyerJid.split('@')[0]} dibatalkan oleh penjual.`,
                    mentions: [senderJid, sellerFound.deal.buyerJid]
                }, { quoted: m })
            }
            return Reply(`❌ Tidak ada penawaran aktif yang bisa dibatalkan.`)
        }

        // ── TAWARIKAN (negosiasi harga) ───────────────────────────────
        if (command === 'tawarikan') {
            cleanExpiredDeals(rpgDB)
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)

            const newHarga = parseInt(text?.trim()) || 0
            if (newHarga <= 0) return Reply(`❌ Format: *.tawarikan [harga]*\nContoh: *.tawarikan 3000*`)

            const buyerFound = findDealAsBuyer(rpgDB, senderJid)
            if (buyerFound) {
                const { key: dealKey, deal } = buyerFound
                if (Date.now() > deal.expiresAt) {
                    delete getDeals(rpgDB)[dealKey]
                    fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                    return Reply(`⌛ Penawaran sudah kadaluarsa!`)
                }
                if (deal.lastOfferBy === 'buyer') return Reply(`⏳ Tunggu penjual merespons tawaranmu dulu!`)
                deal.lastOfferBy = 'buyer'
                deal.price       = newHarga
                deal.expiresAt   = Date.now() + FISH_DEAL_TTL
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return yonz.sendMessage(m.chat, {
                    text: `╭─────────────────────❏\n│▣   💬  NEGOSIASI HARGA  💬\n╰─────────────────────❏\n╭─❏\n│▣ 🐟 Ikan    : *${deal.fishDisp}* x${deal.qty}\n│▣ 💬 Tawaran baru: *${toRupiah(newHarga)}*\n│▣ 📥 Dari    : @${senderJid.split('@')[0]}\n╰──────────❏\n\n@${deal.sellerJid.split('@')[0]} Pembeli menawar *${toRupiah(newHarga)}*\n\n✅ *.setujuikan* — terima\n❌ *.tolakikan* — tolak\n💬 *.tawarikan [harga]* — balas tawaran`,
                    mentions: [senderJid, deal.sellerJid]
                }, { quoted: m })
            }

            const sellerFound = findDealAsSeller(rpgDB, senderJid)
            if (sellerFound) {
                const { key: dealKey, deal } = sellerFound
                if (Date.now() > deal.expiresAt) {
                    delete getDeals(rpgDB)[dealKey]
                    fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                    return Reply(`⌛ Penawaran sudah kadaluarsa!`)
                }
                if (deal.lastOfferBy === 'seller') return Reply(`⏳ Tunggu pembeli merespons tawaranmu dulu!`)
                deal.lastOfferBy = 'seller'
                deal.price       = newHarga
                deal.expiresAt   = Date.now() + FISH_DEAL_TTL
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return yonz.sendMessage(m.chat, {
                    text: `╭─────────────────────❏\n│▣   💬  NEGOSIASI HARGA  💬\n╰─────────────────────❏\n╭─❏\n│▣ 🐟 Ikan    : *${deal.fishDisp}* x${deal.qty}\n│▣ 💬 Tawaran baru: *${toRupiah(newHarga)}*\n│▣ 📤 Dari    : @${senderJid.split('@')[0]}\n╰──────────❏\n\n@${deal.buyerJid.split('@')[0]} Penjual menawarkan *${toRupiah(newHarga)}*\n\n✅ *.setujuikan* — terima\n❌ *.tolakikan* — tolak\n💬 *.tawarikan [harga]* — balas tawaran`,
                    mentions: [senderJid, deal.buyerJid]
                }, { quoted: m })
            }

            return Reply(`❌ Tidak ada penawaran ikan aktif yang bisa dinegosiasi.`)
        }

        // ── SHOPROD ───────────────────────────────────────────────────
        if (command === 'shoprod') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.fishing) player.fishing = { lastCatch: 0, totalCatch: 0, equippedRod: 'starter_rod', equippedBait: null }

            const subArg = text ? text.trim().toLowerCase() : ''

            if (subArg.startsWith('beli ')) {
                const rodId = subArg.replace('beli ', '').trim()
                const rod   = ROD_DATA[rodId]
                if (!rod) return Reply(`❌ Joran *${rodId}* tidak ada!\nKetik *.shoprod* untuk lihat daftar.`)
                if (player.gold < rod.price) return Reply(`❌ Uang kurang! Butuh ${toRupiah(rod.price)}, kamu punya ${toRupiah(player.gold)}.`)
                player.gold -= rod.price
                if (!player.inventory) player.inventory = {}
                player.inventory[`rod_${rodId}`] = (player.inventory[`rod_${rodId}`] || 0) + 1
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   ✅  JORAN DIBELI!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🎣 Joran  : ${rod.emoji} *${rod.name}* [Tier ${rod.tier}]\n│▣ 💰 Harga  : -${toRupiah(rod.price)}\n│▣ 💵 Sisa   : ${toRupiah(player.gold)}\n╰──────────❏\nEquip dengan *.shoprod pasang ${rodId}* 🎣`)
            }

            if (subArg.startsWith('pasang ')) {
                const rodId = subArg.replace('pasang ', '').trim()
                const rod   = ROD_DATA[rodId]
                if (!rod) return Reply(`❌ Joran tidak ditemukan!`)
                if (!player.inventory?.[`rod_${rodId}`] || player.inventory[`rod_${rodId}`] <= 0) return Reply(`❌ Kamu tidak punya joran ini!`)
                player.fishing.equippedRod = rodId
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   ✅  JORAN DIPASANG!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🎣 Joran  : ${rod.emoji} *${rod.name}* [Tier ${rod.tier}]\n│▣ 🎯 Boost  : +${rod.boost} ikan langka\n╰──────────❏`)
            }

            const tierOrder = ['C', 'B', 'A', 'S', 'S+', 'SS', 'SSS']
            const equippedRodId = player.fishing?.equippedRod || 'starter_rod'
            let txt = `╭─────────────────────❏\n│▣   🎣  TOKO JORAN  🎣\n╰─────────────────────❏\n╭─❏\n│▣ 🎣 Aktif   : *${ROD_DATA[equippedRodId]?.name || 'Starter Rod'}*\n│▣\n`
            for (const tier of tierOrder) {
                const rods = Object.entries(ROD_DATA).filter(([,r]) => r.tier === tier)
                if (!rods.length) continue
                txt += `│▣ ▸ *TIER ${tier}*\n`
                for (const [id, r] of rods) {
                    const owned = player.inventory?.[`rod_${id}`] > 0 ? ' ✅' : ''
                    txt += `│▣   ${r.emoji} *${r.name}*${owned}\n`
                    txt += `│▣     💰 ${toRupiah(r.price)} | 🎯 Boost +${r.boost}\n`
                    txt += `│▣     📝 ${r.desc}\n`
                    txt += `│▣     ↳ *.shoprod beli ${id}*\n\n`
                }
            }
            txt += `╰──────────❏\n💵 Saldo : ${toRupiah(player.gold)}\n*.shoprod pasang [id]* — equip joran`
            return Reply(txt)
        }

        // ── SHOPBOMBER ────────────────────────────────────────────────
        if (command === 'shopbomber') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.fishing) player.fishing = { lastCatch: 0, totalCatch: 0, equippedRod: 'starter_rod', equippedBait: null }

            const subArg = text ? text.trim().toLowerCase() : ''

            if (subArg.startsWith('beli ')) {
                const parts3  = subArg.replace('beli ', '').trim().split(/\s+/)
                const baitId  = parts3[0]
                const buyQty  = parseInt(parts3[1]) || 1
                const bait    = BAIT_DATA[baitId]
                if (!bait) return Reply(`❌ Umpan *${baitId}* tidak ada!\nKetik *.shopbomber* untuk lihat daftar.`)
                const totalCost = bait.price * buyQty
                if (player.gold < totalCost) return Reply(`❌ Uang kurang! Butuh ${toRupiah(totalCost)}, kamu punya ${toRupiah(player.gold)}.`)
                player.gold -= totalCost
                if (!player.inventory) player.inventory = {}
                player.inventory[`bait_${baitId}`] = (player.inventory[`bait_${baitId}`] || 0) + buyQty
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   ✅  UMPAN DIBELI!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🪱 Umpan  : ${bait.emoji} *${bait.name}* x${buyQty} [Tier ${bait.tier}]\n│▣ 💰 Harga  : -${toRupiah(totalCost)}\n│▣ 💵 Sisa   : ${toRupiah(player.gold)}\n╰──────────❏\nEquip dengan *.shopbomber pasang ${baitId}* 🪱`)
            }

            if (subArg.startsWith('pasang ')) {
                const baitId = subArg.replace('pasang ', '').trim()
                const bait   = BAIT_DATA[baitId]
                if (!bait) return Reply(`❌ Umpan tidak ditemukan!`)
                if (!player.inventory?.[`bait_${baitId}`] || player.inventory[`bait_${baitId}`] <= 0) return Reply(`❌ Kamu tidak punya umpan ini!`)
                player.fishing.equippedBait = baitId
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏\n│▣   ✅  UMPAN DIPASANG!  ✅\n╰─────────────────────❏\n╭─❏\n│▣ 🪱 Umpan  : ${bait.emoji} *${bait.name}* [Tier ${bait.tier}]\n│▣ 🧬 Mut.Boost : +${bait.mutBoost}\n╰──────────❏`)
            }

            if (subArg === 'lepas') {
                player.fishing.equippedBait = null
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`✅ Umpan dilepas. Mancing tanpa umpan.`)
            }

            const tierOrder2  = ['B', 'A', 'S', 'S+', 'SS', 'SSS']
            const activeBait  = player.fishing?.equippedBait
            let txt = `╭─────────────────────❏\n│▣   🪱  TOKO UMPAN / BOMBER  🪱\n╰─────────────────────❏\n╭─❏\n│▣ 🪱 Aktif   : *${activeBait ? (BAIT_DATA[activeBait]?.name || activeBait) : 'Tidak ada'}*\n│▣\n`
            for (const tier of tierOrder2) {
                const baits = Object.entries(BAIT_DATA).filter(([,b]) => b.tier === tier)
                if (!baits.length) continue
                txt += `│▣ ▸ *TIER ${tier}*\n`
                for (const [id, b] of baits) {
                    const stock = player.inventory?.[`bait_${id}`] || 0
                    txt += `│▣   ${b.emoji} *${b.name}* (stok: ${stock})\n`
                    txt += `│▣     💰 ${toRupiah(b.price)}/pcs | 🧬 Mut.Boost +${b.mutBoost}\n`
                    txt += `│▣     📝 ${b.desc}\n`
                    txt += `│▣     ↳ *.shopbomber beli ${id} [qty]*\n\n`
                }
            }
            txt += `╰──────────❏\n💵 Saldo : ${toRupiah(player.gold)}\n*.shopbomber pasang [id]* — equip umpan\n*.shopbomber lepas* — lepas umpan`
            return Reply(txt)
        }

        // ── TOPMANCING ────────────────────────────────────────────────
        if (command === 'topmancing') {
            const fishers = Object.entries(rpgDB.players)
                .filter(([,p]) => p.fishing && (p.fishing.totalCatch || 0) > 0)
                .sort(([,a], [,b]) => (b.fishing.totalCatch || 0) - (a.fishing.totalCatch || 0))
                .slice(0, 10)
            if (!fishers.length) return Reply(`🎣 Belum ada pemancing!\nMancing dulu dengan *.mancing*`)
            let txt = `╭─────────────────────❏\n│▣   🏆  TOP PEMANCING  🏆\n╰─────────────────────❏\n╭─❏\n`
            const medals = ['🥇', '🥈', '🥉']
            let mentions = []
            fishers.forEach(([jid, p], i) => {
                const medal = medals[i] || `${i + 1}.`
                txt += `│▣ ${medal} @${jid.split('@')[0]} — *${p.fishing.totalCatch || 0}* ekor 🐟\n`
                txt += `│▣   🎣 ${ROD_DATA[p.fishing.equippedRod || 'starter_rod']?.name || 'Starter Rod'}\n`
                mentions.push(jid)
            })
            txt += `╰──────────❏\nMau masuk list? Mancing sekarang dengan *.mancing*!`
            return yonz.sendMessage(m.chat, { text: txt, mentions }, { quoted: m })
        }


        if (command === 'judionline') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.gold < 100) return Reply("❌ duit lu kurang buat deposit, minimal Rp. 100!")
            player.gold -= 100
            const hasil = [
                { nama: "MAXWIN! Lu dapet jackpot besar!", exp: 100, gold: 2000, hp: 0 },
                { nama: "Rungkad... Saldo ludes dimakan bandot.", exp: 10, gold: 0, hp: -5 },
                { nama: "Menang tipis, balik modal aja.", exp: 5, gold: 100, hp: 0 },
                { nama: "Kalah beruntun sampe harus jual ginjal.", exp: 5, gold: -50, hp: -10 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
╭─────────────────────❏
│▣   🎰  JUDI ONLINE  🎰
╰─────────────────────❏
╭─❏
│▣ 💬 Hasil   : ${reward.nama}
│▣ 💵 Gold    : ${reward.gold >= 0 ? "+" : ""}${toRupiah(Math.abs(reward.gold))}
│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp}
│▣ 💵 sisa: ${toRupiah(player.gold)}

╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}
judi gak baik, tapi ini cuma game~`)
            return
        }

        if (command === 'begal') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 25) return Reply("❌ badan lu pegel, gak kuat ngeberhentiin motor orang!")
            const hasil = [
                { nama: "berhasil rampok HP kentang", exp: 30, gold: 300, hp: -10 },
                { nama: "targetnya ngelawan, lu bonyok", exp: 10, gold: 10, hp: -25 },
                { nama: "target ternyata anggota TNI, lari terbirit", exp: 5, gold: 0, hp: -15 },
                { nama: "sukses besar, dapet laptop hasil COD", exp: 50, gold: 500, hp: -15 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
🔪 BEGAL JALANAN
╭─❏
│▣ 💵 +${toRupiah(reward.gold)}

│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp}
╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}`)
            return
        }

        if (command === 'maling') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 15) return Reply("❌ lu terlalu lemes buat gerak cepet!")
            const hasil = [
                { nama: "berhasil nyolong dompet emak-emak", exp: 25, gold: 200, hp: -5 },
                { nama: "ketahuan warga & digebukin", exp: 5, gold: 0, hp: -20 },
                { nama: "cuma dapet kotak kosong", exp: 2, gold: 1, hp: -3 },
                { nama: "salah sasaran, nyolong dompet polisi", exp: 10, gold: 0, hp: -30 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
🥷 *MALING MALAM*
╭─❏
│▣ 💵 +${toRupiah(reward.gold)}

│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp}
╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}`)
            return
        }

        if (command === 'ngojek') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 8) return Reply("❌ lu capek banget, gak kuat narik ojek!")
            const hasil = [
                { nama: "dapet orderan jauh", exp: 15, gold: 70, hp: -8 },
                { nama: "dapet orderan deket", exp: 8, gold: 30, hp: -5 },
                { nama: "kecelakaan kecil", exp: 5, gold: 10, hp: -15 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            player.totalJobs = (player.totalJobs||0) + 1
            checkNewTitles(player)
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
🛵 *NGOJEK*
╭─❏
│▣ 💵 +${toRupiah(reward.gold)}

│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp}
╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}`)
            return
        }

        if (command === 'ngaji') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 3) return Reply("❌ ngantuk berat, gak fokus ngaji!")
            const hasil = [
                { nama: "hati lu tenang", exp: 20, gold: 0, hp: 10 },
                { nama: "dapet ilmu baru", exp: 15, gold: 0, hp: 5 },
                { nama: "ketiduran pas ngaji", exp: 5, gold: 0, hp: -3 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp > player.maxHp) player.hp = player.maxHp
            player.gold += reward.gold
            player.totalJobs = (player.totalJobs||0) + 1
            checkNewTitles(player)
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
📖 NGAJI
╭─❏
│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp > 0 ? "+" : ""}${reward.hp}
╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}
ngaji bikin tenang, jangan lupa istiqomah~`)
            return
        }

        if (command === 'kerja') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 8) return Reply("❌ capek, gak bisa kerja!")
            const hasil = [
                { nama: "lembur dapet bonus", exp: 20, gold: 150, hp: -10 },
                { nama: "kerja santai tapi gaji kecil", exp: 10, gold: 50, hp: -5 },
                { nama: "dimarahin bos", exp: 5, gold: 30, hp: -8 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            player.totalJobs = (player.totalJobs||0) + 1
            checkNewTitles(player)
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
💼 KERJA
╭─❏
│▣ 💵 +${toRupiah(reward.gold)}

│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp}
╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}`)
            return
        }

        if (command === 'jobkerja') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 8) return Reply("❌ capek, gak bisa kerja part time!")
            const hasil = [
                { nama: "jadi kuli bangunan", exp: 15, gold: 100, hp: -12 },
                { nama: "jadi admin warnet", exp: 12, gold: 60, hp: -7 },
                { nama: "kerja part-time di kafe", exp: 18, gold: 80, hp: -10 }
            ]
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            Reply(`
🧑‍🔧 KERJA PART TIME
╭─❏
│▣ 💵 +${toRupiah(reward.gold)}

│▣ ⭐ exp: +${reward.exp}
│▣ ❤️ hp: ${reward.hp}
╰──────────❏
${leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""}`)
            return
        }

        if (command === 'berkebun') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 6) return Reply("🌱 LU MAU BERKEBUN PAKE TANGAN GEMETER? ISTIRAHAT DULU!")
            
            const hasil = [
                { nama: "panen padi banjir", exp: 25, gold: 120, hp: -10 },
                { nama: "dapet sayur mayur", exp: 15, gold: 70, hp: -5 },
                { nama: "tanaman dimakan hama", exp: 8, gold: 30, hp: -7 }
            ]
            
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            player.totalJobs = (player.totalJobs||0) + 1
            checkNewTitles(player)
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            
            let levelUpMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""
            
            Reply(`
╭─────────────────────❏
│▣   🌽  BERKEBUN  🌽
╰─────────────────────❏
╭─❏
│▣ 🌱 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ ❤️  HP      : ${reward.hp}
╰──────────❏
${levelUpMsg}`)
            return
        }

        if (command === 'ngocok') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 5) return Reply("🥵 LU MAU NGOCOK PAKE TANGAN LEMEK? ISTIRAHAT DULU BANGSAT!")
            
            const hasil = [
                { nama: "keluar deras tapi lemes", exp: 5, gold: 10, hp: -3 },
                { nama: "tidur di wc sambil mimpi basah", exp: 2, gold: 5, hp: -5 },
                { nama: "dapet ide ngentot", exp: 8, gold: 15, hp: -2 }
            ]
            
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            
            let levelUpMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""
            
            Reply(`
╭─────────────────────❏
│▣   🍆  NGOCOK  🍆
╰─────────────────────❏
╭─❏
│▣ 💬 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ 🥵 Tenaga  : ${reward.hp}
╰──────────❏
${levelUpMsg}`)
            return
        }

        if (command === 'ngelonte') {
            
                

            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 10) return Reply("💀 LU UDAH REBO, MAU NGELONTE PAKE TONGKAT?")
            
            const hasil = [
                { nama: "dapet om-om kaya raya", exp: 20, gold: 100, hp: -10 },
                { nama: "dapet banci kere hina", exp: 10, gold: 20, hp: -5 },
                { nama: "dikejar satpol pp sambil digebuk", exp: 15, gold: 0, hp: -15 }
            ]
            
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            
            let levelUpMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""
            
            Reply(`
╭─────────────────────❏
│▣   👊  NGELONTE  👊
╰─────────────────────❏
╭─❏
│▣ 💬 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ 🩸 Darah   : ${reward.hp}
╰──────────❏
${levelUpMsg}`)
            return
        }

        if (command === 'openbo') {
            
                
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 10) return Reply("💢 LU MAU OPENBO PAKE KEMEK LELAH? MINUM DULU!")
            
            const hasil = [
                { nama: "dapet om-om sultan minta diempuk", exp: 30, gold: 200, hp: -15 },
                { nama: "dapet bocil kenthu abalabal", exp: 10, gold: 5, hp: -5 },
                { nama: "ditipu customer busuk", exp: 5, gold: 0, hp: -20 }
            ]
            
            let reward = hasil[Math.floor(Math.random() * hasil.length)]
            player.hp += reward.hp
            if (player.hp < 0) player.hp = 0
            player.gold += reward.gold
            let leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            
            
            let levelUpMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}` : ""
            
            Reply(`
╭─────────────────────❏
│▣   💦  OPEN BO  💦
╰─────────────────────❏
╭─❏
│▣ 💬 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ 🍌 Kemek   : ${reward.hp}
╰──────────❏
${levelUpMsg}`)
            return
        }

        if (command === 'market') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            saveMarketDB(marketDB)
            const player = rpgDB.players[senderJid]
            const _mktArgs = text ? text.trim().split(' ') : []
            const sub = _mktArgs[0]?.toLowerCase()

            if (!sub || sub === 'menu') {
                return Reply(`
╭─────────────────────❏
│▣   📈  MARKET GLOBAL  📈
╰─────────────────────❏
╭─❏
│▣ *.market saham*      — 📊 Daftar saham
│▣ *.market properti*   — 🏠 Rumah & bangunan
│▣ *.market kendaraan*  — 🚗 Kendaraan
│▣ *.market asetku*     — 💼 Aset milikmu
│▣ *.market jual*       — 🏪 Jual aset ke player
│▣ *.market listings*   — 📋 Listing player
╰──────────❏
💵 Saldo: ${toRupiah(player.gold)}
Beli: *.beli saham [TICKER] [lot]*  |  *.beli properti [id]*  |  *.beli kendaraan [id]*`)
            }

            if (sub === 'saham') {
                let t = `╭─────────────────────❏\n│▣   📊  BURSA SAHAM  📊\n╰─────────────────────❏\n╭─❏\n│▣ 🕐 Harga update otomatis tiap 5 menit\n│▣\n`
                for (const [ticker, s] of Object.entries(marketDB.saham)) {
                    const arrow = s.change > 0 ? '📈' : s.change < 0 ? '📉' : '➡️'
                    t += `│▣ *${ticker}* — ${toRupiah(s.price)}/lot ${arrow}${s.change > 0 ? '+' : ''}${s.change}%\n`
                    t += `│▣   ↳ ${s.name} (${s.category})\n\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}\n*.beli saham [TICKER] [lot]*`
                return Reply(t)
            }

            if (sub === 'properti') {
                let t = `╭─────────────────────❏\n│▣   🏠  DAFTAR PROPERTI  🏠\n╰─────────────────────❏\n╭─❏\n`
                for (const [id, p] of Object.entries(marketDB.properti)) {
                    t += `│▣ *${p.name}* — ${toRupiah(p.price)}\n`
                    t += `│▣   ↳ ${p.description}\n`
                    if (p.passive > 0) t += `│▣   ↳ 💰 passive: +${toRupiah(p.passive)}/hari\n`
                    t += `│▣   ↳ .beli properti ${id}\n\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            if (sub === 'kendaraan') {
                let t = `╭─────────────────────❏\n│▣   🚗  DAFTAR KENDARAAN  🚗\n╰─────────────────────❏\n╭─❏\n`
                for (const [id, k] of Object.entries(marketDB.kendaraan)) {
                    t += `│▣ *${k.name}* — ${toRupiah(k.price)}\n`
                    t += `│▣   ↳ ${k.description}\n`
                    if (k.passive > 0) t += `│▣   ↳ 💰 passive: +${toRupiah(k.passive)}/hari\n`
                    t += `│▣   ↳ .beli kendaraan ${id}\n\n`
                }
                t += `╰──────────❏\n💵 saldo: ${toRupiah(player.gold)}`
                return Reply(t)
            }

            if (sub === 'asetku') {
                const assets = player.assets || { saham: {}, properti: {}, kendaraan: {} }
                const bankAssets = player.bankAssets || { saham: {}, properti: {}, kendaraan: {} }
                let t = `╭─────────────────────❏\n│▣   💼  ASET MILIKMU  💼\n╰─────────────────────❏\n╭─❏\n`
                t += `│▣ 💵 dompet: ${toRupiah(player.gold)}\n`
                t += `│▣ 🏦 bank: ${toRupiah(player.bank?.balance || 0)}\n│▣\n`
                let hasAsset = false

                const sahamW = Object.entries(assets.saham || {}).filter(([,q]) => q > 0)
                if (sahamW.length > 0) {
                    hasAsset = true
                    t += `│▣ 📊 *SAHAM (dompet)*\n`
                    for (const [ticker, qty] of sahamW) {
                        const harga = marketDB.saham[ticker]?.price || 0
                        t += `│▣   ${ticker} x${qty} = ${toRupiah(harga * qty)}\n`
                    }
                    t += `│▣\n`
                }
                const sahamB = Object.entries(bankAssets.saham || {}).filter(([,q]) => q > 0)
                if (sahamB.length > 0) {
                    hasAsset = true
                    t += `│▣ 📊 *SAHAM (bank)*\n`
                    for (const [ticker, qty] of sahamB) {
                        const harga = marketDB.saham[ticker]?.price || 0
                        t += `│▣   ${ticker} x${qty} = ${toRupiah(harga * qty)}\n`
                    }
                    t += `│▣\n`
                }
                const propW = Object.entries(assets.properti || {}).filter(([,q]) => q > 0)
                if (propW.length > 0) {
                    hasAsset = true
                    t += `│▣ 🏠 *PROPERTI (dompet)*\n`
                    for (const [id, qty] of propW) {
                        const harga = marketDB.properti[id]?.price || 0
                        t += `│▣   ${marketDB.properti[id]?.name || id} x${qty} = ${toRupiah(harga * qty)}\n`
                    }
                    t += `│▣\n`
                }
                const kendarW = Object.entries(assets.kendaraan || {}).filter(([,q]) => q > 0)
                if (kendarW.length > 0) {
                    hasAsset = true
                    t += `│▣ 🚗 *KENDARAAN (dompet)*\n`
                    for (const [id, qty] of kendarW) {
                        const harga = marketDB.kendaraan[id]?.price || 0
                        t += `│▣   ${marketDB.kendaraan[id]?.name || id} x${qty} = ${toRupiah(harga * qty)}\n`
                    }
                }
                if (!hasAsset) t += `│▣ belum punya aset...\n`
                const totalNet = calcTotalAssets(player, marketDB)
                t += `╰──────────❏\n\n💎 *NET WORTH: ${toRupiah(totalNet)}*`
                return Reply(t)
            }

            if (sub === 'listings') {
                const listings = marketDB.listings || []
                if (listings.length === 0) return Reply(`📋 *LISTING KOSONG* — Belum ada yang jual aset saat ini.`)
                let t = `╭─────────────────────❏\n│▣   📋  LISTING PLAYER  📋\n╰─────────────────────❏\n╭─❏\n`
                listings.forEach((l, i) => {
                    t += `│▣ *#${i + 1}* ${l.assetName} (${l.category})\n`
                    t += `│▣   ↳ qty: ${l.qty} | harga: ${toRupiah(l.price)}\n`
                    t += `│▣   ↳ penjual: @${l.seller.split('@')[0]}\n`
                    t += `│▣   ↳ *.beli listing ${i + 1}*\n\n`
                })
                t += `╰──────────❏`
                return await yonz.sendMessage(m.chat, { text: t, mentions: listings.map(l => l.seller) }, { quoted: m })
            }

            if (sub === 'jual') {
                return Reply(`
╭─────────────────────❏
│▣   🏪  JUAL ASET KE PLAYER  🏪
╰─────────────────────❏
╭─❏
│▣ *.jualaset saham [TICKER] [qty] [harga]*
│▣ *.jualaset properti [id] [qty] [harga]*
│▣ *.jualaset kendaraan [id] [qty] [harga]*
╰──────────❏
Contoh: *.jualaset saham ALIP 5 6000*
Aset akan muncul di *.market listings* 📋`)
            }
        }


        if (command === 'minimarket') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const items = getMinimarketItems()
            let txt = `╭─────────────────────❏\n│▣  🏪  MINIMARKET RPG  🏪\n╰─────────────────────❏\n╭─❏\n│▣ Total barang: *100 item*\n│▣ Format: *.beli nama|angka*\n│▣ Contoh: *.beli eskrim|2*\n│▣ Contoh nomor: *.beli 1|2*\n│▣ ──────────────────\n`
            items.forEach(it => {
                txt += `│▣ ${String(it.no).padStart(3, '0')}. ${it.emoji} *${it.name}*\n│▣      Kode: *${it.id}* | ${toRupiah(it.price)}\n`
            })
            txt += `│▣ ──────────────────\n│▣ Cek keranjang: *.keranjang*\n│▣ Bayar: *.bayar*\n╰──────────❏`
            return Reply(txt)
        }

        if (command === 'keranjang') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const cartInfo = renderMinimarketCart(player)
            if (!cartInfo.count) return Reply(`╭─────────────────────❏
│▣  🛒  KERANJANG KOSONG  🛒
╰─────────────────────❏
│▣ Belanja dulu: *.minimarket*
│▣ Masukkan barang: *.beli nama|angka*
╰──────────❏`)
            return Reply(`╭─────────────────────❏
│▣  🛒  KERANJANG MINIMARKET  🛒
╰─────────────────────❏
╭─❏
${cartInfo.rows.join('\n')}
│▣ ──────────────────
│▣ 💵 Total bayar: *${toRupiah(cartInfo.total)}*
│▣ 💰 Gold lu: *${toRupiah(player.gold || 0)}*
│▣ Bayar: *.bayar*
╰──────────❏`)
        }

        if (command === 'bayar') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const cartInfo = renderMinimarketCart(player)
            if (!cartInfo.count) return Reply(`❌ Keranjang kosong. Ngapain bayar angin? Ketik *.minimarket* dulu.`)
            if ((player.gold || 0) < cartInfo.total) return Reply(`❌ Duit kurang, sultan palsu.
Butuh: *${toRupiah(cartInfo.total)}*
Punya: *${toRupiah(player.gold || 0)}*`)
            if (!player.inventory) player.inventory = {}
            player.gold -= cartInfo.total
            for (const [id, qtyRaw] of Object.entries(ensureMinimarketCart(player))) {
                const qty = Number(qtyRaw) || 0
                if (qty <= 0) continue
                const item = getMinimarketItems().find(x => x.id === id)
                if (!item) continue
                player.inventory[id] = (player.inventory[id] || 0) + qty
            }
            player.minimarketCart = {}
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  ✅  BAYAR BERHASIL  ✅
╰─────────────────────❏
╭─❏
${cartInfo.rows.join('\n')}
│▣ ──────────────────
│▣ 💸 Dibayar: *${toRupiah(cartInfo.total)}*
│▣ 💰 Sisa gold: *${toRupiah(player.gold || 0)}*
│▣ Barang masuk inventori. Cek: *.info*
╰──────────❏`)
        }

        if (command === 'beli') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            if (!player.bankAssets) player.bankAssets = { saham: {}, properti: {}, kendaraan: {} }

            const rawBeliText = String(text || '').trim()
            if (rawBeliText.includes('|')) {
                const [namaRaw, qtyRaw] = rawBeliText.split('|')
                const item = findMinimarketItem(namaRaw)
                const qty = Math.max(1, Math.min(999, parseInt(qtyRaw) || 1))
                if (!item) return Reply(`❌ Barang minimarket *${namaRaw || '-'}* gak ketemu. Cek *.minimarket*.`)
                const cart = ensureMinimarketCart(player)
                cart[item.id] = (cart[item.id] || 0) + qty
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                const cartInfo = renderMinimarketCart(player)
                return Reply(`╭─────────────────────❏
│▣  🛒  MASUK KERANJANG  🛒
╰─────────────────────❏
╭─❏
│▣ ${item.emoji} Barang : *${item.name}*
│▣ 📦 Jumlah : *${qty}*
│▣ 💵 Harga  : *${toRupiah(item.price)}* / pcs
│▣ 🧾 Subtotal item: *${toRupiah(item.price * qty)}*
│▣ ──────────────────
│▣ Total keranjang: *${toRupiah(cartInfo.total)}*
│▣ Cek: *.keranjang*
│▣ Bayar: *.bayar*
╰──────────❏`)
            }

            const directMini = findMinimarketItem(rawBeliText)
            if (directMini) {
                const cart = ensureMinimarketCart(player)
                cart[directMini.id] = (cart[directMini.id] || 0) + 1
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                const cartInfo = renderMinimarketCart(player)
                return Reply(`╭─────────────────────❏
│▣  🛒  MASUK KERANJANG  🛒
╰─────────────────────❏
╭─❏
│▣ ${directMini.emoji} Barang : *${directMini.name}*
│▣ 📦 Jumlah : *1*
│▣ 💵 Harga  : *${toRupiah(directMini.price)}*
│▣ Total keranjang: *${toRupiah(cartInfo.total)}*
│▣ Bayar: *.bayar*
╰──────────❏`)
            }

            const _beliArgs = text ? text.trim().split(' ') : []
            const cat = _beliArgs[0]?.toLowerCase()
            const idRaw = _beliArgs[1]
            const qty = parseInt(_beliArgs[2]) || 1

            if (!cat || !idRaw) {
                return Reply(`Gunakan:\n*.beli saham [TICKER] [lot]*\n*.beli properti [id]*\n*.beli kendaraan [id]*\n*.beli listing [no]*
*.beli eskrim|2*  (minimarket masuk keranjang)`)
            }

            if (cat === 'saham') {
                const id = idRaw.toUpperCase()
                if (!marketDB.saham[id]) return Reply(`❌ saham *${id}* gak ada! cek *.market saham*`)
                const saham = marketDB.saham[id]
                const totalHarga = saham.price * qty
                if (player.gold < totalHarga) return Reply(`❌ uang kurang! butuh ${toRupiah(totalHarga)}, punya ${toRupiah(player.gold)}`)
                player.gold -= totalHarga
                player.assets.saham[id] = (player.assets.saham[id] || 0) + qty
                saveMarketDB(marketDB)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`✅ *BELI SAHAM BERHASIL*
╭─❏
│▣ 📊 ${saham.name} (${id})
│▣ 💹 qty: ${qty} lot
│▣ 💵 total: ${toRupiah(totalHarga)}
│▣ 💰 sisa: ${toRupiah(player.gold)}
╰──────────❏
cek aset di *.market asetku*`)
            }

            if (cat === 'properti') {
                const id = idRaw.toLowerCase()
                if (!marketDB.properti[id]) return Reply(`❌ properti *${id}* gak ada! cek *.market properti*`)
                const prop = marketDB.properti[id]
                const totalHarga = prop.price * qty
                if (player.gold < totalHarga) return Reply(`❌ uang kurang! butuh ${toRupiah(totalHarga)}, punya ${toRupiah(player.gold)}`)
                player.gold -= totalHarga
                player.assets.properti[id] = (player.assets.properti[id] || 0) + qty
                saveMarketDB(marketDB)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`✅ *BELI PROPERTI BERHASIL*
╭─❏
│▣ 🏠 ${prop.name}
│▣ 💵 total: ${toRupiah(totalHarga)}
│▣ 💰 sisa: ${toRupiah(player.gold)}
${prop.passive > 0 ? `│▣ 💰 passive income: +${toRupiah(prop.passive)}/hari\n` : ''}╰──────────❏`)
            }

            if (cat === 'kendaraan') {
                const id = idRaw.toLowerCase()
                if (!marketDB.kendaraan[id]) return Reply(`❌ kendaraan *${id}* gak ada! cek *.market kendaraan*`)
                const kendaraan = marketDB.kendaraan[id]
                const totalHarga = kendaraan.price * qty
                if (player.gold < totalHarga) return Reply(`❌ uang kurang! butuh ${toRupiah(totalHarga)}, punya ${toRupiah(player.gold)}`)
                player.gold -= totalHarga
                player.assets.kendaraan[id] = (player.assets.kendaraan[id] || 0) + qty
                saveMarketDB(marketDB)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`✅ *BELI KENDARAAN BERHASIL*
╭─❏
│▣ 🚗 ${kendaraan.name}
│▣ 💵 total: ${toRupiah(totalHarga)}
│▣ 💰 sisa: ${toRupiah(player.gold)}
╰──────────❏`)
            }

            if (cat === 'listing') {
                const no = parseInt(idRaw) - 1
                const listings = marketDB.listings || []
                if (no < 0 || no >= listings.length) return Reply(`❌ nomor listing gak valid! cek *.market listings*`)
                const listing = listings[no]
                if (listing.seller === m.sender) return Reply(`❌ lu gak bisa beli listing sendiri!`)
                if (player.gold < listing.price) return Reply(`❌ uang kurang! butuh ${toRupiah(listing.price)}, punya ${toRupiah(player.gold)}`)
                player.gold -= listing.price
                const sellerPlayer = rpgDB.players[listing.seller]
                if (sellerPlayer) sellerPlayer.gold += listing.price
                if (!player.assets[listing.category]) player.assets[listing.category] = {}
                player.assets[listing.category][listing.assetId] = (player.assets[listing.category][listing.assetId] || 0) + listing.qty
                marketDB.listings.splice(no, 1)
                saveMarketDB(marketDB)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`✅ *BELI LISTING BERHASIL*
╭─❏
│▣ 📦 ${listing.assetName} x${listing.qty}
│▣ 💵 dibayar: ${toRupiah(listing.price)}
│▣ 💰 sisa: ${toRupiah(player.gold)}
╰──────────❏`)
            }

            return Reply(`❌ kategori gak valid! gunakan: saham / properti / kendaraan / listing
Minimarket: *.beli nama|jumlah* lalu *.bayar*`)
        }

        if (command === 'jualsaham') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            if (!player.bankAssets) player.bankAssets = { saham: {}, properti: {}, kendaraan: {} }

            const _jsArgs = text ? text.trim().split(' ') : []
            const ticker = _jsArgs[0]?.toUpperCase()
            const qty = parseInt(_jsArgs[1]) || 1
            if (!ticker) return Reply(`Gunakan: *.jualsaham [TICKER] [lot]*\nContoh: .jualsaham ALIP 5`)
            if (!marketDB.saham[ticker]) return Reply(`❌ saham *${ticker}* gak ada!`)

            const ownedWallet = player.assets.saham[ticker] || 0
            const ownedBank = player.bankAssets.saham?.[ticker] || 0
            const totalOwned = ownedWallet + ownedBank
            if (totalOwned < qty) return Reply(`❌ lu cuma punya ${totalOwned} lot saham ${ticker}!`)

            let fromWallet = Math.min(qty, ownedWallet)
            let fromBank = qty - fromWallet
            player.assets.saham[ticker] = ownedWallet - fromWallet
            if (fromBank > 0) player.bankAssets.saham[ticker] = ownedBank - fromBank

            const harga = marketDB.saham[ticker].price
            const total = Math.floor(harga * qty * 0.95)
            player.gold += total
            saveMarketDB(marketDB)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`💵 *JUAL SAHAM BERHASIL*
╭─❏
│▣ 📊 ${marketDB.saham[ticker].name} (${ticker})
│▣ 💹 qty: ${qty} lot
│▣ 💵 diterima: ${toRupiah(total)} (fee 5%)
│▣ 💰 saldo: ${toRupiah(player.gold)}
╰──────────❏`)
        }

        if (command === 'jualaset') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }

            const _jaArgs = text ? text.trim().split(' ') : []
            const cat = _jaArgs[0]?.toLowerCase()
            const id = cat === 'saham' ? _jaArgs[1]?.toUpperCase() : _jaArgs[1]?.toLowerCase()
            const qty = parseInt(_jaArgs[2]) || 1
            const hargaJual = parseInt(_jaArgs[3])

            if (!cat || !id || !hargaJual) {
                return Reply(`Gunakan:\n*.jualaset saham [TICKER] [qty] [harga]*\n*.jualaset properti [id] [qty] [harga]*\n*.jualaset kendaraan [id] [qty] [harga]*`)
            }

            if (!['saham', 'properti', 'kendaraan'].includes(cat)) return Reply(`❌ kategori salah!`)
            const owned = player.assets[cat]?.[id] || 0
            if (owned < qty) return Reply(`❌ aset tidak cukup! punya ${owned}, mau jual ${qty}`)
            if (!marketDB.listings) marketDB.listings = []
            if (marketDB.listings.filter(l => l.seller === m.sender).length >= 5) {
                return Reply(`❌ maksimal 5 listing aktif sekaligus!`)
            }

            let assetName = id
            if (cat === 'saham' && marketDB.saham[id]) assetName = `${marketDB.saham[id].name} (${id})`
            else if (marketDB[cat]?.[id]) assetName = marketDB[cat][id].name

            player.assets[cat][id] -= qty
            marketDB.listings.push({
                seller: m.sender,
                category: cat,
                assetId: id,
                assetName,
                qty,
                price: hargaJual,
                listedAt: Date.now()
            })
            saveMarketDB(marketDB)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`✅ *LISTING BERHASIL*
╭─❏
│▣ 📦 ${assetName} x${qty}
│▣ 💵 harga: ${toRupiah(hargaJual)}
│▣ 👁️ tampil di *.market listings*
╰──────────❏
listing aktif max 5`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .jualasetbot — jual aset ke sistem bot
        // ─────────────────────────────────────────────
        if (command === 'jualasetbot') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            if (!player.bankAssets) player.bankAssets = { saham: {}, properti: {}, kendaraan: {} }

            const _jabArgs = text ? text.trim().split(' ') : []
            const cat = _jabArgs[0]?.toLowerCase()
            const id = cat === 'saham' ? _jabArgs[1]?.toUpperCase() : _jabArgs[1]?.toLowerCase()
            const qty = parseInt(_jabArgs[2]) || 1

            if (!cat || !id) {
                return Reply(`🏦 *JUAL ASET KE BOT SISTEM*
╭─❏
╭─❏
│▣ *.jualasetbot saham [TICKER] [lot]*
│▣ *.jualasetbot properti [id] [qty]*
│▣ *.jualasetbot kendaraan [id] [qty]*
╰──────────❏
fee: saham 5% | properti 10% | kendaraan 15%
harga mengikuti market saat ini`)
            }

            if (!['saham', 'properti', 'kendaraan'].includes(cat)) return Reply(`❌ kategori salah! saham / properti / kendaraan`)

            const ownedWallet = player.assets[cat]?.[id] || 0
            const ownedBank   = player.bankAssets[cat]?.[id] || 0
            const totalOwned  = ownedWallet + ownedBank
            if (totalOwned < qty) return Reply(`❌ aset tidak cukup! total punya ${totalOwned}, mau jual ${qty}`)

            let hargaSatuan = 0
            let assetName = id
            let fee = 0
            if (cat === 'saham') {
                if (!marketDB.saham[id]) return Reply(`❌ saham *${id}* tidak ada di bursa!`)
                hargaSatuan = marketDB.saham[id].price
                assetName = `${marketDB.saham[id].name} (${id})`
                fee = 0.05
            } else if (cat === 'properti') {
                if (!marketDB.properti[id]) return Reply(`❌ properti *${id}* tidak ada!`)
                hargaSatuan = marketDB.properti[id].price
                assetName = marketDB.properti[id].name
                fee = 0.10
            } else if (cat === 'kendaraan') {
                if (!marketDB.kendaraan[id]) return Reply(`❌ kendaraan *${id}* tidak ada!`)
                hargaSatuan = marketDB.kendaraan[id].price
                assetName = marketDB.kendaraan[id].name
                fee = 0.15
            }

            const grossTotal = hargaSatuan * qty
            const feeAmount  = Math.floor(grossTotal * fee)
            const netTotal   = grossTotal - feeAmount

            // Kurangi dari wallet dulu, sisanya dari bank
            let fromWallet = Math.min(qty, ownedWallet)
            let fromBank   = qty - fromWallet
            player.assets[cat][id] = ownedWallet - fromWallet
            if (fromBank > 0) {
                if (!player.bankAssets[cat]) player.bankAssets[cat] = {}
                player.bankAssets[cat][id] = (player.bankAssets[cat][id] || 0) - fromBank
            }

            player.gold += netTotal
            saveMarketDB(marketDB)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`💰 *JUAL KE BOT BERHASIL*
╭─❏
│▣ 📦 ${assetName} x${qty}
│▣ 💵 harga satuan: ${toRupiah(hargaSatuan)}
│▣ 💸 fee (${Math.floor(fee * 100)}%): -${toRupiah(feeAmount)}
│▣ ✅ diterima: ${toRupiah(netTotal)}
│▣ 💰 saldo: ${toRupiah(player.gold)}
╰──────────❏
jual ke player via *.jualaset* untuk harga lebih baik!`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .batallisting [no] — batalkan listing
        // ─────────────────────────────────────────────
        if (command === 'batallisting') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }

            const no = parseInt(text) - 1
            const listings = marketDB.listings || []
            if (isNaN(no) || no < 0 || no >= listings.length) {
                // Tampilkan listing milik sender
                const myListings = listings
                    .map((l, i) => ({ ...l, no: i + 1 }))
                    .filter(l => l.seller === m.sender)
                if (myListings.length === 0) return Reply(`📋 lu gak punya listing aktif!\njual aset dengan *.jualaset*`)
                let t = `📋 *LISTING AKTIFMU*\n╭─❏\n`
                myListings.forEach(l => {
                    t += `│▣ #${l.no} ${l.assetName} x${l.qty} — ${toRupiah(l.price)}\n`
                })
                t += `╰──────────❏\nbatalin: *.batallisting [nomor]*`
                return Reply(t)
            }

            const listing = listings[no]
            if (listing.seller !== m.sender) return Reply(`❌ itu bukan listing lu!`)

            // Kembalikan aset
            if (!player.assets[listing.category]) player.assets[listing.category] = {}
            player.assets[listing.category][listing.assetId] = (player.assets[listing.category][listing.assetId] || 0) + listing.qty
            marketDB.listings.splice(no, 1)
            saveMarketDB(marketDB)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`✅ *LISTING DIBATALKAN*
╭─❏
│▣ 📦 ${listing.assetName} x${listing.qty} kembali ke dompet
╰──────────❏`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .ceksaham [TICKER] — cek detail saham
        // ─────────────────────────────────────────────
        if (command === 'ceksaham') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            saveMarketDB(marketDB)

            if (!text) {
                // Tampilkan semua saham ringkas
                let t = `╭─────────────────────❏\n│▣   📊  RINGKASAN SAHAM  📊\n╰─────────────────────❏\n╭─❏\n│▣ 🕐 Harga update otomatis tiap 5 menit\n│▣\n`
                for (const [ticker, s] of Object.entries(marketDB.saham)) {
                    const arrow = s.change > 0 ? '📈' : s.change < 0 ? '📉' : '➡️'
                    t += `│▣ *${ticker}* ${toRupiah(s.price)} ${arrow}${s.change > 0 ? '+' : ''}${s.change}%\n`
                }
                t += `╰──────────❏\n*.ceksaham [TICKER]* untuk detail`
                return Reply(t)
            }

            const ticker = text.trim().toUpperCase()
            const s = marketDB.saham[ticker]
            if (!s) return Reply(`❌ saham *${ticker}* tidak ada! cek *.market saham*`)

            const player = rpgDB.players[senderJid]
            const ownedWallet = player.assets?.saham?.[ticker] || 0
            const ownedBank   = player.bankAssets?.saham?.[ticker] || 0
            const totalOwned  = ownedWallet + ownedBank
            const nilaiTotal  = s.price * totalOwned
            const arrow = s.change > 0 ? '📈 NAIK' : s.change < 0 ? '📉 TURUN' : '➡️ STABIL'
            const basePrice = s.basePrice || s.price
            const totalChange = Math.round((s.price - basePrice) / basePrice * 100 * 10) / 10

            return Reply(`📊 *DETAIL SAHAM ${ticker}*
╭─❏
│▣ 🏢 ${s.name}
│▣ 🏷️ kategori: ${s.category}
│▣ 💵 harga: ${toRupiah(s.price)}/lot
│▣ 📈 perubahan: ${s.change > 0 ? '+' : ''}${s.change}% ${arrow}
│▣ 📊 total dari awal: ${totalChange > 0 ? '+' : ''}${totalChange}%
│▣
│▣ 👛 milikmu (dompet): ${ownedWallet} lot
│▣ 🏦 milikmu (bank): ${ownedBank} lot
│▣ 💎 nilai aset: ${toRupiah(nilaiTotal)}
╰──────────❏
beli: *.beli saham ${ticker} [lot]*
jual ke market: *.jualaset saham ${ticker} [lot] [harga]*
jual ke bot: *.jualasetbot saham ${ticker} [lot]*`)
        }

        // ─────────────────────────────────────────────
        // COMMAND: .portofolio — ringkasan investasi
        // ─────────────────────────────────────────────
        if (command === 'portofolio') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            const player = rpgDB.players[senderJid]

            let t = `💼 *PORTOFOLIO INVESTASI*\n╭─❏\n`
            let totalInvest = 0

            // Saham
            const allSaham = {}
            for (const [k, v] of Object.entries(player.assets?.saham || {})) { allSaham[k] = (allSaham[k] || 0) + v }
            for (const [k, v] of Object.entries(player.bankAssets?.saham || {})) { allSaham[k] = (allSaham[k] || 0) + v }
            const sahamEntries = Object.entries(allSaham).filter(([,q]) => q > 0)
            if (sahamEntries.length > 0) {
                t += `│▣ 📊 *SAHAM*\n`
                for (const [ticker, qty] of sahamEntries) {
                    const s = marketDB.saham[ticker]
                    if (!s) continue
                    const nilai = s.price * qty
                    totalInvest += nilai
                    const change = s.change !== 0 ? ` (${s.change > 0 ? '+' : ''}${s.change}%)` : ''
                    t += `│▣  ${ticker} x${qty} = ${toRupiah(nilai)}${change}\n`
                }
                t += `│▣\n`
            }

            // Properti
            const propEntries = Object.entries({
                ...(player.assets?.properti || {}),
                ...Object.fromEntries(Object.entries(player.bankAssets?.properti || {}).map(([k, v]) => [k, (player.assets?.properti?.[k] || 0) + v]))
            }).filter(([,q]) => q > 0)
            if (propEntries.length > 0) {
                t += `│▣ 🏠 *PROPERTI*\n`
                for (const [id, qty] of propEntries) {
                    const p = marketDB.properti[id]
                    if (!p) continue
                    const nilai = p.price * qty
                    totalInvest += nilai
                    t += `│▣  ${p.name} x${qty} = ${toRupiah(nilai)}\n`
                }
                t += `│▣\n`
            }

            // Kendaraan
            const kendarEntries = Object.entries(player.assets?.kendaraan || {}).filter(([,q]) => q > 0)
            if (kendarEntries.length > 0) {
                t += `│▣ 🚗 *KENDARAAN*\n`
                for (const [id, qty] of kendarEntries) {
                    const k = marketDB.kendaraan[id]
                    if (!k) continue
                    const nilai = k.price * qty
                    totalInvest += nilai
                    t += `│▣  ${k.name} x${qty} = ${toRupiah(nilai)}\n`
                }
            }

            if (totalInvest === 0) {
                t += `│▣ belum ada investasi...\n`
            }

            t += `╰──────────❏\n`
            t += `💎 *TOTAL INVESTASI: ${toRupiah(totalInvest)}*\n`
            t += `💵 dompet: ${toRupiah(player.gold)} | 🏦 bank: ${toRupiah(player.bank?.balance || 0)}`
            return Reply(t)
        }

        if (command === 'topkaya') {
            let marketDB = getMarketDB()
            marketDB = fluctuateSaham(marketDB)
            const players = Object.entries(rpgDB.players)
            if (players.length < 1) return Reply(`❌ Belum ada sultan terdaftar!`)

            const ranked = players
                .map(([jid, p]) => ({ jid, net: calcTotalAssets(p, marketDB) }))
                .filter(x => x.net > 0)
                .sort((a, b) => b.net - a.net)
                .slice(0, 10)

            if (ranked.length === 0) return Reply(`❌ Belum ada aset. Mulai investasi sekarang!`)

            let t = `╭─────────────────────❏\n│▣   💎  TOP 10 TERKAYA  💎\n╰─────────────────────❏\n╭─❏\n`
            const medals = ['🥇', '🥈', '🥉']
            ranked.forEach(({ jid, net }, i) => {
                const medal = medals[i] || `${i + 1}.`
                t += `│▣ ${medal} @${jid.split('@')[0]} — *${toRupiah(net)}*\n`
            })
            t += `╰──────────❏`
            return await yonz.sendMessage(m.chat, { text: t, mentions: ranked.map(x => x.jid) }, { quoted: m })
        }

        if (command === 'simpanaset') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            if (!player.bankAssets) player.bankAssets = { saham: {}, properti: {}, kendaraan: {} }

            const _saArgs = text ? text.trim().split(' ') : []
            const cat = _saArgs[0]?.toLowerCase()
            const id = cat === 'saham' ? _saArgs[1]?.toUpperCase() : _saArgs[1]?.toLowerCase()
            const qty = parseInt(_saArgs[2]) || 1

            if (!cat || !id) return Reply(`Gunakan: *.simpanaset [saham/properti/kendaraan] [id] [qty]*\nContoh: .simpanaset saham ALIP 10`)
            if (!['saham', 'properti', 'kendaraan'].includes(cat)) return Reply(`❌ kategori salah!`)

            const owned = player.assets[cat]?.[id] || 0
            if (owned < qty) return Reply(`❌ aset di dompet tidak cukup! punya ${owned}, mau simpan ${qty}`)

            player.assets[cat][id] -= qty
            if (!player.bankAssets[cat]) player.bankAssets[cat] = {}
            player.bankAssets[cat][id] = (player.bankAssets[cat][id] || 0) + qty
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  🏦  ASET DISIMPAN KE BANK  🏦
╰─────────────────────❏
╭─❏
│▣ 📦 Kategori  : ${cat}
│▣ 🏷️  ID        : ${id}
│▣ 🔢 Qty       : x${qty}
│▣ 🔒 Status    : Aman di bank
╰──────────❏
Tarik dengan *.tarikaset ${cat} ${id} ${qty}* 📤`)
        }

        if (command === 'tarikaset') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.bankAssets) player.bankAssets = { saham: {}, properti: {}, kendaraan: {} }

            const _taArgs = text ? text.trim().split(' ') : []
            const cat = _taArgs[0]?.toLowerCase()
            const id = cat === 'saham' ? _taArgs[1]?.toUpperCase() : _taArgs[1]?.toLowerCase()
            const qty = parseInt(_taArgs[2]) || 1

            if (!cat || !id) return Reply(`Gunakan: *.tarikaset [saham/properti/kendaraan] [id] [qty]*\nContoh: .tarikaset saham ALIP 5`)
            if (!['saham', 'properti', 'kendaraan'].includes(cat)) return Reply(`❌ kategori salah!`)

            const banked = player.bankAssets[cat]?.[id] || 0
            if (banked < qty) return Reply(`❌ aset di bank tidak cukup! ada ${banked}, mau tarik ${qty}`)

            player.bankAssets[cat][id] -= qty
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            if (!player.assets[cat]) player.assets[cat] = {}
            player.assets[cat][id] = (player.assets[cat][id] || 0) + qty
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  🏦  ASET DITARIK DARI BANK  🏦
╰─────────────────────❏
╭─❏
│▣ 📦 Kategori  : ${cat}
│▣ 🏷️  ID        : ${id}
│▣ 🔢 Qty       : x${qty}
│▣ ✅ Status    : Kembali ke dompet
╰──────────❏`)
        }

        if (command === 'pasifincome') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            const marketDB = getMarketDB()

            const cooldown = 24 * 60 * 60 * 1000
            const now = Date.now()
            if (now - (player.lastPassive || 0) < cooldown) {
                const timeLeft = msToTime((player.lastPassive || 0) + cooldown - now)
                return Reply(`⏳ passive income bisa diklaim lagi dalam *${timeLeft}*`)
            }

            let totalPassive = 0
            let breakdown = []

            for (const [id, qty] of Object.entries(player.assets.properti || {})) {
                if (qty <= 0) continue
                const prop = marketDB.properti[id]
                if (prop?.passive > 0) {
                    const earn = prop.passive * qty
                    totalPassive += earn
                    breakdown.push(`│▣ 🏠 ${prop.name} x${qty} = +${toRupiah(earn)}`)
                }
            }
            for (const [id, qty] of Object.entries(player.assets.kendaraan || {})) {
                if (qty <= 0) continue
                const kendaraan = marketDB.kendaraan[id]
                if (kendaraan?.passive > 0) {
                    const earn = kendaraan.passive * qty
                    totalPassive += earn
                    breakdown.push(`│▣ 🚚 ${kendaraan.name} x${qty} = +${toRupiah(earn)}`)
                }
            }

            if (totalPassive === 0) return Reply(`❌ lu gak punya aset yang ngasih passive income!\nBeli properti atau truk di *.market properti*`)

            player.gold += totalPassive
            player.lastPassive = now
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  💰  PASSIVE INCOME DIKLAIM!  💰
╰─────────────────────❏
╭─❏
${breakdown.join('\n')}
│▣ ──────────────────
│▣ 💵 Total   : +${toRupiah(totalPassive)}
│▣ 💰 Saldo   : ${toRupiah(player.gold)}
╰──────────❏
Klaim lagi besok! 🔔`)
        }

        // =====================================================
        // RESETGOLDALL — reset gold semua member (creator only)
        // Usage: .resetgoldall [jumlah]
        // =====================================================
        if (command === 'resetgoldall') {
            if (!isCreator) return Reply(`❌ *Khusus owner bot!*`)
            const resetAmount = parseInt(text) || 0
            if (isNaN(resetAmount) || resetAmount < 0) return Reply(`❌ Jumlah tidak valid!\nContoh: .resetgoldall 1000`)

            const totalPlayers = Object.keys(rpgDB.players).length
            if (totalPlayers === 0) return Reply(`❌ Belum ada player terdaftar.`)

            for (const jid of Object.keys(rpgDB.players)) {
                rpgDB.players[jid].gold = resetAmount
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  💰  RESET GOLD ALL  💰
╰─────────────────────❏
╭─❏
│▣ 👥 Total Player  : *${totalPlayers}* orang
│▣ 💵 Gold Di-set   : *${toRupiah(resetAmount)}*
│▣ ✅ Status        : Berhasil
╰──────────❏
Semua member sekarang punya ${toRupiah(resetAmount)}!`)
        }

        // =====================================================
        // RESETGOLDUSER — reset gold 1 user tertentu (creator only)
        // Usage: .resetgolduser [jumlah] @mention / reply
        // =====================================================
        if (command === 'resetgolduser') {
            if (!isCreator) return Reply(`❌ *Khusus owner bot!*`)

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetJid = m.mentionedJid[0]
                if (targetJid.endsWith('@lid') && m.metadata?.participants) {
                    let p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                    if (p && p.jid) targetJid = p.jid
                }
            } else if (m.quoted) {
                targetJid = m.quoted.sender
            }

            if (!targetJid) return Reply(`Tag atau reply user dulu!\nContoh: .resetgolduser 5000 @user`)

            const textParts = text ? text.trim().split(' ') : []
            const resetAmount = parseInt(textParts[0]) || 0

            if (!rpgDB.players[targetJid]) return Reply(`❌ User tersebut belum daftar RPG.`)

            const oldGold = rpgDB.players[targetJid].gold
            rpgDB.players[targetJid].gold = resetAmount
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return yonz.sendMessage(m.chat, {
                text: `
╭─────────────────────❏
│▣  💵  RESET GOLD USER  💵
╰─────────────────────❏
╭─❏
│▣ 👤 User       : @${targetJid.split('@')[0]}
│▣ 💰 Gold Lama  : ${toRupiah(oldGold)}
│▣ 💵 Gold Baru  : ${toRupiah(resetAmount)}
│▣ ✅ Status     : Berhasil
╰──────────❏`,
                mentions: [targetJid]
            }, { quoted: m })
        }

        // =====================================================
        // EDITGOLD — tambah / kurang gold user (creator only)
        // Usage: .editgold [+/-jumlah] @mention / reply
        // =====================================================
        if (command === 'editgold') {
            if (!isCreator) return Reply(`❌ *Khusus owner bot!*`)

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetJid = m.mentionedJid[0]
                if (targetJid.endsWith('@lid') && m.metadata?.participants) {
                    let p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                    if (p && p.jid) targetJid = p.jid
                }
            } else if (m.quoted) {
                targetJid = m.quoted.sender
            }

            if (!targetJid) return Reply(`Tag atau reply user dulu!\nContoh:\n.editgold +5000 @user\n.editgold -2000 @user`)

            const rawText = text ? text.trim().split(' ')[0] : ''
            if (!rawText) return Reply(`Masukkan jumlah edit!\nContoh: .editgold +5000 @user`)

            const isNeg = rawText.startsWith('-')
            const editAmount = parseInt(rawText.replace(/[^0-9]/g, ''))
            if (isNaN(editAmount) || editAmount <= 0) return Reply(`❌ Jumlah tidak valid!`)

            if (!rpgDB.players[targetJid]) return Reply(`❌ User tersebut belum daftar RPG.`)

            const oldGold = rpgDB.players[targetJid].gold
            if (isNeg) {
                rpgDB.players[targetJid].gold = Math.max(0, oldGold - editAmount)
            } else {
                rpgDB.players[targetJid].gold += editAmount
            }
            const newGold = rpgDB.players[targetJid].gold
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return yonz.sendMessage(m.chat, {
                text: `
╭─────────────────────❏
│▣  ✏️  EDIT GOLD USER  ✏️
╰─────────────────────❏
╭─❏
│▣ 👤 User       : @${targetJid.split('@')[0]}
│▣ 💰 Gold Lama  : ${toRupiah(oldGold)}
│▣ ${isNeg ? '➖' : '➕'} Perubahan  : ${isNeg ? '-' : '+'}${toRupiah(editAmount)}
│▣ 💵 Gold Baru  : ${toRupiah(newGold)}
│▣ ✅ Status     : Berhasil
╰──────────❏`,
                mentions: [targetJid]
            }, { quoted: m })
        }

        // =====================================================
        // RESETBANKALL — reset saldo bank semua player ke jumlah tertentu
        // Usage: .resetbankall [jumlah]
        // Khusus: OWNER UTAMA saja (global.owner)
        // =====================================================
        if (command === 'resetbankall') {
            const isMainOwner = m.sender === (global.owner + '@s.whatsapp.net') ||
                                m.sender === (global.owner + '@lid') ||
                                m.sender.split('@')[0] === String(global.owner).replace(/[^0-9]/g, '')
            if (!isMainOwner) return Reply(`❌ *Command ini khusus owner utama bot!*\nBukan untuk co-owner atau admin.`)

            const resetAmount = parseInt(text) || 0
            if (isNaN(resetAmount) || resetAmount < 0) return Reply(`❌ Jumlah tidak valid!\nContoh: *.resetbankall 0*`)

            const allJids = Object.keys(rpgDB.players)
            if (allJids.length === 0) return Reply(`❌ Belum ada player terdaftar.`)

            let totalReset = 0
            for (const jid of allJids) {
                if (!rpgDB.players[jid].bank) {
                    rpgDB.players[jid].bank = { balance: 0, totalDeposited: 0, totalWithdrawn: 0 }
                }
                rpgDB.players[jid].bank.balance = resetAmount
                totalReset++
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`
╭─────────────────────❏
│▣  🏦  RESET BANK ALL  🏦
╰─────────────────────❏
╭─❏
│▣ 👥 Total Player  : *${totalReset}* orang
│▣ 💰 Saldo Di-set  : *${toRupiah(resetAmount)}*
│▣ 🔐 Dilakukan     : Owner Utama
│▣ ✅ Status        : Berhasil
╰──────────❏
Saldo bank semua member sekarang *${toRupiah(resetAmount)}*!`)
        }

        // =====================================================
        // EDITBANK — tambah / kurang / set saldo bank 1 user tertentu
        // Usage: .editbank [+/-/=jumlah] @mention / reply
        // Contoh:
        //   .editbank +50000 @user  → tambah 50rb ke bank
        //   .editbank -20000 @user  → kurangi 20rb dari bank
        //   .editbank =100000 @user → set langsung jadi 100rb
        // Khusus: OWNER UTAMA saja (global.owner)
        // =====================================================
        if (command === 'editbank') {
            const isMainOwner = m.sender === (global.owner + '@s.whatsapp.net') ||
                                m.sender === (global.owner + '@lid') ||
                                m.sender.split('@')[0] === String(global.owner).replace(/[^0-9]/g, '')
            if (!isMainOwner) return Reply(`❌ *Command ini khusus owner utama bot!*\nBukan untuk co-owner atau admin.`)

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetJid = m.mentionedJid[0]
                if (targetJid.endsWith('@lid') && m.metadata?.participants) {
                    const p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                    if (p && p.jid) targetJid = p.jid
                }
            } else if (m.quoted) {
                targetJid = m.quoted.sender
            }

            if (!targetJid) return Reply(`❌ Tag atau reply user dulu!\n\nCara pakai:\n*.editbank +50000 @user* — tambah\n*.editbank -20000 @user* — kurangi\n*.editbank =100000 @user* — set langsung`)

            const rawArg = text ? text.trim().split(/\s+/)[0] : ''
            if (!rawArg) return Reply(`❌ Masukkan jumlah edit!\n\nCara pakai:\n*.editbank +50000 @user* — tambah\n*.editbank -20000 @user* — kurangi\n*.editbank =100000 @user* — set langsung`)

            const isAdd  = rawArg.startsWith('+')
            const isSub  = rawArg.startsWith('-')
            const isSet  = rawArg.startsWith('=')

            if (!isAdd && !isSub && !isSet) return Reply(`❌ Awali dengan *+* (tambah), *-* (kurangi), atau *=* (set).\nContoh: *.editbank +50000 @user*`)

            const amount = parseInt(rawArg.replace(/[^0-9]/g, ''))
            if (isNaN(amount) || amount < 0) return Reply(`❌ Jumlah tidak valid!`)

            if (!rpgDB.players[targetJid]) return Reply(`❌ User tersebut belum daftar RPG!`)

            if (!rpgDB.players[targetJid].bank) {
                rpgDB.players[targetJid].bank = { balance: 0, totalDeposited: 0, totalWithdrawn: 0 }
            }

            const oldBank = rpgDB.players[targetJid].bank.balance || 0
            let newBank = oldBank
            let opEmoji = ''
            let opLabel = ''

            if (isAdd) {
                newBank = oldBank + amount
                opEmoji = '➕'
                opLabel = `+${toRupiah(amount)}`
            } else if (isSub) {
                newBank = Math.max(0, oldBank - amount)
                opEmoji = '➖'
                opLabel = `-${toRupiah(amount)}`
            } else if (isSet) {
                newBank = amount
                opEmoji = '🔄'
                opLabel = `= ${toRupiah(amount)}`
            }

            rpgDB.players[targetJid].bank.balance = newBank
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `
╭─────────────────────❏
│▣  ✏️  EDIT BANK USER  ✏️
╰─────────────────────❏
╭─❏
│▣ 👤 User       : @${targetJid.split('@')[0]}
│▣ 🏦 Bank Lama  : ${toRupiah(oldBank)}
│▣ ${opEmoji} Perubahan  : ${opLabel}
│▣ 💰 Bank Baru  : *${toRupiah(newBank)}*
│▣ ✅ Status     : Berhasil
╰──────────❏`,
                mentions: [targetJid]
            }, { quoted: m })
        }

        // =====================================================
        // RESETASETALL — reset semua aset (saham, properti, kendaraan)
        //                semua player sekaligus
        // Usage: .resetasetall
        //        .resetasetall saham      → hanya reset saham
        //        .resetasetall properti   → hanya reset properti
        //        .resetasetall kendaraan  → hanya reset kendaraan
        // Khusus: OWNER UTAMA saja (global.owner)
        // =====================================================
        if (command === 'resetasetall') {
            const isMainOwner = m.sender === (global.owner + '@s.whatsapp.net') ||
                                m.sender === (global.owner + '@lid') ||
                                m.sender.split('@')[0] === String(global.owner).replace(/[^0-9]/g, '')
            if (!isMainOwner) return Reply(`❌ *Command ini khusus owner utama bot!*\nBukan untuk co-owner atau admin.`)

            const allJids = Object.keys(rpgDB.players)
            if (allJids.length === 0) return Reply(`❌ Belum ada player terdaftar.`)

            // Tentukan kategori aset yang di-reset
            const subArg = text ? text.trim().toLowerCase() : ''
            const validCats = ['saham', 'properti', 'kendaraan']
            let targetCats = []

            if (!subArg || subArg === 'semua' || subArg === 'all') {
                targetCats = ['saham', 'properti', 'kendaraan']
            } else if (validCats.includes(subArg)) {
                targetCats = [subArg]
            } else {
                return Reply(`❌ Kategori tidak valid!\n\nCara pakai:\n*.resetasetall* — reset semua aset\n*.resetasetall saham* — hanya saham\n*.resetasetall properti* — hanya properti\n*.resetasetall kendaraan* — hanya kendaraan`)
            }

            let totalPlayer = 0
            let stats = {}
            for (const cat of targetCats) stats[cat] = 0

            for (const jid of allJids) {
                const p = rpgDB.players[jid]
                if (!p) continue

                // Hitung total item yang akan dihapus (untuk laporan)
                for (const cat of targetCats) {
                    // Wallet aset
                    if (p.assets && p.assets[cat]) {
                        for (const qty of Object.values(p.assets[cat])) {
                            if (qty > 0) stats[cat] += qty
                        }
                        p.assets[cat] = {}
                    }
                    // Bank aset
                    if (p.bankAssets && p.bankAssets[cat]) {
                        for (const qty of Object.values(p.bankAssets[cat])) {
                            if (qty > 0) stats[cat] += qty
                        }
                        p.bankAssets[cat] = {}
                    }
                }

                // Pastikan struktur aset tetap valid
                if (!p.assets) p.assets = { saham: {}, properti: {}, kendaraan: {} }
                if (!p.bankAssets) p.bankAssets = { saham: {}, properti: {}, kendaraan: {} }
                totalPlayer++
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const catLabel = targetCats.length === 3 ? 'semua kategori' : targetCats.join(', ')
            let statLines = ''
            for (const cat of targetCats) {
                const emojiMap = { saham: '📈', properti: '🏠', kendaraan: '🚗' }
                statLines += `│▣ ${emojiMap[cat]} ${cat}        : *${stats[cat]}* item dihapus\n`
            }

            return Reply(`
╭─────────────────────❏
│▣  🗑️  RESET ASET ALL  🗑️
╰─────────────────────❏
╭─❏
│▣ 👥 Total Player  : *${totalPlayer}* orang
│▣ 📦 Kategori      : *${catLabel}*
│▣
${statLines}│▣ 🔐 Dilakukan     : Owner Utama
│▣ ✅ Status        : Berhasil
╰──────────❏
Seluruh aset *${catLabel}* sudah direset tuntas!
Dompet, wallet, dan bank aset semua bersih. 🧹`)
        }

        // =====================================================
        // RESETKELUARGAALL — reset data keluarga semua player (creator only)
        // Usage: .resetkeluargaall
        // =====================================================
        if (command === 'resetkeluargaall') {
            if (!isCreator) return Reply(`❌ *Khusus owner bot!*`)

            const FAMILY_FIELDS = [
                'pasangan', 'pasanganNama', 'tanggalNikah',
                'anak', 'harmoni',
                'rumahKeluarga',
                'lastKencan', 'totalKencan',
                'lastMakanBersama', 'lastLiburan', 'totalLiburan',
                'lastFoto', 'totalFoto',
                'lastAnnivKado', 'chemistryBuff',
                'lastHarmoniTick', 'lastCekEvent',
                'totalNafkah', 'lastCekSelingkuh',
                'lastSelingkuh', 'selingkuhTarget', 'kenaSelingkuh',
                'lastIstanaTick'
            ]

            const totalPlayers = Object.keys(rpgDB.players).length
            if (totalPlayers === 0) return Reply(`❌ Belum ada player terdaftar.`)

            let totalReset = 0
            for (const jid of Object.keys(rpgDB.players)) {
                let adaData = false
                for (const field of FAMILY_FIELDS) {
                    if (rpgDB.players[jid][field] !== undefined) {
                        delete rpgDB.players[jid][field]
                        adaData = true
                    }
                }
                if (adaData) totalReset++
            }

            // Reset proposals juga
            rpgDB.proposals = {}

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            // Reset panti asuhan sekalian
            const pantiKosong = { anak: [], lastReset: {
                tanggal: new Date().toLocaleDateString('id-ID'),
                waktu: new Date().toLocaleTimeString('id-ID'),
                oleh: '@' + senderJid.split('@')[0],
                alasan: 'Reset keluarga massal oleh owner',
                jumlahDireset: 0
            }}
            fs.writeFileSync(pantiDBPath, JSON.stringify(pantiKosong, null, 2))

            return Reply(`╭─────────────────────❏
│▣  👨‍👩‍👧  RESET KELUARGA ALL  👨‍👩‍👧
╰─────────────────────❏
╭─❏
│▣ 👥 Total player     : *${totalPlayers}* orang
│▣ 🗑️  Player direset   : *${totalReset}* orang
│▣ 🏛️  Panti asuhan    : ✅ Dikosongkan
│▣ 💍 Lamaran pending  : ✅ Dihapus
│▣
│▣ 🔄 *Data yang direset:*
│▣ ├ Status pernikahan & pasangan
│▣ ├ Data anak-anak
│▣ ├ Keharmonisan & aktivitas
│▣ ├ Rumah keluarga & renovasi
│▣ ├ Riwayat kencan, liburan, foto
│▣ └ Data selingkuh & investigasi
│▣
│▣ ✅ Status : *Berhasil*
│▣ 📅 Waktu  : ${new Date().toLocaleString('id-ID')}
╰──────────❏
_Seluruh data keluarga telah direset bersih! 🧹_`)
        }

        // =====================================================
        // RESETKELUARGAUSER — reset data keluarga 1 user (creator only)
        // Usage: .resetkeluargauser @mention / reply
        // =====================================================
        if (command === 'resetkeluargauser') {
            if (!isCreator) return Reply(`❌ *Khusus owner bot!*`)

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetJid = m.mentionedJid[0]
                if (targetJid.endsWith('@lid') && m.metadata?.participants) {
                    let p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                    if (p && p.jid) targetJid = p.jid
                }
            } else if (m.quoted) {
                targetJid = m.quoted.sender
            }

            if (!targetJid) return Reply(`❌ Tag atau reply user dulu!\nContoh: *.resetkeluargauser @user*`)
            if (!rpgDB.players[targetJid]) return Reply(`❌ User tersebut belum daftar RPG.`)

            const player = rpgDB.players[targetJid]

            const FAMILY_FIELDS = [
                'pasangan', 'pasanganNama', 'tanggalNikah',
                'anak', 'harmoni',
                'rumahKeluarga',
                'lastKencan', 'totalKencan',
                'lastMakanBersama', 'lastLiburan', 'totalLiburan',
                'lastFoto', 'totalFoto',
                'lastAnnivKado', 'chemistryBuff',
                'lastHarmoniTick', 'lastCekEvent',
                'totalNafkah', 'lastCekSelingkuh',
                'lastSelingkuh', 'selingkuhTarget', 'kenaSelingkuh',
                'lastIstanaTick'
            ]

            // Kumpulkan info sebelum reset
            const infoBefore = {
                pasangan: player.pasanganNama || player.pasangan || '-',
                jumlahAnak: (player.anak || []).length,
                harmoni: player.harmoni || 0,
                punyaRumah: player.rumahKeluarga ? `${player.rumahKeluarga.tier}` : '-'
            }

            // Jika punya pasangan, bersihkan data pasangan juga
            if (player.pasangan) {
                const pasanganJid = player.pasangan.endsWith('@lid')
                    ? player.pasangan.replace('@lid', '@s.whatsapp.net')
                    : player.pasangan
                const pasangan = rpgDB.players[pasanganJid]
                if (pasangan) {
                    for (const field of FAMILY_FIELDS) {
                        delete pasangan[field]
                    }
                }
            }

            // Reset player target
            for (const field of FAMILY_FIELDS) {
                delete player[field]
            }

            // Hapus proposal yang melibatkan user ini
            if (rpgDB.proposals) {
                for (const key of Object.keys(rpgDB.proposals)) {
                    const prop = rpgDB.proposals[key]
                    if (key === targetJid || prop.from === targetJid) {
                        delete rpgDB.proposals[key]
                    }
                }
            }

            // Hapus anak player dari panti jika ada
            try {
                let pantiDB = JSON.parse(fs.readFileSync(pantiDBPath))
                pantiDB.anak = (pantiDB.anak || []).filter(a => a.orangTuaJid !== targetJid && a.pasanganJid !== targetJid)
                fs.writeFileSync(pantiDBPath, JSON.stringify(pantiDB, null, 2))
            } catch(e) {}

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  👨‍👩‍👧  RESET KELUARGA USER  👨‍👩‍👧\n╰─────────────────────❏\n╭─❏\n│▣ 👤 User       : @${targetJid.split('@')[0]}\n│▣\n│▣ 📋 *Data sebelum reset:*\n│▣ ├ Pasangan   : ${infoBefore.pasangan}\n│▣ ├ Jumlah anak: ${infoBefore.jumlahAnak} anak\n│▣ ├ Keharmonisan: ${infoBefore.harmoni}/100\n│▣ └ Rumah      : ${infoBefore.punyaRumah}\n│▣\n│▣ 🔄 *Semua data keluarga dihapus:*\n│▣ ├ Status pernikahan & pasangan\n│▣ ├ Data anak-anak\n│▣ ├ Keharmonisan & aktivitas\n│▣ ├ Rumah keluarga & renovasi\n│▣ └ Riwayat kencan, liburan, foto\n│▣\n│▣ ✅ Status : *Berhasil*\n│▣ 📅 Waktu  : ${new Date().toLocaleString('id-ID')}\n╰──────────❏`,
                mentions: [targetJid]
            }, { quoted: m })
        }

        // =====================================================
        // INFO — menampilkan total gold, aset, saham, bank dll
        // Usage: .info [@mention/reply/kosong=diri sendiri]
        // =====================================================
        if (command === 'info') {
            let targetJid = m.sender
            if (m.isGroup) {
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    targetJid = m.mentionedJid[0]
                    if (targetJid.endsWith('@lid') && m.metadata?.participants) {
                        let p = m.metadata.participants.find(x => x.lid === targetJid || x.id === targetJid)
                        if (p && p.jid) targetJid = p.jid
                    }
                } else if (m.quoted) {
                    targetJid = m.quoted.sender
                }
            } else {
                if (m.quoted) targetJid = m.quoted.sender
            }

            if (!rpgDB.players[targetJid]) return Reply(`❌ User ${targetJid === m.sender ? 'kamu' : 'tersebut'} belum daftar RPG!\nKetik *.rpgstart* untuk mulai.`)

            const player = rpgDB.players[targetJid]
            const marketDB = getMarketDB()
            if (!player.assets) player.assets = { saham: {}, properti: {}, kendaraan: {} }
            if (!player.bankAssets) player.bankAssets = { saham: {}, properti: {}, kendaraan: {} }

            // Hitung nilai saham dompet
            let sahamWalletTotal = 0
            let sahamWalletList = []
            for (const [id, qty] of Object.entries(player.assets.saham || {})) {
                if (qty <= 0) continue
                const harga = marketDB.saham[id]?.price || 0
                const nilai = harga * qty
                sahamWalletTotal += nilai
                sahamWalletList.push(`│▣   📈 ${id} x${qty} = ${toRupiah(nilai)}`)
            }

            // Hitung nilai saham bank
            let sahamBankTotal = 0
            let sahamBankList = []
            for (const [id, qty] of Object.entries(player.bankAssets.saham || {})) {
                if (qty <= 0) continue
                const harga = marketDB.saham[id]?.price || 0
                const nilai = harga * qty
                sahamBankTotal += nilai
                sahamBankList.push(`│▣   🏦📈 ${id} x${qty} = ${toRupiah(nilai)}`)
            }

            // Hitung nilai properti
            let propertiTotal = 0
            let propertiList = []
            for (const cat of ['properti', 'kendaraan']) {
                const emojiMap = { properti: '🏠', kendaraan: '🚗' }
                const allKeys = new Set([
                    ...Object.keys(player.assets[cat] || {}),
                    ...Object.keys(player.bankAssets[cat] || {})
                ])
                for (const id of allKeys) {
                    const wQty = player.assets[cat]?.[id] || 0
                    const bQty = player.bankAssets[cat]?.[id] || 0
                    const totalQty = wQty + bQty
                    if (totalQty <= 0) continue
                    const harga = marketDB[cat]?.[id]?.price || 0
                    const nilai = harga * totalQty
                    propertiTotal += nilai
                    propertiList.push(`│▣   ${emojiMap[cat]} ${marketDB[cat]?.[id]?.name || id} x${totalQty} = ${toRupiah(nilai)}`)
                }
            }

            // Hitung nilai inventori
            let inventoriTotal = 0
            for (const [id, qty] of Object.entries(player.inventory || {})) {
                if (qty <= 0) continue
                const itemPrice = rpgDB.items?.[id]?.price || 0
                inventoriTotal += itemPrice * qty
            }

            const goldDompet = player.gold || 0
            const goldBank = player.bank?.balance || 0
            const totalSaham = sahamWalletTotal + sahamBankTotal
            const totalAset = goldDompet + goldBank + totalSaham + propertiTotal + inventoriTotal

            // Hitung passive income
            let totalPassivePerHari = 0
            for (const [id, qty] of Object.entries(player.assets.properti || {})) {
                if (qty > 0 && marketDB.properti[id]?.passive) totalPassivePerHari += marketDB.properti[id].passive * qty
            }
            for (const [id, qty] of Object.entries(player.assets.kendaraan || {})) {
                if (qty > 0 && marketDB.kendaraan[id]?.passive) totalPassivePerHari += marketDB.kendaraan[id].passive * qty
            }

            const isSelf = targetJid === m.sender
            let infoText = `
╭─────────────────────❏
│▣  📊  INFO KEKAYAAN  📊
╰─────────────────────❏
╭─❏
│▣ 👤 *${player.class?.toUpperCase() || 'PLAYER'}* — Level ${player.level || 1}
│▣ 
│▣ 💵 Gold Dompet   : ${toRupiah(goldDompet)}
│▣ 🏦 Gold Bank     : ${toRupiah(goldBank)}
│▣ 
│▣ 📈 *Saham (Dompet)* : ${toRupiah(sahamWalletTotal)}
${sahamWalletList.length > 0 ? sahamWalletList.join('\n') + '\n' : '│▣   (kosong)\n'}│▣ 🏦📈 *Saham (Bank)* : ${toRupiah(sahamBankTotal)}
${sahamBankList.length > 0 ? sahamBankList.join('\n') + '\n' : '│▣   (kosong)\n'}│▣ 🏠 *Properti & Kendaraan* : ${toRupiah(propertiTotal)}
${propertiList.length > 0 ? propertiList.join('\n') + '\n' : '│▣   (kosong)\n'}│▣ 🎒 *Nilai Inventori* : ${toRupiah(inventoriTotal)}
${(() => {
    const mini = renderOwnedMinimarketItems(player, rpgDB)
    const cart = renderMinimarketCart(player)
    let out = `│▣ 🏪 *Barang Minimarket* : ${mini.totalQty} item (${toRupiah(mini.totalValue)})
`
    out += mini.rows.length > 0 ? mini.rows.slice(0, 15).join('\n') + '\n' : '│▣   (belum ada, miskin gaya)\n'
    if (mini.rows.length > 15) out += `│▣   ...dan ${mini.rows.length - 15} barang lain\n`
    out += `│▣ 🛒 *Keranjang* : ${cart.count ? toRupiah(cart.total) : 'kosong'}\n`
    return out
})()}│▣ 
│▣ 💹 Passive/hari  : ${toRupiah(totalPassivePerHari)}
│▣ 
│▣ ──────────────────
│▣ 🏆 TOTAL NET WORTH : *${toRupiah(totalAset)}*
╰──────────❏`

            return yonz.sendMessage(m.chat, {
                text: infoText,
                mentions: isSelf ? [] : [targetJid]
            }, { quoted: m })
        }


        // ══════════════════════════════════════════════════════════════
        // 🐠 AQUARIUM SYSTEM — PELIHARA & KEMBANGKAN IKAN TANGKAPAN
        // ══════════════════════════════════════════════════════════════

        const FISH_FOOD_DATA = {
            pelet_biasa:    { name: 'Pelet Biasa',    emoji: '🥫', price: 500,    hpHeal: 10,  expGain: 5,   desc: 'Pakan harian, HP +10 & EXP sedikit' },
            pelet_premium:  { name: 'Pelet Premium',  emoji: '🥩', price: 2000,   hpHeal: 30,  expGain: 20,  desc: 'Nutrisi bagus, HP +30 & EXP lumayan' },
            cacing_hidup:   { name: 'Cacing Hidup',   emoji: '🪱', price: 1500,   hpHeal: 20,  expGain: 30,  desc: 'Favorit ikan, EXP tinggi!' },
            jangkrik:       { name: 'Jangkrik',       emoji: '🦗', price: 3000,   hpHeal: 25,  expGain: 45,  desc: 'Protein tinggi, EXP besar' },
            udang_segar:    { name: 'Udang Segar',    emoji: '🦐', price: 5000,   hpHeal: 50,  expGain: 60,  desc: 'Makanan mewah, HP & EXP tinggi' },
            vitamin_ikan:   { name: 'Vitamin Ikan',   emoji: '💊', price: 10000,  hpHeal: 200, expGain: 10,  desc: 'Pulihkan HP penuh! (hampir)' },
            suplemen_kuat:  { name: 'Suplemen Kuat',  emoji: '💉', price: 25000,  hpHeal: 50,  expGain: 150, desc: 'Boost EXP besar untuk level up cepat' },
            pakan_dewa:     { name: 'Pakan Dewa',     emoji: '✨', price: 100000, hpHeal: 500, expGain: 500, desc: 'ULTIMATE FOOD! HP & EXP max boost' }
        }

        const FISH_LEVEL_EXP  = [
            0,       // lv1 start
            100,     // lv2
            300,     // lv3
            700,     // lv4
            1500,    // lv5
            3000,    // lv6
            5500,    // lv7
            9000,    // lv8
            14000,   // lv9
            21000,   // lv10
            30000,   // lv11
            42000,   // lv12
            58000,   // lv13
            78000,   // lv14
            103000,  // lv15
            133000,  // lv16
            170000,  // lv17
            215000,  // lv18
            270000,  // lv19
            340000   // lv20 MAX
        ]
        const FISH_LEVEL_NAMES = [
            '',
            '🥚 Baby',           // lv1
            '🐟 Tiny',           // lv2
            '🐠 Small',          // lv3
            '🐡 Normal',         // lv4
            '🦐 Sprout',         // lv5
            '🦑 Feeder',         // lv6
            '🐙 Fighter',        // lv7
            '🦈 Hunter',         // lv8
            '🐊 Predator',       // lv9
            '🦁 Alpha',          // lv10
            '🌊 Tidal',          // lv11
            '⚡ Storm',          // lv12
            '🔥 Blaze',          // lv13
            '❄️ Frost',           // lv14
            '🌑 Shadow',         // lv15
            '💎 Crystal',        // lv16
            '🌟 Astral',         // lv17
            '👑 Royal',          // lv18
            '🐉 Mythic',         // lv19
            '✨ Legendary God'   // lv20 MAX
        ]
        const FISH_MAX_HP_BY_LEVEL   = [0, 50, 100, 180, 280, 400, 550, 730, 940, 1190, 1500, 1870, 2310, 2830, 3450, 4180, 5030, 6020, 7170, 8500, 10000]
        const FISH_BATTLE_ATK_BY_LEVEL = [0, 10, 22, 38, 58, 82, 112, 148, 192, 244, 305, 378, 464, 565, 684, 823, 985, 1173, 1390, 1640, 1920]

        function getFishLevel(fishInAquarium) {
            let level = 1
            const totalExp = fishInAquarium.exp || 0
            for (let l = 1; l <= 19; l++) {
                if (totalExp >= FISH_LEVEL_EXP[l]) level = l + 1
                else break
            }
            return Math.min(level, 20)
        }

        function getFishAquariumDisplay(f) {
            const lvl = getFishLevel(f)
            const fishBase = FISH_DATA[f.fishId] || { name: f.fishId, emoji: '🐟', rarity: 'UNCOMMON' }
            const mut = f.mutationId ? MUTATION_DATA[f.mutationId] : null
            const name = mut ? `${mut.emoji}${mut.name} ${fishBase.emoji}${fishBase.name}` : `${fishBase.emoji}${fishBase.name}`
            const maxHp = FISH_MAX_HP_BY_LEVEL[lvl]
            const hp = Math.min(f.hp || maxHp, maxHp)
            return { lvl, name, hp, maxHp, fishBase, mut }
        }

        // ── SHOPFOOD ──────────────────────────────────────────────────
        if (command === 'shopfood') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const sub = text ? text.trim().toLowerCase() : ''

            if (sub.startsWith('beli ')) {
                const parts = sub.replace('beli ', '').trim().split(/\s+/)
                const foodId = parts[0]
                const qty = parseInt(parts[1]) || 1
                const food = FISH_FOOD_DATA[foodId]
                if (!food) return Reply(`❌ Makanan *${foodId}* tidak ada!\nKetik *.shopfood* untuk lihat daftar.`)
                const totalCost = food.price * qty
                if (player.gold < totalCost) return Reply(`❌ Uang kurang! Butuh ${toRupiah(totalCost)}, kamu punya ${toRupiah(player.gold)}.`)
                player.gold -= totalCost
                if (!player.inventory) player.inventory = {}
                const invKey = `food_${foodId}`
                player.inventory[invKey] = (player.inventory[invKey] || 0) + qty
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`╭─────────────────────❏
│▣   ✅  MAKANAN DIBELI!  ✅
╰─────────────────────❏
╭─❏
│▣ ${food.emoji} *${food.name}* x${qty}
│▣ 💰 Bayar  : -${toRupiah(totalCost)}
│▣ 💵 Sisa   : ${toRupiah(player.gold)}
╰──────────❏
Beri makan ikan dengan *.makankanikan [slot] ${foodId}*`)
            }

            let txt = `╭─────────────────────❏\n│▣   🏪  TOKO MAKANAN IKAN  🏪\n╰─────────────────────❏\n╭─❏\n`
            for (const [id, f] of Object.entries(FISH_FOOD_DATA)) {
                const stock = player.inventory?.[`food_${id}`] || 0
                txt += `│▣ ${f.emoji} *${f.name}* (stok: ${stock})\n`
                txt += `│▣   💰 ${toRupiah(f.price)}/pcs\n`
                txt += `│▣   ❤️  HP +${f.hpHeal} | ⭐ EXP +${f.expGain}\n`
                txt += `│▣   📝 ${f.desc}\n`
                txt += `│▣   ↳ *.shopfood beli ${id} [qty]*\n\n`
            }
            txt += `╰──────────❏\n💵 Saldo: ${toRupiah(player.gold)}`
            return Reply(txt)
        }

        // ── PELIHARAIKAN ──────────────────────────────────────────────
        if (command === 'peliharaikan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.aquarium) player.aquarium = []

            if (player.aquarium.length >= 5) return Reply(`❌ Akuarium penuh! Maksimal 5 ikan. Lepaskan dulu dengan *.lepaskan [slot]*`)

            const fishKey = text ? `fish_${text.trim()}` : null
            if (!fishKey) return Reply(`❌ Masukkan key ikan!\nContoh: *.peliharaikan minnow*\nCek ikan di *.tasikan*`)

            const inv = player.inventory || {}
            if (!inv[fishKey] || inv[fishKey] <= 0) return Reply(`❌ Ikan *${text.trim()}* tidak ada di inventori!\nCek ikan di *.tasikan*`)

            const { fishId, mutationId } = parseFishKey(fishKey)
            if (!fishId || !FISH_DATA[fishId]) return Reply(`❌ Key ikan tidak valid!`)

            inv[fishKey] -= 1
            const newFish = {
                fishId,
                mutationId: mutationId || null,
                exp: 0,
                hp: FISH_MAX_HP_BY_LEVEL[1],
                adoptedAt: Date.now()
            }
            player.aquarium.push(newFish)
            const slot = player.aquarium.length

            const fishBase = FISH_DATA[fishId]
            const mut = mutationId ? MUTATION_DATA[mutationId] : null
            const displayName = mut ? `${mut.emoji}${mut.name} ${fishBase.emoji}${fishBase.name}` : `${fishBase.emoji}${fishBase.name}`

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣   🐠  IKAN DIPELIHARA!  🐠
╰─────────────────────❏
╭─❏
│▣ 🐟 Ikan    : ${displayName}
│▣ 🎚️ Level   : ${FISH_LEVEL_NAMES[1]}
│▣ ❤️  HP      : ${FISH_MAX_HP_BY_LEVEL[1]}/${FISH_MAX_HP_BY_LEVEL[1]}
│▣ 🔢 Slot    : #${slot}
╰──────────❏
Beri makan dengan *.makankanikan ${slot} [makanan]*
Lihat akuarium di *.akuarium* 🐠`)
        }

        // ── AKUARIUM ──────────────────────────────────────────────────
        if (command === 'akuarium') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.aquarium || player.aquarium.length === 0) {
                return Reply(`🐠 *AKUARIUM KOSONG!*\n\nBelum ada ikan yang dipelihara.\nMancing dulu dengan *.mancing*, lalu pelihara dengan *.peliharaikan [fishkey]* 🎣`)
            }

            let txt = `╭─────────────────────❏\n│▣   🐠  AKUARIUM  🐠\n╰─────────────────────❏\n╭─❏\n`
            player.aquarium.forEach((f, i) => {
                const { lvl, name, hp, maxHp } = getFishAquariumDisplay(f)
                const expForNext = lvl < 20 ? FISH_LEVEL_EXP[lvl] : 'MAX'
                const hpBar = (() => { const p = Math.min(Math.floor((hp/maxHp)*10), 10); return '█'.repeat(p)+'░'.repeat(10-p) })()
                txt += `│▣ *[SLOT ${i+1}]* ${name}\n`
                txt += `│▣   🎚️ Level  : *${FISH_LEVEL_NAMES[lvl]}* (Lv.${lvl}/20)\n`
                txt += `│▣   ❤️  HP     : [${hpBar}] ${hp}/${maxHp}\n`
                txt += `│▣   ⭐ EXP    : ${f.exp || 0}/${lvl < 20 ? expForNext : 'MAX'}\n`
                txt += `│▣   ⚔️  ATK    : ${FISH_BATTLE_ATK_BY_LEVEL[lvl]}\n`
                txt += `│▣\n`
            })
            txt += `╰──────────❏\n`
            txt += `*.makankanikan [slot] [foodId]*  — beri makan\n`
            txt += `*.aduikan @user [slotku]*        — adu ikan\n`
            txt += `*.lepaskan [slot]*               — keluarkan ikan\n`
            txt += `*.shopfood*                      — beli makanan ikan`
            return Reply(txt)
        }

        // ── MAKANKANIKAN ──────────────────────────────────────────────
        if (command === 'makankanikan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.aquarium || player.aquarium.length === 0) return Reply(`❌ Akuarium kosong! Pelihara ikan dulu dengan *.peliharaikan [fishkey]*`)

            const parts = text ? text.trim().split(/\s+/) : []
            const slot = parseInt(parts[0]) - 1
            const foodId = parts[1]
            const qty = parseInt(parts[2]) || 1

            if (isNaN(slot) || slot < 0 || slot >= player.aquarium.length) return Reply(`❌ Slot tidak valid! Kamu punya ${player.aquarium.length} ikan di slot 1–${player.aquarium.length}`)
            if (!foodId) return Reply(`❌ Masukkan jenis makanan!\nContoh: *.makankanikan 1 pelet_biasa 3*\nCek makanan di *.shopfood*`)

            const food = FISH_FOOD_DATA[foodId]
            if (!food) return Reply(`❌ Makanan *${foodId}* tidak ada! Cek *.shopfood*`)

            const invKey = `food_${foodId}`
            const inv = player.inventory || {}
            const stock = inv[invKey] || 0
            if (stock < qty) return Reply(`❌ Stok *${food.name}* kurang! Punya ${stock}, butuh ${qty}.\nBeli di *.shopfood beli ${foodId} ${qty}*`)

            const fish = player.aquarium[slot]
            const lvlBefore = getFishLevel(fish)

            inv[invKey] -= qty
            fish.exp = (fish.exp || 0) + (food.expGain * qty)
            const lvlMid = getFishLevel(fish)
            const maxHpNow = FISH_MAX_HP_BY_LEVEL[lvlMid]
            fish.hp = Math.min((fish.hp || maxHpNow) + (food.hpHeal * qty), maxHpNow)

            const lvlAfter = getFishLevel(fish)
            const leveledUp = lvlAfter > lvlBefore
            if (leveledUp) fish.hp = FISH_MAX_HP_BY_LEVEL[lvlAfter]

            const { name } = getFishAquariumDisplay(fish)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            let msg = `╭─────────────────────❏
│▣   🍽️  IKAN DIBERI MAKAN!  🍽️
╰─────────────────────❏
╭─❏
│▣ 🐟 Ikan    : ${name}
│▣ 🍽️ Makan   : ${food.emoji} ${food.name} x${qty}
│▣ ❤️  HP      : +${food.hpHeal * qty} → ${fish.hp}/${FISH_MAX_HP_BY_LEVEL[lvlAfter]}
│▣ ⭐ EXP     : +${food.expGain * qty} → ${fish.exp}
│▣ 🎚️ Level   : ${FISH_LEVEL_NAMES[lvlAfter]} (Lv.${lvlAfter}/20)
╰──────────❏`
            if (leveledUp) msg += `\n\n🎉 *IKAN NAIK LEVEL!*\n${FISH_LEVEL_NAMES[lvlBefore]} → *${FISH_LEVEL_NAMES[lvlAfter]}*\n⚔️ ATK sekarang: ${FISH_BATTLE_ATK_BY_LEVEL[lvlAfter]}`
            if (lvlAfter === 20) msg += `\n\n🏆 *IKAN SUDAH MAX LEVEL 20 — ✨ LEGENDARY GOD!* 🐉`
            return Reply(msg)
        }

        // ── LEPASKAN ──────────────────────────────────────────────────
        if (command === 'lepaskan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            if (!player.aquarium || player.aquarium.length === 0) return Reply(`❌ Akuarium kosong!`)

            const slot = parseInt(text) - 1
            if (isNaN(slot) || slot < 0 || slot >= player.aquarium.length) return Reply(`❌ Slot tidak valid! Pilih 1–${player.aquarium.length}`)

            const fish = player.aquarium[slot]
            const { lvl, name } = getFishAquariumDisplay(fish)

            const invKey = getFishInventoryKey(fish.fishId, fish.mutationId)
            if (!player.inventory) player.inventory = {}
            player.inventory[invKey] = (player.inventory[invKey] || 0) + 1
            player.aquarium.splice(slot, 1)

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣   📤  IKAN DILEPASKAN  📤
╰─────────────────────❏
╭─❏
│▣ 🐟 Ikan    : ${name}
│▣ 🎚️ Level   : ${FISH_LEVEL_NAMES[lvl]}
│▣ 📦 Status  : Kembali ke inventori
╰──────────❏
Ikan kembali ke inventori & bisa dijual/dipelihara lagi.`)
        }

        // ── INFOADUIKAN — Panduan ────────────────────────────────────
        if (command === 'infoaduikan') {
            return Reply(`╭─────────────────────❏
│▣   🐠  CARA MAIN ADU IKAN  🐠
╰─────────────────────❏
╭─❏
│▣ 📖 *APA ITU ADU IKAN?*
│▣ Tantang ikan peliharaan pemain lain!
│▣ Kamu pilih ikanmu, ikan lawan random.
│▣
│▣ 🎯 *FORMAT COMMAND*
│▣ .aduikan @user [namaikan]
│▣ .aduikan @user minnow
│▣ .aduikan @user golden_carp
│▣ (bisa reply pesan lawan, ganti @user)
│▣
│▣ 💡 *NAMA IKAN*
│▣ Gunakan fishId ikan kamu.
│▣ Cek nama ikan di *.akuarium*
│▣ (contoh: minnow, carp, salmon, dll)
│▣
│▣ ⚔️ *MEKANISME*
│▣ • Kamu pilih ikan spesifik
│▣ • Ikan lawan → random dari akuarium
│▣ • Power = (ATK_Level + Acak 0–20) × Mutasi
│▣ • Power tertinggi MENANG!
│▣ • Power sama → 50/50 keberuntungan
│▣
│▣ 🏆 *HADIAH PEMENANG*
│▣ • Gold (makin tinggi level, makin banyak)
│▣ • EXP ikan naik → bisa level up!
│▣
│▣ 😔 *IKAN KALAH*
│▣ • HP berkurang (maks 30% power lawan)
│▣ • Dapat sedikit EXP hiburan
│▣ • HP 0 = KO, beri makan dulu!
│▣
│▣ ⏳ *COOLDOWN* : 3 menit antar adu
│▣
│▣ 📊 *LEVEL & ATK*
│▣ 🥚 Baby   Lv1 → ATK 10
│▣ 🐟 Small  Lv2 → ATK 25
│▣ 🐠 Medium Lv3 → ATK 50
│▣ 🐡 Large  Lv4 → ATK 90
│▣ 🦈 Giant  Lv5 → ATK 150
│▣ 🐉 Legend Lv6 → ATK 250 (MAX)
╰──────────❏
💡 Cek ikan kamu di *.akuarium*
💡 Beri makan ikan di *.makankanikan [slot] [food]*`)
        }

        // ── ADUIKAN ───────────────────────────────────────────────────
        if (command === 'aduikan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]

            // ── Cooldown 3 menit ──────────────────────────────────────
            const ADUIKAN_COOLDOWN = 3 * 60 * 1000
            const nowAdu = Date.now()
            if ((nowAdu - (player.lastAduikan || 0)) < ADUIKAN_COOLDOWN) {
                const sisa = Math.ceil((ADUIKAN_COOLDOWN - (nowAdu - (player.lastAduikan || 0))) / 1000)
                const m2 = Math.floor(sisa / 60), s2 = sisa % 60
                return Reply(`⏳ *Cooldown Adu Ikan!*\nTunggu *${m2 > 0 ? m2 + ' menit ' : ''}${s2} detik* lagi.\n💡 Manfaatkan untuk beri makan ikanmu! *.makankanikan*`)
            }

            // ── Cek target lawan ──────────────────────────────────────
            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetJid = m.mentionedJid[0]
                if (targetJid && targetJid.endsWith('@lid') && m.isGroup) {
                    const participants = m.metadata?.participants || []
                    const found = participants.find(p => p.lid === targetJid || p.id === targetJid)
                    if (found) targetJid = found.jid || found.id || targetJid
                }
            } else if (m.quoted) targetJid = m.quoted.sender
            if (targetJid) targetJid = resolvePlayerJid(targetJid)

            if (!targetJid) return Reply(`❌ Tag atau reply lawan!\n\n📋 *Format:*\n*.aduikan @user [namaikan]*\n*.aduikan @user minnow*\n*.aduikan @user golden_carp*\n\n💡 Ketik *.infoaduikan* untuk panduan lengkap`)
            if (targetJid === senderJid) return Reply(`❌ Gak bisa adu ikan sendiri!`)
            if (!rpgDB.players[targetJid]) return Reply(`❌ Lawan belum daftar RPG! Suruh ketik *.rpgstart* dulu.`)

            const opponent = rpgDB.players[targetJid]

            // ── Cek aquarium ──────────────────────────────────────────
            if (!player.aquarium || player.aquarium.length === 0) {
                return Reply(`❌ Kamu belum punya ikan di akuarium!\n\n📋 *Cara punya ikan:*\n1. Mancing → *.mancing*\n2. Pelihara → *.peliharaikan [fishkey]*\n3. Beri makan → *.makankanikan [slot] [food]*`)
            }
            const opponentAliveAquarium = (opponent.aquarium || []).filter(f => (f.hp || 0) > 0)
            if (!opponent.aquarium || opponent.aquarium.length === 0) {
                return Reply(`❌ Lawan tidak punya ikan di akuarium!\nTidak bisa adu ikan.`)
            }
            if (opponentAliveAquarium.length === 0) {
                return Reply(`❌ Semua ikan lawan sedang KO (HP 0)!\nTidak ada ikan lawan yang bisa bertanding saat ini.`)
            }

            // ── Cari ikan kamu by nama/fishId ─────────────────────────
            // Parse: ambil teks setelah hapus @mention
            const fishArg = text ? text.replace(/@\d+/g, '').trim().toLowerCase() : ''

            let myFishIdx = -1

            if (!fishArg) {
                // Tidak ada argumen → tampilkan list ikan kamu
                let listMsg = `╭─────────────────────❏\n│▣   🐠  PILIH IKAN KAMU  🐠\n╰─────────────────────❏\n╭─❏\n`
                player.aquarium.forEach((f, i) => {
                    const info = getFishAquariumDisplay(f)
                    const hpBar = (() => { const p = Math.min(Math.floor((info.hp / info.maxHp) * 8), 8); return '█'.repeat(p) + '░'.repeat(8 - p) })()
                    const status = (f.hp || 0) <= 0 ? '❌ KO' : `❤️ [${hpBar}] ${info.hp}/${info.maxHp}`
                    listMsg += `│▣ *[Slot ${i+1}]* ${info.name}\n`
                    listMsg += `│▣   🎚️ Lv.${info.lvl} | ${status}\n`
                    listMsg += `│▣   🔑 Key: ${f.fishId}${f.mutationId ? '_'+f.mutationId : ''}\n│▣\n`
                })
                listMsg += `╰──────────❏\n`
                listMsg += `📋 *Format:* *.aduikan @user [key]*\nContoh: *.aduikan @user ${player.aquarium[0].fishId}*`
                return Reply(listMsg)
            }

            // Cari berdasarkan fishId atau fishId_mutationId
            for (let i = 0; i < player.aquarium.length; i++) {
                const f = player.aquarium[i]
                const fullKey = f.mutationId ? `${f.fishId}_${f.mutationId}` : f.fishId
                if (f.fishId.toLowerCase() === fishArg || fullKey.toLowerCase() === fishArg) {
                    myFishIdx = i
                    break
                }
            }

            // Juga coba cocokkan dengan nama display
            if (myFishIdx === -1) {
                for (let i = 0; i < player.aquarium.length; i++) {
                    const info = getFishAquariumDisplay(player.aquarium[i])
                    if (info.name.toLowerCase().includes(fishArg)) {
                        myFishIdx = i
                        break
                    }
                }
            }

            if (myFishIdx === -1) {
                let listMsg = `❌ Ikan *"${fishArg}"* tidak ditemukan di akuariummu!\n\nIkan yang kamu punya:\n`
                player.aquarium.forEach((f, i) => {
                    const info = getFishAquariumDisplay(f)
                    const key = f.mutationId ? `${f.fishId}_${f.mutationId}` : f.fishId
                    listMsg += `  Slot ${i+1}: ${info.name} (key: ${key})\n`
                })
                listMsg += `\nContoh: *.aduikan @user ${player.aquarium[0].fishId}*`
                return Reply(listMsg)
            }

            const myFish = player.aquarium[myFishIdx]
            if ((myFish.hp || 0) <= 0) {
                return Reply(`❌ Ikan *${getFishAquariumDisplay(myFish).name}* sedang KO (HP 0)!\nBeri makan dulu: *.makankanikan ${myFishIdx+1} pelet_biasa*`)
            }

            // ── Pilih ikan lawan secara RANDOM dari aquarium aktif ────
            const theirFishIdx = Math.floor(Math.random() * opponentAliveAquarium.length)
            const theirFish = opponentAliveAquarium[theirFishIdx]

            const myInfo    = getFishAquariumDisplay(myFish)
            const theirInfo = getFishAquariumDisplay(theirFish)

            // ── Hitung Power ──────────────────────────────────────────
            const myMutMult    = myFish.mutationId    ? (MUTATION_DATA[myFish.mutationId]?.multiplier    || 1) : 1
            const theirMutMult = theirFish.mutationId ? (MUTATION_DATA[theirFish.mutationId]?.multiplier || 1) : 1

            const myPower    = Math.floor((FISH_BATTLE_ATK_BY_LEVEL[myInfo.lvl]    + Math.floor(Math.random() * 20)) * myMutMult)
            const theirPower = Math.floor((FISH_BATTLE_ATK_BY_LEVEL[theirInfo.lvl] + Math.floor(Math.random() * 20)) * theirMutMult)

            // ── Tentukan pemenang (tie = 50/50) ───────────────────────
            const isDraw = myPower === theirPower
            const myWins = isDraw ? (Math.random() < 0.5) : (myPower > theirPower)

            const winner     = myWins ? player   : opponent
            const winnerFish = myWins ? myFish   : theirFish
            const loserFish  = myWins ? theirFish : myFish
            const winnerInfo = myWins ? myInfo   : theirInfo
            const loserInfo  = myWins ? theirInfo : myInfo

            // ── HP Loss ───────────────────────────────────────────────
            const winnerPower = myWins ? myPower : theirPower
            const hpLoss = Math.max(10, Math.floor(winnerPower * 0.3))
            loserFish.hp = Math.max(0, (loserFish.hp || 10) - hpLoss)

            // ── EXP ───────────────────────────────────────────────────
            const powerDiff   = Math.abs(myPower - theirPower)
            const winExpGain  = 50 + powerDiff * 2
            const loseExpGain = Math.max(10, Math.floor(winExpGain * 0.2))
            winnerFish.exp = (winnerFish.exp || 0) + winExpGain
            loserFish.exp  = (loserFish.exp  || 0) + loseExpGain

            const winnerLvlBefore = myWins ? myInfo.lvl : theirInfo.lvl
            const loserLvlBefore  = myWins ? theirInfo.lvl : myInfo.lvl
            const winnerLvlAfter  = getFishLevel(winnerFish)
            const loserLvlAfter   = getFishLevel(loserFish)
            if (winnerLvlAfter > winnerLvlBefore) winnerFish.hp = FISH_MAX_HP_BY_LEVEL[winnerLvlAfter]
            if (loserLvlAfter  > loserLvlBefore)  loserFish.hp  = FISH_MAX_HP_BY_LEVEL[loserLvlAfter]

            // ── Gold reward ───────────────────────────────────────────
            const goldReward = 150 * winnerInfo.lvl + Math.floor(Math.random() * 300)
            winner.gold += goldReward

            // ── Simpan cooldown ───────────────────────────────────────
            player.lastAduikan = nowAdu
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            // ── Bangun pesan hasil ────────────────────────────────────
            const myTag     = `@${senderJid.split('@')[0]}`
            const theirTag  = `@${targetJid.split('@')[0]}`
            const winnerTag = myWins ? myTag : theirTag
            const loserTag  = myWins ? theirTag : myTag

            const hpBarWin  = (() => { const p = Math.min(Math.floor((winnerFish.hp / FISH_MAX_HP_BY_LEVEL[winnerLvlAfter]) * 10), 10); return '█'.repeat(p) + '░'.repeat(10 - p) })()
            const hpBarLose = (() => { const p = Math.min(Math.floor((loserFish.hp  / FISH_MAX_HP_BY_LEVEL[loserLvlAfter])  * 10), 10); return '█'.repeat(p) + '░'.repeat(10 - p) })()

            let battleMsg = `╭─────────────────────❏
│▣   🐠  ADU IKAN  🐠
╰─────────────────────❏
╭─❏
│▣ ⚔️  ${myTag} vs ${theirTag}
│▣
│▣ 🔵 [${myTag}] — PILIHAN SENDIRI
│▣    ${myInfo.name}
│▣    🎚️ Lv.${myInfo.lvl} | ⚔️ Power: *${myPower}*${myFish.mutationId ? ' ✨Mutasi' : ''}
│▣
│▣ 🔴 [${theirTag}] — RANDOM DARI AKUARIUM
│▣    ${theirInfo.name}
│▣    🎚️ Lv.${theirInfo.lvl} | ⚔️ Power: *${theirPower}*${theirFish.mutationId ? ' ✨Mutasi' : ''}
│▣
│▣ ══════ HASIL PERTARUNGAN ══════
${isDraw ? '│▣ 🎲 POWER SAMA! Ditentukan keberuntungan...\n' : ''}│▣ 🏆 PEMENANG : *${winnerTag}*
│▣    🐟 ${winnerInfo.name} (Lv.${winnerLvlAfter})
│▣    ❤️  HP   : [${hpBarWin}] ${winnerFish.hp}
│▣    💰 Gold  : +${toRupiah(goldReward)}
│▣    ⭐ EXP   : +${winExpGain}
│▣
│▣ 😔 KALAH : *${loserTag}*
│▣    🐟 ${loserInfo.name} (Lv.${loserLvlAfter})
│▣    ❤️  HP   : [${hpBarLose}] ${loserFish.hp}${loserFish.hp === 0 ? ' ⚠️ KO!' : ''}
│▣    ⭐ EXP   : +${loseExpGain} (hiburan)
╰──────────❏`

            if (winnerLvlAfter > winnerLvlBefore) battleMsg += `\n\n🎉 *IKAN PEMENANG NAIK LEVEL!*\n${FISH_LEVEL_NAMES[winnerLvlBefore]} → *${FISH_LEVEL_NAMES[winnerLvlAfter]}* 🎊`
            if (loserLvlAfter  > loserLvlBefore)  battleMsg += `\n\n📈 *Ikan yang kalah pun naik level!*\n${FISH_LEVEL_NAMES[loserLvlBefore]} → *${FISH_LEVEL_NAMES[loserLvlAfter]}* 💪`
            if (loserFish.hp === 0) battleMsg += `\n\n⚠️ *${loserInfo.name} milik ${loserTag} KO!*\nBeri makan: *.makankanikan [slot] pelet_biasa*`
            battleMsg += `\n\n⏳ Cooldown 3 menit | 💡 *.infoaduikan* untuk panduan`

            return yonz.sendMessage(m.chat, { text: battleMsg, mentions: [senderJid, targetJid] }, { quoted: m })
        }

        // ══════════════════════════════════════════════════════
        //  🏰  SISTEM CLAN
        // ══════════════════════════════════════════════════════
        const clanDBPath = './library/database/clan.json'

        function loadClanDB() {
            try {
                if (!fs.existsSync(clanDBPath)) {
                    fs.writeFileSync(clanDBPath, JSON.stringify({ clans: {} }, null, 2))
                }
                const raw = JSON.parse(fs.readFileSync(clanDBPath))
                // Pastikan clans selalu object, bukan null/undefined
                if (!raw || typeof raw !== 'object') return { clans: {} }
                if (!raw.clans || typeof raw.clans !== 'object') raw.clans = {}
                return raw
            } catch { return { clans: {} } }
        }

        function saveClanDB(db) {
            if (!db || typeof db !== 'object') db = { clans: {} }
            if (!db.clans || typeof db.clans !== 'object') db.clans = {}
            fs.writeFileSync(clanDBPath, JSON.stringify(db, null, 2))
        }

        function findPlayerClan(clanDB, jid) {
            if (!clanDB || !clanDB.clans || typeof clanDB.clans !== 'object') return null
            for (const [clanId, clan] of Object.entries(clanDB.clans)) {
                if (!clan || typeof clan !== 'object') continue
                if (!Array.isArray(clan.members)) clan.members = []
                if (clan.members.includes(jid)) return { clanId, clan }
            }
            return null
        }

        function getClanPower(clan, rpgDB) {
            let total = 0
            const members = Array.isArray(clan.members) ? clan.members : []
            for (const jid of members) {
                const p = (rpgDB.players || {})[jid]
                if (p) total += getPlayerTotalStats(p).totalAttack + getPlayerTotalStats(p).totalDefense + (p.level || 1) * 5
            }
            return total
        }

        // ── .buatclan ─────────────────────────────────────────
        if (command === 'buatclan') {
            if (!isPremium && !isCreator) return Reply(`👑 *KHUSUS PREMIUM!*\n\nHanya member premium yang bisa membuat clan!\nHub admin untuk upgrade akun kamu.`)

            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            const existingClan = findPlayerClan(clanDB, senderJid)
            if (existingClan) return Reply(`❌ Kamu sudah bergabung dengan clan *${existingClan.clan.emblem} ${existingClan.clan.name}*!\nKeluar dulu dengan *.keluarclan*`)

            const parts = text ? text.trim().split(' ') : []
            if (parts.length < 2) return Reply(`❌ Format salah!\n\nContoh: *.buatclan 🔥 NamaClan*\n\n📌 Lambang harus berupa emoji\n📌 Nama tidak boleh kosong`)

            const emblem = parts[0]
            const name = parts.slice(1).join(' ')

            // Validasi emblem (emoji check sederhana)
            const emojiRegex = /\p{Emoji}/u
            if (!emojiRegex.test(emblem)) return Reply(`❌ Lambang harus berupa *emoji*!\nContoh: 🔥 ⚔️ 🐉 🌟 💀`)

            if (name.length < 3 || name.length > 20) return Reply(`❌ Nama clan harus 3-20 karakter!`)

            // Cek nama duplikat
            const dupName = Object.values(clanDB.clans).find(c => c && c.name && c.name.toLowerCase() === name.toLowerCase())
            if (dupName) return Reply(`❌ Nama clan *${name}* sudah dipakai! Pilih nama lain.`)

            // Generate short 6-char alphanumeric clan code (uppercase), unik
            const genShortId = () => {
                const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
                let id = ''
                for (let i = 0; i < 6; i++) id += chars[Math.floor(Math.random() * chars.length)]
                return id
            }
            let clanCode = genShortId()
            const existingCodes = new Set(Object.values(clanDB.clans).map(c => c && c.clanCode).filter(Boolean))
            while (existingCodes.has(clanCode)) clanCode = genShortId()

            const clanId = `clan_${Date.now()}`
            clanDB.clans[clanId] = {
                id: clanId,
                clanCode: clanCode,
                name: name,
                emblem: emblem,
                leader: senderJid,
                members: [senderJid],
                maxMembers: 4,
                renameCount: 0,
                maxRename: 2,
                gold: 0,
                createdAt: Date.now(),
                lastRaid: 0,
                wins: 0,
                losses: 0,
                description: 'Clan baru yang keren!'
            }
            saveClanDB(clanDB)

            return Reply(`╭─────────────────────❏
│▣  🏰  CLAN DIBUAT!  🏰
╰─────────────────────❏
╭─❏
│▣ ${emblem} Nama    : *${name}*
│▣ 🆔 ID Clan : *#${clanCode}*
│▣ 👑 Leader  : @${senderJid.split('@')[0]}
│▣ 👥 Member  : 1/4
│▣ 🔄 Rename  : 2x tersisa
│▣ 💰 Kas     : Rp. 0
│▣ 🏆 W/L     : 0/0
╰──────────❏

✅ Clan berhasil dibuat!
📢 Bagikan ID clan: *#${clanCode}*
💡 Teman bisa gabung: *.gabukclan ${clanCode}* atau *.gabukclan ${name}*`)
        }

        // ── .listclan ─────────────────────────────────────────
        if (command === 'listclan') {
            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            const clans = Object.values(clanDB.clans).filter(c => c && c.name)
            if (clans.length === 0) return Reply(`📭 Belum ada clan yang dibuat!\n\n💡 Buat clan pertama dengan: *.buatclan [emoji] [nama]*\n(Khusus member premium)`)

            let msg = `╭─────────────────────❏\n│▣  🏰  DAFTAR CLAN  🏰\n╰─────────────────────❏\n╭─❏\n`
            clans.forEach((clan, i) => {
                const memberCount = Array.isArray(clan.members) ? clan.members.length : 0
                const maxSlot = clan.maxMembers || 4
                const cid = clan.clanCode ? `#${clan.clanCode}` : `-`
                msg += `│▣ ${i + 1}. ${clan.emblem || '🏰'} *${clan.name}*\n`
                msg += `│▣    🆔 ID   : *${cid}*\n`
                msg += `│▣    👥 ${memberCount}/${maxSlot} member | 🏆 ${clan.wins || 0}W/${clan.losses || 0}L\n`
                msg += `│▣    👑 Leader: @${(clan.leader || '').split('@')[0]}\n`
                if (i < clans.length - 1) msg += `│▣ ──────────────────\n`
            })
            msg += `╰──────────❏\n\n💡 Gabung: *.gabukclan [nama]* atau *.gabukclan [ID]*\n🆕 Buat clan: *.buatclan [emoji] [nama]* _(premium)_`
            return yonz.sendMessage(m.chat, { text: msg, mentions: clans.map(c => c.leader).filter(Boolean) }, { quoted: m })
        }

        // ── .gabukclan ────────────────────────────────────────
        if (command === 'gabukclan') {
            if (!text) return Reply(`❌ Sebutkan nama clan!\nContoh: *.gabukclan Phoenix*`)

            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            const existingClan = findPlayerClan(clanDB, senderJid)
            if (existingClan) return Reply(`❌ Kamu sudah di clan *${existingClan.clan.emblem} ${existingClan.clan.name}*!\nKeluar dulu dengan *.keluarclan*`)

            if (!rpgDB.players || !rpgDB.players[senderJid]) return Reply(`❌ Kamu belum terdaftar RPG! Gunakan *.rpgstart* dulu.`)

            const input = text.trim()
            const inputCode = input.toUpperCase().replace(/^#/, "")
            const targetClan = Object.entries(clanDB.clans).find(([, c]) => {
                if (!c || !c.name) return false
                return c.name.toLowerCase() === input.toLowerCase() ||
                       (c.clanCode && c.clanCode.toUpperCase() === inputCode)
            })
            if (!targetClan) return Reply(`❌ Clan *${input}* tidak ditemukan!\nLihat daftar: *.listclan*`)

            const [clanId, clan] = targetClan
            if (!Array.isArray(clan.members)) clan.members = []
            const maxSlot = clan.maxMembers || 4
            if (clan.members.length >= maxSlot) return Reply(`❌ Clan *${clan.emblem} ${clan.name}* sudah penuh! (${clan.members.length}/${maxSlot} member)\nCari clan lain: *.listclan*`)

            clan.members.push(senderJid)
            saveClanDB(clanDB)

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  🏰  BERGABUNG CLAN  🏰\n╰─────────────────────❏\n╭─❏\n│▣ ${clan.emblem} Clan   : *${clan.name}*\n│▣ 👤 Member  : @${senderJid.split('@')[0]}\n│▣ 👥 Anggota : ${clan.members.length}/${maxSlot}\n╰──────────❏\n\n✅ Berhasil bergabung!`,
                mentions: [senderJid]
            }, { quoted: m })
        }

        // ── .keluarclan ───────────────────────────────────────
        if (command === 'keluarclan') {
            const clanDB = loadClanDB()
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)

            const { clanId, clan } = found
            if (clan.leader === senderJid && clan.members.length > 1) return Reply(`❌ Kamu adalah leader! Transfer kepemimpinan dulu dengan *.transferclan @user* sebelum keluar.`)

            clan.members = clan.members.filter(j => j !== senderJid)
            if (clan.members.length === 0) {
                delete clanDB.clans[clanId]
                saveClanDB(clanDB)
                return Reply(`🏚️ Kamu keluar dan clan *${clan.emblem} ${clan.name}* dibubarkan karena tidak ada anggota!`)
            }
            if (clan.leader === senderJid) clan.leader = clan.members[0]
            saveClanDB(clanDB)
            return Reply(`✅ Berhasil keluar dari clan *${clan.emblem} ${clan.name}*!`)
        }

        // ── .infoclan ─────────────────────────────────────────
        if (command === 'infoclan') {
            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            let targetClan = null

            if (text) {
                const inp = text.trim()
                const inpCode = inp.toUpperCase().replace(/^#/, "")
                const entry = Object.entries(clanDB.clans).find(([, c]) => {
                    if (!c || !c.name) return false
                    return c.name.toLowerCase() === inp.toLowerCase() ||
                           (c.clanCode && c.clanCode.toUpperCase() === inpCode)
                })
                if (entry) targetClan = entry[1]
                else return Reply(`❌ Clan *${inp}* tidak ditemukan!`)
            } else {
                const found = findPlayerClan(clanDB, senderJid)
                if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!\nCek clan tertentu: *.infoclan [nama]*`)
                targetClan = found.clan
            }

            if (!Array.isArray(targetClan.members)) targetClan.members = []
            const memberTags = targetClan.members.map(j => `│▣    ${j === targetClan.leader ? '👑' : '⚔️'} @${j.split('@')[0]}`).join('\n')
            const now = Date.now()
            const raidCool = targetClan.lastRaid ? Math.max(0, 3 * 60 * 60 * 1000 - (now - targetClan.lastRaid)) : 0
            const maxSlot = targetClan.maxMembers || 4

            const codeDisplay = targetClan.clanCode ? `#${targetClan.clanCode}` : `-`
            let msg = `╭─────────────────────❏\n│▣  🏰  INFO CLAN  🏰\n╰─────────────────────❏\n╭─❏\n│▣ ${targetClan.emblem || '🏰'} Nama    : *${targetClan.name}*\n│▣ 🆔 ID Clan : *${codeDisplay}*\n│▣ 👑 Leader  : @${(targetClan.leader || '').split('@')[0]}\n│▣ 👥 Member  : ${targetClan.members.length}/${maxSlot}\n│▣ 💰 Kas     : ${toRupiah(targetClan.gold || 0)}\n│▣ 🏆 Menang  : ${targetClan.wins || 0}\n│▣ 💀 Kalah   : ${targetClan.losses || 0}\n│▣ 🔄 Rename  : ${(targetClan.maxRename || 2) - (targetClan.renameCount || 0)}x tersisa\n│▣ ──────────────────\n│▣ 👥 ANGGOTA:\n${memberTags}\n│▣ ──────────────────\n│▣ ⚔️ Raid CD : ${raidCool > 0 ? formatTime(raidCool / 1000) : 'Siap!'}\n╰──────────❏`
            return yonz.sendMessage(m.chat, { text: msg, mentions: targetClan.members }, { quoted: m })
        }

        // ── .renameclan ───────────────────────────────────────
        if (command === 'renameclan') {
            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)
            const { clanId, clan } = found
            if (clan.leader !== senderJid) return Reply(`❌ Hanya leader yang bisa rename clan!`)

            const maxRename = clan.maxRename || 2
            if ((clan.renameCount || 0) >= maxRename) return Reply(`❌ Batas rename sudah habis!\n\nClan hanya bisa di-rename *2x* selama pembuatan.`)

            const parts = text ? text.trim().split(' ') : []
            if (parts.length < 2) return Reply(`❌ Format: *.renameclan [emoji_baru] [nama_baru]*\nContoh: *.renameclan 🌟 ClanBaru*`)

            const newEmblem = parts[0]
            const newName = parts.slice(1).join(' ')
            const emojiRegex = /\p{Emoji}/u
            if (!emojiRegex.test(newEmblem)) return Reply(`❌ Lambang harus emoji!`)
            if (newName.length < 3 || newName.length > 20) return Reply(`❌ Nama clan 3-20 karakter!`)

            const dupName = Object.entries(clanDB.clans).find(([id, c]) => c && c.name && c.name.toLowerCase() === newName.toLowerCase() && id !== clanId)
            if (dupName) return Reply(`❌ Nama *${newName}* sudah dipakai!`)

            const oldName = clan.name
            const oldEmblem = clan.emblem
            clan.name = newName
            clan.emblem = newEmblem
            clan.renameCount = (clan.renameCount || 0) + 1
            saveClanDB(clanDB)

            return Reply(`✅ Clan berhasil diubah!\n\n${oldEmblem} *${oldName}* → ${newEmblem} *${newName}*\n\n🔄 Sisa rename: *${maxRename - clan.renameCount}x*`)
        }

        // ── .kickclan ─────────────────────────────────────────
        if (command === 'kickclan') {
            const clanDB = loadClanDB()
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)
            const { clan } = found
            if (clan.leader !== senderJid) return Reply(`❌ Hanya leader yang bisa kick member!`)

            let targetJid = null
            if (m.mentionedJid?.length > 0) targetJid = m.mentionedJid[0]
            else if (m.quoted) targetJid = m.quoted.sender
            if (!targetJid) return Reply(`❌ Tag atau reply member yang ingin di-kick!`)
            if (targetJid === senderJid) return Reply(`❌ Kamu tidak bisa kick dirimu sendiri!`)
            if (!clan.members.includes(targetJid)) return Reply(`❌ User tersebut bukan member clan ini!`)

            clan.members = clan.members.filter(j => j !== targetJid)
            saveClanDB(clanDB)
            return yonz.sendMessage(m.chat, { text: `✅ @${targetJid.split('@')[0]} berhasil di-kick dari clan *${clan.emblem} ${clan.name}*!`, mentions: [targetJid] }, { quoted: m })
        }

        // ── .transferclan ─────────────────────────────────────
        if (command === 'transferclan') {
            const clanDB = loadClanDB()
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)
            const { clan } = found
            if (clan.leader !== senderJid) return Reply(`❌ Hanya leader yang bisa transfer kepemimpinan!`)

            let targetJid = null
            if (m.mentionedJid?.length > 0) targetJid = m.mentionedJid[0]
            else if (m.quoted) targetJid = m.quoted.sender
            if (!targetJid) return Reply(`❌ Tag atau reply member yang akan dijadikan leader!`)
            if (!clan.members.includes(targetJid)) return Reply(`❌ User tersebut bukan member clan ini!`)

            clan.leader = targetJid
            saveClanDB(clanDB)
            return yonz.sendMessage(m.chat, { text: `👑 Kepemimpinan clan *${clan.emblem} ${clan.name}* berhasil ditransfer ke @${targetJid.split('@')[0]}!`, mentions: [targetJid] }, { quoted: m })
        }

        // ── .depositclan ──────────────────────────────────────
        if (command === 'depositclan') {
            const clanDB = loadClanDB()
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)

            const amount = parseInt(text)
            if (isNaN(amount) || amount <= 0) return Reply(`❌ Masukkan jumlah gold!\nContoh: *.depositclan 5000*`)

            const player = rpgDB.players[senderJid]
            if (!player) return Reply(`❌ Kamu belum terdaftar RPG!`)
            if ((player.gold || 0) < amount) return Reply(`❌ Gold kamu tidak cukup! Gold kamu: ${toRupiah(player.gold)}`)

            player.gold -= amount
            found.clan.gold = (found.clan.gold || 0) + amount
            saveClanDB(clanDB)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`✅ Berhasil deposit *${toRupiah(amount)}* ke kas clan!\n💰 Kas clan sekarang: ${toRupiah(found.clan.gold)}`)
        }

        // ── .serangclan ───────────────────────────────────────
        if (command === 'serangclan') {
            if (!isPremium && !isCreator) return Reply(`👑 *KHUSUS PREMIUM!*\n\nHanya member premium yang bisa memulai serangan clan!`)

            const clanDB = loadClanDB()
            const atkFound = findPlayerClan(clanDB, senderJid)
            if (!atkFound) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)

            const { clan: atkClan } = atkFound
            if (atkClan.leader !== senderJid && !isCreator) return Reply(`❌ Hanya leader yang bisa memimpin serangan clan!`)

            const now = Date.now()
            const raidCooldown = 3 * 60 * 60 * 1000 // 3 jam
            if (atkClan.lastRaid && now - atkClan.lastRaid < raidCooldown) {
                const sisa = raidCooldown - (now - atkClan.lastRaid)
                return Reply(`⏳ Clan kamu masih cooldown!\nBisa menyerang lagi dalam: *${formatTime(sisa / 1000)}*`)
            }

            if (!text) return Reply(`❌ Sebutkan nama clan yang ingin diserang!\nContoh: *.serangclan NamaClan*`)

            const defEntry = Object.entries(clanDB.clans).find(([, c]) => c.name.toLowerCase() === text.trim().toLowerCase())
            if (!defEntry) return Reply(`❌ Clan *${text.trim()}* tidak ditemukan!\nLihat daftar: *.listclan*`)

            const [defClanId, defClan] = defEntry
            if (defClanId === atkFound.clanId) return Reply(`❌ Kamu tidak bisa menyerang clan sendiri!`)

            // Hitung power masing-masing clan (+ buff bonus)
            const now2 = Date.now()
            const atkBuffs = atkClan.buffs || {}
            const defBuffs2 = defClan.buffs || {}

            const atkAtkBonus = (atkBuffs['atk_buff'] || 0) > now2 ? 10 * (atkClan.members || []).length : 0
            const defDefBonus = (defBuffs2['def_buff'] || 0) > now2 ? 10 * (defClan.members || []).length : 0

            const atkPower = getClanPower(atkClan, rpgDB) + atkAtkBonus
            const defPower = getClanPower(defClan, rpgDB) + defDefBonus

            // Formula: 60% base power + 40% random luck
            const atkScore = atkPower * 0.6 + Math.random() * atkPower * 0.4 + ((Array.isArray(atkClan.members) ? atkClan.members.length : 0) * 50)
            const defScore = defPower * 0.6 + Math.random() * defPower * 0.4 + ((Array.isArray(defClan.members) ? defClan.members.length : 0) * 50)

            const atkWins = atkScore >= defScore

            // Hitung rampasan (20-35% dari kas clan yang kalah)
            const loserClan = atkWins ? defClan : atkClan
            const winnerClan = atkWins ? atkClan : defClan
            const stealPct = 0.20 + Math.random() * 0.15
            const stolenGold = Math.floor((loserClan.gold || 0) * stealPct)

            loserClan.gold = Math.max(0, (loserClan.gold || 0) - stolenGold)
            winnerClan.gold = (winnerClan.gold || 0) + stolenGold

            if (atkWins) {
                atkClan.wins = (atkClan.wins || 0) + 1
                defClan.losses = (defClan.losses || 0) + 1
            } else {
                defClan.wins = (defClan.wins || 0) + 1
                atkClan.losses = (atkClan.losses || 0) + 1
            }

            atkClan.lastRaid = now
            saveClanDB(clanDB)

            const winEmoji = atkWins ? '🏆' : '💀'
            const resultText = atkWins ? '🎉 CLAN KAMU MENANG!' : '😔 CLAN KAMU KALAH!'
            const goldText = atkWins
                ? `💰 Berhasil merampok *${toRupiah(stolenGold)}* dari kas ${defClan.emblem} ${defClan.name}!`
                : `💸 ${defClan.emblem} ${defClan.name} berhasil mempertahankan diri!\nKas kamu berkurang *${toRupiah(stolenGold)}*`

            const atkBar = Math.min(10, Math.round(atkScore / (atkScore + defScore) * 10))
            const defBar = 10 - atkBar
            const powerBar = `${'⚔️'.repeat(atkBar)}${'🛡️'.repeat(defBar)}`

            return Reply(`╭─────────────────────❏
│▣  ⚔️  PERANG CLAN  ⚔️
╰─────────────────────❏
╭─❏
│▣ ${atkClan.emblem} ${atkClan.name} VS ${defClan.emblem} ${defClan.name}
│▣
│▣ ⚔️  Power Serang : ${atkPower}
│▣ 🛡️  Power Tahan  : ${defPower}
│▣
│▣ ${powerBar}
│▣
│▣ ${winEmoji} *${resultText}*
│▣ ${goldText}
│▣
│▣ 💰 Kas ${atkClan.emblem} ${atkClan.name}: ${toRupiah(atkClan.gold)}
│▣ 💰 Kas ${defClan.emblem} ${defClan.name}: ${toRupiah(defClan.gold)}
│▣ ──────────────────
│▣ ⏳ Cooldown serangan: 3 jam
╰──────────❏`)
        }

        // ── .rampokclan ───────────────────────────────────────
        if (command === 'rampokclan') {
            if (!isPremium && !isCreator) return Reply(`👑 *KHUSUS PREMIUM!*\n\nHanya member premium yang bisa memimpin perampokan clan!`)

            const clanDB = loadClanDB()
            const atkFound = findPlayerClan(clanDB, senderJid)
            if (!atkFound) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)

            const { clan: atkClan } = atkFound
            if (!text) return Reply(`❌ Sebutkan nama clan target!\nContoh: *.rampokclan NamaClan*\n\n💡 Berbeda dengan *.serangclan*, rampokan fokus mencuri lebih banyak gold tapi risikonya lebih tinggi!`)

            const defEntry = Object.entries(clanDB.clans).find(([, c]) => c.name.toLowerCase() === text.trim().toLowerCase())
            if (!defEntry) return Reply(`❌ Clan *${text.trim()}* tidak ditemukan!`)

            const [defClanId, defClan] = defEntry
            if (defClanId === atkFound.clanId) return Reply(`❌ Tidak bisa merampok clan sendiri!`)

            const now = Date.now()
            const robbCooldown = 2 * 60 * 60 * 1000
            const robbKey = `lastRobb_${defClanId}`
            if (atkClan[robbKey] && now - atkClan[robbKey] < robbCooldown) {
                return Reply(`⏳ Masih cooldown merampok clan ini!\nBisa lagi dalam: *${formatTime((robbCooldown - (now - atkClan[robbKey])) / 1000)}*`)
            }

            const player = rpgDB.players[senderJid]
            if (!player) return Reply(`❌ Kamu belum terdaftar RPG!`)

            // Cek kas_shield buff pada clan defender
            const defBuffs = defClan.buffs || {}
            const shieldExpiry = defBuffs['kas_shield'] || 0
            if (shieldExpiry > now) {
                const sisaJam = Math.ceil((shieldExpiry - now) / 3600000)
                return Reply(`╭─────────────────────❏\n│▣  🔒  KAS TERLINDUNGI!  🔒\n╰─────────────────────❏\n╭─❏\n│▣ 🏰 Clan ${defClan.emblem} *${defClan.name}*\n│▣    sedang aktif *Kas Shield*!\n│▣\n│▣ ⏳ Shield habis dalam: *${sisaJam} jam*\n│▣ ❌ Kas mereka tidak bisa dirampok!\n╰──────────❏`)
            }

            // Rampokan: player solo vs seluruh clan
            const playerPower = getPlayerTotalStats(player).totalAttack + (player.level || 1) * 3
            const defPower = getClanPower(defClan, rpgDB)

            const successChance = Math.min(0.75, Math.max(0.15, playerPower / (playerPower + defPower * 0.5)))
            const success = Math.random() < successChance

            let msg = ''
            if (success) {
                const stealPct = 0.30 + Math.random() * 0.20
                const stolen = Math.floor((defClan.gold || 0) * stealPct)
                defClan.gold = Math.max(0, (defClan.gold || 0) - stolen)
                player.gold = (player.gold || 0) + stolen
                atkClan[robbKey] = now
                saveClanDB(clanDB)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                msg = `╭─────────────────────❏\n│▣  💰  RAMPOKAN BERHASIL!  💰\n╰─────────────────────❏\n╭─❏\n│▣ 🥷 Perampok : @${senderJid.split('@')[0]}\n│▣ 🏰 Target   : ${defClan.emblem} ${defClan.name}\n│▣\n│▣ 💰 Berhasil mencuri: *${toRupiah(stolen)}*\n│▣ 💸 Kas ${defClan.emblem} tersisa: ${toRupiah(defClan.gold)}\n│▣\n│▣ ⏳ Cooldown: 2 jam\n╰──────────❏`
            } else {
                const penalty = Math.floor((player.gold || 0) * 0.10)
                player.gold = Math.max(0, (player.gold || 0) - penalty)
                atkClan[robbKey] = now
                saveClanDB(clanDB)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                msg = `╭─────────────────────❏\n│▣  💀  RAMPOKAN GAGAL!  💀\n╰─────────────────────❏\n╭─❏\n│▣ 🥷 Perampok : @${senderJid.split('@')[0]}\n│▣ 🏰 Target   : ${defClan.emblem} ${defClan.name}\n│▣\n│▣ ❌ Kamu tertangkap!\n│▣ 💸 Denda: *${toRupiah(penalty)}*\n│▣ 💰 Sisa gold kamu: ${toRupiah(player.gold)}\n│▣\n│▣ ⏳ Cooldown: 2 jam\n╰──────────❏`
            }
            return yonz.sendMessage(m.chat, { text: msg, mentions: [senderJid] }, { quoted: m })
        }

        // ── .clanhelp ─────────────────────────────────────────
        if (command === 'clanhelp') {
            return Reply(`╭─────────────────────❏
│▣  🏰  PANDUAN CLAN  🏰
╰─────────────────────❏
╭─❏
│▣ 🔧 *PEMBUATAN & MANAGEMENT*
│▣ *.buatclan [🔥] [nama]*
│▣   └ Buat clan baru _(Premium only)_
│▣ *.listclan*
│▣   └ Lihat semua clan
│▣ *.infoclan [nama?]*
│▣   └ Info detail clan
│▣ *.renameclan [🔥] [nama baru]*
│▣   └ Ganti nama & lambang _(maks 2x)_
│▣ ──────────────────
│▣ 👥 *KEANGGOTAAN*
│▣ *.gabukclan [nama]*
│▣   └ Bergabung ke clan
│▣ *.keluarclan*
│▣   └ Keluar dari clan
│▣ *.kickclan @user*
│▣   └ Keluarkan member _(leader only)_
│▣ *.transferclan @user*
│▣   └ Transfer kepemimpinan
│▣ *.depositclan [amount]*
│▣   └ Setor gold ke kas clan
│▣ ──────────────────
│▣ 🏪 *TOKO CLAN*
│▣ *.tokoclan*
│▣   └ Lihat item buff yang bisa dibeli
│▣ *.beliclan [item]*
│▣   └ Beli buff pakai kas clan _(leader)_
│▣ ──────────────────
│▣ ⚔️ *PERANG & RAMPOKAN*
│▣ *.serangclan [nama]*
│▣   └ Serang clan lain _(Premium, CD: 3j)_
│▣ *.rampokclan [nama]*
│▣   └ Rampok kas clan _(Premium, CD: 2j)_
│▣ ──────────────────
│▣ ℹ️ *INFO*
│▣ 👥 Maks anggota: 4 orang
│▣ 🔄 Rename: 2x seumur hidup
│▣ 👑 Pembuat clan: khusus premium
│▣ 💰 Kas clan: bisa diisi semua member
╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  CLAN: TOKO CLAN
// ═══════════════════════════════════════════════════════════

        if (command === 'tokoclan') {
            if (!rpgDB.players || !rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)

            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!\nGabung dulu dengan *.gabukclan [nama]*`)

            const { clan } = found
            if (!clan.buffs || typeof clan.buffs !== 'object') clan.buffs = {}
            const now = Date.now()
            const buffs = clan.buffs

            const TOKO_CLAN = {
                'exp_boost':   { name: '⭐ EXP Boost',    harga: 5000000,  durasi: 24, desc: 'EXP +50% untuk semua member, 24 jam' },
                'gold_boost':  { name: '💰 Gold Boost',   harga: 8000000,  durasi: 24, desc: 'Gold drop +50% untuk semua member, 24 jam' },
                'atk_buff':    { name: '⚔️ ATK Buff',     harga: 6000000,  durasi: 12, desc: 'ATK +10 untuk semua member, 12 jam' },
                'def_buff':    { name: '🛡️ DEF Buff',     harga: 6000000,  durasi: 12, desc: 'DEF +10 untuk semua member, 12 jam' },
                'drop_boost':  { name: '🎁 Drop Boost',   harga: 10000000, durasi: 24, desc: 'Chance drop item langka x2, 24 jam' },
                'kas_shield':  { name: '🔒 Kas Shield',   harga: 7000000,  durasi: 12, desc: 'Kas aman dari rampokclan, 12 jam' },
                'slot_expand': { name: '👥 Slot Expand',  harga: 20000000, durasi: 0,  desc: '+2 slot anggota permanen (maks 10)' },
            }

            const daftar = Object.entries(TOKO_CLAN).map(([key, item]) => {
                let status = ''
                if (item.durasi === 0) {
                    const maxSlot = clan.maxMembers || 4
                    status = maxSlot >= 10 ? ' ⛔ _(maks tercapai)_' : ` — Slot saat ini: ${maxSlot}`
                } else {
                    const expiry = buffs[key] || 0
                    if (expiry > now) {
                        const sisaJam = Math.ceil((expiry - now) / 3600000)
                        status = ` ✅ _(aktif ${sisaJam}j lagi)_`
                    }
                }
                return `│▣ 🔹 *${key}*${status}\n│▣    ${item.name} — ${toRupiah(item.harga)}\n│▣    📝 ${item.desc}`
            }).join('\n│▣ ──────────────────\n')

            const isLeader = clan.leader === senderJid
            const leaderNote = isLeader ? `📌 Kamu leader! Beli dengan *.beliclan [item]*` : `📌 Hanya leader yang bisa beli`

            return Reply(`╭─────────────────────❏\n│▣  🏪  TOKO CLAN  🏪\n╰─────────────────────❏\n╭─❏\n│▣ 🏰 Clan : ${clan.emblem} *${clan.name}*\n│▣ 💰 Kas  : *${toRupiah(clan.gold || 0)}*\n│▣ ──────────────────\n${daftar}\n│▣ ──────────────────\n│▣ ${leaderNote}\n│▣ Contoh: *.beliclan exp_boost*\n╰──────────❏`)
        }

        if (command === 'beliclan') {
            if (!rpgDB.players || !rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)

            const clanDB = loadClanDB()
            if (!clanDB.clans) clanDB.clans = {}
            const found = findPlayerClan(clanDB, senderJid)
            if (!found) return Reply(`❌ Kamu tidak bergabung di clan manapun!`)

            const { clan } = found
            if (!clan.buffs || typeof clan.buffs !== 'object') clan.buffs = {}
            if (clan.leader !== senderJid) return Reply(`❌ Hanya *leader* clan yang bisa belanja di toko!\n👑 Leader: @${(clan.leader || '').split('@')[0]}`)

            const TOKO_CLAN = {
                'exp_boost':   { name: '⭐ EXP Boost',    harga: 5000000,  durasi: 24, desc: 'EXP +50% untuk semua member, 24 jam' },
                'gold_boost':  { name: '💰 Gold Boost',   harga: 8000000,  durasi: 24, desc: 'Gold drop +50% untuk semua member, 24 jam' },
                'atk_buff':    { name: '⚔️ ATK Buff',     harga: 6000000,  durasi: 12, desc: 'ATK +10 untuk semua member, 12 jam' },
                'def_buff':    { name: '🛡️ DEF Buff',     harga: 6000000,  durasi: 12, desc: 'DEF +10 untuk semua member, 12 jam' },
                'drop_boost':  { name: '🎁 Drop Boost',   harga: 10000000, durasi: 24, desc: 'Chance drop item langka x2, 24 jam' },
                'kas_shield':  { name: '🔒 Kas Shield',   harga: 7000000,  durasi: 12, desc: 'Kas aman dari rampokclan, 12 jam' },
                'slot_expand': { name: '👥 Slot Expand',  harga: 20000000, durasi: 0,  desc: '+2 slot anggota permanen (maks 10)' },
            }

            // Ambil dari args[0] agar tidak bentrok dengan nama clan di text
            const itemKey = (args[0] || '').trim().toLowerCase()
            if (!itemKey || !TOKO_CLAN[itemKey]) {
                const list = Object.keys(TOKO_CLAN).map(k => `*${k}*`).join(', ')
                return Reply(`❌ Item tidak ditemukan!\n\n📋 Item tersedia:\n${list}\n\nContoh: *.beliclan exp_boost*\nLihat daftar lengkap: *.tokoclan*`)
            }

            const item = TOKO_CLAN[itemKey]
            const kasSekarang = clan.gold || 0

            if (kasSekarang < item.harga) {
                return Reply(`╭─────────────────────❏\n│▣  ❌  KAS TIDAK CUKUP  ❌\n╰─────────────────────❏\n╭─❏\n│▣ 🏪 Item   : ${item.name}\n│▣ 💸 Harga  : ${toRupiah(item.harga)}\n│▣ 💰 Kas    : ${toRupiah(kasSekarang)}\n│▣ 📉 Kurang : ${toRupiah(item.harga - kasSekarang)}\n│▣\n│▣ 📌 Isi kas dengan *.depositclan [jumlah]*\n╰──────────❏`)
            }

            const now = Date.now()
            clan.buffs = clan.buffs || {}

            // Slot expand — permanen, tidak berdurasi
            if (itemKey === 'slot_expand') {
                if ((clan.maxMembers || 4) >= 10) return Reply(`❌ Slot anggota sudah maksimum (10 orang)!`)
                clan.maxMembers = Math.min(10, (clan.maxMembers || 4) + 2)
                clan.gold = kasSekarang - item.harga
                saveClanDB(clanDB)
                return Reply(`╭─────────────────────❏\n│▣  🏪  BELI BERHASIL!  🏪\n╰─────────────────────❏\n╭─❏\n│▣ ${item.name}\n│▣ 👥 Slot anggota kini: *${clan.maxMembers} orang*\n│▣ 💸 Biaya    : ${toRupiah(item.harga)}\n│▣ 💰 Kas sisa : ${toRupiah(clan.gold)}\n╰──────────❏\n_Slot clan berhasil diperluas! 🎉_`)
            }

            // Buff berdurasi — stack jika sudah aktif
            const existingExpiry = clan.buffs[itemKey] || 0
            const baseTime = Math.max(now, existingExpiry)
            clan.buffs[itemKey] = baseTime + item.durasi * 3600000
            clan.gold = kasSekarang - item.harga
            saveClanDB(clanDB)

            const expiredAt = new Date(clan.buffs[itemKey]).toLocaleString('id-ID')
            const memberMentions = Array.isArray(clan.members) ? clan.members : []

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  🏪  TOKO CLAN — BELI BERHASIL!  🏪\n╰─────────────────────❏\n╭─❏\n│▣ 🏰 Clan   : ${clan.emblem} *${clan.name}*\n│▣ 🎁 Item   : ${item.name}\n│▣ 📝 Efek   : ${item.desc}\n│▣ ⏳ Aktif hingga: *${expiredAt}*\n│▣\n│▣ 💸 Biaya    : ${toRupiah(item.harga)}\n│▣ 💰 Kas sisa : ${toRupiah(clan.gold)}\n│▣ ──────────────────\n│▣ 📢 Buff aktif untuk semua member!\n│▣ ${memberMentions.map(j => '@' + j.split('@')[0]).join(' ')}\n╰──────────❏`,
                mentions: memberMentions
            }, { quoted: m })
        }


        // ════════════════════════════════════════════
        //  💒  SIMULATOR KEHIDUPAN
        // ════════════════════════════════════════════

        // ── .lamar — Melamar pemain lain ─────────────────────────
        if (command === 'lamar') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.pasangan) return Reply(`❌ Kamu sudah menikah dengan *${player.pasanganNama || 'seseorang'}*! Cerai dulu dengan *.cerai*`)

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) targetJid = resolveMentionJid(m.mentionedJid[0])
            else if (m.quoted) targetJid = resolveMentionJid(m.quoted.sender)
            if (!targetJid) return Reply(`❌ Tag atau reply siapa yang mau kamu lamar!\nContoh: *.lamar @user*`)
            // Normalize ke @s.whatsapp.net sebagai kunci standar
            if (targetJid.endsWith('@lid')) targetJid = targetJid.replace('@lid', '@s.whatsapp.net')
            if (targetJid === senderJid) return Reply(`❌ Kamu tidak bisa melamar diri sendiri!`)
            if (!rpgDB.players[targetJid]) return Reply(`❌ User itu belum terdaftar sebagai petualang! Suruh mereka ketik *.rpgstart* dulu.`)
            const target = rpgDB.players[targetJid]
            if (target.pasangan) return Reply(`❌ User itu sudah menikah!`)

            // Syarat: harus punya gold minimal Rp 500.000 (mas kawin)
            const BIAYA_NIKAH = 7000000
            if ((player.gold || 0) < BIAYA_NIKAH) return Reply(`❌ Kamu butuh minimal *${toRupiah(BIAYA_NIKAH)}* sebagai mas kawin untuk melamar!`)

            // Simpan proposal
            if (!rpgDB.proposals) rpgDB.proposals = {}
            rpgDB.proposals[targetJid] = {
                from: senderJid,
                time: Date.now()
            }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  💍  LAMARAN CINTA  💍\n╰─────────────────────❏\n╭─❏\n│▣ 💌 @${senderJid.split('@')[0]} melamar @${targetJid.split('@')[0]}!\n│▣\n│▣ 💍 Mas kawin siap: *${toRupiah(BIAYA_NIKAH)}*\n│▣\n│▣ ❓ @${targetJid.split('@')[0]}, ketik:\n│▣   *.terima* — Terima lamaran 💖\n│▣   *.tolak*  — Tolak lamaran 💔\n╰──────────❏`,
                mentions: [senderJid, targetJid]
            }, { quoted: m })
        }

        // ── .terima — Terima lamaran ──────────────────────────────
        if (command === 'terima') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (player.pasangan) return Reply(`❌ Kamu sudah menikah!`)
            // Cari proposal dengan normalisasi JID
            const normSenderJid = senderJid.endsWith('@lid') ? senderJid.replace('@lid', '@s.whatsapp.net') : senderJid
            if (!rpgDB.proposals || (!rpgDB.proposals[senderJid] && !rpgDB.proposals[normSenderJid])) return Reply(`❌ Kamu tidak punya lamaran masuk saat ini!`)
            const prop = rpgDB.proposals[normSenderJid] || rpgDB.proposals[senderJid]
            const proposalKey = rpgDB.proposals[normSenderJid] ? normSenderJid : senderJid
            // Cek proposal tidak expired (24 jam)
            if (Date.now() - prop.time > 24 * 60 * 60 * 1000) {
                delete rpgDB.proposals[proposalKey]
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`❌ Lamaran sudah expired (lebih dari 24 jam)!`)
            }

            const pelamarJid = resolvePlayerJid(prop.from)
            const pelamar = rpgDB.players[pelamarJid]
            if (!pelamar) return Reply(`❌ Pelamar sudah tidak terdaftar!`)
            if (pelamar.pasangan) return Reply(`❌ Pelamar sudah menikah dengan orang lain!`)

            const BIAYA_NIKAH = 7000000
            if ((pelamar.gold || 0) < BIAYA_NIKAH) return Reply(`❌ Pelamar tidak punya cukup gold untuk mas kawin!`)

            // Proses nikah
            pelamar.gold -= BIAYA_NIKAH
            const tanggalNikah = new Date().toLocaleDateString('id-ID')
            pelamar.pasangan = senderJid
            pelamar.pasanganNama = `@${senderJid.split('@')[0]}`
            pelamar.tanggalNikah = tanggalNikah
            pelamar.anak = pelamar.anak || []
            player.pasangan = pelamarJid
            player.pasanganNama = `@${pelamarJid.split('@')[0]}`
            player.tanggalNikah = tanggalNikah
            player.anak = player.anak || []
            delete rpgDB.proposals[proposalKey]

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  💒  SELAMAT MENIKAH!  💒\n╰─────────────────────❏\n╭─❏\n│▣ 👰 Pasutri baru!\n│▣ 💑 @${pelamarJid.split('@')[0]} & @${senderJid.split('@')[0]}\n│▣\n│▣ 📅 Tanggal: *${tanggalNikah}*\n│▣ 💍 Mas kawin: *${toRupiah(BIAYA_NIKAH)}*\n│▣\n│▣ 🍼 Punya anak? Gunakan *.buatanak*\n│▣ 🍱 Beri makan anak: *.belimakanan*\n│▣ 💵 Kasih nafkah: *.nafkah [jumlah]*\n╰──────────❏\nSelamat menempuh hidup baru! 🥳`,
                mentions: [pelamarJid, senderJid]
            }, { quoted: m })
        }

        // ── .tolak — Tolak lamaran ────────────────────────────────
        if (command === 'tolak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const normSenderJid = senderJid.endsWith('@lid') ? senderJid.replace('@lid', '@s.whatsapp.net') : senderJid
            if (!rpgDB.proposals || (!rpgDB.proposals[senderJid] && !rpgDB.proposals[normSenderJid])) return Reply(`❌ Kamu tidak punya lamaran masuk!`)
            const prop = rpgDB.proposals[normSenderJid] || rpgDB.proposals[senderJid]
            const proposalKey = rpgDB.proposals[normSenderJid] ? normSenderJid : senderJid
            const pelamarJid = resolvePlayerJid(prop.from)
            delete rpgDB.proposals[proposalKey]
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  💔  LAMARAN DITOLAK  💔\n╰─────────────────────❏\n│▣ @${senderJid.split('@')[0]} menolak lamaran dari @${pelamarJid.split('@')[0]}.\n│▣ Semangat ya bro 😔`,
                mentions: [senderJid, pelamarJid]
            }, { quoted: m })
        }

        // ── .cerai — Cerai ────────────────────────────────────────
        if (command === 'cerai') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const BIAYA_CERAI = 5000000
            if ((player.gold || 0) < BIAYA_CERAI) return Reply(`❌ Biaya cerai: *${toRupiah(BIAYA_CERAI)}*. Gold kamu tidak cukup!`)

            const pasanganJid = resolvePlayerJid(player.pasangan)
            // [FIX] Simpan nama pasangan sebelum dihapus (untuk pesan cerai)
            const namaExPasangan = player.pasanganNama || (pasanganJid ? pasanganJid.split('@')[0] : 'mantan')
            const pasangan = pasanganJid ? rpgDB.players[pasanganJid] : null

            player.gold -= BIAYA_CERAI

            // Hapus status nikah kedua pihak
            delete player.pasangan
            delete player.pasanganNama
            delete player.tanggalNikah
            // Reset harmoni ke netral
            player.harmoni = 50
            if (pasangan) {
                delete pasangan.pasangan
                delete pasangan.pasanganNama
                delete pasangan.tanggalNikah
                pasangan.harmoni = 50
            }

            // Anak tetap ada di data masing-masing, tapi status keluarga terputus
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            // [FIX] Cegah mention undefined jika pasanganJid tidak ada di DB
            if (pasanganJid) {
                return yonz.sendMessage(m.chat, {
                    text: `╭─────────────────────❏\n│▣  💔  PERCERAIAN RESMI  💔\n╰─────────────────────❏\n╭─❏\n│▣ 📄 @${senderJid.split('@')[0]} dan @${pasanganJid.split('@')[0]}\n│▣    resmi bercerai.\n│▣\n│▣ 💸 Biaya cerai: *${toRupiah(BIAYA_CERAI)}*\n│▣ 👶 Anak tetap tercatat di data masing-masing\n╰──────────❏\nSemoga ke depannya lebih baik... 😔`,
                    mentions: [senderJid, pasanganJid]
                }, { quoted: m })
            } else {
                return Reply(`╭─────────────────────❏\n│▣  💔  PERCERAIAN RESMI  💔\n╰─────────────────────❏\n╭─❏\n│▣ 📄 Kamu dan *${namaExPasangan}* resmi bercerai.\n│▣\n│▣ 💸 Biaya cerai: *${toRupiah(BIAYA_CERAI)}*\n│▣ 👶 Anak tetap tercatat di data kamu\n╰──────────❏\nSemoga ke depannya lebih baik... 😔`)
            }
        }

        // ── .infopasangan — Info status pernikahan ─────────────────
        if (command === 'infopasangan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]

            if (!player.pasangan) {
                return Reply(`╭─────────────────────❏\n│▣  💑  STATUS CINTA  💑\n╰─────────────────────❏\n╭─❏\n│▣ 💔 Status: *Lajang*\n│▣ 💍 Cari pasangan dengan *.lamar @user*\n╰──────────❏`)
            }

            const anakList = (player.anak || [])
            const anakInfo = anakList.length === 0
                ? '— belum punya anak'
                : anakList.map((a, i) => `│▣   ${i+1}. ${a.nama} (👶 Usia: ${a.usia} thn, ❤️ ${a.kesehatan}/100)`).join('\n')

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  💑  STATUS KELUARGA  💑\n╰─────────────────────❏\n╭─❏\n│▣ 💒 Status   : *Menikah*\n│▣ 💑 Pasangan : ${player.pasanganNama || player.pasangan}\n│▣ 📅 Tgl Nikah: ${player.tanggalNikah || '-'}\n│▣ ──────────────────\n│▣ 👶 ANAK (${anakList.length}):\n${anakInfo}\n╰──────────❏`,
                mentions: [player.pasangan]
            }, { quoted: m })
        }

        // ── .buatanak — Punya anak ────────────────────────────────
        if (command === 'buatanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]

            if (!player.pasangan) return Reply(`❌ Kamu belum menikah! Lamar dulu dengan *.lamar @user*`)

            const pasanganJid = resolvePlayerJid(player.pasangan)
            const pasangan = rpgDB.players[pasanganJid]
            if (!pasangan) return Reply(`❌ Data pasanganmu tidak ditemukan! (JID: ${player.pasangan})`)

            const anakSaya = player.anak || []

            // Syarat anak berikutnya: anak pertama harus berusia ≥ 6 tahun
            if (anakSaya.length > 0) {
                const anakPertama = anakSaya[0]
                if ((anakPertama.usia || 0) < 6) {
                    return Reply(`╭─────────────────────❏\n│▣  🚫  BELUM BISA!  🚫\n╰─────────────────────❏\n╭─❏\n│▣ 👶 Anak pertama *${anakPertama.nama}* masih\n│▣    berusia *${anakPertama.usia} tahun*.\n│▣\n│▣ ⚠️ Syarat: Anak pertama harus\n│▣    berusia minimal *6 tahun*.\n│▣\n│▣ 💊 Rawat anak dengan *.rawatanak*\n│▣    untuk meningkatkan usianya!\n╰──────────❏`)
                }
            }

            const BIAYA_ANAK = 2000000
            if ((player.gold || 0) < BIAYA_ANAK) return Reply(`❌ Butuh *${toRupiah(BIAYA_ANAK)}* untuk biaya kehamilan & persalinan!`)

            // Generate nama anak random
            const namaLaki = ['Arjuna','Bima','Satria','Rizky','Fadhil','Ghaza','Hafizh','Ilham','Jabir','Khalid']
            const namaCewek = ['Aulia','Bunga','Cantika','Dewi','Elisa','Fatimah','Ghina','Hana','Isna','Jasmine']
            const gender = Math.random() < 0.5 ? 'laki-laki' : 'perempuan'
            const namaPool = gender === 'laki-laki' ? namaLaki : namaCewek
            const namaAnak = namaPool[Math.floor(Math.random() * namaPool.length)]
            const emoji = gender === 'laki-laki' ? '👦' : '👧'

            const anakBaru = {
                nama: namaAnak,
                gender: gender,
                emoji: emoji,
                usia: 0,
                kesehatan: 100,
                lahir: new Date().toLocaleDateString('id-ID'),
                terakhirDirawat: Date.now(),
                makanan: 100,
                bakat: randomBakat()
            }

            player.gold -= BIAYA_ANAK
            player.anak = [...anakSaya, anakBaru]

            // [FIX] Sinkron ke pasangan, cegah duplikat berdasarkan nama+lahir
            pasangan.anak = pasangan.anak || []
            const sudahAdaDiPasangan = pasangan.anak.some(a => a.nama === anakBaru.nama && a.lahir === anakBaru.lahir)
            if (!sudahAdaDiPasangan) pasangan.anak.push(anakBaru)

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  🍼  SELAMAT! PUNYA ANAK!  🍼\n╰─────────────────────❏\n╭─❏\n│▣ ${emoji} Nama   : *${namaAnak}*\n│▣ 🚻 Gender : *${gender}*\n│▣ 📅 Lahir  : *${anakBaru.lahir}*\n│▣ ❤️  Kesehatan: 100/100\n│▣ 🍱 Makanan : 100/100\n│▣\n│▣ 💸 Biaya lahiran: *${toRupiah(BIAYA_ANAK)}*\n│▣ ──────────────────\n│▣ 📌 Rawat anakmu agar tumbuh besar!\n│▣ *.rawatanak* — Rawat & tambah usia\n│▣ *.belimakanan* — Beli makanan\n│▣ *.nafkah [jml]* — Kasih uang saku\n╰──────────❏`,
                mentions: [senderJid, pasanganJid]
            }, { quoted: m })
        }

        // ── .rawatanak — Merawat anak (naikkan usia) ──────────────
        if (command === 'rawatanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]

            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu belum punya anak! Gunakan *.buatanak* terlebih dahulu.`)

            const now = Date.now()
            let COOLDOWN_RAWAT = 4 * 60 * 60 * 1000 // 4 jam cooldown
            if (player.rumahKeluarga?.tier === 'villa') COOLDOWN_RAWAT -= 60 * 60 * 1000
            if (player.rumahKeluarga?.tier === 'istana') COOLDOWN_RAWAT -= 2 * 60 * 60 * 1000

            // Ambil index anak (opsional, default anak pertama)
            let idxAnak = 0
            if (args[0]) {
                const parsed = parseInt(args[0]) - 1
                if (!isNaN(parsed) && parsed >= 0 && parsed < anakList.length) idxAnak = parsed
                else {
                    const daftar = anakList.map((a, i) => `│▣ ${i+1}. ${a.emoji || '👶'} *${a.nama || 'Anak'}* — usia ${a.usia || 0} thn`).join('\n')
                    return Reply(`╭─────────────────────❏\n│▣  👶  PILIH ANAK  👶\n╰─────────────────────❏\n╭─❏\n${daftar}\n╰──────────❏\nGunakan: *.rawatanak [nomor]*`)
                }
            }

            const anak = anakList[idxAnak]
            anak.nama = anak.nama || `Anak ${idxAnak + 1}`
            anak.emoji = anak.emoji || '👶'
            anak.kesehatan = Math.max(0, Math.min(100, anak.kesehatan ?? 70))
            anak.makanan = Math.max(0, Math.min(100, anak.makanan ?? 100))
            const lastRawat = anak.terakhirDirawat || 0

            if (now - lastRawat < COOLDOWN_RAWAT) {
                const sisaWaktu = msToTime(COOLDOWN_RAWAT - (now - lastRawat))
                return Reply(`⏳ *${anak.nama}* baru saja dirawat!\nTunggu lagi *${sisaWaktu}* sebelum merawat lagi.`)
            }

            // Biaya rawat
            const BIAYA_RAWAT = 150000
            if ((player.gold || 0) < BIAYA_RAWAT) return Reply(`❌ Butuh *${toRupiah(BIAYA_RAWAT)}* untuk biaya perawatan anak!`)

            // Kondisi: makanan anak harus > 30 untuk bisa tumbuh
            if ((anak.makanan || 0) < 30) {
                return Reply(`╭─────────────────────❏\n│▣  😢  ANAK LAPAR!  😢\n╰─────────────────────❏\n│▣ *${anak.nama}* terlalu lapar (🍱 ${anak.makanan}/100)\n│▣ Makanan < 30 → tidak bisa tumbuh!\n│▣\n│▣ 🛒 Beli makanan dulu: *.belimakanan*\n╰──────────❏`)
            }

            player.gold -= BIAYA_RAWAT

            // Naikkan usia dan kesehatan
            const TAMBAH_USIA = 1
            anak.usia = (anak.usia || 0) + TAMBAH_USIA
            anak.kesehatan = Math.min(100, (anak.kesehatan || 0) + 15)
            anak.makanan = Math.max(0, (anak.makanan || 100) - 20) // makanan berkurang
            anak.terakhirDirawat = now

            // [FIX] Sinkron ke pasangan berdasarkan nama agar tidak salah index
            const pasanganJid = resolvePlayerJid(player.pasangan)
            if (pasanganJid && rpgDB.players[pasanganJid]) {
                const pasangan = rpgDB.players[pasanganJid]
                if (pasangan.anak) {
                    const anakPasangan = pasangan.anak.find(a => (a.nama === anak.nama && (!anak.lahir || a.lahir === anak.lahir)) || (a.id && anak.id && a.id === anak.id))
                    if (anakPasangan) {
                        anakPasangan.usia = anak.usia
                        anakPasangan.kesehatan = anak.kesehatan
                        anakPasangan.makanan = anak.makanan
                        anakPasangan.terakhirDirawat = now
                        anakPasangan.bakat = anak.bakat
                        anakPasangan.pendidikan = anak.pendidikan
                    }
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  ${anak.emoji}  RAWAT ANAK  ${anak.emoji}\n╰─────────────────────❏\n╭─❏\n│▣ 👶 Nama      : *${anak.nama}*\n│▣ 🎂 Usia      : *${anak.usia} tahun*\n│▣ ❤️  Kesehatan : *${anak.kesehatan}/100*\n│▣ 🍱 Makanan   : *${anak.makanan}/100*\n│▣\n│▣ 💸 Biaya rawat: *${toRupiah(BIAYA_RAWAT)}*\n│▣ ⏳ Rawat lagi: *${msToTime(COOLDOWN_RAWAT)}*\n╰──────────❏\n${anak.usia >= 6 ? '🎉 Sudah bisa punya adik!' : `📌 Butuh ${6 - anak.usia} rawatan lagi untuk bisa punya adik!`}`)
        }

        // ── .belimakanan — Beli makanan untuk anak ───────────────
        if (command === 'belimakanan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu belum punya anak!`)

            const HARGA_MAKANAN = 250000
            const jml = parseInt(args[0]) || 1
            const totalBiaya = HARGA_MAKANAN * jml

            if ((player.gold || 0) < totalBiaya) return Reply(`❌ Butuh *${toRupiah(totalBiaya)}* untuk beli ${jml}x makanan!`)

            player.gold -= totalBiaya

            // Isi makanan semua anak merata
            for (let i = 0; i < anakList.length; i++) {
                anakList[i].makanan = Math.min(100, (anakList[i].makanan || 0) + (30 * jml))
            }

            // Sinkron ke pasangan
            const pasanganJid = resolvePlayerJid(player.pasangan)
            if (pasanganJid && rpgDB.players[pasanganJid]) {
                const pasangan = rpgDB.players[pasanganJid]
                if (pasangan.anak) {
                    for (let i = 0; i < pasangan.anak.length; i++) {
                        pasangan.anak[i].makanan = anakList[i]?.makanan ?? pasangan.anak[i].makanan
                    }
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const anakInfo = anakList.map((a, i) => `│▣   ${i+1}. ${a.emoji} ${a.nama} → 🍱 ${a.makanan}/100`).join('\n')
            return Reply(`╭─────────────────────❏\n│▣  🛒  BELI MAKANAN  🛒\n╰─────────────────────❏\n╭─❏\n│▣ 🍱 Makanan x${jml} dibeli!\n│▣ 💸 Total: *${toRupiah(totalBiaya)}*\n│▣ ──────────────────\n│▣ 📊 Status makanan anak:\n${anakInfo}\n╰──────────❏`)
        }

        // ── .nafkah — Kasih nafkah/uang saku ke anak ─────────────
        if (command === 'nafkah') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu belum punya anak!`)

            const jumlah = parseInt(args[0])
            if (isNaN(jumlah) || jumlah <= 0) return Reply(`❌ Masukkan jumlah nafkah yang valid!\nContoh: *.nafkah 100000*`)

            if ((player.gold || 0) < jumlah) return Reply(`❌ Gold kamu tidak cukup! Kamu punya *${toRupiah(player.gold)}*`)

            const NAFKAH_MIN = 200000
            if (jumlah < NAFKAH_MIN) return Reply(`❌ Nafkah minimal *${toRupiah(NAFKAH_MIN)}* per pemberian!`)

            player.gold -= jumlah

            // Nafkah total yang pernah diberikan
            player.totalNafkah = (player.totalNafkah || 0) + jumlah

            // Naikkan kesehatan anak karena tercukupi
            for (let i = 0; i < anakList.length; i++) {
                anakList[i].kesehatan = Math.min(100, (anakList[i].kesehatan || 0) + 10)
            }

            // [FIX] Naikkan keharmonisan +5 per nafkah (sesuai panduan simulatorhelp)
            player.harmoni = Math.min(100, (player.harmoni || 50) + 5)

            // [FIX] Sinkron kesehatan anak & harmoni ke pasangan
            const pasanganJidNafkah = resolvePlayerJid(player.pasangan)
            if (pasanganJidNafkah && rpgDB.players[pasanganJidNafkah]) {
                const pasanganNafkah = rpgDB.players[pasanganJidNafkah]
                if (pasanganNafkah.anak) {
                    for (let i = 0; i < pasanganNafkah.anak.length && i < anakList.length; i++) {
                        pasanganNafkah.anak[i].kesehatan = anakList[i].kesehatan
                    }
                }
                pasanganNafkah.harmoni = Math.min(100, (pasanganNafkah.harmoni || 50) + 5)
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  💵  NAFKAH KELUARGA  💵\n╰─────────────────────❏\n╭─❏\n│▣ 💰 Nafkah: *${toRupiah(jumlah)}*\n│▣ 💖 Kesehatan anak meningkat +10!\n│▣\n│▣ 💳 Total nafkah: *${toRupiah(player.totalNafkah)}*\n│▣ 💰 Sisa gold   : *${toRupiah(player.gold)}*\n╰──────────❏\nResponsible parent banget! 👨‍👩‍👧`)
        }

        // ── .infoanak — Lihat detail semua anak ──────────────────
        if (command === 'infoanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []

            if (anakList.length === 0) return Reply(`╭─────────────────────❏\n│▣  👶  INFO ANAK  👶\n╰─────────────────────❏\n│▣ Kamu belum punya anak.\n│▣ Gunakan *.buatanak* setelah menikah!\n╰──────────❏`)

            const anakDetail = anakList.map((a, i) => {
                const hpBar = '█'.repeat(Math.floor(a.kesehatan / 10)) + '░'.repeat(10 - Math.floor(a.kesehatan / 10))
                const mkBar = '█'.repeat(Math.floor((a.makanan||0) / 10)) + '░'.repeat(10 - Math.floor((a.makanan||0) / 10))
                const siapAdik = a.usia >= 6 ? '✅ Siap punya adik' : `⏳ Perlu ${6-a.usia} rawat lagi`
                return `│▣ ─── Anak ke-${i+1} ───\n│▣ ${a.emoji} Nama: *${a.nama}* (${a.gender})\n│▣ 🎂 Usia: *${a.usia} tahun* | ${siapAdik}\n│▣ ❤️ HP : [${hpBar}] ${a.kesehatan}/100\n│▣ 🍱 Mkn: [${mkBar}] ${a.makanan||0}/100\n│▣ 📅 Lahir: ${a.lahir||'-'}`
            }).join('\n')

            return Reply(`╭─────────────────────❏\n│▣  👨‍👩‍👧  DATA ANAK  👨‍👩‍👧\n╰─────────────────────❏\n╭─❏\n${anakDetail}\n│▣ ──────────────────\n│▣ *.rawatanak [no]* — Rawat anak (CD: 4j)\n│▣ *.belimakanan [jml]* — Beli makanan\n│▣ *.nafkah [jml]* — Kasih nafkah\n╰──────────❏`)
        }

        // ── .simulatorhelp — Panduan fitur simulator ─────────────
        if (command === 'simulatorhelp') {
            return Reply(`╭─────────────────────❏
│▣  💒  SIMULATOR KEHIDUPAN  💒
╰─────────────────────❏
╭─❏
│▣ 💍 *PERNIKAHAN*
│▣ *.lamar @user*
│▣   └ Lamar seseorang (mas kawin Rp 7jt)
│▣ *.terima / .tolak*
│▣   └ Jawab lamaran yang masuk
│▣ *.cerai*
│▣   └ Cerai (biaya Rp 5jt)
│▣ *.infopasangan*
│▣   └ Info status & keluarga
│▣ ──────────────────
│▣ 👶 *ANAK*
│▣ *.buatanak*
│▣   └ Punya anak baru (biaya Rp 2jt)
│▣   └ Syarat: Anak ke-2+ butuh anak
│▣     pertama usia ≥ 6 tahun!
│▣ *.rawatanak [no]*
│▣   └ Rawat anak → naikkan usia +1
│▣   └ CD: 4 jam, biaya Rp 150rb
│▣   └ Makanan anak harus > 30!
│▣ *.infoanak*
│▣   └ Lihat detail semua anak
│▣ *.kadoanak [no] [jml]*
│▣   └ Beri kado anak (min Rp 50rb)
│▣ ──────────────────
│▣ 🏫 *PENDIDIKAN ANAK*
│▣ *.sekolahkan [no]*
│▣   └ SD: Rp 2jt | SMP: Rp 5jt
│▣   └ SMA: Rp 10jt | Kuliah: Rp 25jt
│▣ *.kerjaanak [no]*
│▣   └ Anak mulai bekerja (syarat: lulus kuliah)
│▣ *.rapotanak*
│▣   └ Lihat progress pendidikan anak
│▣ ──────────────────
│▣ 🍱 *NAFKAH & MAKANAN*
│▣ *.belimakanan [jml]*
│▣   └ Beli makanan (Rp 250rb/paket +30)
│▣ *.nafkah [jumlah]*
│▣   └ Beri nafkah keluarga (min Rp 200rb)
│▣ ──────────────────
│▣ 💞 *KEHARMONISAN*
│▣ *.kencan* — Kencan (Rp 1,5jt, CD:12j)
│▣ *.makanbersama* — Makan bersama (CD:8j)
│▣ *.kadoanniversary* — Kado (Rp 3jt, 1x/thn)
│▣ *.cekselingkuh* — Investigasi (Rp 1,5jt)
│▣ ──────────────────
│▣ 📌 *CATATAN*
│▣ • Anak ke-2+ butuh anak 1 usia ≥ 6 thn
│▣ • Rawat anak tiap 4 jam (+1 usia)
│▣ • Makanan habis = tidak bisa tumbuh
│▣ • Kesehatan anak naik dgn nafkah
│▣ • Ketik *.hargasimulator* untuk
│▣   info lengkap semua harga!
╰──────────❏`)
        }

        // ── .hargasimulator — Daftar harga fitur simulator ─────────────
        if (command === 'hargasimulator') {
            return Reply(`╭─────────────────────❏
│▣  💰  HARGA SIMULATOR  💰
╰─────────────────────❏
╭─❏
│▣ 💍 *PERNIKAHAN & KELUARGA*
│▣ ┌ Mas kawin (lamar)  : Rp 7.000.000
│▣ ├ Biaya cerai        : Rp 5.000.000
│▣ ├ Biaya punya anak   : Rp 2.000.000
│▣ ├ Rawat anak (CD:4j) : Rp 150.000
│▣ ├ Beli makanan/paket : Rp 250.000
│▣ └ Nafkah minimum     : Rp 200.000
│▣ ──────────────────
│▣ 💞 *KEHARMONISAN*
│▣ ┌ Kencan (CD:12j)    : Rp 1.500.000
│▣ ├ Makan bersama(CD:8j): Rp 300rb/org
│▣ ├ Foto bersama (CD:4j): Rp 500.000
│▣ ├ Kado anniversary   : Rp 3.000.000
│▣ └ Investigasi selingkuh: Rp 1.500.000
│▣ ──────────────────
│▣ ✈️ *LIBURAN KELUARGA* (CD:7 hari)
│▣ ┌ 🏔️ Gunung          : Rp 2.000.000
│▣ ├ 🏖️ Pantai          : Rp 3.000.000
│▣ ├ 🏙️ Kota Besar      : Rp 5.000.000
│▣ ├ ✈️ Luar Negeri     : Rp 15.000.000
│▣ └ ✨ Alam Para Dewa   : Rp 100.000.000
│▣ ──────────────────
│▣ 🏫 *PENDIDIKAN ANAK*
│▣ ┌ SD (min usia 6)    : Rp 2.000.000
│▣ ├ SMP (min 12 thn)   : Rp 5.000.000
│▣ ├ SMA (min 15 thn)   : Rp 10.000.000
│▣ └ Kuliah (min 18 thn): Rp 25.000.000
│▣ ──────────────────
│▣ 🎁 *KADO ANAK* (bonus kesehatan)
│▣ ┌ Min Rp 50.000      : +10 HP anak
│▣ ├ Rp 200.000+        : +30 HP anak
│▣ ├ Rp 500.000+        : +40 HP anak
│▣ └ Rp 1.000.000+      : +50 HP anak
│▣ ──────────────────
│▣ 🏠 *RUMAH KELUARGA*
│▣ ┌ Rumah Biasa        : Rp 15.000.000
│▣ ├ Rumah Mewah        : Rp 150.000.000
│▣ ├ Villa              : Rp 500.000.000
│▣ └ Istana             : Rp 5.000.000.000
│▣ ──────────────────
│▣ 🔨 *RENOVASI RUMAH*
│▣ ┌ 🍳 Dapur           : Rp 3.000.000
│▣ ├ 🌸 Taman           : Rp 5.000.000
│▣ └ 🏊 Kolam Renang    : Rp 25.000.000
│▣ ──────────────────
│▣ 🏛️ *PANTI ASUHAN*
│▣ └ Adopsi anak        : Rp 200.000
╰──────────❏`)
        }


// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: KENCAN
// ═══════════════════════════════════════════════════════════

        if (command === 'kencan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah! Cari pasangan dulu 💔`)

            const BIAYA_KENCAN = 1500000
            const CD_KENCAN = 12 * 60 * 60 * 1000
            const now = Date.now()

            if ((player.gold || 0) < BIAYA_KENCAN) return Reply(`❌ Butuh *${toRupiah(BIAYA_KENCAN)}* untuk kencan!\n💰 Gold kamu: ${toRupiah(player.gold || 0)}`)

            const lastKencan = player.lastKencan || 0
            if (now - lastKencan < CD_KENCAN) {
                const sisa = CD_KENCAN - (now - lastKencan)
                return Reply(`⏳ Pasangan kamu masih lelah!\nBisa kencan lagi dalam: *${msToTime(sisa)}*`)
            }

            tickKeluarga(player, rpgDB)

            player.gold -= BIAYA_KENCAN
            player.lastKencan = now
            player.totalKencan = (player.totalKencan || 0) + 1

            const harmoni = player.harmoni || 50
            let hasilKencan, bonusHarmoni, buff = ''

            const roll = Math.random()
            if (harmoni >= 80 && roll > 0.3) {
                hasilKencan = '💖 *ROMANTIS BANGET!*\nKencan berjalan sempurna, kalian makin dekat!'
                bonusHarmoni = 20
                buff = '\n│▣ ✨ Buff *Chemistry* aktif 6 jam!\n│▣   (ATK +3 saat battle)'
                player.chemistryBuff = now + 6 * 60 * 60 * 1000
            } else if (roll > 0.4) {
                hasilKencan = '🙂 *MENYENANGKAN*\nKencan berjalan baik, pasangan senang!'
                bonusHarmoni = 12
            } else {
                hasilKencan = '😐 *BIASA SAJA*\nKencan kurang berkesan, tapi lumayan lah...'
                bonusHarmoni = 5
            }

            player.harmoni = Math.min(100, harmoni + bonusHarmoni)

            // [FIX] Sinkron harmoni & cooldown kencan ke pasangan
            const pasJidKencan = resolvePlayerJid(player.pasangan)
            if (pasJidKencan && rpgDB.players[pasJidKencan]) {
                const pasKencan = rpgDB.players[pasJidKencan]
                pasKencan.harmoni = Math.min(100, (pasKencan.harmoni || 50) + bonusHarmoni)
                pasKencan.lastKencan = now
                if (player.chemistryBuff) pasKencan.chemistryBuff = player.chemistryBuff
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  💑  KENCAN BERSAMA  💑\n╰─────────────────────❏\n╭─❏\n│▣ 💌 @${senderJid.split('@')[0]} & ${player.pasanganNama}\n│▣\n│▣ 🎬 ${hasilKencan}\n│▣\n│▣ 💞 Keharmonisan: +${bonusHarmoni}\n│▣ ${getHarmoniBar(player.harmoni)}${buff}\n│▣\n│▣ 💸 Biaya: ${toRupiah(BIAYA_KENCAN)}\n│▣ ⏳ CD: 12 jam\n╰──────────❏`,
                mentions: [senderJid, player.pasangan]
            }, { quoted: m })
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: CEK KEHARMONISAN
// ═══════════════════════════════════════════════════════════

        if (command === 'harmoni' || command === 'cekharmoni') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            tickKeluarga(player, rpgDB)

            const harmoni = player.harmoni || 50
            let statusHarmoni = ''
            if (harmoni >= 90) statusHarmoni = '💖 Pasangan Sejati — hubungan luar biasa!'
            else if (harmoni >= 70) statusHarmoni = '💛 Bahagia — hubungan sehat & hangat'
            else if (harmoni >= 50) statusHarmoni = '🧡 Biasa — masih perlu perhatian'
            else if (harmoni >= 30) statusHarmoni = '⚠️ Mulai Retak — segera diperbaiki!'
            else statusHarmoni = '💔 KRISIS — hubungan sangat berbahaya!'

            const anniv = hitungAnniversary(player.tanggalNikah)
            const annivText = anniv && anniv.isAnniversary
                ? `\n│▣ 🎉 *HARI INI ANNIVERSARY KE-${anniv.tahun}!*`
                : anniv ? `\n│▣ 💍 Pernikahan ke-${anniv.tahun} tahun` : ''

            let tips = ''
            if (harmoni < 50) tips = '\n│▣ 💡 Tips: Kencan, nafkah, & rawat anak\n│▣   untuk naikkan keharmonisan!'
            else if (harmoni >= 80) tips = '\n│▣ ✨ Tip: Coba *.liburankeluarga* untuk\n│▣   bonus keharmonisan besar!'

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  💞  KEHARMONISAN  💞\n╰─────────────────────❏\n╭─❏\n│▣ 💑 @${senderJid.split('@')[0]} & ${player.pasanganNama}${annivText}\n│▣\n│▣ ${getHarmoniBar(harmoni)}\n│▣ ${statusHarmoni}${tips}\n│▣\n│▣ ── Cara naikkan keharmonisan: ──\n│▣ *.kencan* (+12-20) | CD: 12j\n│▣ *.nafkah* (+5) | tiap kasih nafkah\n│▣ *.makanbersama* (+10) | CD: 8j\n│▣ *.liburankeluarga* (+30) | CD: 7h\n│▣ *.kadoanniversary* (+25) | 1x/tahun\n╰──────────❏`,
                mentions: [senderJid, player.pasangan]
            }, { quoted: m })
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: KADO ANNIVERSARY
// ═══════════════════════════════════════════════════════════

        if (command === 'kadoanniversary') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const anniv = hitungAnniversary(player.tanggalNikah)
            if (!anniv || !anniv.isAnniversary) return Reply(`╭─────────────────────❏\n│▣  📅  ANNIVERSARY  📅\n╰─────────────────────❏\n│▣ ❌ Hari ini bukan anniversary-mu!\n│▣\n│▣ 📅 Nikah: ${player.tanggalNikah || '-'}\n│▣ 🎂 Anniversary berikutnya:\n│▣    Tanggal yang sama tahun depan!\n╰──────────❏`)

            if (player.lastAnnivKado && new Date(player.lastAnnivKado).getFullYear() === new Date().getFullYear()) {
                return Reply(`❌ Sudah kasih kado anniversary tahun ini!`)
            }

            const BIAYA_KADO = 3000000
            if ((player.gold || 0) < BIAYA_KADO) return Reply(`❌ Butuh *${toRupiah(BIAYA_KADO)}* untuk kado anniversary!`)

            player.gold -= BIAYA_KADO
            player.harmoni = Math.min(100, (player.harmoni || 50) + 25)
            player.lastAnnivKado = Date.now()

            const pasangan = rpgDB.players[resolvePlayerJid(player.pasangan)]
            if (pasangan) {
                pasangan.harmoni = Math.min(100, (pasangan.harmoni || 50) + 25)
                pasangan.lastAnnivKado = Date.now()
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  🎉  ANNIVERSARY KE-${anniv.tahun}!  🎉\n╰─────────────────────❏\n╭─❏\n│▣ 🎁 @${senderJid.split('@')[0]} memberikan kado\n│▣    kepada ${player.pasanganNama}!\n│▣\n│▣ 💞 Keharmonisan: +25\n│▣ ${getHarmoniBar(player.harmoni)}\n│▣\n│▣ 💸 Biaya kado: ${toRupiah(BIAYA_KADO)}\n╰──────────❏\nSelamat anniversary! Semoga langgeng! 🥂`,
                mentions: [senderJid, player.pasangan]
            }, { quoted: m })
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: SELINGKUH
// ═══════════════════════════════════════════════════════════

        if (command === 'selingkuh') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah! Mau selingkuh dari siapa? 😂`)

            let targetJid = null
            if (m.mentionedJid && m.mentionedJid.length > 0) targetJid = resolveMentionJid(m.mentionedJid[0])
            else if (m.quoted) targetJid = resolveMentionJid(m.quoted.sender)
            if (!targetJid) return Reply(`❌ Tag siapa yang mau kamu selingkuhi!\nContoh: *.selingkuh @user*`)
            if (targetJid.endsWith('@lid')) targetJid = targetJid.replace('@lid', '@s.whatsapp.net')

            if (targetJid === senderJid) return Reply(`❌ Gak bisa selingkuh sama diri sendiri 😭`)
            if (targetJid === player.pasangan) return Reply(`❌ Itu pasangan kamu sendiri! 🤦`)
            if (!rpgDB.players[targetJid]) return Reply(`❌ User itu belum terdaftar!`)

            const CD_SELINGKUH = 6 * 60 * 60 * 1000
            const now = Date.now()
            if (player.lastSelingkuh && now - player.lastSelingkuh < CD_SELINGKUH) {
                return Reply(`⏳ Kamu baru saja selingkuh! Istirahat dulu...\nCD: *${msToTime(CD_SELINGKUH - (now - player.lastSelingkuh))}*`)
            }

            player.lastSelingkuh = now

            const ketahuan = Math.random() < 0.30
            const pasanganJid = resolvePlayerJid(player.pasangan)
            const pasangan = rpgDB.players[pasanganJid]

            if (ketahuan) {
                const DENDA = 10000000
                player.gold = Math.max(0, (player.gold || 0) - DENDA)
                player.harmoni = Math.max(0, (player.harmoni || 50) - 50)
                player.kenaSelingkuh = (player.kenaSelingkuh || 0) + 1

                if (pasangan) {
                    pasangan.harmoni = Math.max(0, (pasangan.harmoni || 50) - 30)
                    pasangan.pasanganSelingkuh = true
                }

                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return yonz.sendMessage(m.chat, {
                    text: `╭─────────────────────❏\n│▣  🚨  KETAHUAN SELINGKUH!  🚨\n╰─────────────────────❏\n╭─❏\n│▣ 😱 @${senderJid.split('@')[0]} ketahuan selingkuh\n│▣    dengan @${targetJid.split('@')[0]}!\n│▣\n│▣ 💔 Keharmonisan: -50\n│▣ ${getHarmoniBar(player.harmoni)}\n│▣\n│▣ 💸 Denda: *${toRupiah(DENDA)}*\n│▣ 😤 Pasangan marah!\n│▣\n│▣ 🕵️ Sudah ketahuan: ${player.kenaSelingkuh}x\n╰──────────❏\nMalu-maluin! 😤`,
                    mentions: [senderJid, targetJid, pasanganJid]
                }, { quoted: m })

            } else {
                player.moodBuff = now + 4 * 60 * 60 * 1000
                if (!player.riwayatSelingkuh) player.riwayatSelingkuh = []
                player.riwayatSelingkuh.push({ dengan: targetJid, waktu: now })

                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return Reply(`╭─────────────────────❏\n│▣  🤫  SELINGKUH BERHASIL  🤫\n╰─────────────────────❏\n╭─❏\n│▣ 😏 Kamu berhasil selingkuh...\n│▣    Semoga tidak ketahuan! 👀\n│▣\n│▣ ✨ Buff *Mood Boost* aktif 4 jam!\n│▣   (EXP +5% dari battle)\n│▣\n│▣ ⚠️ Pasangan bisa *.cekselingkuh*\n│▣   untuk investigasi kamu!\n╰──────────❏`)
            }
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: CEK SELINGKUH
// ═══════════════════════════════════════════════════════════

        if (command === 'cekselingkuh') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const BIAYA_INVESTIGASI = 1500000
            const CD_CEK = 8 * 60 * 60 * 1000
            const now = Date.now()

            if ((player.gold || 0) < BIAYA_INVESTIGASI) return Reply(`❌ Butuh *${toRupiah(BIAYA_INVESTIGASI)}* untuk biaya investigasi!`)
            if (player.lastCekSelingkuh && now - player.lastCekSelingkuh < CD_CEK) {
                return Reply(`⏳ Baru investigasi!\nBisa cek lagi dalam: *${msToTime(CD_CEK - (now - player.lastCekSelingkuh))}*`)
            }

            player.gold -= BIAYA_INVESTIGASI
            player.lastCekSelingkuh = now

            const pasangan = rpgDB.players[resolvePlayerJid(player.pasangan)]
            if (!pasangan) {
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
                return Reply(`❌ Data pasanganmu tidak ditemukan!`)
            }

            const riwayat = pasangan.riwayatSelingkuh || []
            const recent = riwayat.filter(r => now - r.waktu < 48 * 60 * 60 * 1000)

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            if (recent.length === 0) {
                return Reply(`╭─────────────────────❏\n│▣  🕵️  HASIL INVESTIGASI  🕵️\n╰─────────────────────❏\n╭─❏\n│▣ ✅ ${player.pasanganNama} *bersih*!\n│▣ Tidak ada tanda-tanda selingkuh\n│▣ dalam 48 jam terakhir.\n│▣\n│▣ 💸 Biaya investigasi: ${toRupiah(BIAYA_INVESTIGASI)}\n╰──────────❏\nPasangan kamu setia! 💖`)
            } else {
                if (pasangan.harmoni > 0) pasangan.harmoni = Math.max(0, (pasangan.harmoni || 50) - 20)
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return yonz.sendMessage(m.chat, {
                    text: `╭─────────────────────❏\n│▣  🚨  INVESTIGASI: TERBUKTI!  🚨\n╰─────────────────────❏\n╭─❏\n│▣ 😱 ${player.pasanganNama} *TERBUKTI SELINGKUH!*\n│▣\n│▣ 📋 Terdeteksi ${recent.length}x dalam 48 jam\n│▣\n│▣ ⚠️ Kamu bisa *.cerai* atau\n│▣   *.kencan* untuk perbaiki hubungan\n│▣\n│▣ 💔 Keharmonisan pasangan: -20\n│▣\n│▣ 💸 Biaya investigasi: ${toRupiah(BIAYA_INVESTIGASI)}\n╰──────────❏`,
                    mentions: [senderJid, player.pasangan]
                }, { quoted: m })
            }
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: PENDIDIKAN ANAK
// ═══════════════════════════════════════════════════════════

        if (command === 'sekolahkan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []

            if (anakList.length === 0) return Reply(`❌ Kamu belum punya anak!`)

            const noAnak = parseInt(text)
            if (!noAnak || noAnak < 1 || noAnak > anakList.length) {
                const daftarAnak = anakList.map((a, i) => {
                    const jenjang = a.pendidikan || 'belum'
                    return `│▣ ${i+1}. ${a.emoji} ${a.nama} (${a.usia} thn) — ${getJenjangLabel(jenjang)}`
                }).join('\n')
                return Reply(`╭─────────────────────❏\n│▣  🏫  SEKOLAHKAN ANAK  🏫\n╰─────────────────────❏\n╭─❏\n${daftarAnak}\n│▣ ──────────────────\n│▣ Contoh: *.sekolahkan 1*\n│▣\n│▣ Biaya per jenjang:\n│▣ 🏫 SD     : Rp 500.000 (min usia 6)\n│▣ 🏫 SMP    : Rp 1.500.000 (min 12 thn)\n│▣ 🏫 SMA    : Rp 3.000.000 (min 15 thn)\n│▣ 🎓 Kuliah : Rp 10.000.000 (min 18 thn)\n╰──────────❏`)
            }

            const anak = anakList[noAnak - 1]
            const pendidikanSaat = anak.pendidikan || 'belum'

            const urutanJenjang = ['belum', 'sd', 'smp', 'sma', 'kuliah', 'lulus']
            const idxSaat = urutanJenjang.indexOf(pendidikanSaat)
            const jenjangBerikut = urutanJenjang[idxSaat + 1]

            if (!jenjangBerikut || jenjangBerikut === 'lulus') {
                return Reply(`╭─────────────────────❏\n│▣  🎓  PENDIDIKAN ANAK  🎓\n╰─────────────────────❏\n│▣ ${anak.emoji} ${anak.nama} sudah *lulus semua*!\n│▣ Gunakan *.kerjaanak ${noAnak}* agar\n│▣ mereka bisa bekerja & kirim uang 💰\n╰──────────❏`)
            }

            // [FIX] biaya disesuaikan dengan panduan di menu sekolahkan
            const biayaJenjang = { 'sd': 500000, 'smp': 1500000, 'sma': 3000000, 'kuliah': 10000000 }
            const usiaMini = { 'sd': 6, 'smp': 12, 'sma': 15, 'kuliah': 18 }
            const biaya = biayaJenjang[jenjangBerikut]
            const minUsia = usiaMini[jenjangBerikut]

            if (anak.usia < minUsia) return Reply(`❌ ${anak.emoji} *${anak.nama}* belum cukup umur!\nMinimal *${minUsia} tahun* untuk ${getJenjangLabel(jenjangBerikut)}\nUsia sekarang: ${anak.usia} tahun`)
            if ((player.gold || 0) < biaya) return Reply(`❌ Gold tidak cukup!\nBiaya ${getJenjangLabel(jenjangBerikut)}: *${toRupiah(biaya)}*\nGold kamu: ${toRupiah(player.gold || 0)}`)

            player.gold -= biaya
            anak.pendidikan = jenjangBerikut

            // [FIX] Sinkron pendidikan anak ke pasangan berdasarkan nama
            const pasJidSek = resolvePlayerJid(player.pasangan)
            if (pasJidSek && rpgDB.players[pasJidSek]) {
                const pasSek = rpgDB.players[pasJidSek]
                if (pasSek.anak) {
                    const anakPasSek = pasSek.anak.find(a => a.nama === anak.nama)
                    if (anakPasSek) anakPasSek.pendidikan = jenjangBerikut
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  🏫  ANAK DISEKOLAHKAN  🏫\n╰─────────────────────❏\n╭─❏\n│▣ ${anak.emoji} *${anak.nama}* kini bersekolah di:\n│▣ 📚 ${getJenjangLabel(jenjangBerikut)}\n│▣\n│▣ 💸 Biaya: ${toRupiah(biaya)}\n│▣ 💰 Sisa gold: ${toRupiah(player.gold)}\n│▣\n│▣ 💡 Lanjutkan ke jenjang berikutnya\n│▣    dengan *.sekolahkan ${noAnak}* lagi!\n╰──────────❏\nMaju terus pendidikannya! 📖`)
        }

        if (command === 'kerjaanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []

            const noAnak = parseInt(text)
            if (!noAnak || noAnak < 1 || noAnak > anakList.length) return Reply(`❌ Nomor anak tidak valid!\nGunakan: *.kerjaanak [nomor]*`)

            const anak = anakList[noAnak - 1]
            // [FIX] hanya bisa kerja jika sudah 'lulus' (bukan masih 'kuliah')
            if (anak.pendidikan !== 'lulus') return Reply(`❌ ${anak.emoji} *${anak.nama}* belum lulus kuliah!\nSelesaikan semua pendidikan dulu dengan *.sekolahkan ${noAnak}*`)
            if (anak.bekerja) return Reply(`✅ ${anak.emoji} *${anak.nama}* sudah bekerja!\n💰 Penghasilan: ${toRupiah(5000)}/jam`)

            anak.bekerja = true
            anak.lastTransfer = Date.now()
            anak.totalKiriman = 0

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  💼  ANAK MULAI BEKERJA  💼\n╰─────────────────────❏\n╭─❏\n│▣ ${anak.emoji} *${anak.nama}* kini bekerja!\n│▣\n│▣ 💰 Passive income: *${toRupiah(5000)}/jam*\n│▣ 📦 Diterima otomatis setiap command\n│▣\n│▣ 🎓 Bakat: ${getBakatLabel(anak.bakat || 'pejuang')}\n╰──────────❏\nBangga punya anak sukses! 🥹`)
        }

        if (command === 'rapotanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu belum punya anak!`)

            const detail = anakList.map((a, i) => {
                const jenjang = a.pendidikan || 'belum'
                const statusKerja = a.bekerja ? `✅ Bekerja (${toRupiah(a.totalKiriman || 0)} total)` : '❌ Belum kerja'
                const bakatText = a.bakat ? getBakatLabel(a.bakat) : '❓ Belum diketahui'
                return `│▣ ─── Anak ke-${i+1}: ${a.emoji} ${a.nama} ───\n│▣ 🎂 Usia   : ${a.usia} tahun\n│▣ 📚 Sekolah: ${getJenjangLabel(jenjang)}\n│▣ 💼 Kerja  : ${statusKerja}\n│▣ 🌟 Bakat  : ${bakatText}`
            }).join('\n')

            return Reply(`╭─────────────────────❏\n│▣  📋  RAPOT ANAK  📋\n╰─────────────────────❏\n╭─❏\n${detail}\n│▣ ──────────────────\n│▣ *.sekolahkan [no]* — Sekolahkan anak\n│▣ *.kerjaanak [no]* — Anak mulai kerja\n╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: RUMAH KELUARGA
// ═══════════════════════════════════════════════════════════

        if (command === 'belirumahtinggal') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Harus menikah dulu untuk beli rumah keluarga!`)

            const hargaRumah = {
                'kontrakan':   500000,
                'rumah_biasa': 15000000,
                'rumah_mewah': 150000000,
                'villa':       500000000,
                'istana':      5000000000
            }

            const tier = text ? text.trim().toLowerCase().replace(' ', '_') : null

            if (!tier || !hargaRumah[tier]) {
                const daftar = Object.entries(hargaRumah).map(([t, h]) => `│▣ *${t}* — ${toRupiah(h)}\n│▣   └ ${getRumahBonus(t)}`).join('\n')
                const rumahSaat = player.rumahKeluarga ? `│▣ 🏠 Rumah sekarang: *${getRumahLabel(player.rumahKeluarga.tier)}*\n│▣ ──────────────────\n` : ''
                return Reply(`╭─────────────────────❏\n│▣  🏠  BELI RUMAH KELUARGA  🏠\n╰─────────────────────❏\n╭─❏\n${rumahSaat}${daftar}\n│▣ ──────────────────\n│▣ Contoh: *.belirumahtinggal rumah_biasa*\n╰──────────❏`)
            }

            const hargaBeli = hargaRumah[tier]
            if ((player.gold || 0) < hargaBeli) return Reply(`❌ Gold tidak cukup!\nHarga: *${toRupiah(hargaBeli)}*\nGold kamu: ${toRupiah(player.gold || 0)}`)

            const urutanTier = ['kontrakan', 'rumah_biasa', 'rumah_mewah', 'villa', 'istana']
            const idxBaru = urutanTier.indexOf(tier)
            const idxSaat = player.rumahKeluarga ? urutanTier.indexOf(player.rumahKeluarga.tier) : -1
            if (idxBaru <= idxSaat) return Reply(`❌ Kamu sudah punya rumah yang lebih baik!\nRumah sekarang: *${getRumahLabel(player.rumahKeluarga.tier)}*`)

            player.gold -= hargaBeli
            player.rumahKeluarga = {
                tier,
                beli: new Date().toLocaleDateString('id-ID'),
                renovasi: player.rumahKeluarga?.renovasi || []
            }

            // [FIX] Sinkron rumah ke pasangan
            const pasJidRumah = resolvePlayerJid(player.pasangan)
            if (pasJidRumah && rpgDB.players[pasJidRumah]) {
                rpgDB.players[pasJidRumah].rumahKeluarga = { ...player.rumahKeluarga }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  🏠  RUMAH BARU!  🏠\n╰─────────────────────❏\n╭─❏\n│▣ 🎉 Selamat! Kamu punya rumah baru!\n│▣ 🏠 Tipe  : *${getRumahLabel(tier)}*\n│▣ 💰 Harga : ${toRupiah(hargaBeli)}\n│▣ 💰 Sisa  : ${toRupiah(player.gold)}\n│▣\n│▣ ✨ Bonus aktif:\n│▣ ${getRumahBonus(tier)}\n│▣\n│▣ 🔨 Tambah renovasi:\n│▣ *.renovasirumah [tipe]*\n╰──────────❏`)
        }

        if (command === 'renovasirumah') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.rumahKeluarga) return Reply(`❌ Kamu belum punya rumah keluarga!\nBeli dulu dengan *.belirumahtinggal*`)

            const opsiRenovasi = {
                'dapur':        { biaya: 3000000,  desc: '🍳 Dapur — Unlock fitur *.masak*' },
                'taman':        { biaya: 5000000,  desc: '🌸 Taman — Keharmonisan +5/hari' },
                'kamar_anak':   { biaya: 7000000,  desc: '🛏️ Kamar Anak — Recovery kesehatan anak lebih cepat' },
                'gym':          { biaya: 12000000, desc: '💪 Gym — ATK +2 permanen (1x saja)' },
                'kolam_renang': { biaya: 25000000, desc: '🏊 Kolam Renang — HP regen +10/jam' }
            }

            const tipe = text ? text.trim().toLowerCase().replace(' ', '_') : null
            const renovasiSudah = player.rumahKeluarga.renovasi || []

            if (!tipe || !opsiRenovasi[tipe]) {
                const daftar = Object.entries(opsiRenovasi).map(([t, r]) => {
                    const sudah = renovasiSudah.includes(t) ? ' ✅' : ''
                    return `│▣ *${t}*${sudah} — ${toRupiah(r.biaya)}\n│▣   └ ${r.desc}`
                }).join('\n')
                return Reply(`╭─────────────────────❏\n│▣  🔨  RENOVASI RUMAH  🔨\n╰─────────────────────❏\n╭─❏\n│▣ 🏠 Rumah: *${getRumahLabel(player.rumahKeluarga.tier)}*\n│▣ ──────────────────\n${daftar}\n│▣ ──────────────────\n│▣ Contoh: *.renovasirumah dapur*\n╰──────────❏`)
            }

            if (renovasiSudah.includes(tipe)) return Reply(`❌ Renovasi *${tipe}* sudah ada!`)

            const { biaya, desc } = opsiRenovasi[tipe]
            if ((player.gold || 0) < biaya) return Reply(`❌ Gold tidak cukup!\nBiaya: *${toRupiah(biaya)}*\nGold kamu: ${toRupiah(player.gold || 0)}`)

            player.gold -= biaya
            player.rumahKeluarga.renovasi = [...renovasiSudah, tipe]

            if (tipe === 'gym') player.attack = (player.attack || 10) + 2

            // [FIX] Sinkron renovasi rumah ke pasangan
            const pasJidRenovasi = resolvePlayerJid(player.pasangan)
            if (pasJidRenovasi && rpgDB.players[pasJidRenovasi]) {
                const pasRenovasi = rpgDB.players[pasJidRenovasi]
                if (pasRenovasi.rumahKeluarga) {
                    pasRenovasi.rumahKeluarga.renovasi = [...player.rumahKeluarga.renovasi]
                } else {
                    pasRenovasi.rumahKeluarga = { ...player.rumahKeluarga }
                }
                // Sinkron bonus gym ke pasangan juga
                if (tipe === 'gym') pasRenovasi.attack = (pasRenovasi.attack || 10) + 2
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  🔨  RENOVASI BERHASIL  🔨\n╰─────────────────────❏\n╭─❏\n│▣ ✅ ${desc} selesai!\n│▣\n│▣ 💸 Biaya: ${toRupiah(biaya)}\n│▣ 💰 Sisa gold: ${toRupiah(player.gold)}\n╰──────────❏`)
        }

        if (command === 'inforumah') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.rumahKeluarga) return Reply(`╭─────────────────────❏\n│▣  🏚️  INFO RUMAH  🏚️\n╰─────────────────────❏\n│▣ ❌ Kamu belum punya rumah keluarga.\n│▣ Beli dengan *.belirumahtinggal*\n╰──────────❏`)

            const rumah = player.rumahKeluarga
            const renovasiList = (rumah.renovasi || []).map(r => `│▣   ✅ ${r}`).join('\n') || '│▣   — Belum ada renovasi'

            return Reply(`╭─────────────────────❏\n│▣  🏠  INFO RUMAH KELUARGA  🏠\n╰─────────────────────❏\n╭─❏\n│▣ 🏠 Tipe   : *${getRumahLabel(rumah.tier)}*\n│▣ 📅 Dibeli : ${rumah.beli || '-'}\n│▣\n│▣ ✨ Bonus Aktif:\n│▣   ${getRumahBonus(rumah.tier)}\n│▣\n│▣ 🔨 Renovasi:\n${renovasiList}\n│▣\n│▣ *.renovasirumah* — tambah renovasi\n│▣ *.belirumahtinggal* — upgrade rumah\n╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: MAKAN BERSAMA
// ═══════════════════════════════════════════════════════════

        if (command === 'makanbersama') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const anakList = player.anak || []
            const totalAnggota = 2 + anakList.length
            const BIAYA_PER_ORANG = 300000
            const BIAYA_TOTAL = BIAYA_PER_ORANG * totalAnggota
            const CD_MAKAN = 8 * 60 * 60 * 1000
            const now = Date.now()

            if ((player.gold || 0) < BIAYA_TOTAL) return Reply(`❌ Gold tidak cukup!\nBiaya makan ${totalAnggota} orang: *${toRupiah(BIAYA_TOTAL)}*\nGold kamu: ${toRupiah(player.gold || 0)}`)

            if (player.lastMakanBersama && now - player.lastMakanBersama < CD_MAKAN) {
                return Reply(`⏳ Baru saja makan bersama!\nBisa lagi dalam: *${msToTime(CD_MAKAN - (now - player.lastMakanBersama))}*`)
            }

            const punyaDapur = player.rumahKeluarga?.renovasi?.includes('dapur')
            const bonusHarmoni = punyaDapur ? 15 : 10
            const bonusKesehatanAnak = punyaDapur ? 20 : 15

            player.gold -= BIAYA_TOTAL
            player.lastMakanBersama = now
            player.harmoni = Math.min(100, (player.harmoni || 50) + bonusHarmoni)

            anakList.forEach(a => {
                a.kesehatan = Math.min(100, (a.kesehatan || 50) + bonusKesehatanAnak)
                a.makanan = Math.min(100, (a.makanan || 0) + 20)
            })

            // [FIX] Sinkron ke pasangan (harmoni, anak, cooldown)
            const pasJidMakan = resolvePlayerJid(player.pasangan)
            if (pasJidMakan && rpgDB.players[pasJidMakan]) {
                const pasMakan = rpgDB.players[pasJidMakan]
                pasMakan.harmoni = Math.min(100, (pasMakan.harmoni || 50) + bonusHarmoni)
                pasMakan.lastMakanBersama = now
                if (pasMakan.anak) {
                    pasMakan.anak.forEach(pa => {
                        const sync = anakList.find(a => a.nama === pa.nama)
                        if (sync) {
                            pa.kesehatan = sync.kesehatan
                            pa.makanan = sync.makanan
                        }
                    })
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const dapurBonus = punyaDapur ? '\n│▣ 🍳 Bonus Dapur: +5 extra semua!' : ''

            return Reply(`╭─────────────────────❏\n│▣  🍽️  MAKAN BERSAMA  🍽️\n╰─────────────────────❏\n╭─❏\n│▣ 👨‍👩‍👧 Keluarga makan bersama!\n│▣ ${totalAnggota} orang duduk di meja makan~\n│▣${dapurBonus}\n│▣\n│▣ 💞 Keharmonisan : +${bonusHarmoni}\n│▣ ${getHarmoniBar(player.harmoni)}\n│▣ ❤️ Kesehatan anak: +${bonusKesehatanAnak}\n│▣ 🍱 Makanan anak  : +20\n│▣\n│▣ 💸 Biaya: ${toRupiah(BIAYA_TOTAL)}\n│▣ ⏳ CD: 8 jam\n╰──────────❏\nHangat banget! 🥰`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: LIBURAN KELUARGA
// ═══════════════════════════════════════════════════════════

        if (command === 'liburankeluarga') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const destinasi = {
                'pantai':      { biaya: 3000000,  harmoni: 25, desc: '🏖️ Pantai — ombak & pasir putih', anakBonus: 20 },
                'gunung':      { biaya: 2000000,  harmoni: 20, desc: '🏔️ Gunung — udara sejuk & pemandangan', anakBonus: 15 },
                'kota':        { biaya: 5000000,  harmoni: 22, desc: '🏙️ Kota Besar — belanja & wisata kuliner', anakBonus: 18 },
                'luar_negeri': { biaya: 15000000, harmoni: 35, desc: '✈️ Luar Negeri — pengalaman internasional!', anakBonus: 30 },
                'alam_dewa':   { biaya: 100000000, harmoni: 50, desc: '✨ Alam Para Dewa — liburan mewah epic!', anakBonus: 50 }
            }

            const tujuan = text ? text.trim().toLowerCase().replace(' ', '_') : null
            const CD_LIBURAN = 7 * 24 * 60 * 60 * 1000
            const now = Date.now()

            if (!tujuan || !destinasi[tujuan]) {
                const daftar = Object.entries(destinasi).map(([t, d]) => `│▣ *${t}* — ${toRupiah(d.biaya)}\n│▣   └ ${d.desc}`).join('\n')
                return Reply(`╭─────────────────────❏\n│▣  ✈️  LIBURAN KELUARGA  ✈️\n╰─────────────────────❏\n╭─❏\n${daftar}\n│▣ ──────────────────\n│▣ Contoh: *.liburankeluarga pantai*\n│▣ ⏳ Cooldown: 7 hari\n╰──────────❏`)
            }

            if (player.lastLiburan && now - player.lastLiburan < CD_LIBURAN) {
                return Reply(`⏳ Keluarga masih butuh istirahat!\nLiburan berikutnya: *${msToTime(CD_LIBURAN - (now - player.lastLiburan))}*`)
            }

            const { biaya, harmoni, desc, anakBonus } = destinasi[tujuan]
            if ((player.gold || 0) < biaya) return Reply(`❌ Gold tidak cukup!\nBiaya liburan: *${toRupiah(biaya)}*\nGold kamu: ${toRupiah(player.gold || 0)}`)

            player.gold -= biaya
            player.lastLiburan = now
            player.harmoni = Math.min(100, (player.harmoni || 50) + harmoni)
            player.totalLiburan = (player.totalLiburan || 0) + 1

            const anakList = player.anak || []
            anakList.forEach(a => {
                a.kesehatan = Math.min(100, (a.kesehatan || 50) + anakBonus)
                a.makanan = Math.min(100, (a.makanan || 0) + 25)
            })

            const pasangan = rpgDB.players[resolvePlayerJid(player.pasangan)]
            if (pasangan) {
                pasangan.harmoni = Math.min(100, (pasangan.harmoni || 50) + harmoni)
                pasangan.lastLiburan = now
                // [FIX] Sinkron anak ke pasangan
                if (pasangan.anak) {
                    pasangan.anak.forEach(pa => {
                        const sync = anakList.find(a => a.nama === pa.nama)
                        if (sync) {
                            pa.kesehatan = sync.kesehatan
                            pa.makanan = sync.makanan
                        }
                    })
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const anakText = anakList.length > 0 ? `\n│▣ 👶 Anak bahagia    : +${anakBonus} kesehatan` : ''

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  ✈️  LIBURAN KELUARGA!  ✈️\n╰─────────────────────❏\n╭─❏\n│▣ 👨‍👩‍👧 @${senderJid.split('@')[0]} & keluarga\n│▣    liburan ke ${desc}!\n│▣\n│▣ 💞 Keharmonisan: +${harmoni}\n│▣ ${getHarmoniBar(player.harmoni)}${anakText}\n│▣\n│▣ 💸 Biaya  : ${toRupiah(biaya)}\n│▣ 💰 Sisa   : ${toRupiah(player.gold)}\n│▣ ⏳ CD     : 7 hari\n╰──────────❏\nMomen terbaik bersama keluarga! 📸`,
                mentions: [senderJid, player.pasangan]
            }, { quoted: m })
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: FOTO BERSAMA
// ═══════════════════════════════════════════════════════════

        if (command === 'fotobersama') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const CD_FOTO = 4 * 60 * 60 * 1000
            const now = Date.now()
            if (player.lastFoto && now - player.lastFoto < CD_FOTO) {
                return Reply(`⏳ Baru foto! Tunggu dulu...\nBisa foto lagi dalam: *${msToTime(CD_FOTO - (now - player.lastFoto))}*`)
            }

            const BIAYA_FOTO = 500000
            if ((player.gold || 0) < BIAYA_FOTO) return Reply(`❌ Butuh ${toRupiah(BIAYA_FOTO)} untuk sewa fotografer!`)

            player.gold -= BIAYA_FOTO
            player.lastFoto = now
            player.harmoni = Math.min(100, (player.harmoni || 50) + 5)
            player.totalFoto = (player.totalFoto || 0) + 1

            // [FIX] Sinkron harmoni & cooldown foto ke pasangan
            const pasJidFoto = resolvePlayerJid(player.pasangan)
            if (pasJidFoto && rpgDB.players[pasJidFoto]) {
                const pasFoto = rpgDB.players[pasJidFoto]
                pasFoto.harmoni = Math.min(100, (pasFoto.harmoni || 50) + 5)
                pasFoto.lastFoto = now
            }

            const anakList = player.anak || []
            const anakStr = anakList.length > 0
                ? anakList.map(a => `${a.emoji} ${a.nama}`).join(', ')
                : '(belum punya anak)'

            const lokasiFoto = ['🏡 Di rumah', '🌸 Di taman', '🏖️ Di pantai', '🌄 Di pegunungan', '🌙 Saat sunset'][Math.floor(Math.random() * 5)]

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  📸  FOTO KELUARGA  📸\n╰─────────────────────❏\n╭─❏\n│▣ ${lokasiFoto}\n│▣\n│▣ 📷 *ALBUM KELUARGA #${player.totalFoto}*\n│▣ ───────────────────\n│▣ 👨 Ayah/Ibu : @${senderJid.split('@')[0]}\n│▣ 💑 Pasangan : ${player.pasanganNama}\n│▣ 👶 Anak     : ${anakStr}\n│▣ ───────────────────\n│▣ 📅 ${new Date().toLocaleDateString('id-ID')}\n│▣\n│▣ 💞 Keharmonisan: +5\n│▣ ${getHarmoniBar(player.harmoni)}\n╰──────────❏\nKenangan indah keluarga! 🥰`,
                mentions: [senderJid, player.pasangan]
            }, { quoted: m })
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: KADO ANAK
// ═══════════════════════════════════════════════════════════

        if (command === 'kadoanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const argKado = text ? text.trim().split(' ') : []
            const noAnak = parseInt(argKado[0])
            const jumlahKado = parseInt(argKado[1])

            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu belum punya anak!`)

            if (!noAnak || noAnak < 1 || noAnak > anakList.length || !jumlahKado || jumlahKado < 50000) {
                return Reply(`╭─────────────────────❏\n│▣  🎁  KADO ANAK  🎁\n╰─────────────────────❏\n│▣ Berikan kado untuk anak!\n│▣\n│▣ Format: *.kadoanak [no] [jumlah]*\n│▣ Contoh: *.kadoanak 1 100000*\n│▣\n│▣ Min kado: Rp 50.000\n│▣ Efek: kesehatan anak +10 s/d +50\n│▣        keharmonisan +3\n╰──────────❏`)
            }

            if ((player.gold || 0) < jumlahKado) return Reply(`❌ Gold tidak cukup!\nGold kamu: ${toRupiah(player.gold || 0)}`)

            const anak = anakList[noAnak - 1]
            player.gold -= jumlahKado

            let bonusKesehatan = 10
            if (jumlahKado >= 1000000) bonusKesehatan = 50
            else if (jumlahKado >= 500000) bonusKesehatan = 40
            else if (jumlahKado >= 200000) bonusKesehatan = 30
            else if (jumlahKado >= 100000) bonusKesehatan = 20

            anak.kesehatan = Math.min(100, (anak.kesehatan || 50) + bonusKesehatan)
            player.harmoni = Math.min(100, (player.harmoni || 50) + 3)

            // [FIX] Sinkron kesehatan anak & harmoni ke pasangan
            const pasJidKado = resolvePlayerJid(player.pasangan)
            if (pasJidKado && rpgDB.players[pasJidKado]) {
                const pasKado = rpgDB.players[pasJidKado]
                pasKado.harmoni = Math.min(100, (pasKado.harmoni || 50) + 3)
                if (pasKado.anak) {
                    const anakPasKado = pasKado.anak.find(a => a.nama === anak.nama)
                    if (anakPasKado) anakPasKado.kesehatan = anak.kesehatan
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  🎁  KADO UNTUK ANAK  🎁\n╰─────────────────────❏\n╭─❏\n│▣ 🎀 Kado untuk ${anak.emoji} *${anak.nama}*!\n│▣\n│▣ 💝 Jumlah kado : ${toRupiah(jumlahKado)}\n│▣ ❤️ Kesehatan   : +${bonusKesehatan}\n│▣ 💞 Keharmonisan: +3\n│▣\n│▣ ${anak.emoji} "${anak.nama} senang banget!"\n╰──────────❏\nOrang tua terbaik! 🥹`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: EVENT RANDOM KRISIS KELUARGA
// ═══════════════════════════════════════════════════════════

        if (command === 'cekevent') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            if (!player.pasangan) return Reply(`❌ Kamu belum menikah!`)

            const now = Date.now()
            const CD_EVENT = 6 * 60 * 60 * 1000
            if (player.lastCekEvent && now - player.lastCekEvent < CD_EVENT) {
                return Reply(`⏳ Tidak ada event baru.\nCek lagi dalam: *${msToTime(CD_EVENT - (now - player.lastCekEvent))}*`)
            }

            player.lastCekEvent = now
            const harmoni = player.harmoni || 50
            const anakList = player.anak || []

            let eventMsg = '✅ Tidak ada event. Keluarga aman!'

            const anakSakit = anakList.find(a => (a.makanan || 0) < 20)
            if (anakSakit && Math.random() < 0.4) {
                const BIAYA_OBAT = 2000000
                if ((player.gold || 0) >= BIAYA_OBAT) {
                    player.gold -= BIAYA_OBAT
                    anakSakit.kesehatan = Math.max(10, (anakSakit.kesehatan || 50) - 20)
                    eventMsg = `🤒 *ANAK SAKIT!*\n│▣ ${anakSakit.emoji} *${anakSakit.nama}* sakit keras!\n│▣ Makanan habis, daya tahan turun...\n│▣\n│▣ 💊 Biaya obat: ${toRupiah(BIAYA_OBAT)}\n│▣ ❤️ Kesehatan: -20\n│▣\n│▣ Segera beli makanan: *.belimakanan*`
                } else {
                    anakSakit.kesehatan = Math.max(5, (anakSakit.kesehatan || 50) - 30)
                    eventMsg = `🤒 *ANAK SAKIT PARAH!*\n│▣ ${anakSakit.emoji} *${anakSakit.nama}* sangat sakit!\n│▣ Kamu tidak punya gold untuk obat!\n│▣ ❤️ Kesehatan anak: -30`
                }
            } else if (harmoni < 35 && Math.random() < 0.5) {
                eventMsg = `💔 *PASANGAN MENGELUH!*\n│▣ ${player.pasanganNama} merasa tidak diperhatikan!\n│▣ Keharmonisan sangat rendah (${harmoni}/100)\n│▣\n│▣ ⚠️ Kalau tidak ditangani:\n│▣   Keharmonisan -5 tiap hari!\n│▣\n│▣ 💡 Solusi: *.kencan* atau *.makanbersama*`
                player.harmoni = Math.max(0, harmoni - 5)
            } else if (player.rumahKeluarga &&
                     ['rumah_mewah', 'villa', 'istana'].includes(player.rumahKeluarga.tier) &&
                     Math.random() < 0.25) {
                const tagihanMap = { 'rumah_mewah': 2000000, 'villa': 7500000, 'istana': 25000000 }
                const tagihan = tagihanMap[player.rumahKeluarga.tier]
                if ((player.gold || 0) >= tagihan) {
                    player.gold -= tagihan
                    eventMsg = `🏠 *TAGIHAN BULANAN RUMAH*\n│▣ Tagihan maintenance ${getRumahLabel(player.rumahKeluarga.tier)}!\n│▣ 💸 Dibayar: ${toRupiah(tagihan)}\n│▣ 💰 Sisa: ${toRupiah(player.gold)}`
                } else {
                    player.harmoni = Math.max(0, harmoni - 10)
                    eventMsg = `🏠 *TAGIHAN TIDAK TERBAYAR!*\n│▣ Tagihan ${getRumahLabel(player.rumahKeluarga.tier)} tidak terbayar!\n│▣ 💔 Keharmonisan -10\n│▣ Segera cari gold!`
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  ⚡  EVENT KELUARGA  ⚡\n╰─────────────────────❏\n╭─❏\n│▣ ${eventMsg}\n│▣\n│▣ ⏳ Cek event berikutnya: 6 jam\n╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: STATISTIK KELUARGA
// ═══════════════════════════════════════════════════════════

        if (command === 'statkeluarga') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]

            tickKeluarga(player, rpgDB)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

            const statusNikah = player.pasangan
                ? `💒 Menikah dengan ${player.pasanganNama} sejak ${player.tanggalNikah}`
                : '💔 Lajang'

            const anniv = player.pasangan ? hitungAnniversary(player.tanggalNikah) : null
            const annivText = anniv ? `\n│▣ 🎂 Pernikahan : ${anniv.tahun} tahun${anniv.isAnniversary ? ' 🎉 HARI INI!' : ''}` : ''

            const harmoniText = player.pasangan
                ? `\n│▣ ${getHarmoniBar(player.harmoni || 50)}`
                : ''

            const anakList = player.anak || []
            const anakSummary = anakList.length === 0
                ? '│▣ 👶 Belum punya anak'
                : anakList.map((a, i) => {
                    const jenjang = a.pendidikan ? getJenjangLabel(a.pendidikan) : 'Belum sekolah'
                    const kerja = a.bekerja ? ` 💼 ${toRupiah(a.totalKiriman || 0)} total` : ''
                    return `│▣ ${i+1}. ${a.emoji} ${a.nama} | ${a.usia} thn | ${jenjang}${kerja}`
                }).join('\n')

            const rumahText = player.rumahKeluarga
                ? `│▣ 🏠 ${getRumahLabel(player.rumahKeluarga.tier)}\n│▣   Renovasi: ${(player.rumahKeluarga.renovasi || []).join(', ') || '-'}`
                : '│▣ 🏚️ Belum punya rumah keluarga'

            return yonz.sendMessage(m.chat, {
                text: `╭─────────────────────❏\n│▣  👨‍👩‍👧  STATISTIK KELUARGA  👨‍👩‍👧\n╰─────────────────────❏\n╭─❏\n│▣ 💑 Status: ${statusNikah}${annivText}${harmoniText}\n│▣ ──────────────────\n│▣ 👶 ANAK (${anakList.length}):\n${anakSummary}\n│▣ ──────────────────\n│▣ 🏠 RUMAH:\n${rumahText}\n│▣ ──────────────────\n│▣ 📊 STATISTIK:\n│▣ 💵 Total nafkah   : ${toRupiah(player.totalNafkah || 0)}\n│▣ ✈️ Total liburan  : ${player.totalLiburan || 0}x\n│▣ 📸 Total foto     : ${player.totalFoto || 0}x\n│▣ 💑 Kencan         : ${player.totalKencan || 0}x\n│▣ 🚨 Kena selingkuh : ${player.kenaSelingkuh || 0}x\n╰──────────❏`,
                mentions: player.pasangan ? [senderJid, player.pasangan] : [senderJid]
            }, { quoted: m })
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: HELP LENGKAP
// ═══════════════════════════════════════════════════════════

        if (command === 'lifehelp') {
            return Reply(`╭─────────────────────❏
│▣  💒  LIFE SIMULATOR LENGKAP  💒
╰─────────────────────❏
╭─❏
│▣ 💍 *PERNIKAHAN*
│▣ *.lamar @user*      — Lamar (Rp 500rb)
│▣ *.terima / .tolak*  — Jawab lamaran
│▣ *.cerai*            — Cerai (Rp 1jt)
│▣ *.infopasangan*     — Status keluarga
│▣ ──────────────────
│▣ 💞 *KEHARMONISAN*
│▣ *.harmoni*          — Cek keharmonisan
│▣ *.kencan*           — Kencan (Rp 200rb, CD:12j)
│▣ *.kadoanniversary*  — Kado anniversary (Rp 500rb)
│▣ *.selingkuh @user*  — ⚠️ Selingkuh (30% ketahuan)
│▣ *.cekselingkuh*     — Investigasi pasangan (Rp 100rb)
│▣ ──────────────────
│▣ 👶 *ANAK*
│▣ *.buatanak*         — Punya anak baru
│▣ *.rawatanak [no]*   — Rawat anak (CD:4j)
│▣ *.infoanak*         — Detail semua anak
│▣ *.kadoanak [no] [jml]* — Kado untuk anak
│▣ ──────────────────
│▣ 🏫 *PENDIDIKAN ANAK*
│▣ *.sekolahkan [no]*  — Sekolahkan anak
│▣ *.kerjaanak [no]*   — Anak mulai bekerja
│▣ *.rapotanak*        — Lihat progress pendidikan
│▣ ──────────────────
│▣ 🏠 *RUMAH KELUARGA*
│▣ *.belirumahtinggal [tier]* — Beli rumah
│▣ *.renovasirumah [tipe]*    — Renovasi rumah
│▣ *.inforumah*               — Info rumah & bonus
│▣ ──────────────────
│▣ 🍽️ *AKTIVITAS KELUARGA*
│▣ *.makanbersama*      — Makan keluarga (CD:8j)
│▣ *.liburankeluarga [tujuan]* — Liburan (CD:7h)
│▣ *.fotobersama*       — Foto keluarga (CD:4j)
│▣ ──────────────────
│▣ 🍱 *NAFKAH & MAKANAN*
│▣ *.belimakanan [jml]* — Beli makanan anak
│▣ *.nafkah [jml]*      — Kasih nafkah keluarga
│▣ ──────────────────
│▣ ⚡ *LAINNYA*
│▣ *.cekevent*         — Cek event random keluarga
│▣ *.statkeluarga*     — Statistik lengkap keluarga
│▣ *.topkeluarga*      — 🏆 Ranking keluarga terbaik
│▣ *.simulatorhelp*    — Panduan simulator
│▣ *.hargasimulator*   — Daftar semua harga 💰
│▣ ──────────────────
│▣ 🏛️ *PANTI ASUHAN*
│▣ *.buanganak [no]*   — Buang anak ke panti
│▣ *.hapusanak [no]*   — Hapus anak permanen
│▣ *.pantiasuhan*      — Lihat anak di panti
│▣ *.pantiasuhan [no]* — Adopsi anak (Rp 3jt)
│▣ *.resetpanti [alasan]* — 🔧 Reset panti (admin)
╰──────────❏`)
        }


// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: BUANG ANAK (kirim ke panti asuhan)
// ═══════════════════════════════════════════════════════════

        if (command === 'buanganak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu tidak punya anak!`)

            const idx = args[0] ? parseInt(args[0]) - 1 : -1
            if (isNaN(idx + 1) || idx < 0 || idx >= anakList.length) {
                const daftar = anakList.map((a, i) => `│▣ ${i+1}. ${a.emoji} *${a.nama}* — usia ${a.usia} thn`).join('\n')
                return Reply(`╭─────────────────────❏\n│▣  👶  PILIH ANAK  👶\n╰─────────────────────❏\n╭─❏\n${daftar}\n╰──────────❏\n\nGunakan: *.buanganak [nomor]*\nContoh: *.buanganak 1*`)
            }

            const anak = anakList[idx]

            let pantiDB = { anak: [] }
            try { pantiDB = JSON.parse(fs.readFileSync(pantiDBPath)) } catch(e) {}
            if (!pantiDB.anak) pantiDB.anak = []

            const BIAYA_BUANG = 1000000
            if ((player.gold || 0) < BIAYA_BUANG) return Reply(`❌ Butuh *${toRupiah(BIAYA_BUANG)}* untuk biaya administrasi panti asuhan!`)

            const anakPanti = {
                ...anak,
                id: Date.now() + '_' + Math.random().toString(36).substr(2, 6),
                orangTuaJid: senderJid,
                orangTuaNama: '@' + senderJid.split('@')[0],
                pasanganJid: player.pasangan || null,
                tanggalBuang: new Date().toLocaleDateString('id-ID'),
                sudahDiadopsi: false
            }
            pantiDB.anak.push(anakPanti)
            fs.writeFileSync(pantiDBPath, JSON.stringify(pantiDB, null, 2))

            player.gold -= BIAYA_BUANG
            player.anak = anakList.filter((_, i) => i !== idx)
            player.harmoni = Math.max(0, (player.harmoni || 50) - 20)

            if (player.pasangan) {
                const pasanganJid = resolvePlayerJid(player.pasangan)
                const pasangan = rpgDB.players[pasanganJid]
                if (pasangan && pasangan.anak) {
                    pasangan.anak = pasangan.anak.filter(a => a.nama !== anak.nama || a.lahir !== anak.lahir)
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏\n│▣  😢  ANAK DIKIRIM KE PANTI  😢\n╰─────────────────────❏\n╭─❏\n│▣ ${anak.emoji} *${anak.nama}* (usia ${anak.usia} thn)\n│▣    telah dikirim ke panti asuhan.\n│▣\n│▣ 💸 Biaya administrasi: *${toRupiah(BIAYA_BUANG)}*\n│▣ 💔 Keharmonisan: -20\n│▣ 👶 Sisa anak kamu: ${player.anak.length}\n│▣\n│▣ 📌 Anak bisa diadopsi player lain\n│▣    dengan command *.pantiasuhan*\n╰──────────❏\n_Semoga ${anak.nama} mendapat orang tua yang baik... 🙏_`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: HAPUS ANAK (permanen, tidak ke panti)
// ═══════════════════════════════════════════════════════════

        if (command === 'hapusanak') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)
            const player = rpgDB.players[senderJid]
            const anakList = player.anak || []
            if (anakList.length === 0) return Reply(`❌ Kamu tidak punya anak!`)

            const idx = args[0] ? parseInt(args[0]) - 1 : -1
            if (isNaN(idx + 1) || idx < 0 || idx >= anakList.length) {
                const daftar = anakList.map((a, i) => `│▣ ${i+1}. ${a.emoji} *${a.nama}* — usia ${a.usia} thn`).join('\n')
                return Reply(`╭─────────────────────❏\n│▣  👶  PILIH ANAK YANG DIHAPUS  👶\n╰─────────────────────❏\n╭─❏\n${daftar}\n╰──────────❏\n\n⚠️ Hapus anak bersifat *PERMANEN* dan tidak masuk panti!\nGunakan: *.hapusanak [nomor]*\nContoh: *.hapusanak 1*`)
            }

            const anak = anakList[idx]
            const anakKey = anak.nama + '_' + (anak.lahir || '')

            if (!args[1] || args[1].toLowerCase() !== 'ya') {
                return Reply(`╭─────────────────────❏\n│▣  ⚠️  KONFIRMASI HAPUS  ⚠️\n╰─────────────────────❏\n╭─❏\n│▣ Kamu yakin ingin menghapus:\n│▣ ${anak.emoji} *${anak.nama}* (usia ${anak.usia} thn)?\n│▣\n│▣ ⚠️ Data anak akan *DIHAPUS PERMANEN*\n│▣    dan tidak bisa dikembalikan!\n│▣\n│▣ Ketik: *.hapusanak ${idx + 1} ya*\n│▣    untuk konfirmasi.\n╰──────────❏`)
            }

            // Hapus dari data player sendiri
            player.anak = anakList.filter((_, i) => i !== idx)

            // Hapus dari data pasangan (gunakan key nama+lahir agar akurat)
            if (player.pasangan) {
                const pasanganJid = resolvePlayerJid(player.pasangan)
                const pasangan = rpgDB.players[pasanganJid]
                if (pasangan && Array.isArray(pasangan.anak)) {
                    pasangan.anak = pasangan.anak.filter(a => {
                        const key = a.nama + '_' + (a.lahir || '')
                        return key !== anakKey
                    })
                }
            }

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏\n│▣  🗑️  ANAK DIHAPUS  🗑️\n╰─────────────────────❏\n╭─❏\n│▣ ${anak.emoji} *${anak.nama}* telah dihapus\n│▣    dari data keluarga.\n│▣\n│▣ 👶 Sisa anak: ${player.anak.length}\n│▣ 📌 Kamu dan pasangan sekarang\n│▣    bisa membuat anak baru!\n╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  ADMIN: RESET PANTI ASUHAN
// ═══════════════════════════════════════════════════════════

        if (command === 'resetpanti') {
            // Cek apakah pengirim adalah owner/admin bot
            const isOwner = m.fromMe || (global.owner && global.owner.includes(senderJid.split('@')[0]))
            if (!isOwner) return Reply(`❌ Command ini hanya bisa digunakan oleh *owner/admin bot*!`)

            let pantiDB = { anak: [] }
            try { pantiDB = JSON.parse(fs.readFileSync(pantiDBPath)) } catch(e) {}
            if (!pantiDB.anak) pantiDB.anak = []

            const alasan = args.join(' ') || 'Pemeliharaan sistem panti asuhan'
            const jumlahSebelum = pantiDB.anak.length
            const jumlahTersedia = pantiDB.anak.filter(a => !a.sudahDiadopsi).length
            const jumlahSudahAdopsi = pantiDB.anak.filter(a => a.sudahDiadopsi).length

            if (jumlahSebelum === 0) {
                return Reply(`╭─────────────────────❏\n│▣  🏛️  RESET PANTI  🏛️\n╰─────────────────────❏\n╭─❏\n│▣ ℹ️ Panti asuhan sudah kosong!\n│▣ Tidak ada anak yang perlu direset.\n╰──────────❏`)
            }

            // Reset data panti — kosongkan semua anak
            pantiDB.anak = []
            pantiDB.lastReset = {
                tanggal: new Date().toLocaleDateString('id-ID'),
                waktu: new Date().toLocaleTimeString('id-ID'),
                oleh: '@' + senderJid.split('@')[0],
                alasan: alasan,
                jumlahDireset: jumlahSebelum
            }

            fs.writeFileSync(pantiDBPath, JSON.stringify(pantiDB, null, 2))

            return Reply(`╭─────────────────────❏\n│▣  🏛️  RESET PANTI BERHASIL  🏛️\n╰─────────────────────❏\n╭─❏\n│▣ ✅ Data panti asuhan telah direset!\n│▣\n│▣ 📊 *Ringkasan Reset:*\n│▣ ├ Total anak sebelumnya : *${jumlahSebelum}*\n│▣ ├ Belum diadopsi        : *${jumlahTersedia}* anak\n│▣ └ Sudah diadopsi        : *${jumlahSudahAdopsi}* anak\n│▣\n│▣ 📋 *Alasan Reset:*\n│▣ _${alasan}_\n│▣\n│▣ 📅 ${new Date().toLocaleDateString('id-ID')} — ${new Date().toLocaleTimeString('id-ID')}\n│▣ 👤 Oleh: @${senderJid.split('@')[0]}\n│▣\n│▣ ℹ️ Semua anak telah dipindahkan.\n│▣    Panti siap menerima anak baru!\n╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: PANTI ASUHAN — lihat & adopsi anak
// ═══════════════════════════════════════════════════════════

        if (command === 'pantiasuhan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* untuk memulai.`)

            let pantiDB = { anak: [] }
            try { pantiDB = JSON.parse(fs.readFileSync(pantiDBPath)) } catch(e) {}
            if (!pantiDB.anak) pantiDB.anak = []

            const tersedia = pantiDB.anak.filter(a => !a.sudahDiadopsi)

            // Jika ada argumen nomor → proses adopsi
            if (args[0] && !isNaN(parseInt(args[0]))) {
                const noAdopsi = parseInt(args[0]) - 1
                if (noAdopsi < 0 || noAdopsi >= tersedia.length) {
                    return Reply(`❌ Nomor anak tidak valid! Ketik *.pantiasuhan* untuk lihat daftar.`)
                }

                const anakAdopsi = tersedia[noAdopsi]
                const player = rpgDB.players[senderJid]

                if (anakAdopsi.orangTuaJid === senderJid || anakAdopsi.pasanganJid === senderJid) {
                    return Reply(`❌ Kamu tidak bisa mengadopsi anakmu sendiri!`)
                }

                const BIAYA_ADOPSI = 3000000
                if ((player.gold || 0) < BIAYA_ADOPSI) {
                    return Reply(`❌ Biaya adopsi: *${toRupiah(BIAYA_ADOPSI)}*. Gold kamu tidak cukup!`)
                }

                const anakBaru = {
                    nama: anakAdopsi.nama,
                    gender: anakAdopsi.gender,
                    emoji: anakAdopsi.emoji,
                    usia: anakAdopsi.usia,
                    kesehatan: anakAdopsi.kesehatan || 80,
                    lahir: anakAdopsi.lahir,
                    terakhirDirawat: Date.now(),
                    makanan: anakAdopsi.makanan || 60,
                    bakat: anakAdopsi.bakat || randomBakat(),
                    diadopsi: true,
                    orangTuaAsliNama: anakAdopsi.orangTuaNama,
                    pendidikan: anakAdopsi.pendidikan || null,
                    bekerja: anakAdopsi.bekerja || false
                }

                player.gold -= BIAYA_ADOPSI
                player.anak = player.anak || []
                player.anak.push(anakBaru)

                if (player.pasangan) {
                    const pasanganJid = resolvePlayerJid(player.pasangan)
                    const pasangan = rpgDB.players[pasanganJid]
                    if (pasangan) {
                        pasangan.anak = pasangan.anak || []
                        pasangan.anak.push(anakBaru)
                    }
                }

                const idxPanti = pantiDB.anak.findIndex(a => a.id === anakAdopsi.id)
                if (idxPanti !== -1) {
                    pantiDB.anak[idxPanti].sudahDiadopsi = true
                    pantiDB.anak[idxPanti].adopsiOleh = senderJid
                    pantiDB.anak[idxPanti].tanggalAdopsi = new Date().toLocaleDateString('id-ID')
                }

                fs.writeFileSync(pantiDBPath, JSON.stringify(pantiDB, null, 2))
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                return Reply(`╭─────────────────────❏\n│▣  🏠  ADOPSI BERHASIL!  🏠\n╰─────────────────────❏\n╭─❏\n│▣ ${anakBaru.emoji} *${anakBaru.nama}* kini menjadi\n│▣    anakmu secara resmi! 🎉\n│▣\n│▣ 🎂 Usia saat adopsi: *${anakBaru.usia} tahun*\n│▣ ❤️  Kesehatan: *${anakBaru.kesehatan}/100*\n│▣ 🍱 Makanan  : *${anakBaru.makanan}/100*\n│▣ ✨ Bakat    : *${getBakatLabel(anakBaru.bakat)}*\n│▣ 👤 Ortu asli: *${anakBaru.orangTuaAsliNama}*\n│▣\n│▣ 💸 Biaya adopsi: *${toRupiah(BIAYA_ADOPSI)}*\n│▣ ──────────────────\n│▣ 📌 Rawat anakmu agar tumbuh besar!\n│▣ *.rawatanak* — Rawat & tambah usia\n╰──────────❏\n_Selamat datang di keluarga baru, ${anakBaru.nama}! 🥰_`)
            }

            // Tampilkan daftar anak di panti
            if (tersedia.length === 0) {
                return Reply(`╭─────────────────────❏\n│▣  🏛️  PANTI ASUHAN  🏛️\n╰─────────────────────❏\n╭─❏\n│▣ 😊 Saat ini tidak ada anak\n│▣    yang membutuhkan orang tua.\n│▣\n│▣ 📌 Anak akan muncul saat ada\n│▣    player yang pakai *.buanganak*\n╰──────────❏`)
            }

            const daftarAnak = tersedia.map((a, i) => {
                return `│▣ *${i+1}.* ${a.emoji} *${a.nama}*\n│▣    🎂 Usia: ${a.usia} thn  |  ❤️ Sehat: ${a.kesehatan || 80}/100\n│▣    ✨ Bakat: ${getBakatLabel(a.bakat || 'pejuang')}\n│▣    👤 Ortu: ${a.orangTuaNama}\n│▣    📅 Masuk: ${a.tanggalBuang}`
            }).join('\n│▣ ──────────────────\n')

            return Reply(`╭─────────────────────❏\n│▣  🏛️  PANTI ASUHAN  🏛️\n╰─────────────────────❏\n╭─❏\n│▣ 👶 Anak butuh orang tua: *${tersedia.length}*\n│▣ ──────────────────\n${daftarAnak}\n│▣ ──────────────────\n│▣ 💰 Biaya adopsi : *Rp. 200.000*\n│▣ ✅ Bisa adopsi tanpa harus nikah!\n│▣\n│▣ 📌 Untuk adopsi:\n│▣    *.pantiasuhan [nomor]*\n│▣    Contoh: *.pantiasuhan 1*\n╰──────────❏`)
        }

// ═══════════════════════════════════════════════════════════
//  LIFE SIMULATOR: TOP KELUARGA
// ═══════════════════════════════════════════════════════════

        if (command === 'topkeluarga') {
            const semua = Object.entries(rpgDB.players)
            const subCmd = args[0] ? args[0].toLowerCase() : 'harmoni'

            const KATEGORI = {
                'harmoni':  { label: '💞 Keharmonisan Tertinggi', key: p => p.pasangan ? (p.harmoni || 0) : -1, unit: 'harmoni', format: v => v + '/100' },
                'anak':     { label: '👶 Anak Terbanyak',         key: p => (p.anak || []).length, unit: 'anak', format: v => v + ' anak' },
                'nafkah':   { label: '💵 Nafkah Terbesar',        key: p => p.totalNafkah || 0, unit: 'gold', format: v => toRupiah(v) },
                'kencan':   { label: '💑 Kencan Terbanyak',       key: p => p.totalKencan || 0, unit: 'kali', format: v => v + 'x kencan' },
                'kaya':     { label: '🏠 Keluarga Terkaya',       key: p => (p.gold || 0) + (p.bank || 0), unit: 'gold', format: v => toRupiah(v) },
            }

            if (!KATEGORI[subCmd]) {
                return Reply(`╭─────────────────────❏\n│▣  👨‍👩‍👧  TOP KELUARGA  👨‍👩‍👧\n╰─────────────────────❏\n╭─❏\n│▣ Pilih kategori:\n│▣ *.topkeluarga harmoni*  — 💞 Keharmonisan\n│▣ *.topkeluarga anak*     — 👶 Anak terbanyak\n│▣ *.topkeluarga nafkah*   — 💵 Nafkah terbesar\n│▣ *.topkeluarga kencan*   — 💑 Kencan terbanyak\n│▣ *.topkeluarga kaya*     — 🏠 Keluarga terkaya\n╰──────────❏`)
            }

            const kat = KATEGORI[subCmd]

            // Filter & sort
            const ranked = semua
                .map(([jid, p]) => ({ jid, p, score: kat.key(p) }))
                .filter(x => x.score >= 0)
                .sort((a, b) => b.score - a.score)
                .slice(0, 10)

            if (ranked.length === 0) {
                return Reply(`╭─────────────────────❏\n│▣  👨‍👩‍👧  TOP KELUARGA  👨‍👩‍👧\n╰─────────────────────❏\n│▣ ❌ Belum ada data untuk kategori ini!\n╰──────────❏`)
            }

            const MEDAL = ['🥇','🥈','🥉','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟']

            const daftar = ranked.map(({ jid, p, score }, i) => {
                const nama = p.name || ('@' + jid.split('@')[0])
                const pasanganNama = p.pasanganNama ? ` & ${p.pasanganNama}` : ''
                const anakCount = (p.anak || []).length
                const rumah = p.rumahKeluarga ? ` 🏠` : ''
                return `│▣ ${MEDAL[i]} *${nama}*${pasanganNama}${rumah}\n│▣    ${kat.format(score)} | 👶 ${anakCount} anak`
            }).join('\n│▣ ──────────────────\n')

            // Cek posisi pengirim
            const myRank = ranked.findIndex(x => x.jid === senderJid)
            const myText = myRank >= 0
                ? `\n│▣ ──────────────────\n│▣ 📍 Posisimu: *#${myRank + 1}*`
                : `\n│▣ ──────────────────\n│▣ 📍 Kamu belum masuk top 10`

            return Reply(`╭─────────────────────❏\n│▣  👨‍👩‍👧  TOP KELUARGA  👨‍👩‍👧\n╰─────────────────────❏\n╭─❏\n│▣ 🏆 ${kat.label}\n│▣ ──────────────────\n${daftar}${myText}\n╰──────────❏`)
        }


        // ══════════════════════════════════════════════════════
        //  🏆 TITLE / PRESTASI COMMANDS
        // ══════════════════════════════════════════════════════
        if (command === 'prestasi' || command === 'title') {
            if (!rpgDB.players[senderJid]) return Reply('❌ Belum jadi petualang! Ketik *.rpgstart* dulu.')
            const player = rpgDB.players[senderJid]
            // Cek title baru
            const newT = checkNewTitles(player)
            if (!player.titles) player.titles = []
            if (!player.equippedTitle) player.equippedTitle = null

            const unlockedLines = player.titles.map(id => {
                const t = TITLE_DATA[id]
                if (!t) return null
                const isEquipped = player.equippedTitle === id
                return `│▣ ${isEquipped ? '✅' : '  '} ${t.name}\n│▣     📝 ${t.desc}`
            }).filter(Boolean).join('\n│▣ ──────────────────\n')

            const lockedCount = Object.keys(TITLE_DATA).length - player.titles.length
            const equippedData = player.equippedTitle ? TITLE_DATA[player.equippedTitle] : null
            const equippedDisplay = equippedData ? equippedData.name : '— Tidak ada'

            const newMsg = newT.length > 0 ? `\n\n🎊 *TITLE BARU TERBUKA!*\n${newT.map(n => `✨ ${n}`).join('\n')}` : ''

            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣   🏆  PRESTASI & TITLE  🏆
╰─────────────────────❏
╭─❏
│▣ 🎖️ Title Aktif : ${equippedDisplay}
│▣ 🔓 Terbuka     : ${player.titles.length} / ${Object.keys(TITLE_DATA).length}
│▣ 🔒 Terkunci    : ${lockedCount}
│▣ ──────────────────
${unlockedLines || '│▣ Belum ada title terbuka.'}
╰──────────❏
💡 Ketik *.pakaititle <id>* untuk pasang title
💡 Contoh: *.pakaititle pejuang*${newMsg}`)
        }

        if (command === 'pakaititle') {
            if (!rpgDB.players[senderJid]) return Reply('❌ Belum jadi petualang!')
            const player = rpgDB.players[senderJid]
            if (!player.titles) player.titles = []
            const titleId = text?.trim()?.toLowerCase()
            if (!titleId) return Reply('❌ Masukkan ID title! Contoh: *.pakaititle pejuang*\nLihat semua title dengan *.prestasi*')
            if (!TITLE_DATA[titleId]) return Reply(`❌ Title ${titleId} tidak ada. Cek *.prestasi* untuk daftar lengkap.`)
            if (!player.titles.includes(titleId)) return Reply(`❌ Kamu belum punya title ini! Kamu harus memenuhi syaratnya dulu.`)
            player.equippedTitle = titleId
            const t = TITLE_DATA[titleId]
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`✅ Title *${t.name}* berhasil dipasang!\nSekarang terlihat di .rpgstats kamu 🎖️`)
        }

        if (command === 'lepastititle' || command === 'removetitle') {
            if (!rpgDB.players[senderJid]) return Reply('❌ Belum jadi petualang!')
            const player = rpgDB.players[senderJid]
            player.equippedTitle = null
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply('✅ Title berhasil dilepas.')
        }

        // ══════════════════════════════════════════════════════
        //  🔥 BOSS EVENT COMMANDS
        // ══════════════════════════════════════════════════════
        if (command === 'bossevent' || command === 'cekboss') {
            if (!activeBossEvent) {
                return Reply(`╭─────────────────────❏
│▣   🔥  BOSS EVENT  🔥
╰─────────────────────❏
╭─❏
│▣ 😴 Belum ada Boss Event aktif.
│▣ ──────────────────
│▣ 💡 Boss Event muncul secara acak.
│▣ 💡 Admin bisa spawn dengan:
│▣     *.spawnboss <id>*
│▣ 💡 List boss:
${Object.entries(BOSS_EVENT_MONSTERS).map(([id,b]) => `│▣   • ${b.name} → *.spawnboss ${id}`).join('\n')}
╰──────────❏`)
            }
            const boss = activeBossEvent.bossData
            const hpPct = Math.max(0, Math.floor((activeBossEvent.currentHp / boss.hp) * 100))
            const hpBar = '█'.repeat(Math.floor(hpPct / 10)) + '░'.repeat(10 - Math.floor(hpPct / 10))
            const elapsed = Date.now() - activeBossEvent.startTime
            const remaining = Math.max(0, BOSS_EVENT_DURATION_MS - elapsed)
            const remMins = Math.floor(remaining / 60000)
            const remSecs = Math.floor((remaining % 60000) / 1000)
            const topDmg = Object.entries(activeBossEvent.participants)
                .sort((a,b) => b[1]-a[1]).slice(0,5)
                .map(([jid,dmg],i) => `│▣ ${['🥇','🥈','🥉','4️⃣','5️⃣'][i]} @${jid.split('@')[0]} — ${dmg.toLocaleString()} dmg`).join('\n')
            return Reply(`╭─────────────────────❏
│▣   🔥  BOSS EVENT AKTIF!  🔥
╰─────────────────────❏
╭─❏
│▣ 👹 ${boss.name}
│▣ ❤️ HP : [${hpBar}] ${activeBossEvent.currentHp.toLocaleString()}/${boss.hp.toLocaleString()} (${hpPct}%)
│▣ ⏱️ Sisa: ${remMins}m ${remSecs}s
│▣ 👥 Peserta: ${Object.keys(activeBossEvent.participants).length} orang
│▣ ──────────────────
│▣ 🏆 TOP DAMAGE:
${topDmg || '│▣   Belum ada yang menyerang!'}
╰──────────❏
⚔️ Ketik *.serangboss* untuk ikut menyerang!`)
        }

        if (command === 'spawnboss') {
            if (!m.isOwner) return Reply('❌ Hanya owner yang bisa spawn boss event.')
            if (activeBossEvent && !activeBossEvent.ended) return Reply('❌ Sudah ada Boss Event aktif! Tunggu selesai dulu.')
            const bossId = text?.trim()?.toLowerCase() || Object.keys(BOSS_EVENT_MONSTERS)[Math.floor(Math.random() * Object.keys(BOSS_EVENT_MONSTERS).length)]
            const bossData = BOSS_EVENT_MONSTERS[bossId]
            if (!bossData) return Reply(`❌ Boss ${bossId} tidak ada.\nList: ${Object.keys(BOSS_EVENT_MONSTERS).join(', ')}`)
            activeBossEvent = {
                bossId, bossData,
                currentHp: bossData.hp,
                participants: {},
                startTime: Date.now(),
                ended: false
            }
            // Auto-end after duration
            setTimeout(() => {
                if (activeBossEvent && !activeBossEvent.ended) {
                    activeBossEvent.ended = true
                    activeBossEvent.result = 'timeout'
                }
            }, BOSS_EVENT_DURATION_MS)
            return Reply(`╭─────────────────────❏
│▣   🚨  BOSS EVENT DIMULAI!  🚨
╰─────────────────────❏
╭─❏
│▣ 👹 ${bossData.name} MUNCUL!
│▣ ❤️ HP    : ${bossData.hp.toLocaleString()}
│▣ ⚔️ ATK   : ${bossData.attack}
│▣ 🛡️ DEF   : ${bossData.defense}
│▣ ⏱️ Waktu  : 30 menit
│▣ ──────────────────
│▣ 🎁 Reward per peserta:
│▣   ⭐ EXP, 💵 Gold, dan item langka!
│▣   🏆 Top damage dapat bonus reward!
╰──────────❏
⚔️ Ketik *.serangboss* untuk ikut!`)
        }

        if (command === 'serangboss') {
            if (!rpgDB.players[senderJid]) return Reply('❌ Belum jadi petualang! Ketik *.rpgstart* dulu.')
            if (!activeBossEvent || activeBossEvent.ended) return Reply('❌ Tidak ada Boss Event aktif. Cek *.bossevent*')
            if (Date.now() - activeBossEvent.startTime > BOSS_EVENT_DURATION_MS) {
                activeBossEvent.ended = true
                activeBossEvent.result = 'timeout'
                return Reply('⏰ Boss Event sudah berakhir! Boss melarikan diri...')
            }
            const player = rpgDB.players[senderJid]
            if (!player) return Reply('❌ Data player tidak ditemukan.')

            const boss = activeBossEvent.bossData
            // Cooldown serangan boss: 30 detik
            const lastAttack = activeBossEvent.lastAttacks?.[senderJid] || 0
            if (Date.now() - lastAttack < 30000) {
                const sisa = Math.ceil((30000 - (Date.now() - lastAttack)) / 1000)
                return Reply(`⏳ Tunggu ${sisa} detik lagi untuk menyerang boss!`)
            }
            if (!activeBossEvent.lastAttacks) activeBossEvent.lastAttacks = {}
            activeBossEvent.lastAttacks[senderJid] = Date.now()

            const totalStats = getPlayerTotalStats(player)
            // Damage ke boss = ATK player - 20% DEF boss (minimal 1)
            const playerDmg = Math.max(1, Math.floor(totalStats.attack - boss.defense * 0.2))
            const isCrit = Math.random() < ((player.agility || 5) / 100)
            const finalDmg = isCrit ? Math.floor(playerDmg * 2) : playerDmg

            activeBossEvent.currentHp = Math.max(0, activeBossEvent.currentHp - finalDmg)
            activeBossEvent.participants[senderJid] = (activeBossEvent.participants[senderJid] || 0) + finalDmg

            // Boss balas player
            const bossDmgToPlayer = Math.max(Math.floor(boss.attack * 0.15), Math.floor(boss.attack - totalStats.defense * 0.3))
            player.hp = Math.max(1, player.hp - bossDmgToPlayer)

            let resultMsg = ''
            let rewardMsg = ''

            if (activeBossEvent.currentHp <= 0) {
                // BOSS MATI!
                activeBossEvent.ended = true
                activeBossEvent.result = 'killed'
                const totalParticipants = Object.keys(activeBossEvent.participants).length
                const topDamager = Object.entries(activeBossEvent.participants).sort((a,b) => b[1]-a[1])[0]

                // Bagi reward ke semua peserta
                for (const [pJid, dmgDealt] of Object.entries(activeBossEvent.participants)) {
                    const p = rpgDB.players[pJid]
                    if (!p) continue
                    const shareRatio = dmgDealt / boss.hp
                    const expGain = Math.floor(boss.exp * Math.max(0.1, shareRatio))
                    const goldGain = Math.floor(boss.gold * Math.max(0.1, shareRatio))
                    gainExp(p, expGain)
                    p.gold = (p.gold || 0) + goldGain
                    p.bossKills = (p.bossKills || 0) + 1
                    // Drop items berdasarkan damage share
                    if (!p.inventory) p.inventory = {}
                    for (const [itemId, chance] of Object.entries(boss.drops)) {
                        if (Math.random() < chance * Math.min(1, shareRatio * 2 + 0.3)) {
                            p.inventory[itemId] = (p.inventory[itemId] || 0) + 1
                        }
                    }
                    checkNewTitles(p)
                }
                // Bonus top damager
                const topP = rpgDB.players[topDamager[0]]
                if (topP) {
                    gainExp(topP, Math.floor(boss.exp * 0.5))
                    topP.gold = (topP.gold || 0) + Math.floor(boss.gold * 0.5)
                    for (const [itemId] of Object.entries(boss.drops)) {
                        if (!topP.inventory) topP.inventory = {}
                        topP.inventory[itemId] = (topP.inventory[itemId] || 0) + 2
                    }
                }
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))

                const myDmg = activeBossEvent.participants[senderJid] || 0
                const myShare = Math.max(0.1, myDmg / boss.hp)
                resultMsg = `🎉 *BOSS TEWAS!* ${boss.name} berhasil dikalahkan!`
                rewardMsg = `
╭─❏
│▣ ⚔️ Damage mu  : ${myDmg.toLocaleString()}
│▣ ⭐ EXP        : +${Math.floor(boss.exp * myShare).toLocaleString()}
│▣ 💵 Gold       : +${toRupiah(Math.floor(boss.gold * myShare))}
│▣ 🏆 Top Dmg    : @${topDamager[0].split('@')[0]} (${topDamager[1].toLocaleString()})
│▣ 👥 Peserta    : ${totalParticipants} orang
╰──────────❏`
            } else {
                const hpPct = Math.floor((activeBossEvent.currentHp / boss.hp) * 100)
                const hpBar = '█'.repeat(Math.floor(hpPct/10)) + '░'.repeat(10-Math.floor(hpPct/10))
                resultMsg = isCrit ? `💥 *CRITICAL!* ${finalDmg} damage!` : `⚔️ ${finalDmg} damage ke ${boss.name}!`
                rewardMsg = `
╭─❏
│▣ ❤️ Boss HP: [${hpBar}] ${activeBossEvent.currentHp.toLocaleString()}/${boss.hp.toLocaleString()} (${hpPct}%)
│▣ 💢 Boss balas: -${bossDmgToPlayer} HP
│▣ ❤️ HP mu  : ${player.hp}/${player.maxHp}
╰──────────❏`
                fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            }

            return Reply(`╭─────────────────────❏
│▣   🔥  BOSS ATTACK  🔥
╰─────────────────────❏
${resultMsg}
${rewardMsg}`)
        }

        // ══════════════════════════════════════════════════════
        //  💼 PEKERJAAN BARU
        // ══════════════════════════════════════════════════════
        if (command === 'ngedokter') {
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 10) return Reply('🏥 Kamu terlalu sakit buat praktek! Minum potion dulu.')
            const cooldown = 120000
            if (Date.now() - (player.lastNgedokter||0) < cooldown) {
                const sisa = Math.ceil((cooldown - (Date.now()-(player.lastNgedokter||0)))/1000)
                return Reply(`⏳ Tunggu ${sisa} detik lagi untuk praktek.`)
            }
            const hasil = [
                { nama: 'pasien VIP bayar mahal', exp: 40, gold: 800, hp: -12 },
                { nama: 'operasi berjalan lancar', exp: 35, gold: 600, hp: -10 },
                { nama: 'pasien kabur gak bayar 💀', exp: 20, gold: 100, hp: -8 },
                { nama: 'diagnosa salah, dimarahin', exp: 15, gold: 200, hp: -15 }
            ]
            const reward = hasil[Math.floor(Math.random()*hasil.length)]
            player.hp = Math.max(1, player.hp + reward.hp)
            player.gold += reward.gold
            player.lastNgedokter = Date.now()
            player.totalJobs = (player.totalJobs||0) + 1
            const newT = checkNewTitles(player)
            const leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            const lvlMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}!` : ''
            const titleMsg = newT.length > 0 ? `\n🎖️ Title baru: ${newT.join(', ')}` : ''
            return Reply(`╭─────────────────────❏
│▣   🏥  NGEDOKTER  🏥
╰─────────────────────❏
╭─❏
│▣ 💊 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ ❤️ HP      : ${reward.hp}
╰──────────❏${lvlMsg}${titleMsg}`)
        }

        if (command === 'ngajar') {
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 5) return Reply('📚 Terlalu capek buat ngajar!')
            const cooldown = 90000
            if (Date.now() - (player.lastNgajar||0) < cooldown) {
                const sisa = Math.ceil((cooldown - (Date.now()-(player.lastNgajar||0)))/1000)
                return Reply(`⏳ Tunggu ${sisa} detik lagi.`)
            }
            const hasil = [
                { nama: 'murid semangat belajar', exp: 50, gold: 400, hp: -5 },
                { nama: 'kelas penuh & bayar extra', exp: 40, gold: 500, hp: -8 },
                { nama: 'murid tidur semua 😪', exp: 20, gold: 150, hp: -3 },
                { nama: 'ujian berhasil semua lulus!', exp: 60, gold: 600, hp: -10 }
            ]
            const reward = hasil[Math.floor(Math.random()*hasil.length)]
            player.hp = Math.max(1, player.hp + reward.hp)
            player.gold += reward.gold
            player.lastNgajar = Date.now()
            player.totalJobs = (player.totalJobs||0) + 1
            const newT = checkNewTitles(player)
            const leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            const lvlMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}!` : ''
            const titleMsg = newT.length > 0 ? `\n🎖️ Title baru: ${newT.join(', ')}` : ''
            return Reply(`╭─────────────────────❏
│▣   📚  NGAJAR  📚
╰─────────────────────❏
╭─❏
│▣ 🏫 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ ❤️ HP      : ${reward.hp}
╰──────────❏${lvlMsg}${titleMsg}`)
        }

        if (command === 'streaming') {
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 5) return Reply('📱 Terlalu capek buat streaming!')
            const cooldown = 60000
            if (Date.now() - (player.lastStreaming||0) < cooldown) {
                const sisa = Math.ceil((cooldown - (Date.now()-(player.lastStreaming||0)))/1000)
                return Reply(`⏳ Tunggu ${sisa} detik lagi.`)
            }
            const hasil = [
                { nama: 'viral dapat 1000 penonton!', exp: 45, gold: 700, hp: -5 },
                { nama: 'dapet superchat gila', exp: 40, gold: 1200, hp: -8 },
                { nama: 'konten biasa aja, sedikit penonton', exp: 20, gold: 150, hp: -3 },
                { nama: 'internet mati pas lagi seru 💀', exp: 10, gold: 50, hp: -2 },
                { nama: 'di-raid streamer besar!', exp: 60, gold: 900, hp: -10 }
            ]
            const reward = hasil[Math.floor(Math.random()*hasil.length)]
            player.hp = Math.max(1, player.hp + reward.hp)
            player.gold += reward.gold
            player.lastStreaming = Date.now()
            player.totalJobs = (player.totalJobs||0) + 1
            const newT = checkNewTitles(player)
            const leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            const lvlMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}!` : ''
            const titleMsg = newT.length > 0 ? `\n🎖️ Title baru: ${newT.join(', ')}` : ''
            return Reply(`╭─────────────────────❏
│▣   📱  STREAMING  📱
╰─────────────────────❏
╭─❏
│▣ 🎥 Hasil   : ${reward.nama}
│▣ 💵 Gold    : +${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ ❤️ HP      : ${reward.hp}
╰──────────❏${lvlMsg}${titleMsg}`)
        }

        if (command === 'dagang') {
            let jid = m.sender
            if (!rpgDB.players[jid]) rpgDB.players[jid] = initPlayerRPG(jid)
            let player = rpgDB.players[jid]
            if (player.hp < 8) return Reply('🛒 Capek banget, gak kuat dagang!')
            const cooldown = 90000
            if (Date.now() - (player.lastDagang||0) < cooldown) {
                const sisa = Math.ceil((cooldown - (Date.now()-(player.lastDagang||0)))/1000)
                return Reply(`⏳ Tunggu ${sisa} detik lagi.`)
            }
            const hasil = [
                { nama: 'jualan laris manis!', exp: 35, gold: 550, hp: -8 },
                { nama: 'dapet pelanggan tetap baru', exp: 30, gold: 400, hp: -7 },
                { nama: 'barang kurang laku', exp: 15, gold: 120, hp: -5 },
                { nama: 'kena tipu pembeli nakal 😤', exp: 20, gold: -100, hp: -10 },
                { nama: 'dapet order grosiran!', exp: 45, gold: 900, hp: -12 }
            ]
            const reward = hasil[Math.floor(Math.random()*hasil.length)]
            player.hp = Math.max(1, player.hp + reward.hp)
            player.gold = Math.max(0, (player.gold||0) + reward.gold)
            player.lastDagang = Date.now()
            player.totalJobs = (player.totalJobs||0) + 1
            const newT = checkNewTitles(player)
            const leveled = gainExp(player, reward.exp)
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            const lvlMsg = leveled ? `\n🎊 *LEVEL UP!* level ${player.level}!` : ''
            const titleMsg = newT.length > 0 ? `\n🎖️ Title baru: ${newT.join(', ')}` : ''
            return Reply(`╭─────────────────────❏
│▣   🛒  DAGANG  🛒
╰─────────────────────❏
╭─❏
│▣ 🏪 Hasil   : ${reward.nama}
│▣ 💵 Gold    : ${reward.gold >= 0 ? '+' : ''}${toRupiah(reward.gold)}
│▣ ⭐ EXP     : +${reward.exp}
│▣ ❤️ HP      : ${reward.hp}
╰──────────❏${lvlMsg}${titleMsg}`)
        }


        // ═══════════════════════════════════════════════════
        //  GAME NELAYAN — PERAHU, JARING, IKAN (SAFE ADDON)
        // ═══════════════════════════════════════════════════
        if (command === 'nelayan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            let txt = `╭─────────────────────❏
│▣  🌊  GAME NELAYAN RPG  🌊
╰─────────────────────❏
╭─❏
│▣ Jadi juragan laut, bukan cuma jadi beban grup.
│▣ Beli perahu, turun laut, lempar jaring,
│▣ angkat ikan, simpan, lalu jual.
│▣ ──────────────────
│▣ *.listperahu*        — Lihat 20 perahu
│▣ *.beliperahu nama/no* — Beli perahu
│▣ *.gantiperahu nama/no* — Pakai perahu
│▣ *.nelayanstart*      — Mulai melaut
│▣ *.turunkanjaring*    — Turunkan jaring
│▣ *.naikanjaring*      — Angkat hasil ikan
│▣ *.masukanikan*       — Masukkin hasil ke box
│▣ *.jualikannelayan*   — Jual ikan di box
│▣ ──────────────────
│▣ Tips: beli murah dulu, jangan sok sultan.
╰──────────❏`
            return Reply(txt)
        }

        if (command === 'listperahu') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            let txt = `╭─────────────────────❏
│▣  🚢  LIST 20 PERAHU NELAYAN  🚢
╰─────────────────────❏
╭─❏
│▣ Aktif: *${nelayan.activeBoat ? (getPerahuNelayan(nelayan.activeBoat)?.name || nelayan.activeBoat) : 'Belum ada'}*
│▣ Format beli: *.beliperahu nama/no*
│▣ Format ganti: *.gantiperahu nama/no*
│▣ ──────────────────
`
            NELAYAN_PERAHU.forEach((boat, i) => {
                const owned = nelayan.perahu[boat.id] ? '✅' : '❌'
                txt += `│▣ ${String(i + 1).padStart(2, '0')}. ${boat.emoji} *${boat.name}* ${owned}
│▣     Tier: ${boat.tier} | Muatan: ${boat.capacity}kg
│▣     Power: ${boat.power} | Harga: ${toRupiah(boat.price)}
`
            })
            txt += `╰──────────❏`
            return Reply(txt)
        }

        if (command === 'beliperahu') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            const boat = getPerahuNelayan(text || args.join(' '))
            if (!boat) return Reply(`❌ Perahu gak ketemu. Cek *.listperahu*, jangan nebak ngawur.`)
            if (nelayan.perahu[boat.id]) return Reply(`✅ Lu sudah punya *${boat.name}*. Pakai: *.gantiperahu ${boat.id}*`)
            if ((player.gold || 0) < boat.price) return Reply(`❌ Gold kurang. Butuh *${toRupiah(boat.price)}*, punya *${toRupiah(player.gold || 0)}*.`)
            player.gold -= boat.price
            nelayan.perahu[boat.id] = 1
            if (!nelayan.activeBoat) nelayan.activeBoat = boat.id
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  ✅  BELI PERAHU BERHASIL  ✅
╰─────────────────────❏
╭─❏
│▣ ${boat.emoji} Perahu: *${boat.name}*
│▣ 🏷️ Tier: *${boat.tier}*
│▣ 📦 Muatan: *${boat.capacity}kg*
│▣ ⚙️ Power: *${boat.power}*
│▣ 💸 Harga: *${toRupiah(boat.price)}*
│▣ 💰 Sisa: *${toRupiah(player.gold)}*
╰──────────❏`)
        }

        if (command === 'gantiperahu') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            const boat = getPerahuNelayan(text || args.join(' '))
            if (!boat) return Reply(`❌ Perahu gak ketemu. Cek *.listperahu*.`)
            if (!nelayan.perahu[boat.id]) return Reply(`❌ Lu belum punya *${boat.name}*. Beli dulu: *.beliperahu ${boat.id}*`)
            if (nelayan.trip) return Reply(`❌ Lagi melaut. Jangan ganti perahu di tengah laut, otak dipakai dikit.`)
            nelayan.activeBoat = boat.id
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`✅ Perahu aktif diganti ke ${boat.emoji} *${boat.name}*.`)
        }

        if (command === 'nelayanstart') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            const boat = getPerahuNelayan(nelayan.activeBoat)
            if (!boat) return Reply(`❌ Lu belum punya perahu aktif. Cek *.listperahu*, beli pakai *.beliperahu 1*.`)
            if (nelayan.trip) return Reply(`❌ Trip masih jalan. Lanjut: *.turunkanjaring* atau *.naikanjaring*.`)
            nelayan.trip = { boatId: boat.id, status: 'sailing', catch: {}, startedAt: Date.now(), netAt: 0 }
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  🌊  BERANGKAT MELAUT  🌊
╰─────────────────────❏
╭─❏
│▣ ${boat.emoji} Perahu: *${boat.name}*
│▣ 📦 Kapasitas: *${boat.capacity}kg*
│▣ ⚙️ Power: *${boat.power}*
│▣
│▣ Langkah berikutnya:
│▣ *.turunkanjaring*
╰──────────❏`)
        }

        if (command === 'turunkanjaring') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            if (!nelayan.trip) return Reply(`❌ Belum melaut. Pakai *.nelayanstart* dulu.`)
            if (nelayan.trip.status === 'net_down') return Reply(`❌ Jaring udah turun. Tinggal *.naikanjaring*, jangan diturunin dua kali kayak nilai rapor.`)
            nelayan.trip.status = 'net_down'
            nelayan.trip.netAt = Date.now()
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  🕸️  JARING DITURUNKAN  🕸️
╰─────────────────────❏
╭─❏
│▣ Byurrr... jaring masuk laut.
│▣ Tunggu sebentar lalu pakai:
│▣ *.naikanjaring*
╰──────────❏`)
        }

        if (command === 'naikanjaring') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            if (!nelayan.trip) return Reply(`❌ Belum melaut. Pakai *.nelayanstart* dulu.`)
            if (nelayan.trip.status !== 'net_down') return Reply(`❌ Jaring belum turun. Pakai *.turunkanjaring* dulu.`)
            const boat = getPerahuNelayan(nelayan.trip.boatId || nelayan.activeBoat)
            const hasil = nelayanCatch(boat?.power || 1)
            const currentLoad = nelayanLoad(nelayan.trip.catch)
            let added = {}
            let load = currentLoad
            for (const [id, qty] of Object.entries(hasil)) {
                const fish = NELAYAN_IKAN.find(f => f.id === id)
                let can = qty
                while (can > 0 && load + (fish?.weight || 1) <= (boat?.capacity || 10)) {
                    added[id] = (added[id] || 0) + 1
                    load += (fish?.weight || 1)
                    can--
                }
            }
            addNelayanItems(nelayan.trip.catch, added)
            nelayan.trip.status = 'catch_ready'
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  🐟  JARING DIANGKAT  🐟
╰─────────────────────❏
╭─❏
${formatNelayanIkan(added)}
│▣ ──────────────────
│▣ Muatan: *${load}/${boat?.capacity || 10}kg*
│▣ Lanjut: *.masukanikan*
╰──────────❏`)
        }

        if (command === 'masukanikan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            if (!nelayan.trip || nelayan.trip.status !== 'catch_ready') return Reply(`❌ Belum ada ikan siap masuk box. Alurnya: *.nelayanstart* → *.turunkanjaring* → *.naikanjaring*.`)
            addNelayanItems(nelayan.storage, nelayan.trip.catch)
            const saved = nelayan.trip.catch
            nelayan.trip = null
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  📦  IKAN MASUK BOX  📦
╰─────────────────────❏
╭─❏
${formatNelayanIkan(saved)}
│▣ ──────────────────
│▣ Jual pakai: *.jualikannelayan*
╰──────────❏`)
        }

        if (command === 'jualikannelayan') {
            if (!rpgDB.players[senderJid]) return Reply(`❌ Belum jadi petualang! Ketik *.rpgstart* dulu.`)
            const player = rpgDB.players[senderJid]
            const nelayan = ensureNelayan(player)
            const total = sellNelayanItems(player, nelayan.storage)
            if (total <= 0) return Reply(`❌ Box ikan kosong. Melaut dulu, kapten kesiangan.`)
            const soldText = formatNelayanIkan(nelayan.storage)
            nelayan.storage = {}
            fs.writeFileSync(rpgDBPath, JSON.stringify(rpgDB, null, 2))
            return Reply(`╭─────────────────────❏
│▣  💰  IKAN TERJUAL  💰
╰─────────────────────❏
╭─❏
${soldText}
│▣ ──────────────────
│▣ Total: *${toRupiah(total)}*
│▣ Gold sekarang: *${toRupiah(player.gold || 0)}*
╰──────────❏`)
        }

        } catch (error) {
        console.error('RPG Plugin Error:', error)
        Reply(`❌ *RPG ERROR* ❌\n\n${error.message}`)
    }
}

Object.assign(module.exports, {
    command: [
        'transfersawit',
        'jualsawit',
        'topsawit',
        'ceksawit',
        'panensawit',
        'tanamsawit',
        'sawit',
        'adduang', 'cekuang', 'topgold',
        'rpgstart', 'rpgstats', 'rpgexplore', 'attack', 'skill', 'flee', 'rpgmove', 'rpginv', 'rpgshop', 'buy', 'sell', 'use',
        'prestasi', 'title', 'pakaititle', 'lepastititle', 'removetitle',
        'bossevent', 'cekboss', 'spawnboss', 'serangboss',
        'ngedokter', 'ngajar', 'streaming', 'dagang',
        'equip', 'unequip', 'item', 'rpghelp', 'tambang', 'mining', 'besi', 'nikel', 'emas', 'berlian', 'meramu', 'foraging',
        'jualbot', 'drop', 'buang', 'give', 'berikan',
        'dungeon', 'adopsipet', 'adoptpet', 'infopet', 'petinfo', 'judionline', 'begal', 'maling',
        'quest', 'craft', 'daily', 'pvp', 'leaderboardrpg', 'lb_rpg',
        'mancingstart', 'mancing', 'tasikan', 'jualikanbot', 'jualikan', 'setujuikan', 'tolakikan', 'tawarikan', 'batalkanikan', 'shoprod', 'shopbomber', 'topmancing',
        'ngocok', 'ngelonte',
        'openbo', 'ngojek', 'ngaji', 'kerja', 'jobkerja', 'berkebun', 'tfuang', 'bank', 'setor', 'tarik', 'topbank',
        'market', 'minimarket', 'keranjang', 'bayar', 'beli', 'jualsaham', 'jualaset', 'jualasetbot', 'batallisting', 'ceksaham', 'portofolio',
        'topkaya', 'simpanaset', 'tarikaset', 'pasifincome',
        'resetgoldall', 'resetgolduser', 'editgold', 'resetbankall', 'editbank', 'resetasetall', 'resetkeluargaall', 'resetkeluargauser', 'info',
        'shopfood', 'peliharaikan', 'akuarium', 'makankanikan', 'lepaskan', 'aduikan', 'infoaduikan',
        'buatclan', 'listclan', 'gabukclan', 'keluarclan', 'infoclan', 'renameclan', 'kickclan', 'transferclan', 'depositclan', 'serangclan', 'rampokclan', 'clanhelp', 'tokoclan', 'beliclan',
        'lamar', 'terima', 'tolak', 'cerai', 'infopasangan',
        'buatanak', 'rawatanak', 'belimakanan', 'nafkah', 'infoanak', 'simulatorhelp', 'hargasimulator',
        'kencan', 'harmoni', 'cekharmoni', 'kadoanniversary',
        'selingkuh', 'cekselingkuh',
        'sekolahkan', 'kerjaanak', 'rapotanak',
        'belirumahtinggal', 'renovasirumah', 'inforumah',
        'makanbersama', 'liburankeluarga', 'fotobersama',
        'kadoanak', 'cekevent', 'statkeluarga', 'lifehelp', 'topkeluarga',
        'buanganak', 'hapusanak', 'pantiasuhan', 'resetpanti',
        'nelayan', 'listperahu', 'beliperahu', 'gantiperahu', 'nelayanstart', 'turunkanjaring', 'naikanjaring', 'jualikannelayan', 'masukanikan'
    ]
})
// Compatibility metadata untuk berbagai loader bot.
// Biar command baru kebaca walau loader pakai nama property beda-beda.
module.exports.commands = module.exports.command
module.exports.cmd = module.exports.command
module.exports.help = module.exports.command
module.exports.tags = ['rpg']
module.exports.category = 'rpg'
