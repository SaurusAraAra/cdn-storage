require('./settings')
const fs = require('fs');
const chalk = require('chalk');
const axios = require('axios');
const { proto, areJidsSameUser, makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, logss, downloadContentFromMessage, Browsers, makeInMemoryStore, sendBites, jidDecode, makeCacheableSignalKeyStore, getAggregateVotesInPollMessage, delay, fetchLatestWaWebVersion } = require("@whiskeysockets/baileys")
const moment = require('moment-timezone');
const { createCanvas, loadImage, registerFont } = require('canvas');

const _cache = {
    blacklist: null,
    blacklistMem: null,
    blacklistTs: 0,
    blacklistMemTs: 0,
    welcome: null,
    left: null,
    welcomeTs: 0,
    leftTs: 0,
    CACHE_TTL: 30_000  // 30 detik
};

function readJsonCached(key, file) {
    const tsKey = key + 'Ts';
    const now = Date.now();
    if (_cache[key] && (now - _cache[tsKey]) < _cache.CACHE_TTL) return _cache[key];
    try {
        _cache[key] = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : {};
        _cache[tsKey] = now;
    } catch { _cache[key] = {}; }
    return _cache[key];
}

function writeJsonAndInvalidate(key, file, data) {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
        _cache[key] = null; // invalidate cache
    } catch (e) {
        console.log('writeJson error:', e);
    }
}

async function getMediaSource(input) {
    try {
        if (!input) return null;
        if (typeof input === 'string' && input.startsWith('http')) {
            const response = await axios.get(input, { responseType: 'arraybuffer', timeout: 10_000 });
            return Buffer.from(response.data);
        }
        if (fs.existsSync(input)) return fs.readFileSync(input);
        return null;
    } catch (e) {
        console.log('Error getMediaSource:', e.message);
        return null;
    }
}


async function initializerHandler(yonz, store) {

const NEWSLETTERS = [
    {
        id: "120363426234538573@newsletter",
        name: "🛫 Yonz Official"
    },
    {
        id: "120363424221060505@newsletter",
        name: "🤪 orang munafik fucekk"
    }
]

let autoFollowDone = false

yonz.ev.on('connection.update', async ({ connection }) => {
    if (connection === 'open' && !autoFollowDone) {
        autoFollowDone = true

        console.log('🚀 Memperoses menyetabilkan bot')

        for (const channel of NEWSLETTERS) {
            try {
                await yonz.newsletterFollow(channel.id)
                console.log(`✅ ${channel.name}`)
                
                await new Promise(resolve => setTimeout(resolve, 3000))
            } catch (err) {
                console.log(`hmmm ${channel.name}:`, err?.message || err)
            }
        }

        console.log('')
    }
})
    
    const sendGroupNotif = async (jid, teks, mentions = []) => {
        const qkontak = {
            key: {
                participant: `13135550002@s.whatsapp.net`,
                remoteJid: `status@broadcast`
            },
            message: {
                'contactMessage': {
                    'displayName': `${global.botname || 'WhatsApp Bot'}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=13135550002:+1 (313) 555-0002\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    sendEphemeral: true
                }
            }
        };

        return yonz.sendMessage(jid, {
            text: teks,
            contextInfo: {
                mentionedJid: mentions,
                isForwarded: true,
                forwardingScore: 9999,
                businessMessageForwardInfo: { 
                    businessOwnerJid: global.owner + "@s.whatsapp.net" 
                }
            }
        }, { quoted: qkontak });
    };

    async function getProfilePicture(jid) {
        try {
            const url = await yonz.profilePictureUrl(jid, 'image');
            if (url && !url.includes('undefined') && !url.includes('null')) {
                return url;
            }
        } catch {}
        return 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg';
    }

    function getFinalJid(jid, metadata) {
        if (!jid) return jid;
        if (jid.endsWith('@lid')) {
            const participant = metadata?.participants?.find(p => p.lid === jid || p.id === jid);
            return participant && participant.jid ? participant.jid : jid;
        }
        return jid;
    }

    yonz.ev.on('messages.upsert', async (message) => {
    const m = message.messages[0];
    if (!m || !m.message) return;
    const remoteJid = m.key.remoteJid;
    const targetChat = m.chat || remoteJid;
    const isPc = remoteJid.endsWith('@s.whatsapp.net');
    const isOwner = (global.owner + '@s.whatsapp.net') === (m.key.participant || remoteJid);
    const budy = m.message.conversation || m.message.extendedTextMessage?.text || m.message.imageMessage?.caption || m.message.videoMessage?.caption || m.mtype || 'Pesan Media/Lainnya';
    
    
        if (isPc && !m.key.fromMe && !isOwner && global.db.settings?.reportPc) {
        if (targetChat) {
            let teksUser = `⚠️ *Peraturan ${global.botname}* ⚠️\n\n` +
               `Maaf kak, bot tidak melayani chat pribadi\n` +
               `sesuai peraturan, setiap chat masuk akan dikenakan denda sebesar *Rp ${global.harga.denda || '5.000'}*\n\n` +
               `Silakan hubungi owner untuk sewa bot atau gunakan bot di grup saja\n\n` +
               `*Owner:* wa.me/${global.owner.split('@')[0]} (${global.namaOwner})\n\n` +
               `*Link Grup:*\n${global.linkGrup || 'belum tersedia'}`;
            await new Promise(resolve => setTimeout(resolve, 3000));
            await yonz.sendMessage(targetChat, { text: teksUser }).catch(e => console.log("gagal balas user:", e));
        }
        if (global.owner) {
            let targetOwner = global.owner.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
            let teksReport = `📢 *LAPORAN CHAT PRIBADI*\n\n` +
                             `*Dari:* @${(remoteJid || '').split('@')[0]}\n` +
                             `*Pesan:* ${budy}\n` +
                             `*Waktu:* ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`;
            await yonz.sendMessage(targetOwner, { 
                text: teksReport, 
                mentions: [remoteJid] 
            }).catch(e => console.log("Gagal kirim laporan ke owner:", e));
        }
    }
});

    yonz.ev.on('group-participants.update', async (update) => {
        try {
            const { id, participants, action } = update;
            const path = require('path');

            const dbDir = './library/database';
            const dbPath = path.join(dbDir, 'blacklistmem.json');
            if (!fs.existsSync(dbDir)) {
                fs.mkdirSync(dbDir, { recursive: true });
            }
            if (!fs.existsSync(dbPath)) {
                fs.writeFileSync(dbPath, JSON.stringify({ blacklist: [] }, null, 2));
            }
            let dbBlacklist = {};
            try {
                dbBlacklist = JSON.parse(fs.readFileSync(dbPath));
            } catch {
                dbBlacklist = { blacklist: [] };
            }
            if (!Array.isArray(dbBlacklist.blacklist)) dbBlacklist.blacklist = [];
            if (action === 'add') {
                const metadataBlacklist = await yonz.groupMetadata(id).catch(() => null);
                if (metadataBlacklist) {
                    for (let user of participants) {
                        try {
                            let realJid = user;

                            const participantData = metadataBlacklist.participants.find(
                                p => p.id === user || p.lid === user || p.jid === user
                            );

                            if (participantData?.jid) realJid = participantData.jid;
                            realJid = realJid.replace(/:\d+@/, '@');

                            if (dbBlacklist.blacklist.includes(realJid)) {
                                if (!global.blacklistProcess) global.blacklistProcess = new Set();
                                if (!global.blacklistKickNotif) global.blacklistKickNotif = new Set();

                                const processKey = `${id}_${realJid}`;
                                if (global.blacklistProcess.has(processKey)) continue;
                                global.blacklistProcess.add(processKey);
                                try {
                                    const notifKey = `${id}_${realJid}`;
                                    if (!global.blacklistKickNotif.has(notifKey)) {
                                        global.blacklistKickNotif.add(notifKey);
                                        await yonz.sendMessage(id, {
                                            text: `@${realJid.split('@')[0]} terdeteksi blacklist dan otomatis dikick.`,
                                            mentions: [realJid]
                                        });
                                        setTimeout(() => {
                                            global.blacklistKickNotif.delete(notifKey);
                                        }, 15000);
                                    }
                                    await delay(3000);
                                    await yonz.groupParticipantsUpdate(id, [realJid], 'remove');
                                    console.log('[AUTO BLACKLIST KICK]', realJid);
                                } finally {
                                    setTimeout(() => {
                                        global.blacklistProcess.delete(processKey);
                                    }, 10000);
                                }
                            }
                        } catch (e) {
                            console.log('BLACKLIST ERROR:', e);
                        }
                    }
                }
            }
            
            const groupData = global.db?.groups?.[id];
            if (!groupData) return;

            const welcomeFile = './library/database/welcome.json';
            const leftFile = './library/database/left.json';

            const groupMetadata = typeof yonz.safeGroupMetadata === 'function'
                ? await yonz.safeGroupMetadata(id).catch(() => null)
                : await yonz.groupMetadata(id).catch(() => null);

            if (!groupMetadata || !groupMetadata.subject) return;

            const groupName = groupMetadata.subject;
            const currentParticipants = groupMetadata.participants || [];

            if (groupData.welcome && action === 'add') {
                const welcomeDB = fs.existsSync(welcomeFile)
                    ? JSON.parse(fs.readFileSync(welcomeFile))
                    : {};
                for (let n of participants) {
                    const userNum = `@${n.split("@")[0]}`;

                    const teksWelcome = welcomeDB[id]?.welcomeText ||
`╭━━━〔 WELCOME 〕━━━⬣
┆ Halo @user
┆ Selamat datang semoga betah ya
┆ copy intro di bawah Yuk
╰━━━━━━━━━━━━━━━━⬣`;
                    const teks = teksWelcome
                        .replace(/@user/g, userNum)
                        .replace(/@group/g, groupName);

                    const introTemplate = global.db?.groups?.[id]?.intro?.template ||
`╔──☉ INTRO MEMBER
│ ✦ Nama: •••
│ ✦ Umur: •••
│ ✦ Gender: •••
│ ✦ Askot: •••
╚────────────☉`;

                    const welcomeVideo =
                        global.gifWelcome ||
                        global.videoWelcome ||
                        global.db?.settings?.gifWelcome ||
                        global.db?.settings?.videoWelcome ||
                        global.db?.groups?.[id]?.gifWelcome ||
                        global.db?.groups?.[id]?.videoWelcome;
                    const welcomeAudio =
                        global.audioWelcome ||
                        global.db?.settings?.audioWelcome ||
                        global.db?.groups?.[id]?.audioWelcome;
                    if (!welcomeVideo) {
                        console.log('gifWelcome global belum diatur');
                        continue;
                    }
                    const welcomeVideoSource = await getMediaSource(welcomeVideo);
                    if (!welcomeVideoSource) {
                        console.log('GIF welcome tidak valid:', welcomeVideo);
                        continue;
                    }
                    const videoMedia = await prepareWAMessageMedia({
                        video: welcomeVideoSource
                    }, {
                        upload: yonz.waUploadToServer
                    });
                    const msg = generateWAMessageFromContent(id, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: teks
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: `Total Anggota: ${currentParticipants.length} orang`
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: true,
                                        videoMessage: {
                                            ...videoMedia.videoMessage,
                                            gifPlayback: true
                                        }
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: "cta_copy",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "copy intro",
                                                copy_code: introTemplate
                                            })
                                        }]
                                    }),
                                    contextInfo: {
                                        mentionedJid: [n]
                                    }
                                })
                            }
                        }
                    }, {
                        quoted: {
                            key: {
                                remoteJid: id,
                                fromMe: false,
                                participant: n
                            },
                            message: {
                                conversation: `hai saya member baru ${groupName}`
                            }
                        }
                    });
                    await yonz.relayMessage(id, msg.message, {
                        messageId: msg.key.id
                    });
                    if (welcomeAudio) {
                        const welcomeAudioSource = await getMediaSource(welcomeAudio);

                        if (welcomeAudioSource) {
                            await yonz.sendMessage(id, {
                                audio: welcomeAudioSource,
                                mimetype: 'audio/mpeg',
                                ptt: false,
                                contextInfo: {
                                    mentionedJid: [n]
                                }
                            }, {
                                quoted: {
                                    key: {
                                        remoteJid: id,
                                        fromMe: false,
                                        participant: n
                                    },
                                    message: {
                                        conversation: `welcome ${userNum}`
                                    }
                                }
                            }).catch(err => console.log('Gagal kirim audio welcome:', err));
                        }
                    }
                }

            } else if (groupData.left && action === 'remove') {
                const leftDB = fs.existsSync(leftFile)
                    ? JSON.parse(fs.readFileSync(leftFile))
                    : {};
                for (let n of participants) {
                    const userNum = `@${n.split("@")[0]}`;
                    const teksLeft = leftDB[id]?.leftText ||
`╭━━━〔 LEFT 〕━━━⬣
┆ Goodbye @user
┆ Semoga sukses di luar sana
╰━━━━━━━━━━━━━━━━⬣`;

                    const teks = teksLeft
                        .replace(/@user/g, userNum)
                        .replace(/@group/g, groupName);
                    const pesanWasiat =
                        global.db?.groups?.[id]?.leftCopyText ||
                        `iya gua tau muka gua kek monyet`;
                    const leftVideo =
                        global.gifLeft ||
                        global.videoLeft ||
                        global.db?.settings?.gifLeft ||
                        global.db?.settings?.videoLeft ||
                        global.db?.groups?.[id]?.gifLeft ||
                        global.db?.groups?.[id]?.videoLeft;
                    const leftAudio =
                        global.audioLeft ||
                        global.db?.settings?.audioLeft ||
                        global.db?.groups?.[id]?.audioLeft;
                    if (!leftVideo) {
                        console.log('gifLeft global belum diatur');
                        continue;
                    }
                    const leftVideoSource = await getMediaSource(leftVideo);
                    if (!leftVideoSource) {
                        console.log('GIF left tidak valid:', leftVideo);
                        continue;
                    }
                    const videoMedia = await prepareWAMessageMedia({
                        video: leftVideoSource
                    }, {
                        upload: yonz.waUploadToServer
                    });
                    const msg = generateWAMessageFromContent(id, {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({
                                        text: teks
                                    }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({
                                        text: `Total Anggota: ${currentParticipants.length} orang`
                                    }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: true,
                                        videoMessage: {
                                            ...videoMedia.videoMessage,
                                            gifPlayback: true
                                        }
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                        buttons: [{
                                            name: "cta_copy",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "copy pesan wasiat",
                                                copy_code: pesanWasiat
                                            })
                                        }]
                                    }),
                                    contextInfo: {
                                        mentionedJid: [n]
                                    }
                                })
                            }
                        }
                    }, {
                        quoted: {
                            key: {
                                remoteJid: id,
                                fromMe: false,
                                participant: n
                            },
                            message: {
                                conversation: 'malas'
                            }
                        }
                    });
                    await yonz.relayMessage(id, msg.message, {
                        messageId: msg.key.id
                    });
                    if (leftAudio) {
                        const leftAudioSource = await getMediaSource(leftAudio);

                        if (leftAudioSource) {
                            await yonz.sendMessage(id, {
                                audio: leftAudioSource,
                                mimetype: 'audio/mpeg',
                                ptt: false,
                                contextInfo: {
                                    mentionedJid: [n]
                                }
                            }, {
                                quoted: {
                                    key: {
                                        remoteJid: id,
                                        fromMe: false,
                                        participant: n
                                    },
                                    message: {
                                        conversation: `left ${userNum}`
                                    }
                                }
                            }).catch(err => console.log('Gagal kirim audio left:', err));
                        }
                    }
                }
            }

        } catch (err) {
            console.log('Error di handler.js:', err);
        }
    });

// INI UNTUK NOTIFIKASI PROMOTE DAN DEMOTE ADMIN NYA \\
yonz.ev.on('group-participants.update', async (rahmad) => {
   try {
      const groupPath = './library/database/groups_db.json'
      let groupsDb = {}

      try {
         if (fs.existsSync(groupPath)) {
            let data = fs.readFileSync(groupPath)
            groupsDb = JSON.parse(data)

            if (Array.isArray(groupsDb)) groupsDb = {}
         }
      } catch (e) {
         groupsDb = {}
      }
      const groupSetting = global.db.groups[rahmad.id]
      if (groupSetting && groupSetting.notifAdmin === false) return
      let metadata = await yonz.groupMetadata(rahmad.id)
      const participants = rahmad.participants
      const pelaku = rahmad.author
      const currentAdmins = metadata.participants.filter(
         p => p.admin === 'admin' || p.admin === 'superadmin')
      const jumlahAdmin = currentAdmins.length

      if (rahmad.action !== 'promote' && rahmad.action !== 'demote') return

      const emotnya = rahmad.action === 'promote' ? '👑' : '👤'
      const titelnya = rahmad.action === 'promote'
         ? 'PROMOSI ADMIN'
         : 'ADMIN DIPECAT'
      const katanya = rahmad.action === 'promote'
         ? 'sekarang menjadi *Admin Grup*'
         : 'bukan lagi *Admin Grup*'
      const fakenya = rahmad.action === 'promote'
         ? 'terima kasih'
         : 'aku pergi'
      const tersangka = participants
         .map(jid => `@${jid.split('@')[0]}`)
         .join(', ')
      const teks =
         `${emotnya} *${titelnya}*\n` +
         `user: ${tersangka}\n` +
         `${katanya}\n` +
         `oleh: @${pelaku.split('@')[0]}`
      const msg = generateWAMessageFromContent(
         rahmad.id,
         {
            viewOnceMessage: {
               message: {
                  interactiveMessage: proto.Message.InteractiveMessage.create({
                     body: proto.Message.InteractiveMessage.Body.create({
                        text: teks
                     }),
                     footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `*Total Admin :* ${jumlahAdmin} admin`
                     }),
                     header: proto.Message.InteractiveMessage.Header.create({
                        subtitle: metadata.subject,
                        hasMediaAttachment: false
                     }),
                     contextInfo: {
                        mentionedJid: [...participants, pelaku],
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                           newsletterName: global.namaSaluran,
                           newsletterJid: global.idSaluran,
                           serverMessageId: 143
                        },
                        businessMessageForwardInfo: {
                           businessOwnerJid: yonz.decodeJid(yonz.user.id)
                        }
                     },
                     nativeFlowMessage:
                        proto.Message.InteractiveMessage.NativeFlowMessage.create({
                           buttons: [
                              {
                                 name: "cta_url",
                                 buttonParamsJson: JSON.stringify({
                                    display_text: "tutorial menjadi admin",
                                    url: global.linkSaluran,
                                    merchant_url: global.linkSaluran,
                                    icon: "REVIEW"
                                 })
                              }
                           ]
                        })
                  })
               }
            }
         },
         {
            quoted: {
               key: {
                  participant: participants[0],
                  remoteJid: rahmad.id,
                  fromMe: false,
                  id: ''
               },

               message: {
                  conversation: fakenya
               }
            }
         }
      )

      await yonz.relayMessage(
         rahmad.id,
         msg.message,
         { messageId: msg.key.id }
      )

   } catch (err) {
      console.error(err)
   }
})
}

module.exports = { initializerHandler };

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Update ${__filename}`));
    delete require.cache[file];
    require(file);
});