//©alifalfrl__ wa : 081249703469
//jangan hapus credit!!!!

require('../settings');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const FileType = require('file-type');
const PhoneNumber = require('awesome-phonenumber');

const { imageToWebp, videoToWebp, writeExif } = require('../library/exif');
const { isUrl, getGroupAdmins, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep, getTypeUrlMedia } = require('../library/function');
const { jidNormalizedUser, proto, getBinaryNodeChildren, getBinaryNodeChild, generateWAMessageContent, generateForwardMessageContent, prepareWAMessageMedia, delay, areJidsSameUser, extractMessageContent, generateMessageID, downloadContentFromMessage, generateWAMessageFromContent, jidDecode, generateWAMessage, toBuffer, getContentType, getDevice } = require('@whiskeysockets/baileys');

// Thumbnail gambar lokal untuk semua fitur proses/reply
// (menggantikan pola externalAdReply)
const Jimp = require('jimp');
const THUMB_DOC_PATH = path.join(__dirname, 'media', 'foto', 'imgdokumen.jpg');
let _cachedThumbBuffer = null;   // buffer dokumen asli
let _cachedThumbSmall = null;    // buffer thumbnail kecil (jpegThumbnail)

function getReplyThumbBuffer() {
    try {
        if (_cachedThumbBuffer) return _cachedThumbBuffer;
        if (fs.existsSync(THUMB_DOC_PATH)) {
            _cachedThumbBuffer = fs.readFileSync(THUMB_DOC_PATH);
        }
        return _cachedThumbBuffer;
    } catch {
        return null;
    }
}

async function getReplyThumbSmall() {
    try {
        if (_cachedThumbSmall) return _cachedThumbSmall;
        const raw = getReplyThumbBuffer();
        if (!raw) return null;
        const img = await Jimp.read(raw);
        _cachedThumbSmall = await img.resize(100, 100).quality(60).getBufferAsync(Jimp.MIME_JPEG);
        return _cachedThumbSmall;
    } catch {
        return getReplyThumbBuffer(); // fallback pakai buffer asli kalau jimp gagal
    }
}

async function LoadDataBase(yonz, m) {
	try {
		const botNumber = await yonz.decodeJid(yonz.user.id);
		const isNumber = x => typeof x === 'number' && !isNaN(x)
		const isBoolean = x => typeof x === 'boolean' && Boolean(x)

let setBot = global.db.settings
if (typeof setBot !== 'object') global.db.settings = {}
if (setBot) {
    if (!('autoread' in setBot)) setBot.autoread = true
    if (!('autotyping' in setBot)) setBot.autotyping = false
    if (!('autoai' in setBot)) setBot.autoai = 'off'
    if (!('isPublic' in setBot)) setBot.isPublic = false
    if (!('wajibDaftar' in setBot)) setBot.wajibDaftar = true
} else {
    global.db.settings = {
        autoread: true,
        autotyping: false,
        autoai: 'off',
        isPublic: false,
        wajibDaftar: true,
    }
}
let user = global.db.users[m.sender]
if (typeof user !== 'object') global.db.users[m.sender] = {}
if (!user) {
    global.db.users[m.sender] = {}
}
if (m.isGroup) {
  let group = global.db.groups[m.chat]
  if (typeof group !== 'object') global.db.groups[m.chat] = {}
  if (group) {
if (!('antilink' in group)) group.antilink = false
if (!('antilink2' in group)) group.antilink2 = false
if (!('welcome' in group)) group.welcome = false
if (!('left' in group)) group.left = false
if (!('mute' in group)) group.mute = false
if (!('blacklistjpm' in group)) group.blacklistjpm = false
if (!('autodownload' in group)) group.autodownload = false
if (!('autotyping' in group)) group.autotyping = false
} else {
global.db.groups[m.chat] = {
    antilink: false,
    antilink2: false,
    welcome: false,
    left: false,
    mute: false,
    blacklistjpm: false,
    autodownload: false,
    autotyping: false
    }
  }
}

	} catch (e) {
		throw e;
	}
}

async function MessagesUpsert(yonz, message, store) {
  try {
    let botNumber = await yonz.decodeJid(yonz.user.id);
    const msg = message.messages[0];
    const remoteJid = msg.key.remoteJid;
    
    store.messages[remoteJid] ??= {};
    store.messages[remoteJid].array ??= [];
    store.messages[remoteJid].keyId ??= new Set();
    
    if (!(store.messages[remoteJid].keyId instanceof Set)) {
      store.messages[remoteJid].keyId = new Set(store.messages[remoteJid].array.map(m => m.key.id));
    }
    
    if (store.messages[remoteJid].keyId.has(msg.key.id)) return;
    store.messages[remoteJid].array.push(msg);
    store.messages[remoteJid].keyId.add(msg.key.id);
    
    if (store.messages[remoteJid].array.length > (global.chatLength || 250)) {
      const removed = store.messages[remoteJid].array.shift();
      store.messages[remoteJid].keyId.delete(removed.key.id);
    }

    const type = msg.message ? (getContentType(msg.message) || Object.keys(msg.message)[0]) : '';

    if (msg.key?.remoteJid === 'status@broadcast') {
        if (global.db.settings.readsw === true) {
            await yonz.readMessages([msg.key]).catch(() => {});
        }
        return; 
    }
    if (!msg.message) return;
    if (!yonz.public && !msg.key.fromMe && message.type === 'notify') {
      const sender = yonz.decodeJid(msg.key.participant || msg.key.remoteJid || '');
      const ownerList = [
        ...(global.owners || []), 
        global.owner
      ].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net');

      if (!ownerList.includes(sender)) return;
    }

    const isGroupChat = remoteJid.endsWith('@g.us');
    const groupCfg = isGroupChat ? global.db.groups[remoteJid] : null;

    // Autoread berlaku global untuk SEMUA chat (grup & pribadi), hanya diatur oleh owner
    // lewat setting global.db.settings.autoread — tidak bisa dioverride per-grup.
    const wantAutoread = global.db.settings.autoread === true;

    const wantAutotyping = (isGroupChat && groupCfg && typeof groupCfg.autotyping === 'boolean')
      ? groupCfg.autotyping
      : global.db.settings.autotyping === true;

    if (wantAutoread) {
      await yonz.readMessages([msg.key]).catch((e) => {
        console.log('Autoread error (diabaikan):', e?.message || e);
      });
    }

    if (wantAutotyping && !msg.key.fromMe) {
      // Fire-and-forget: jangan blokir alur pesan, dan pastikan status "mengetik"
      // di-nonaktifkan lagi setelah beberapa detik biar tidak macet.
      yonz.sendPresenceUpdate('composing', remoteJid)
        .then(() => {
          setTimeout(() => {
            yonz.sendPresenceUpdate('paused', remoteJid).catch(() => {});
          }, 3000);
        })
        .catch((e) => {
          console.log('Autotyping error (diabaikan):', e?.message || e);
        });
    }

    const m = await Serialize(yonz, msg, store);
    if (m.isBaileys) return
    require('../yonz-cmd.js')(yonz, m, message, store);

    // Auto AI: jawab otomatis kalau pesan bot di-reply (lihat lib/yonz-autoai.js)
    require('../lib/yonz-autoai.js').AutoAI(yonz, m).catch((e) => {
      console.log('AutoAI error (diabaikan):', e?.message || e);
    });

    if (type === 'interactiveResponseMessage' && m.quoted && m.quoted.fromMe) {
      const parsedId = JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id;

      let apb = await generateWAMessage(
        m.chat,
        { text: parsedId, mentions: m.mentionedJid },
        { userJid: yonz.user.id, quoted: m.quoted }
      );

      apb.key = msg.key;
      apb.key.fromMe = areJidsSameUser(m.sender, yonz.user.id);
      if (m.isGroup) apb.participant = m.sender;

      let pbr = {
        ...msg,
        messages: [proto.WebMessageInfo.fromObject(apb)],
        type: 'append'
      };

      yonz.ev.emit('messages.upsert', pbr);
    }
  } catch (e) {
    throw e;
  }
}

async function Solving(yonz, store) {
    yonz.public = global.db.settings.isPublic;
    
    yonz.serializeM = (m) => MessagesUpsert(yonz, m, store)
	
	yonz.decodeJid = (jid) => {
		if (!jid) return jid
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {}
			return decode.user && decode.server && decode.user + '@' + decode.server || jid
		} else return jid
	}
	
	yonz.getName = async (jid, withoutContact = false) => {
		try {
			const id = yonz.decodeJid(jid);
			if (id.endsWith('@g.us')) {
				const groupInfo = store.contacts[id] || await yonz.groupMetadata(id).catch(_ => ({})) || {};
				return groupInfo.subject || groupInfo.name || PhoneNumber('+' + id.replace('@g.us', '')).getNumber('international');
			} else {
				if (id === '0@s.whatsapp.net') return 'WhatsApp';
				const contactInfo = store.contacts[id] || {};
				return withoutContact ? '' : contactInfo.name || contactInfo.verifiedName || contactInfo.notify || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international');
			}
		} catch {
			return jid.split('@')[0];
		}
	}
	
	yonz.sendContactV2 = async (jid, kon, desk = "Developer Bot", quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: namaOwner,
  vcard: 'BEGIN:VCARD\n' +
    'VERSION:3.0\n' +
    `N:;${namaOwner};;;\n` +
    `FN:${namaOwner}\n` +
    'ORG:null\n' +
    'TITLE:\n' +
    `item1.TEL;waid=${i}:${i}\n` +
    'item1.X-ABLabel:Ponsel\n' +
    `X-WA-BIZ-DESCRIPTION:${desk}\n` +
    `X-WA-BIZ-NAME:${namaOwner}\n` +
    'END:VCARD'
})
}
yonz.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
}
	
	yonz.sendContact = async (jid, kon, quoted = '', opts = {}) => {
		let list = []
		for (let i of kon) {
			list.push({
				displayName: await yonz.getName(i + '@s.whatsapp.net'),
				vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await yonz.getName(i + '@s.whatsapp.net')}\nFN:${await yonz.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.ADR:;;Indonesia;;;;\nitem2.X-ABLabel:Region\nEND:VCARD`
			})
		}
		yonz.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })
	}
	
	yonz.profilePictureUrl = async (jid, type = 'image', timeoutMs) => {
		try {
			const result = await yonz.query({
				tag: 'iq',
				attrs: {
					target: jidNormalizedUser(jid),
					to: '@s.whatsapp.net',
					type: 'get',
					xmlns: 'w:profile:picture'
				},
				content: [{
					tag: 'picture',
					attrs: {
						type, query: 'url'
					},
				}]
			}, timeoutMs);
			const child = getBinaryNodeChild(result, 'picture');
			return child?.attrs?.url;
		} catch {
			return null;
		}
	}
	
	yonz.setStatus = (status) => {
		yonz.query({
			tag: 'iq',
			attrs: {
				to: '@s.whatsapp.net',
				type: 'set',
				xmlns: 'status',
			},
			content: [{
				tag: 'status',
				attrs: {},
				content: Buffer.from(status, 'utf-8')
			}]
		})
		return status
	}
	
	yonz.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
		const quotedOptions = { quoted }
		async function getFileUrl(res, mime) {
			if (mime && mime.includes('gif')) {
				return yonz.sendMessage(jid, { video: res.data, caption: caption, gifPlayback: true, ...options }, quotedOptions);
			} else if (mime && mime === 'application/pdf') {
				return yonz.sendMessage(jid, { document: res.data, mimetype: 'application/pdf', caption: caption, ...options }, quotedOptions);
			} else if (mime && mime.includes('image')) {
				return yonz.sendMessage(jid, { image: res.data, caption: caption, ...options }, quotedOptions);
			} else if (mime && mime.includes('video')) {
				return yonz.sendMessage(jid, { video: res.data, caption: caption, mimetype: 'video/mp4', ...options }, quotedOptions);
			} else if (mime && mime.includes('webp') && !/.jpg|.jpeg|.png/.test(url)) {
				return yonz.sendAsSticker(jid, res.data, quoted, options);
			} else if (mime && mime.includes('audio')) {
				return yonz.sendMessage(jid, { audio: res.data, mimetype: 'audio/mpeg', ...options }, quotedOptions);
			} else {
				return yonz.sendMessage(jid, { document: res.data, mimetype: mime, fileName: url.split('/').pop(), caption: caption, ...options }, quotedOptions);
			}
		}
		
		try {
			const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
			let mime = res.headers['content-type'];
			if (!mime || mime.includes('octet-stream')) {
				const fileType = await FileType.fromBuffer(res.data);
				mime = fileType ? fileType.mime : 'application/octet-stream';
			}
			const hasil = await getFileUrl(res, mime);
			return hasil
		} catch (error) {
			throw new Error(`Failed to download file: ${error.message}`);
		}
	}
	
	yonz.sendTextMentions = async (jid, text, quoted, options = {}) => yonz.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted })
	
	yonz.sendAsSticker = async (jid, path, quoted, options = {}) => {
		const buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
		let buffer
	 if (options && (options.packname || options.author)) {
            buffer = await writeExif(buff, options);
        } else {
            buffer = await videoToWebp(buff);
        }
		await yonz.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buff;
	}
	
	yonz.downloadMediaMessage = async (message) => {
		try {
			const msg = message.msg || message;
			const mime = msg.mimetype || '';
			const messageType = (message.type || mime.split('/')[0]).replace(/Message/gi, '');
			const stream = await downloadContentFromMessage(msg, messageType);
			let buffer = Buffer.from([]);
			for await (const chunk of stream) {
				buffer = Buffer.concat([buffer, chunk]);
			}
			return buffer
		} catch (error) {
			throw new Error(`Failed to download media: ${error.message}`);
		}
	}
	
	yonz.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
		const buffer = await yonz.downloadMediaMessage(message);
		const type = await FileType.fromBuffer(buffer);
		const trueFileName = attachExtension ? `./library/database/sampah/${filename ? filename : Date.now()}.${type.ext}` : filename;
		await fs.promises.writeFile(trueFileName, buffer);
		return trueFileName;
	}
	
	yonz.getFile = async (PATH, save) => {
		let res;
		let filename;
		let data = Buffer.isBuffer(PATH) ? PATH : 
				   /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : 
				   /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : 
				   fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : 
				   typeof PATH === 'string' ? PATH : Buffer.alloc(0)
		
		let type = await FileType.fromBuffer(data) || { mime: 'application/octet-stream', ext: '.bin' }
		filename = path.join(__filename, '../library/database/sampah/' + new Date * 1 + '.' + type.ext)
		if (data && save) fs.promises.writeFile(filename, data)
		return {
			res,
			filename,
			size: await getSizeMedia(data),
			...type,
			data
		}
	}
	
	yonz.sendMedia = async (jid, path, fileName = '', caption = '', quoted = '', options = {}) => {
		const { mime, data, filename } = await yonz.getFile(path, true);
		const isWebpSticker = options.asSticker || /webp/.test(mime);
		let type = 'document', mimetype = mime, pathFile = filename;
		
		if (isWebpSticker) {
			const { writeExif } = require('../library/exif');
			const media = { mimetype: mime, data };
			pathFile = await writeExif(media, {
				packname: options.packname || global.packname,
				author: options.author || global.author,
				categories: options.categories || [],
			})
			await fs.promises.unlink(filename);
			type = 'sticker';
			mimetype = 'image/webp';
		} else if (/image|video|audio/.test(mime)) {
			type = mime.split('/')[0];
			mimetype = type == 'video' ? 'video/mp4' : type == 'audio' ? 'audio/mpeg' : mime
		}
		
		let anu = await yonz.sendMessage(jid, { [type]: { url: pathFile }, caption, mimetype, fileName, ...options }, { quoted, ...options });
		await fs.promises.unlink(pathFile);
		return anu;
	}
	
	// Kirim balasan sebagai bubble document ber-thumbnail jpg lokal
	// (source/media/foto/imgdokumen.jpg) -- thumbnail kecil, BUKAN foto penuh
	// dan bukan pola externalAdReply
	yonz.sendReplyThumbnail = async (jid, content, quoted = '', options = {}) => {
		const mentions = [...content.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net');
		const thumb = getReplyThumbBuffer();

		if (!thumb) {
			// fallback aman kalau file thumbnail belum ada
			return yonz.sendMessage(jid, { text: content, mentions, ...options }, { quoted });
		}

		const smallThumb = await getReplyThumbSmall();

		return yonz.sendMessage(jid, {
			document: thumb,
			mimetype: 'image/jpeg',
			fileName: `${global.botname}`,
			jpegThumbnail: smallThumb,
			caption: content,
			mentions,
			...options
		}, { quoted });
	}

	yonz.appendResponseMessage = async (m, text) => {
		let apb = await generateWAMessage(m.chat, { text, mentions: m.mentionedJid }, { userJid: yonz.user.id, quoted: m.quoted && m.quoted.fakeObj });
		apb.key = m.key
		apb.key.id = [...Array(32)].map(() => '0123456789ABCDEF'[Math.floor(Math.random() * 16)]).join('');
		apb.key.fromMe = areJidsSameUser(m.sender, yonz.user.id);
		if (m.isGroup) apb.participant = m.sender;
		yonz.ev.emit('messages.upsert', {
			...m,
			messages: [proto.WebMessageInfo.fromObject(apb)],
			type: 'append'
		});
	}
	
	return yonz
}

async function Serialize(yonz, msg, store) {
    const botNumber = yonz.decodeJid(yonz.user.id);
    const botrunning = global.owner + '@s.whatsapp.net';
    if (!msg) return msg
    const m = { ...msg };

    if (m.key) {
        m.id = m.key.id
        m.chat = m.key.remoteJid
        m.fromMe = m.key.fromMe
        m.isBaileys = m.id ? (m.id.startsWith('3EB0') || m.id.startsWith('B1E') || m.id.startsWith('BAE') || m.id.startsWith('3F8')) : false
        
        m.isBot = ['HSK', 'BAE', 'B1E', '3EB0', 'B24E', 'WA'].some(a => m.id.startsWith(a) && [12, 16, 20, 22, 40].includes(m.id.length)) || /(.)\1{5,}|[^a-zA-Z0-9]|[^0-9A-F]/.test(m.id) || false
        
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = yonz.decodeJid(m.fromMe && yonz.user.id || m.key.participant || m.chat || '')

        if (m.isGroup) {
            try {
                m.metadata = await yonz.groupMetadata(m.chat)
            } catch {
                m.metadata = {}
            }
                
            if (m.metadata.addressingMode === 'lid') {
                const participant = m.metadata.participants.find(a => a.lid === m.sender)
                m.key.participant = m.sender = participant?.id || m.sender; 
            }
            
            const admins = []
            if (m.metadata?.participants) {
                for (let p of m.metadata.participants) {
                    if (p.admin !== null) {
                        if (p.jid) admins.push(p.jid)
                        if (p.id) admins.push(p.id)
                        if (p.lid) admins.push(p.lid)
                    }
                }
            }
            m.admins = admins
            const checkAdmin = (jid, list) =>
                list.some(x =>
                    x === jid ||
                    (jid.endsWith('@s.whatsapp.net') && x === jid.replace('@s.whatsapp.net', '@lid')) ||
                    (jid.endsWith('@lid') && x === jid.replace('@lid', '@s.whatsapp.net'))
                )
            m.isAdmin = checkAdmin(m.sender, m.admins)
            m.isBotAdmin = checkAdmin(botNumber, m.admins)
            m.participant = m.key.participant || ""
        }

        m.isDeveloper = botrunning.includes(m.sender) ? true : false
    }

    if (m.message) {
        m.type = getContentType(m.message) || Object.keys(m.message)[0]
        m.msg = (/viewOnceMessage|viewOnceMessageV2Extension|editedMessage|ephemeralMessage/i.test(m.type) 
            ? m.message[m.type].message[getContentType(m.message[m.type].message)] 
            : (extractMessageContent(m.message[m.type]) || m.message[m.type]))

        let interactiveData = {}

        if (m.msg?.interactiveResponseMessage?.paramsJson) {
            try {
                interactiveData = JSON.parse(m.msg.interactiveResponseMessage.paramsJson)
            } catch (e) {
                interactiveData = {}
            }
        }

        if (m.msg?.nativeFlowResponseMessage?.paramsJson) {
            try {
                const nativeParams = JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson)
                interactiveData = { ...interactiveData, ...nativeParams }
            } catch (e) {
            }
        }

        m.interactive = interactiveData
        
        m.body = m.message?.conversation || 
                 m.msg?.text || 
                 m.msg?.conversation || 
                 m.msg?.caption || 
                 m.msg?.selectedButtonId || 
                 m.msg?.singleSelectReply?.selectedRowId || 
                 m.msg?.selectedId || 
                 m.msg?.contentText || 
                 m.msg?.selectedDisplayText || 
                 m.msg?.title || 
                 m.msg?.name || 
                 m.msg?.description || 
                 ''

		m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []
		m.text = m.msg?.text || 
                 m.msg?.caption || 
                 m.message?.conversation || 
                 m.msg?.contentText || 
                 m.msg?.selectedDisplayText || 
                 m.msg?.title || 
                 m.msg?.description || 
                 '';

        m.prefix = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(m.body) ? 
                   m.body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : 
                   /[\uD800-\uDBFF][\uDC00-\uDFFF]/gi.test(m.body) ? 
                   m.body.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/gi)[0] : ''

        m.command = m.body && m.body.replace(m.prefix, '').trim().split(/ +/).shift()
        m.args = m.body?.trim().replace(new RegExp("^" + m.prefix?.replace(/[.*=+:\-?^${}()|[\]\\]|\s/g, '\\$&'), 'i'), '')
                    .replace(m.command, '').split(/ +/).filter(a => a) || []

        m.device = getDevice(m.id)
        m.expiration = m.msg?.contextInfo?.expiration || 0
        
        m.timestamp = (typeof m.messageTimestamp === 'number' 
            ? m.messageTimestamp 
            : m.messageTimestamp?.low 
            ? m.messageTimestamp.low 
            : m.messageTimestamp?.high) || m.msg.timestampMs * 1000

        m.isMedia = !!m.msg?.mimetype || !!m.msg?.thumbnailDirectPath || !!m.msg?.jpegThumbnail
        if (m.isMedia) {
            m.mime = m.msg?.mimetype
            m.size = m.msg?.fileLength
            m.height = m.msg?.height || ''
            m.width = m.msg?.width || ''
            if (/webp/i.test(m.mime)) {
                m.isAnimated = m.msg?.isAnimated
            }
        }

        m.quoted = m.msg?.contextInfo?.quotedMessage || null
        if (m.quoted) {
            if (m.isGroup && m.msg?.contextInfo?.participant?.endsWith('@lid')) { 
                m.msg.contextInfo.participant =  m?.metadata?.participants?.find(a => a.lid === m.msg.contextInfo.participant)?.id || m.msg.contextInfo.participant;
            }
            
            m.quoted.message = extractMessageContent(m.msg?.contextInfo?.quotedMessage)
            m.quoted.type = getContentType(m.quoted.message) || Object.keys(m.quoted.message)[0]
            m.quoted.id = m.msg.contextInfo.stanzaId
            m.quoted.device = getDevice(m.quoted.id)
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
            
            m.quoted.isBot = m.quoted.id ? 
                ['HSK', 'BAE', 'B1E', '3EB0', 'B24E', 'WA'].some(a => m.quoted.id.startsWith(a) && [12, 16, 20, 22, 40].includes(m.quoted.id.length)) || 
                /(.)\1{5,}|[^a-zA-Z0-9]|[^0-9A-F]/.test(m.quoted.id) : false
            
            m.quoted.sender = yonz.decodeJid(m.msg.contextInfo.participant)
            m.quoted.fromMe = m.quoted.sender === yonz.decodeJid(yonz.user.id)
            m.quoted.text = m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || m.quoted.description || ''
            m.quoted.msg = extractMessageContent(m.quoted.message[m.quoted.type]) || m.quoted.message[m.quoted.type]
            m.quoted.mentionedJid = m.quoted?.msg?.contextInfo?.mentionedJid || []
            
            m.quoted.body = m.quoted.msg?.text || 
                           m.quoted.msg?.caption || 
                           m.quoted?.message?.conversation || 
                           m.quoted.msg?.selectedButtonId || 
                           m.quoted.msg?.singleSelectReply?.selectedRowId || 
                           m.quoted.msg?.selectedId || 
                           m.quoted.msg?.contentText || 
                           m.quoted.msg?.selectedDisplayText || 
                           m.quoted.msg?.title || 
                           m.quoted?.msg?.name || 
                           m.quoted.msg?.description || 
                           ''

			m.getQuotedObj = async () => {
				if (!m.quoted.id) return false
				let q = await store.loadMessage(m.chat, m.quoted.id, yonz)
				return await Serialize(yonz, q, store)
			}
            
            m.quoted.key = {
                remoteJid: m.msg?.contextInfo?.remoteJid || m.chat,
                participant: m.quoted.sender,
                fromMe: areJidsSameUser(yonz.decodeJid(m.msg?.contextInfo?.participant), yonz.decodeJid(yonz?.user?.id)),
                id: m.msg?.contextInfo?.stanzaId,
            }
            
            m.quoted.isGroup = m.quoted.chat.endsWith('@g.us')
            m.quoted.mentions = m.quoted.msg?.contextInfo?.mentionedJid || []
            
            m.quoted.prefix = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(m.quoted.body) ? 
                             m.quoted.body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : 
                             /[\uD800-\uDBFF][\uDC00-\uDFFF]/gi.test(m.quoted.body) ? 
                             m.quoted.body.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/gi)[0] : ''

            m.quoted.command = m.quoted.body && m.quoted.body.replace(m.quoted.prefix, '').trim().split(/ +/).shift()
            m.quoted.isMedia = !!m.quoted.msg?.mimetype || !!m.quoted.msg?.thumbnailDirectPath || !!m.quoted.msg?.jpegThumbnail
            
            if (m.quoted.isMedia) {
                m.quoted.mime = m.quoted.msg?.mimetype
                m.quoted.size = m.quoted.msg?.fileLength
                m.quoted.height = m.quoted.msg?.height || ''
                m.quoted.width = m.quoted.msg?.width || ''
                if (/webp/i.test(m.quoted.mime)) {
                    m.quoted.isAnimated = m?.quoted?.msg?.isAnimated || false
                }
            }
            
            m.quoted.fakeObj = proto.WebMessageInfo.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id,
                },
                message: m.quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {}),
            })
            
            m.quoted.download = () => yonz.downloadMediaMessage(m.quoted)
            m.quoted.delete = () => {
                yonz.sendMessage(m.quoted.chat, {
                    delete: {
                        remoteJid: m.quoted.chat,
                        fromMe: m.isBotAdmin ? false : true,
                        id: m.quoted.id,
                        participant: m.quoted.sender,
                    },
                })
            }
        }
    }

    m.download = () => yonz.downloadMediaMessage(m)
    
    m.copy = () => Serialize(yonz, proto.WebMessageInfo.fromObject(proto.WebMessageInfo.toObject(m)))
    
    m.react = (u) => yonz.sendMessage(m.chat, { react: { text: u, key: m.key }})
    
    m.reply = async (content, options = {}) => {
        const { quoted = m, chat = m.chat, caption = '', ...validate } = options;
        
        if (typeof content === 'object') {
            return yonz.sendMessage(chat, content, { ...options, quoted })
        } else if (typeof content === 'string') {
            try {
                if (/^https?:\/\//.test(content)) {
                    const data = await axios.get(content, { responseType: 'arraybuffer', timeout: 30000 });
                    const mime = data.headers['content-type'] || (await FileType.fromBuffer(data.data))?.mime
                    if (/gif|image|video|audio|pdf/i.test(mime)) {
                        return yonz.sendFileUrl(chat, content, caption, quoted, options)
                    } else {
                        return yonz.sendMessage(chat, { 
                            text: content, 
                            mentions: [...content.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), 
                            ...options 
                        }, { quoted })
                    }
                } else {
                    return yonz.sendReplyThumbnail(chat, content, quoted, options)
                }
            } catch (e) {
                return yonz.sendReplyThumbnail(chat, content, quoted, options)
            }
        }
    }

    m.pushName = m.pushName || m.verifiedBizName || 'User'

    return m
}

module.exports = { LoadDataBase, MessagesUpsert, Solving }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});