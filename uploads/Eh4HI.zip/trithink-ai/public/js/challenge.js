/**
 * ============================================================
 *  public/js/challenge.js
 * ------------------------------------------------------------
 *  AI Challenge Mode: setelah AI menjawab, user bisa tekan
 *  tombol "Challenge" untuk minta AI mengkritik jawabannya
 *  sendiri dan memberikan versi yang lebih kuat.
 * ============================================================
 */

const TriChallenge = (() => {
  let isRunning = false;

  function esc(s) {
    const d = document.createElement("div"); d.textContent = s ?? ""; return d.innerHTML;
  }

  /**
   * Tambahkan tombol Challenge ke bubble AI terbaru.
   * Dipanggil dari chat.js setelah jawaban ditambahkan.
   */
  function addChallengeButton(questionText, answerText, bubbleEl) {
    if (!bubbleEl) return;
    // Hapus tombol lama kalau ada
    bubbleEl.querySelectorAll(".challenge-trigger-btn").forEach(b => b.remove());

    const btn = document.createElement("button");
    btn.className = "challenge-trigger-btn";
    btn.innerHTML = `
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z"/><path d="M12 8v4M12 16h.01"/></svg>
      AI Challenge`;
    btn.title = "Minta AI mengkritik dan mencari kelemahan jawabannya sendiri";
    btn.addEventListener("click", () => runChallenge(questionText, answerText, bubbleEl));
    bubbleEl.appendChild(btn);
  }

  async function runChallenge(question, answer, bubbleEl) {
    if (isRunning) return;
    isRunning = true;

    // Ganti tombol jadi loading
    const btn = bubbleEl.querySelector(".challenge-trigger-btn");
    if (btn) { btn.disabled = true; btn.textContent = "Menganalisis..."; }

    // Hapus hasil challenge lama kalau ada
    bubbleEl.querySelector(".challenge-result")?.remove();

    const res = await TriAPI.post("/api/challenge", { question, answer });
    isRunning = false;

    if (btn) btn.remove(); // hapus tombol setelah challenge

    const resultEl = document.createElement("div");
    resultEl.className = "challenge-result";

    if (!res.ok) {
      resultEl.innerHTML = `<div class="challenge-error">⚠️ Gagal menjalankan AI Challenge: ${esc(res.error)}</div>`;
      bubbleEl.appendChild(resultEl);
      return;
    }

    const { weaknesses, missed_angles, confidence_original, confidence_improved, improved_answer, modelUsed } = res;
    const hasWeaknesses = weaknesses && weaknesses.length > 0;
    const hasMissed = missed_angles && missed_angles.length > 0;

    const confHtml = (confidence_original != null && confidence_improved != null) ? `
      <div class="challenge-conf-row">
        <div class="challenge-conf-item">
          <span class="conf-label">Kepercayaan Awal</span>
          <span class="conf-val ${confidence_original < 70 ? "low" : "high"}">${confidence_original}%</span>
        </div>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        <div class="challenge-conf-item">
          <span class="conf-label">Setelah Revisi</span>
          <span class="conf-val high">${confidence_improved}%</span>
        </div>
      </div>` : "";

    const weakHtml = hasWeaknesses ? `
      <div class="challenge-section">
        <div class="challenge-section-title">🔍 Kelemahan Ditemukan</div>
        <ul class="challenge-list">${weaknesses.map(w => `<li>${esc(w)}</li>`).join("")}</ul>
      </div>` : "";

    const missedHtml = hasMissed ? `
      <div class="challenge-section">
        <div class="challenge-section-title">💡 Sudut Pandang Terlewat</div>
        <ul class="challenge-list">${missed_angles.map(m => `<li>${esc(m)}</li>`).join("")}</ul>
      </div>` : "";

    const noWeaknessHtml = !hasWeaknesses && !hasMissed ? `
      <div class="challenge-strong">✅ Jawaban sudah kuat — tidak ada kelemahan berarti yang ditemukan.</div>` : "";

    resultEl.innerHTML = `
      <div class="challenge-header">
        <span class="challenge-badge">⚡ AI Challenge</span>
        <span class="challenge-model">by ${esc(modelUsed || "AI")}</span>
      </div>
      ${confHtml}
      ${weakHtml}
      ${missedHtml}
      ${noWeaknessHtml}
      ${hasWeaknesses || hasMissed ? `
        <details class="challenge-improved">
          <summary>✨ Lihat Jawaban yang Diperkuat</summary>
          <div class="challenge-improved-content">${esc(improved_answer)}</div>
        </details>` : ""}`;

    bubbleEl.appendChild(resultEl);

    // Scroll ke result
    requestAnimationFrame(() => {
      resultEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }

  return { addChallengeButton, runChallenge };
})();
