/**
 * ============================================================
 *  public/js/memory.js
 * ------------------------------------------------------------
 *  Panel "Memory" — tampilkan semua hal yang AI ingat tentang
 *  user, bisa tambah manual, hapus satu-satu, atau hapus semua.
 * ============================================================
 */

const TriMemory = (() => {
  let isOpen = false;
  let memories = [];

  function esc(s) {
    const d = document.createElement("div");
    d.textContent = s ?? "";
    return d.innerHTML;
  }

  const categoryLabel = {
    identity: "👤 Identitas",
    preference: "❤️ Preferensi",
    goal: "🎯 Tujuan",
    project: "📁 Proyek",
    technical: "⚙️ Teknis",
    general: "💡 Umum",
    other: "📝 Lainnya",
  };

  function groupByCategory(mems) {
    const groups = {};
    mems.forEach(m => {
      const cat = m.category || "general";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(m);
    });
    return groups;
  }

  function renderPanel() {
    const panel = document.getElementById("memoryPanel");
    if (!panel) return;

    if (!TriAuth.isLoggedIn()) {
      panel.innerHTML = `
        <div class="mp-header">
          <div class="mp-title">🧠 Memori AI</div>
          <button class="mp-close-btn" id="btnMemoryClose">✕</button>
        </div>
        <div class="mp-empty">Login untuk menggunakan fitur Memory.</div>`;
      document.getElementById("btnMemoryClose")?.addEventListener("click", close);
      return;
    }

    const groups = groupByCategory(memories);
    const totalCount = memories.length;

    let groupsHtml = "";
    if (totalCount === 0) {
      groupsHtml = `<div class="mp-empty">Belum ada memori tersimpan.<br><span style="font-size:11px;color:var(--text-tertiary)">AI akan otomatis mengingat fakta penting dari percakapanmu.</span></div>`;
    } else {
      Object.entries(groups).forEach(([cat, mems]) => {
        groupsHtml += `
          <div class="mp-group">
            <div class="mp-group-label">${categoryLabel[cat] || cat}</div>
            ${mems.map(m => `
              <div class="mp-item" data-id="${m.id}">
                <div class="mp-item-body">
                  <div class="mp-item-key">${esc(m.mem_key.replace(/_/g, " "))}</div>
                  <div class="mp-item-val">${esc(m.mem_value)}</div>
                </div>
                <div class="mp-item-actions">
                  ${m.auto_extracted ? '<span class="mp-auto-badge">auto</span>' : ''}
                  <button class="mp-del-btn" data-id="${m.id}" title="Hapus memori ini">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6h16Z"/></svg>
                  </button>
                </div>
              </div>`).join("")}
          </div>`;
      });
    }

    panel.innerHTML = `
      <div class="mp-header">
        <div class="mp-title">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z"/><path d="M12 8v4l3 3"/></svg>
          Memori AI <span class="mp-count">${totalCount}</span>
        </div>
        <div style="display:flex;gap:6px;align-items:center;">
          ${totalCount > 0 ? `<button class="mp-clear-btn" id="btnMemoryClearAll">Hapus semua</button>` : ""}
          <button class="mp-close-btn" id="btnMemoryClose">✕</button>
        </div>
      </div>

      <div class="mp-info">
        AI menggunakan memori ini sebagai konteks tambahan untuk semua percakapanmu. Memori baru diekstrak otomatis setelah setiap sesi.
      </div>

      <div class="mp-list" id="mpList">${groupsHtml}</div>

      <div class="mp-add-form">
        <div class="mp-add-title">+ Tambah memori manual</div>
        <input type="text" id="mpNewKey" placeholder="Nama / Label (mis. bahasa_favorit)" class="mp-input">
        <input type="text" id="mpNewVal" placeholder="Nilai (mis. Python)" class="mp-input">
        <select id="mpNewCat" class="mp-input mp-select">
          <option value="general">💡 Umum</option>
          <option value="identity">👤 Identitas</option>
          <option value="preference">❤️ Preferensi</option>
          <option value="goal">🎯 Tujuan</option>
          <option value="project">📁 Proyek</option>
          <option value="technical">⚙️ Teknis</option>
        </select>
        <button class="mp-add-btn" id="btnMemoryAdd">Simpan</button>
      </div>`;

    // Bind events
    document.getElementById("btnMemoryClose")?.addEventListener("click", close);

    document.getElementById("btnMemoryClearAll")?.addEventListener("click", async () => {
      if (!confirm("Hapus SEMUA memori AI tentang kamu? Tindakan ini tidak bisa dibatalkan.")) return;
      await TriAPI.del("/api/memory?all=1");
      await fetchMemories();
      Toast.show("Semua memori dihapus.", "default");
    });

    panel.querySelectorAll(".mp-del-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        await TriAPI.del(`/api/memory?id=${id}`);
        memories = memories.filter(m => String(m.id) !== id);
        renderPanel();
        Toast.show("Memori dihapus.", "default");
      });
    });

    document.getElementById("btnMemoryAdd")?.addEventListener("click", async () => {
      const key = document.getElementById("mpNewKey")?.value.trim();
      const value = document.getElementById("mpNewVal")?.value.trim();
      const category = document.getElementById("mpNewCat")?.value;
      if (!key || !value) { Toast.show("Key dan nilai harus diisi.", "error"); return; }
      const btn = document.getElementById("btnMemoryAdd");
      btn.disabled = true; btn.textContent = "Menyimpan...";
      const res = await TriAPI.post("/api/memory", { key, value, category });
      btn.disabled = false; btn.textContent = "Simpan";
      if (res.ok) {
        await fetchMemories();
        Toast.show("Memori disimpan!", "success");
      } else {
        Toast.show(res.error || "Gagal menyimpan.", "error");
      }
    });

    // Enter untuk submit
    const handleEnter = e => { if (e.key === "Enter") document.getElementById("btnMemoryAdd")?.click(); };
    document.getElementById("mpNewKey")?.addEventListener("keydown", handleEnter);
    document.getElementById("mpNewVal")?.addEventListener("keydown", handleEnter);
  }

  async function fetchMemories() {
    if (!TriAuth.isLoggedIn()) { memories = []; renderPanel(); return; }
    const res = await TriAPI.get("/api/memory");
    memories = res.ok ? (res.memories || []) : [];
    renderPanel();
  }

  function open() {
    if (isOpen) { close(); return; }
    isOpen = true;

    let panel = document.getElementById("memoryPanel");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "memoryPanel";
      panel.className = "memory-panel glass";
      document.body.appendChild(panel);
    }

    let scrim = document.getElementById("memoryScrim");
    if (!scrim) {
      scrim = document.createElement("div");
      scrim.id = "memoryScrim";
      scrim.className = "status-scrim"; // pakai style scrim yang sama
      document.body.appendChild(scrim);
      scrim.addEventListener("click", close);
    }

    requestAnimationFrame(() => {
      panel.classList.add("open");
      scrim.classList.add("show");
    });

    panel.innerHTML = `<div class="mp-loading"><span class="thinking-spinner"></span> Memuat memori...</div>`;
    fetchMemories();
  }

  function close() {
    isOpen = false;
    const panel = document.getElementById("memoryPanel");
    const scrim = document.getElementById("memoryScrim");
    if (panel) {
      panel.classList.remove("open");
      setTimeout(() => panel.remove(), 280);
    }
    if (scrim) {
      scrim.classList.remove("show");
      setTimeout(() => scrim.remove(), 280);
    }
  }

  // Dipanggil dari luar untuk refresh setelah auto-extract
  function refreshIfOpen() {
    if (isOpen) fetchMemories();
  }

  function init() {
    const btn = document.getElementById("btnMemory");
    if (btn) btn.addEventListener("click", open);
  }

  return { init, open, close, refreshIfOpen };
})();
