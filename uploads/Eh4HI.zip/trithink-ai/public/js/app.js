/**
 * ============================================================
 *  public/js/app.js
 * ------------------------------------------------------------
 *  Entry point: inisialisasi semua modul saat halaman dimuat,
 *  serta logika buka/tutup sidebar (overlay di mobile, kolom
 *  collapsible di desktop).
 * ============================================================
 */

(function bootstrap() {
  function isDesktop() {
    return window.innerWidth >= 900;
  }

  function initSidebarToggle() {
    const sidebar = document.getElementById("sidebar");
    const scrim = document.getElementById("sidebarScrim");
    const toggleBtn = document.getElementById("btnToggleSidebar");
    const closeBtn = document.getElementById("btnCloseSidebar");

    function openSidebar() {
      if (isDesktop()) {
        sidebar.classList.remove("closed-desktop");
      } else {
        sidebar.classList.add("open");
        scrim.classList.add("show");
      }
      localStorage.setItem("tt_sidebar_state", "open");
    }

    function closeSidebar() {
      if (isDesktop()) {
        sidebar.classList.add("closed-desktop");
      } else {
        sidebar.classList.remove("open");
        scrim.classList.remove("show");
      }
      localStorage.setItem("tt_sidebar_state", "closed");
    }

    function toggleSidebar() {
      const isOpen = isDesktop()
        ? !sidebar.classList.contains("closed-desktop")
        : sidebar.classList.contains("open");
      if (isOpen) closeSidebar();
      else openSidebar();
    }

    // Initial state: desktop starts open, mobile starts closed
    if (isDesktop()) {
      const saved = localStorage.getItem("tt_sidebar_state");
      if (saved === "closed") sidebar.classList.add("closed-desktop");
    } else {
      sidebar.classList.remove("open");
    }

    toggleBtn.addEventListener("click", toggleSidebar);
    closeBtn.addEventListener("click", closeSidebar);
    scrim.addEventListener("click", closeSidebar);

    // Saat resize melewati breakpoint, reset state biar tidak nyangkut
    let lastIsDesktop = isDesktop();
    window.addEventListener("resize", () => {
      const nowDesktop = isDesktop();
      if (nowDesktop !== lastIsDesktop) {
        lastIsDesktop = nowDesktop;
        sidebar.classList.remove("open", "closed-desktop");
        scrim.classList.remove("show");
        if (!nowDesktop) sidebar.classList.remove("open");
      }
    });

    // Tutup sidebar otomatis di mobile setelah memilih riwayat / mulai chat baru
    document.addEventListener("click", (e) => {
      if (isDesktop()) return;
      const closeTriggers = e.target.closest(".history-item, #btnNewChat");
      if (closeTriggers) closeSidebar();
    });
  }

  function initMonitorCollapse() {
    const header = document.getElementById("monitorHeader");
    const list = document.getElementById("monitorList");
    header.addEventListener("click", () => {
      const isHidden = list.style.display === "none";
      list.style.display = isHidden ? "flex" : "none";
    });
  }

  async function init() {
    // Setiap modul dibungkus try-catch sendiri-sendiri. Kalau satu
    // bagian gagal (mis. elemen DOM belum siap / error kecil), bagian
    // lain tetap jalan dan halaman tidak blank total.
    safeRun("initSidebarToggle", initSidebarToggle);
    safeRun("initMonitorCollapse", initMonitorCollapse);
    safeRun("TriAuth.initUI", () => TriAuth.initUI());
    safeRun("TriChat.initUI", () => TriChat.initUI());
    safeRun("TriMonitor.initUI", () => TriMonitor.initUI());
    safeRun("TriServerStatus.init", () => TriServerStatus.init());
    safeRun("TriMemory.init", () => TriMemory.init());
    safeRun("TriProjects.init", () => TriProjects.init());

    try {
      const user = await TriAuth.checkSession();
      if (user) {
        TriChat.refreshHistory();
      } else {
        setTimeout(() => {
          if (!TriAuth.isLoggedIn()) TriAuth.openModal("login");
        }, 900);
      }
    } catch (err) {
      console.error("checkSession gagal:", err);
    }
  }

  function safeRun(label, fn) {
    try {
      fn();
    } catch (err) {
      console.error(`[TriThink AI] Gagal inisialisasi "${label}":`, err);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
