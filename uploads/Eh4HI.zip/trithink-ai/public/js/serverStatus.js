/**
 * ============================================================
 *  public/js/serverStatus.js
 * ------------------------------------------------------------
 *  Panel "Server Status" yang muncul saat tombol di sidebar
 *  ditekan. Menampilkan:
 *  - Status tiap server (good/warn/down) dengan grafik latency
 *  - Nama server, model AI, kategori
 *  - URL endpoint (domain), method, timeout
 *  - User-Agent aktif
 *  - Rata-rata, min, max latency + uptime %
 *  - Tombol refresh manual
 * ============================================================
 */

const TriServerStatus = (() => {
  let isOpen = false;
  let lastData = null;
  let refreshTimer = null;

  // ---------- Helpers ----------

  function escHtml(s) {
    const d = document.createElement("div");
    d.textContent = s ?? "";
    return d.innerHTML;
  }

  function statusColor(s) {
    if (s === "good") return "var(--status-good)";
    if (s === "warn") return "var(--status-warn)";
    return "var(--status-down)";
  }

  function statusLabel(s) {
    if (s === "good") return "Online";
    if (s === "warn") return "Lambat";
    return "Down";
  }

  function catLabel(c) {
    const m = { daily: "Daily Chat", agent: "AI Agent", image: "Image AI", search: "Web Search" };
    return m[c] || c;
  }

  function fmtMs(ms) {
    if (ms == null) return "—";
    if (ms >= 1000) return (ms / 1000).toFixed(1) + "s";
    return ms + "ms";
  }

  function timeAgo(isoStr) {
    if (!isoStr) return "";
    const diff = Math.floor((Date.now() - new Date(isoStr).getTime()) / 1000);
    if (diff < 60) return `${diff}d lalu`;
    if (diff < 3600) return `${Math.floor(diff/60)}m lalu`;
    return `${Math.floor(diff/3600)}j lalu`;
  }

  // ---------- Mini bar chart untuk latency history ----------

  function buildMiniChart(history, currentStatus) {
    if (!history || history.length === 0) {
      return `<div class="ss-chart-empty">Belum ada data histori</div>`;
    }
    const max = Math.max(...history.map(h => h.latencyMs), 1);
    const bars = history.map(h => {
      const pct = Math.round((h.latencyMs / max) * 100);
      const col = statusColor(h.status);
      return `<div class="ss-bar" style="height:${Math.max(pct, 4)}%;background:${col};" title="${h.latencyMs}ms"></div>`;
    }).join("");
    return `
      <div class="ss-chart">
        <div class="ss-chart-bars">${bars}</div>
        <div class="ss-chart-labels">
          <span>${history.length > 0 ? history.length + " ping" : ""}</span>
          <span>max ${fmtMs(max)}</span>
        </div>
      </div>`;
  }

  // ---------- Render ----------

  function buildPanel(data) {
    if (!data) return `<div class="ss-loading">Memuat data server...</div>`;

    const { servers, summary, globalInfo, generatedAt } = data;

    const summaryHtml = `
      <div class="ss-summary-row">
        <div class="ss-summary-item good">
          <span class="ss-sum-num">${summary.good}</span>
          <span class="ss-sum-lbl">Online</span>
        </div>
        <div class="ss-summary-item warn">
          <span class="ss-sum-num">${summary.warn}</span>
          <span class="ss-sum-lbl">Lambat</span>
        </div>
        <div class="ss-summary-item down">
          <span class="ss-sum-num">${summary.down}</span>
          <span class="ss-sum-lbl">Down</span>
        </div>
        <div class="ss-summary-item neutral">
          <span class="ss-sum-num">${summary.total}</span>
          <span class="ss-sum-lbl">Total</span>
        </div>
      </div>`;

    const cardsHtml = servers.map(s => `
      <div class="ss-card" data-status="${s.status}">
        <div class="ss-card-header">
          <span class="ss-status-badge" style="background:${statusColor(s.status)}20;color:${statusColor(s.status)};border-color:${statusColor(s.status)}40;">
            <span class="ss-status-dot" style="background:${statusColor(s.status)};box-shadow:0 0 6px ${statusColor(s.status)};"></span>
            ${statusLabel(s.status)}
          </span>
          <span class="ss-cat-badge">${escHtml(catLabel(s.category))}</span>
          <span class="ss-latency-badge">${fmtMs(s.latencyMs)}</span>
        </div>

        <div class="ss-card-title">${escHtml(s.serverName)}</div>
        <div class="ss-card-model">${escHtml(s.modelName)}</div>

        ${buildMiniChart(s.latencyHistory, s.status)}

        <div class="ss-card-stats">
          <div class="ss-stat">
            <span class="ss-stat-lbl">Rata-rata</span>
            <span class="ss-stat-val">${fmtMs(s.avgLatencyMs)}</span>
          </div>
          <div class="ss-stat">
            <span class="ss-stat-lbl">Min</span>
            <span class="ss-stat-val">${fmtMs(s.minLatencyMs)}</span>
          </div>
          <div class="ss-stat">
            <span class="ss-stat-lbl">Maks</span>
            <span class="ss-stat-val">${fmtMs(s.maxLatencyMs)}</span>
          </div>
          <div class="ss-stat">
            <span class="ss-stat-lbl">Uptime</span>
            <span class="ss-stat-val">${s.uptimePercent != null ? s.uptimePercent + "%" : "—"}</span>
          </div>
        </div>

        <div class="ss-card-meta">
          ${s.endpointPath ? `<div class="ss-meta-row"><span class="ss-meta-key">Endpoint</span><span class="ss-meta-val url">${escHtml(s.endpointPath)}</span></div>` : ""}
          ${s.method ? `<div class="ss-meta-row"><span class="ss-meta-key">Method</span><span class="ss-meta-val">${escHtml(s.method)}</span></div>` : ""}
          ${s.timeoutMs ? `<div class="ss-meta-row"><span class="ss-meta-key">Timeout</span><span class="ss-meta-val">${fmtMs(s.timeoutMs)}</span></div>` : ""}
          ${s.error ? `<div class="ss-meta-row error"><span class="ss-meta-key">Error</span><span class="ss-meta-val">${escHtml(s.error)}</span></div>` : ""}
        </div>

        <details class="ss-ua-details">
          <summary>User-Agent</summary>
          <div class="ss-ua-text">${escHtml(s.userAgent || globalInfo?.defaultUserAgent || "—")}</div>
        </details>
      </div>`).join("");

    const globalHtml = globalInfo ? `
      <div class="ss-global-info">
        <div class="ss-section-label">Konfigurasi Global</div>
        <div class="ss-meta-row"><span class="ss-meta-key">Default Timeout</span><span class="ss-meta-val">${fmtMs(globalInfo.defaultTimeoutMs)}</span></div>
        <div class="ss-meta-row"><span class="ss-meta-key">User-Agent Default</span></div>
        <div class="ss-ua-text" style="margin-top:4px;">${escHtml(globalInfo.defaultUserAgent)}</div>
      </div>` : "";

    return `
      <div class="ss-header">
        <div class="ss-title">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
          Server Status
        </div>
        <div class="ss-header-right">
          <span class="ss-updated">${timeAgo(generatedAt)}</span>
          <button class="ss-refresh-btn" id="btnStatusRefresh" type="button" title="Refresh">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2v6h-6M3 22v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L21 8M3 16l2.64 2.36A9 9 0 0 0 20.49 15"/></svg>
          </button>
          <button class="ss-close-btn" id="btnStatusClose" type="button">✕</button>
        </div>
      </div>
      ${summaryHtml}
      <div class="ss-cards">${cardsHtml}</div>
      ${globalHtml}`;
  }

  // ---------- Open / Close ----------

  function render() {
    const panel = document.getElementById("serverStatusPanel");
    if (!panel) return;
    panel.innerHTML = buildPanel(lastData);

    // Re-bind buttons setelah render ulang
    const closeBtn = document.getElementById("btnStatusClose");
    if (closeBtn) closeBtn.addEventListener("click", close);

    const refreshBtn = document.getElementById("btnStatusRefresh");
    if (refreshBtn) {
      refreshBtn.addEventListener("click", async () => {
        refreshBtn.classList.add("spinning");
        await fetchData();
        render();
        refreshBtn.classList.remove("spinning");
      });
    }
  }

  async function fetchData() {
    try {
      const res = await TriAPI.get("/api/monitor");
      if (res.ok) lastData = res;
    } catch (err) {
      console.error("serverStatus fetchData:", err);
    }
  }

  function open() {
    if (isOpen) { close(); return; }
    isOpen = true;

    // Buat panel kalau belum ada
    let panel = document.getElementById("serverStatusPanel");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "serverStatusPanel";
      panel.className = "server-status-panel glass";
      document.body.appendChild(panel);
    }

    // Buat scrim
    let scrim = document.getElementById("statusScrim");
    if (!scrim) {
      scrim = document.createElement("div");
      scrim.id = "statusScrim";
      scrim.className = "status-scrim";
      document.body.appendChild(scrim);
      scrim.addEventListener("click", close);
    }

    // Animasi masuk
    requestAnimationFrame(() => {
      panel.classList.add("open");
      scrim.classList.add("show");
    });

    panel.innerHTML = `<div class="ss-loading"><span class="thinking-spinner"></span> Memuat data server...</div>`;

    fetchData().then(() => {
      render();
      // Auto-refresh setiap 30 detik selagi panel terbuka
      refreshTimer = setInterval(async () => {
        await fetchData();
        render();
      }, 30000);
    });
  }

  function close() {
    isOpen = false;
    if (refreshTimer) { clearInterval(refreshTimer); refreshTimer = null; }

    const panel = document.getElementById("serverStatusPanel");
    const scrim = document.getElementById("statusScrim");
    if (panel) {
      panel.classList.remove("open");
      setTimeout(() => { if (panel.parentNode) panel.parentNode.removeChild(panel); }, 280);
    }
    if (scrim) {
      scrim.classList.remove("show");
      setTimeout(() => { if (scrim.parentNode) scrim.parentNode.removeChild(scrim); }, 280);
    }
  }

  function init() {
    const btn = document.getElementById("btnServerStatus");
    if (btn) btn.addEventListener("click", open);
  }

  return { init, open, close };
})();
