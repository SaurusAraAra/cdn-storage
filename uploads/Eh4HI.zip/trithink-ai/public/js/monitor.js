/**
 * ============================================================
 *  public/js/monitor.js
 * ------------------------------------------------------------
 *  Mengambil & menampilkan status server AI di sidebar
 *  (hijau = baik, kuning = lambat, merah = down).
 * ============================================================
 */

const TriMonitor = (() => {
  let intervalId = null;

  function dotColor(status) {
    if (status === "good") return "var(--status-good)";
    if (status === "warn") return "var(--status-warn)";
    return "var(--status-down)";
  }

  function render(data) {
    const list = document.getElementById("monitorList");
    const summaryDot = document.getElementById("monitorSummaryDot");
    const ssDot = document.getElementById("ssSummaryDot"); // dot di tombol Server Status

    if (!data || !data.servers) {
      list.innerHTML = `<div class="monitor-row"><span style="color:var(--text-tertiary);font-size:11px;">Gagal memuat status server.</span></div>`;
      if (summaryDot) { summaryDot.style.background = "var(--status-down)"; summaryDot.style.color = "var(--status-down)"; }
      return;
    }

    const { servers, summary } = data;
    let overall = "good";
    if (summary.down > 0 && summary.good === 0 && summary.warn === 0) overall = "down";
    else if (summary.down > 0 || summary.warn > 0) overall = "warn";

    const col = dotColor(overall);
    if (summaryDot) { summaryDot.style.background = col; summaryDot.style.color = col; }
    if (ssDot) { ssDot.style.background = col; ssDot.style.color = col; ssDot.style.boxShadow = `0 0 6px ${col}`; }

    list.innerHTML = servers
      .map(s => `
        <div class="monitor-row" title="${s.error ? escapeHtml(s.error) : "Status baik"}">
          <span class="monitor-status-dot ${s.status}"></span>
          <span class="monitor-row-name">${escapeHtml(s.serverName)}</span>
          <span class="monitor-row-model">${escapeHtml(s.modelName)}</span>
          <span class="monitor-row-latency">${s.status === "down" ? "down" : s.latencyMs + "ms"}</span>
        </div>`)
      .join("");
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str ?? "";
    return div.innerHTML;
  }

  async function refresh() {
    const btn = document.getElementById("btnRefreshMonitor");
    btn.classList.add("spinning");
    const res = await TriAPI.get("/api/monitor");
    btn.classList.remove("spinning");
    if (res.ok) {
      render(res);
    } else {
      render(null);
    }
  }

  // ---------------- Database fallback banner ----------------
  function renderFallbackBanner(status) {
    const banner = document.getElementById("dbFallbackBanner");
    const text = document.getElementById("dbFallbackText");
    if (!banner || !text) return;

    if (!status || status.mainDbReachable) {
      banner.style.display = "none";
      return;
    }

    const stats = status.fallbackStats;
    banner.style.display = "flex";

    if (stats && stats.userCount > 0) {
      text.textContent = `Mode cadangan aktif — ${stats.userCount} akun, ${stats.usedPercent}% kapasitas`;
    } else {
      text.textContent = "Database utama tidak terhubung — mode cadangan aktif";
    }
  }

  async function refreshFallbackStatus() {
    const res = await TriAPI.get("/api/storage-status");
    if (res.ok) {
      renderFallbackBanner(res);
    }
  }

  async function forceSyncFallback() {
    const btn = document.getElementById("btnForceSync");
    if (!btn) return;
    btn.disabled = true;
    btn.classList.add("syncing");
    btn.textContent = "Sync...";

    const res = await TriAPI.post("/api/storage-status?sync=1", {});

    btn.disabled = false;
    btn.classList.remove("syncing");
    btn.textContent = "Sync";

    if (res.ok) {
      const { syncResult, mainDbReachable } = res;
      if (!mainDbReachable) {
        Toast.show("Database utama masih belum bisa dihubungi.", "error");
      } else if (syncResult.syncedUsers > 0 || syncResult.syncedConversations > 0) {
        Toast.show(
          `Berhasil sinkron: ${syncResult.syncedUsers} akun, ${syncResult.syncedConversations} percakapan.`,
          "success"
        );
      } else {
        Toast.show("Database utama terhubung, tidak ada data cadangan yang perlu disinkron.", "default");
      }
      renderFallbackBanner(res);
    } else {
      Toast.show("Gagal memeriksa status sinkronisasi.", "error");
    }
  }

  function startAutoRefresh(everyMs = 60000) {
    refresh();
    refreshFallbackStatus();
    if (intervalId) clearInterval(intervalId);
    intervalId = setInterval(() => {
      refresh();
      refreshFallbackStatus();
    }, everyMs);
  }

  function initUI() {
    document.getElementById("btnRefreshMonitor").addEventListener("click", (e) => {
      e.stopPropagation();
      refresh();
    });

    const syncBtn = document.getElementById("btnForceSync");
    if (syncBtn) {
      syncBtn.addEventListener("click", forceSyncFallback);
    }

    startAutoRefresh();
  }

  return { initUI, refresh, refreshFallbackStatus };
})();
