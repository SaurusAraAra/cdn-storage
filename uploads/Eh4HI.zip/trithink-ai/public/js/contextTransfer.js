/**
 * ============================================================
 *  public/js/contextTransfer.js
 * ------------------------------------------------------------
 *  Smart Context Transfer: saat user ganti mode (mis. dari
 *  Daily Chat ke AI Agent), pesan terakhir dari sesi aktif
 *  otomatis dibawa sebagai konteks awal di mode baru.
 *
 *  CARA KERJA:
 *  - Saat mode berubah, snapshot 3 pesan terakhir dari chat
 *    aktif disimpan ke contextSnapshot.
 *  - Ketika kirim pesan pertama di mode baru, snapshot tsb
 *    diinjeksikan ke prompt sebagai "Konteks Sebelumnya".
 *  - Setelah pesan pertama terkirim, snapshot dihapus
 *    (tidak terus-menerus ikut di semua pesan).
 * ============================================================
 */

const TriContextTransfer = (() => {
  let snapshot = null; // { fromMode, messages: [{role, content}], capturedAt }
  let pendingTransfer = false;

  /**
   * Ambil snapshot pesan terakhir dari chat area yang sedang aktif.
   * Dipanggil saat user klik mode lain di picker.
   */
  function captureCurrentContext(fromMode) {
    const rows = document.querySelectorAll("#chatInner .msg-row");
    if (!rows || rows.length === 0) { snapshot = null; return; }

    const messages = [];
    rows.forEach(row => {
      const isUser = row.classList.contains("user");
      const bubble = row.querySelector(".msg-bubble");
      if (!bubble) return;
      // Ambil teks (strip HTML)
      const text = bubble.innerText?.trim();
      if (!text || text.length < 3) return;
      messages.push({ role: isUser ? "user" : "assistant", content: text.slice(0, 300) });
    });

    // Ambil maksimal 4 pesan terakhir
    const recent = messages.slice(-4);
    if (recent.length === 0) { snapshot = null; return; }

    snapshot = { fromMode, messages: recent, capturedAt: Date.now() };
    pendingTransfer = true;
  }

  /**
   * Bangun string konteks untuk diinjeksikan ke prompt pertama
   * setelah mode berpindah.
   */
  function buildTransferContext() {
    if (!snapshot || !pendingTransfer) return "";
    const modeName = { daily: "Daily Chat", agent: "AI Agent", image: "Image Mode" };
    const lines = snapshot.messages
      .map(m => `${m.role === "user" ? "User" : "AI"}: ${m.content}`)
      .join("\n");
    return `[KONTEKS DARI SESI SEBELUMNYA (${modeName[snapshot.fromMode] || snapshot.fromMode})]:\n${lines}\n\n[Lanjutkan membantu user berdasarkan konteks di atas jika relevan]\n\n`;
  }

  /**
   * Ambil konteks transfer jika ada (dan tandai sudah dikonsumsi).
   * Dipanggil sekali saat sendMessage() berjalan.
   */
  function consumeTransferContext() {
    if (!snapshot || !pendingTransfer) return "";
    const ctx = buildTransferContext();
    pendingTransfer = false; // hanya sekali dipakai
    return ctx;
  }

  /**
   * Cek apakah ada konteks yang siap ditransfer.
   */
  function hasPendingTransfer() {
    return !!snapshot && pendingTransfer;
  }

  /**
   * Hapus snapshot (misalnya saat new conversation).
   */
  function clear() {
    snapshot = null;
    pendingTransfer = false;
  }

  /**
   * Tampilkan badge kecil di topbar kalau ada context transfer aktif.
   */
  function updateTransferBadge() {
    let badge = document.getElementById("contextTransferBadge");
    if (hasPendingTransfer()) {
      if (!badge) {
        badge = document.createElement("div");
        badge.id = "contextTransferBadge";
        badge.className = "context-transfer-badge";
        badge.title = "Konteks dari mode sebelumnya akan ikut ke pesan pertamamu";
        const topbar = document.querySelector(".topbar");
        if (topbar) topbar.appendChild(badge);
      }
      const modeName = { daily: "Daily", agent: "Agent", image: "Image" };
      badge.innerHTML = `
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        Konteks dari ${modeName[snapshot?.fromMode] || "mode lama"} siap ditransfer`;
    } else {
      if (badge) badge.remove();
    }
  }

  return {
    captureCurrentContext,
    consumeTransferContext,
    hasPendingTransfer,
    clear,
    updateTransferBadge,
  };
})();
