/**
 * ============================================================
 *  public/js/chat.js (v3)
 * ============================================================
 *  PERUBAHAN DARI v2:
 *  - Bug fix: riwayat sekarang ter-update benar setelah kirim pesan
 *  - Bug fix: newConversation benar2 reset state + re-bind events
 *  - Hapus composerHint "Mode: Daily Chat..." dari bawah composer
 *  - Model picker pindah dari topbar dropdown ke toolbar composer
 *    (di sebelah kanan Web Search toggle)
 *  - Support upload gambar/foto ke chat (dikirim ke AI sebagai
 *    deskripsi base64 atau URL) — tombol 📎 di composer
 *  - Web search auto-render gambar jika hasil mengandung URL image
 *  - Web search: lebih robust parsing berbagai format respons API
 *    (mendukung summary, answer, snippet, description, dll)
 *  - Image dalam pesan: auto-detect URL gambar dalam teks dan
 *    render sebagai <img> inline bukan teks URL mentah
 * ============================================================
 */

const TriChat = (() => {
  let currentMode = "daily";
  let webSearchOn = false;
  let currentConversationId = null;
  let isSending = false;
  let selectedDailyModel = "auto";
  let dailyModelsCache = null;
  let pendingImageFile = null;   // File object dari input[type=file]
  let pendingImageData = null;   // { base64, mimeType, previewUrl }

  const modeLabels = {
    daily: "Daily Chat",
    agent: "AI Agent",
    image: "Image Mode",
  };

  // ============================================================
  // ALUR BERPIKIR — Diagram bertahap (sesuai diagram yang diminta)
  // ============================================================

  // Definisi steps per mode — setiap step punya title, section, sub-items opsional
  const THINKING_FLOWS = {
    daily: [
      { section: "🔍 INPUT", title: "Memahami pertanyaanmu", subs: ["Deteksi tipe input", "Normalisasi & ekstraksi"] },
      { section: "🧠 ANALISIS", title: "Deteksi maksud & konteks", subs: ["Intent classification", "Pembentukan konteks final"] },
      { section: "🧠 PERENCANAAN", title: "Menyusun strategi jawaban", subs: ["Pecah masalah", "Tentukan pendekatan terbaik"] },
      { section: "⚙️ EKSEKUSI", title: "Menghubungi server AI", subs: ["Kirim prompt ke model", "Tunggu respons"] },
      { section: "✨ OUTPUT", title: "Menyusun & memformat jawaban", subs: ["Validasi & cek konsistensi", "Render output"] },
    ],
    agent: [
      { section: "🔍 INPUT", title: "Memahami pertanyaanmu", subs: ["Deteksi tipe input", "Normalisasi input"] },
      { section: "🧠 PERENCANAAN", title: "Orkestrasi 5 AI agent", subs: ["Distribusi ke semua agent", "Strategi sintesis jawaban"] },
      { section: "🔁 DEBATE", title: "Agen berpikir & berdebat", subs: null, isAgentList: true },
      { section: "🧾 VALIDASI", title: "Evaluasi & bandingkan jawaban", subs: ["Cek logika & konsistensi", "Skor keyakinan (confidence)"] },
      { section: "✨ OUTPUT", title: "Sintesis jawaban terbaik", subs: ["Gabungkan poin terbaik", "Format & render output"] },
    ],
    image: [
      { section: "🔍 INPUT", title: "Memahami deskripsi gambar", subs: ["Parsing prompt visual", "Ekstraksi elemen kunci"] },
      { section: "🧠 PERENCANAAN", title: "Menyusun rencana generasi", subs: ["Pilih model image AI", "Optimasi prompt"] },
      { section: "⚙️ GENERASI", title: "Menghubungi server image AI", subs: ["Kirim prompt ke model", "Render gambar (ini memakan waktu...)"] },
      { section: "✨ OUTPUT", title: "Menyelesaikan & menampilkan gambar", subs: ["Finalisasi render", "Kirim ke browser"] },
    ],
    search: [
      { section: "🔍 INPUT", title: "Memahami query pencarian", subs: ["Normalisasi kata kunci", "Optimasi query"] },
      { section: "⚙️ PENCARIAN", title: "Mencari di web", subs: ["Query ke search engine", "Kumpulkan hasil"] },
      { section: "🧾 ANALISIS", title: "Menganalisis & merangkum", subs: ["Parse hasil pencarian", "Ekstrak informasi penting"] },
      { section: "✨ OUTPUT", title: "Menyusun ringkasan hasil", subs: ["Format output", "Render informasi"] },
    ],
  };

  let thinkingStepTimer = null;
  let thinkingCurrentStep = 0;

  function buildFlowHTML(kind) {
    const steps = THINKING_FLOWS[kind] || THINKING_FLOWS.daily;
    return steps.map((s, i) => `
      <div class="thinking-step" id="tstep-${i}">
        <div class="thinking-step-line">
          <div class="thinking-step-dot ${i === 0 ? "active" : ""}"></div>
          <div class="thinking-step-vline"></div>
        </div>
        <div class="thinking-step-content">
          <div class="thinking-step-section ${i === 0 ? "active" : ""}">${s.section}</div>
          <div class="thinking-step-title ${i === 0 ? "active" : ""}">${s.title}</div>
          ${s.subs ? `
            <div class="thinking-sub-items ${i === 0 ? "show" : ""}" id="tsubs-${i}">
              ${s.subs.map(sub => `<div class="thinking-sub-item active"><span class="sub-dot"></span>${sub}</div>`).join("")}
            </div>` : ""}
          ${s.isAgentList ? `
            <div class="thinking-agents" id="thinkingAgents" style="padding-left:0;margin-top:4px;">
              ${["Agent GPT","Agent Llama","Agent DeepSeek","Agent Gemini","Agent Mistral"].map((n,ai) => `
                <div class="thinking-agent-row pending" data-idx="${ai}">
                  <span class="thinking-agent-dot"></span>
                  <span>${n}</span>
                  <span class="thinking-agent-time"></span>
                </div>`).join("")}
            </div>` : ""}
        </div>
      </div>`).join("");
  }

  function advanceThinkingStep(kind) {
    const steps = THINKING_FLOWS[kind] || THINKING_FLOWS.daily;
    const total = steps.length;
    if (thinkingCurrentStep >= total) return;

    const prev = thinkingCurrentStep - 1;
    if (prev >= 0) {
      const prevEl = document.getElementById(`tstep-${prev}`);
      if (prevEl) {
        prevEl.querySelector(".thinking-step-dot")?.classList.replace("active", "done");
        prevEl.querySelector(".thinking-step-section")?.classList.replace("active", "done");
        prevEl.querySelector(".thinking-step-title")?.classList.replace("active", "done");
        const subs = prevEl.querySelector(".thinking-sub-items");
        if (subs) subs.classList.remove("show");
      }
    }

    const curr = thinkingCurrentStep;
    const currEl = document.getElementById(`tstep-${curr}`);
    if (currEl) {
      currEl.querySelector(".thinking-step-dot")?.classList.add("active");
      currEl.querySelector(".thinking-step-section")?.classList.add("active");
      const title = currEl.querySelector(".thinking-step-title");
      if (title) { title.classList.add("active"); }
      const subs = currEl.querySelector(".thinking-sub-items");
      if (subs) setTimeout(() => subs.classList.add("show"), 100);

      // Update label header
      const label = document.getElementById("thinkingLabelText");
      if (label) label.textContent = steps[curr].title;
    }

    thinkingCurrentStep++;
  }

  function addThinkingBubble(kind) {
    thinkingCurrentStep = 0;
    const chatInner = document.getElementById("chatInner");
    const row = document.createElement("div");
    row.className = "msg-row assistant";
    row.id = "typingRow";

    const steps = THINKING_FLOWS[kind] || THINKING_FLOWS.daily;

    row.innerHTML = `
      <div class="msg-avatar">T</div>
      <div class="msg-bubble-wrap">
        <div class="thinking-card">
          <div class="thinking-top">
            <span class="thinking-spinner"></span>
            <span class="thinking-label"><span id="thinkingLabelText">${steps[0].title}</span><span class="dotcycle"></span></span>
          </div>
          <div class="thinking-flow" id="thinkingFlow">
            ${buildFlowHTML(kind)}
          </div>
        </div>
      </div>`;
    chatInner.appendChild(row);
    scrollToBottom();

    // Advance steps otomatis setiap 1.8 detik (natural timing)
    thinkingCurrentStep = 1; // step 0 sudah aktif dari buildFlowHTML
    thinkingStepTimer = setInterval(() => {
      if (!document.getElementById("typingRow")) {
        clearInterval(thinkingStepTimer); thinkingStepTimer = null; return;
      }
      advanceThinkingStep(kind);
    }, 1800);
  }

  function setThinkingAgentState(idx, state, ms) {
    const row = document.querySelector(`.thinking-agent-row[data-idx="${idx}"]`);
    if (!row) return;
    row.className = `thinking-agent-row ${state}`;
    if (ms !== undefined) {
      const t = row.querySelector(".thinking-agent-time");
      if (t) t.textContent = state === "failed" ? "gagal" : `${ms}ms`;
    }
  }

  function removeTypingBubble() {
    if (thinkingStepTimer) { clearInterval(thinkingStepTimer); thinkingStepTimer = null; }
    const row = document.getElementById("typingRow");
    if (row) row.remove();
  }

  // ============================================================
  // HELPERS
  // ============================================================

  function escapeHtml(str) {
    const d = document.createElement("div");
    d.textContent = str ?? "";
    return d.innerHTML;
  }

  const IMAGE_URL_RE = /https?:\/\/\S+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?/gi;

  function renderRichText(text) {
    if (!text) return "";
    let safe = escapeHtml(text);
    safe = safe.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
    safe = safe.replace(/`([^`]+)`/g, "<code>$1</code>");
    safe = safe.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    safe = safe.replace(IMAGE_URL_RE, url =>
      `<img src="${url}" alt="Gambar" loading="lazy" style="max-width:100%;border-radius:8px;margin-top:6px;display:block;">`
    );
    return safe;
  }

  function clearWelcome() {
    const w = document.getElementById("welcomeState");
    if (w) w.remove();
  }

  function scrollToBottom() {
    const el = document.getElementById("chatScroll");
    if (el) requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
  }

  function addUserBubble(text, imagePreview) {
    clearWelcome();
    const chatInner = document.getElementById("chatInner");
    const row = document.createElement("div");
    row.className = "msg-row user";
    const imgHtml = imagePreview
      ? `<img src="${imagePreview}" alt="Foto" loading="lazy" style="max-width:100%;border-radius:8px;margin-bottom:6px;display:block;">`
      : "";
    row.innerHTML = `
      <div class="msg-avatar">${escapeHtml((TriAuth.getUser()?.username || "U").slice(0,1).toUpperCase())}</div>
      <div class="msg-bubble-wrap">
        <div class="msg-bubble">${imgHtml}${renderRichText(text)}</div>
      </div>`;
    chatInner.appendChild(row);
    scrollToBottom();
  }

  function addAssistantBubble({ text, meta, agentResults, imageUrl, isSearch, searchQuery, _questionText }) {
    clearWelcome();
    const chatInner = document.getElementById("chatInner");
    const row = document.createElement("div");
    row.className = "msg-row assistant";

    let bubbleContent = "";
    if (imageUrl) {
      bubbleContent = `<img src="${imageUrl}" alt="Gambar hasil AI" loading="lazy" style="max-width:100%;border-radius:8px;display:block;">`;
    } else if (isSearch) {
      bubbleContent = `
        <div class="search-result-card">
          <span class="src-label">Hasil Web Search: "${escapeHtml(searchQuery)}"</span>
          ${renderRichText(text)}
        </div>`;
    } else {
      bubbleContent = renderRichText(text);
    }

    let agentHtml = "";
    if (agentResults && agentResults.length) {
      agentHtml = `
        <details class="agent-breakdown">
          <summary>Lihat rincian ${agentResults.length} AI agent</summary>
          <div class="agent-breakdown-list">
            ${agentResults.map(a => `
              <div class="agent-breakdown-item">
                <div class="ab-head">
                  <span class="monitor-status-dot ${a.ok?"good":"down"}"></span>
                  ${escapeHtml(a.modelName)} · ${a.ok ? a.latencyMs+"ms" : "gagal"}
                </div>
                <div class="ab-preview">${a.ok ? escapeHtml(a.preview)+"…" : escapeHtml(a.error||"Tidak merespons")}</div>
              </div>`).join("")}
          </div>
        </details>`;
    }

    let metaHtml = "";
    if (meta && meta.length) {
      metaHtml = `<div class="msg-meta">${meta.map(m => `<span class="meta-badge">${escapeHtml(m)}</span>`).join("")}</div>`;
    }

    row.innerHTML = `
      <div class="msg-avatar">T</div>
      <div class="msg-bubble-wrap">
        <div class="msg-bubble">${bubbleContent}</div>
        ${agentHtml}
        ${metaHtml}
      </div>`;
    chatInner.appendChild(row);
    scrollToBottom();

    // Tambah challenge button untuk jawaban teks (bukan gambar/search/error)
    if (text && !imageUrl && !isSearch && !meta?.includes("error") && typeof TriChallenge !== "undefined") {
      const bubbleWrap = row.querySelector(".msg-bubble-wrap");
      if (bubbleWrap && _questionText) {
        TriChallenge.addChallengeButton(_questionText, text, bubbleWrap);
      }
    }

    return row;
  }

  function addErrorBubble(message) {
    addAssistantBubble({ text: `⚠️ ${message}`, meta: ["error"] });
  }

  // ---------- Mode picker ----------

  const modeIcons = {
    daily: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    agent: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 10v6M4.2 4.2l4.2 4.2m7.2 7.2 4.2 4.2M1 12h6m10 0h6M4.2 19.8l4.2-4.2m7.2-7.2 4.2-4.2"/></svg>',
    image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>',
  };

  function setMode(mode) {
    // Smart Context Transfer: capture context sebelum mode berubah
    if (typeof TriContextTransfer !== "undefined" && mode !== currentMode) {
      const prevMode = currentMode;
      const chatInner = document.getElementById("chatInner");
      // Capture hanya kalau ada chat aktif (bukan welcome screen)
      if (chatInner && !document.getElementById("welcomeState")) {
        TriContextTransfer.captureCurrentContext(prevMode);
        TriContextTransfer.updateTransferBadge();
      }
    }

    currentMode = mode;
    document.querySelectorAll(".mode-picker-item").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.mode === mode);
    });
    document.getElementById("modePickerLabel").textContent = modeLabels[mode];
    document.getElementById("modePickerIcon").innerHTML = modeIcons[mode];

    const placeholders = {
      daily: "Tanyakan sesuatu ke TriThink AI…",
      agent: "Ajukan pertanyaan untuk didebat 5 AI agent…",
      image: "Deskripsikan gambar yang ingin kamu buat…",
    };
    document.getElementById("chatInput").placeholder = placeholders[mode];

    // Tampilkan/sembunyikan model picker di composer
    const modelPickerWrap = document.getElementById("composerModelPicker");
    if (modelPickerWrap) {
      modelPickerWrap.style.display = mode === "daily" ? "block" : "none";
      if (mode === "daily") refreshModelPicker();
    }

    // Submenu daily di dalam mode dropdown
    const submenu = document.getElementById("dailyModelSubmenu");
    if (submenu) submenu.classList.toggle("show", mode === "daily");
  }

  function toggleWebSearch(force) {
    webSearchOn = typeof force === "boolean" ? force : !webSearchOn;
    document.getElementById("toggleWebSearch").classList.toggle("active", webSearchOn);
  }

  // ---------- Model picker (di composer) ----------

  function statusColor(status) {
    if (status === "good") return "var(--status-good)";
    if (status === "warn") return "var(--status-warn)";
    if (status === "down") return "var(--status-down)";
    return "#5e5e64";
  }

  function buildComposerModelMenu() {
    const menu = document.getElementById("composerModelMenu");
    if (!menu) return;
    const models = dailyModelsCache || [];
    const items = [
      { id: "auto", name: "Otomatis", status: null },
      ...models.map(m => ({ id: m.id, name: m.modelName, status: m.status })),
    ];
    menu.innerHTML = items.map(it => `
      <button class="mp-model-item ${it.id === selectedDailyModel ? "selected" : ""}" data-id="${it.id}" type="button">
        <span class="mp-status-dot" style="background:${it.status ? statusColor(it.status) : "#5e5e64"};color:${it.status ? statusColor(it.status) : "#5e5e64"};"></span>
        <span>${escapeHtml(it.name)}</span>
        <svg class="mp-model-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
      </button>`).join("");
    menu.querySelectorAll(".mp-model-item").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        selectedDailyModel = btn.dataset.id;
        updateComposerModelBtn();
        buildComposerModelMenu();
        closeComposerModelMenu();
      });
    });
  }

  function updateComposerModelBtn() {
    const label = document.getElementById("composerModelLabel");
    if (!label) return;
    if (selectedDailyModel === "auto") { label.textContent = "Model"; return; }
    const found = (dailyModelsCache || []).find(m => m.id === selectedDailyModel);
    label.textContent = found ? found.modelName : "Model";
  }

  function openComposerModelMenu() {
    const menu = document.getElementById("composerModelMenu");
    const btn = document.getElementById("composerModelBtn");
    if (menu) menu.classList.add("open");
    if (btn) btn.classList.add("open");
  }
  function closeComposerModelMenu() {
    const menu = document.getElementById("composerModelMenu");
    const btn = document.getElementById("composerModelBtn");
    if (menu) menu.classList.remove("open");
    if (btn) btn.classList.remove("open");
  }

  async function refreshModelPicker() {
    const res = await TriAPI.get("/api/monitor");
    if (res.ok && res.servers) {
      dailyModelsCache = res.servers.filter(s => s.category === "daily");
      buildComposerModelMenu();
      updateComposerModelBtn();
    }
  }

  function openModePickerMenu() {
    document.getElementById("modePickerMenu").classList.add("open");
    document.getElementById("modePickerBtn").classList.add("open");
    document.getElementById("modePickerBtn").setAttribute("aria-expanded", "true");
  }
  function closeModePickerMenu() {
    const menu = document.getElementById("modePickerMenu");
    const btn = document.getElementById("modePickerBtn");
    if (menu) menu.classList.remove("open");
    if (btn) { btn.classList.remove("open"); btn.setAttribute("aria-expanded", "false"); }
  }

  // ---------- Image upload ----------

  function initImageInput() {
    // Buat input file tersembunyi
    let fileInput = document.getElementById("imageFileInput");
    if (!fileInput) {
      fileInput = document.createElement("input");
      fileInput.type = "file";
      fileInput.id = "imageFileInput";
      fileInput.accept = "image/*";
      fileInput.style.display = "none";
      document.body.appendChild(fileInput);
    }
    fileInput.addEventListener("change", e => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 5 * 1024 * 1024) {
        Toast.show("Ukuran foto maksimal 5MB.", "error");
        return;
      }
      const reader = new FileReader();
      reader.onload = ev => {
        const result = ev.target.result;
        pendingImageFile = file;
        pendingImageData = {
          base64: result.split(",")[1],
          mimeType: file.type,
          previewUrl: result,
        };
        renderImagePreview();
      };
      reader.readAsDataURL(file);
      fileInput.value = ""; // reset supaya bisa upload file yang sama lagi
    });
    return fileInput;
  }

  function renderImagePreview() {
    let preview = document.getElementById("imagePreviewWrap");
    if (!preview) {
      preview = document.createElement("div");
      preview.id = "imagePreviewWrap";
      preview.className = "image-preview-wrap";
      const composer = document.getElementById("composer");
      composer.insertBefore(preview, composer.firstChild);
    }
    if (!pendingImageData) { preview.remove(); return; }
    preview.innerHTML = `
      <div class="image-preview-inner">
        <img src="${pendingImageData.previewUrl}" alt="Preview" class="image-preview-thumb">
        <button class="image-preview-remove" id="btnRemoveImage" type="button">✕</button>
      </div>`;
    document.getElementById("btnRemoveImage").addEventListener("click", clearPendingImage);
  }

  function clearPendingImage() {
    pendingImageFile = null;
    pendingImageData = null;
    const preview = document.getElementById("imagePreviewWrap");
    if (preview) preview.remove();
  }

  // ---------- Sending ----------

  async function sendMessage(rawText) {
    const text = (rawText ?? document.getElementById("chatInput").value).trim();
    const hasImage = !!pendingImageData;
    if (!text && !hasImage) return;
    if (isSending) return;

    isSending = true;
    document.getElementById("btnSend").disabled = true;
    document.getElementById("chatInput").value = "";
    autoResizeTextarea();

    const imageSnapshot = pendingImageData ? { ...pendingImageData } : null;
    clearPendingImage();
    addUserBubble(text, imageSnapshot?.previewUrl);

    try {
      let res;

      // ── WEB SEARCH ──────────────────────────────────────────
      if (webSearchOn && currentMode !== "image") {
        addThinkingBubble("search");
        const searchText = imageSnapshot
          ? `${text || "deskripsikan"} [gambar dilampirkan]`
          : text;
        res = await TriAPI.post("/api/chat/websearch", { text: searchText });
        removeTypingBubble();
        if (res.ok) {
          addAssistantBubble({
            text: res.result,
            isSearch: true,
            searchQuery: res.query,
            meta: res.latencyMs ? [`${res.latencyMs}ms`] : [],
          });
        } else {
          addErrorBubble(res.error || "Web search gagal.");
        }
        isSending = false;
        document.getElementById("btnSend").disabled = false;
        return;
      }

      // ── DAILY CHAT ───────────────────────────────────────────
      if (currentMode === "daily") {
        addThinkingBubble("daily");

        // Smart Context Transfer: ambil konteks dari mode sebelumnya (sekali pakai)
        const ctxTransfer = typeof TriContextTransfer !== "undefined"
          ? TriContextTransfer.consumeTransferContext()
          : "";
        if (ctxTransfer && typeof TriContextTransfer !== "undefined") {
          TriContextTransfer.updateTransferBadge();
        }

        const payload = {
          text: ctxTransfer + (text || "(pengguna mengirim gambar, deskripsikan dan bantu analisis gambar tsb)"),
          conversationId: currentConversationId,
          projectId: typeof TriProjects !== "undefined" ? TriProjects.getActiveProjectId() : null,
        };
        if (selectedDailyModel !== "auto") payload.model = selectedDailyModel;
        if (imageSnapshot) {
          payload.imageBase64 = imageSnapshot.base64;
          payload.imageMimeType = imageSnapshot.mimeType;
          payload.hasImage = true;
        }
        res = await TriAPI.post("/api/chat/daily", payload);
        removeTypingBubble();
        if (res.ok) {
          if (res.conversationId != null) currentConversationId = res.conversationId;
          addAssistantBubble({ text: res.answer, meta: [res.modelUsed, `${res.latencyMs}ms`], _questionText: text });
          updateTopbarTitle(text || "Gambar dikirim");
          if (res.conversationId != null) await refreshHistory();
          else if (!TriAuth.isLoggedIn()) showLoginNudge();
        } else {
          addErrorBubble(res.error || "Gagal mendapatkan jawaban.");
        }

      // ── AI AGENT ─────────────────────────────────────────────
      } else if (currentMode === "agent") {
        addThinkingBubble("agent");
        simulateAgentProgress();
        const ctxAgent = typeof TriContextTransfer !== "undefined"
          ? TriContextTransfer.consumeTransferContext() : "";
        if (ctxAgent && typeof TriContextTransfer !== "undefined")
          TriContextTransfer.updateTransferBadge();
        res = await TriAPI.post("/api/chat/agent", {
          text: ctxAgent + (text || "(pengguna mengirim gambar, analisis dan berikan pendapat terbaik)"),
          conversationId: currentConversationId,
        });
        removeTypingBubble();
        if (res.ok) {
          if (res.conversationId != null) currentConversationId = res.conversationId;
          addAssistantBubble({
            text: res.answer,
            meta: [res.synthesizedBy ? `Disusun oleh ${res.synthesizedBy}` : "Gabungan 5 agent",
                   res.usedFallback ? "fallback" : "sintesis"],
            agentResults: res.agentResults,
            _questionText: text,
          });
          updateTopbarTitle(text || "Pertanyaan ke agent");
          if (res.conversationId != null) await refreshHistory();
          else if (!TriAuth.isLoggedIn()) showLoginNudge();
        } else {
          addErrorBubble(res.error || "Semua AI agent gagal merespons.");
        }

      // ── IMAGE MODE ────────────────────────────────────────────
      } else if (currentMode === "image") {
        addThinkingBubble("image");
        res = await TriAPI.post("/api/chat/image", {
          text: text || "buatkan gambar kreatif berdasarkan foto yang dilampirkan",
          conversationId: currentConversationId,
        });
        removeTypingBubble();
        if (res.ok) {
          if (res.conversationId != null) currentConversationId = res.conversationId;
          addAssistantBubble({ imageUrl: res.imageUrl, meta: [res.modelUsed, `${res.latencyMs}ms`] });
          updateTopbarTitle(text || "Buat gambar");
          if (res.conversationId != null) await refreshHistory();
          else if (!TriAuth.isLoggedIn()) showLoginNudge();
        } else {
          addErrorBubble(res.error || "Gagal membuat gambar.");
        }
      }
    } catch (err) {
      removeTypingBubble();
      addErrorBubble("Terjadi kesalahan tak terduga. Silakan coba lagi.");
      console.error(err);
    } finally {
      isSending = false;
      document.getElementById("btnSend").disabled = false;
    }
  }

  // Tampilkan nudge sekali kalau user belum login dan riwayat tidak tersimpan
  let loginNudgeShown = false;
  function showLoginNudge() {
    if (loginNudgeShown) return;
    loginNudgeShown = true;
    setTimeout(() => {
      Toast.show("Login untuk menyimpan riwayat percakapan.", "default");
    }, 600);
  }

  function simulateAgentProgress() {
    // Animasi kosmetik: tandai agent loading satu-satu, lalu done
    // sambil request asli berjalan paralel di background
    [0,1,2,3,4].forEach((idx, i) => {
      setTimeout(() => {
        if (!document.getElementById("typingRow")) return;
        setThinkingAgentState(idx, "loading");
      }, 300 * (i + 1));
    });
    [0,1,2,3,4].forEach((idx, i) => {
      const d = 1200 + i * 600 + Math.random() * 400;
      setTimeout(() => {
        if (!document.getElementById("typingRow")) return;
        setThinkingAgentState(idx, "done", Math.round(d));
      }, d);
    });
  }



  function updateTopbarTitle(text) {
    const title = document.getElementById("topbarTitle");
    if (title && title.textContent === "Percakapan Baru") {
      title.textContent = text.length > 38 ? text.slice(0, 38) + "…" : text;
    }
  }

  function autoResizeTextarea() {
    const ta = document.getElementById("chatInput");
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 140) + "px";
  }

  // ---------- New conversation ----------

  function buildWelcomeHTML() {
    return `
      <div class="welcome-state" id="welcomeState">
        <div class="welcome-mark">T</div>
        <div class="welcome-title">Selamat datang di TriThink AI</div>
        <div class="welcome-sub">Pilih mode dari menu di atas: <b>Daily Chat</b> untuk obrolan cepat, <b>AI Agent</b> untuk 5 model AI berdebat, atau <b>Image Mode</b> untuk membuat gambar.</div>
        <div class="welcome-suggestions">
          <button class="suggestion-card" type="button" data-fill="Jelaskan perbedaan antara REST API dan GraphQL"><b>Tanya teknis</b>Perbedaan REST API dan GraphQL</button>
          <button class="suggestion-card" type="button" data-fill="Buatkan rencana belajar Node.js untuk pemula selama 30 hari"><b>Rencana belajar</b>Roadmap Node.js 30 hari</button>
          <button class="suggestion-card" type="button" data-fill="Apa kabar berita teknologi AI terbaru minggu ini?"><b>Coba Web Search</b>Berita AI terbaru</button>
          <button class="suggestion-card" type="button" data-fill="Kucing oranye memakai jaket astronaut, gaya digital art"><b>Coba Image Mode</b>Kucing astronaut</button>
        </div>
      </div>`;
  }

  function newConversation() {
    currentConversationId = null;
    clearPendingImage();
    if (typeof TriContextTransfer !== "undefined") TriContextTransfer.clear();
    loginNudgeShown = false;
    const title = document.getElementById("topbarTitle");
    if (title) title.textContent = "Percakapan Baru";
    const chatInner = document.getElementById("chatInner");
    if (chatInner) {
      chatInner.innerHTML = buildWelcomeHTML();
      bindSuggestionCards();
    }
    setActiveHistoryItem(null);
  }

  // ---------- History ----------

  async function refreshHistory() {
    const list = document.getElementById("historyList");
    if (!list) return;
    if (!TriAuth.isLoggedIn()) {
      list.innerHTML = `<div class="history-empty">Belum ada percakapan. Login untuk menyimpan riwayat.</div>`;
      return;
    }
    try {
      const res = await TriAPI.get("/api/conversations");
      if (!res.ok || !res.conversations || res.conversations.length === 0) {
        list.innerHTML = `<div class="history-empty">Belum ada percakapan tersimpan.</div>`;
        return;
      }
      const tagMap = { daily: "Chat", agent: "Agent", image: "Image" };
      list.innerHTML = res.conversations.map(c => `
        <div class="history-item ${c.id === currentConversationId ? "active" : ""}" data-id="${c.id}" data-mode="${c.mode}">
          <span class="h-tag">${tagMap[c.mode] || c.mode}</span>
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(c.title)}</span>
          <svg class="h-del" data-id="${c.id}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6h16Z"/></svg>
        </div>`).join("");

      list.querySelectorAll(".history-item").forEach(item => {
        item.addEventListener("click", e => {
          if (e.target.closest(".h-del")) return;
          loadConversation(parseInt(item.dataset.id, 10), item.dataset.mode);
        });
      });
      list.querySelectorAll(".h-del").forEach(btn => {
        btn.addEventListener("click", async e => {
          e.stopPropagation();
          const id = btn.dataset.id;
          await TriAPI.del(`/api/conversations?id=${id}`);
          if (parseInt(id, 10) === currentConversationId) newConversation();
          refreshHistory();
        });
      });
    } catch (err) {
      console.error("refreshHistory error:", err);
      list.innerHTML = `<div class="history-empty">Gagal memuat riwayat.</div>`;
    }
  }

  function setActiveHistoryItem(id) {
    document.querySelectorAll(".history-item").forEach(item => {
      item.classList.toggle("active", parseInt(item.dataset.id, 10) === id);
    });
  }

  async function loadConversation(id, mode) {
    try {
      const res = await TriAPI.get(`/api/conversations/messages?id=${id}`);
      if (!res.ok) { Toast.show(res.error || "Gagal memuat percakapan.", "error"); return; }
      currentConversationId = id;
      setMode(mode);
      setActiveHistoryItem(id);
      const chatInner = document.getElementById("chatInner");
      chatInner.innerHTML = "";
      let titleSet = false;
      res.messages.forEach(m => {
        if (m.role === "user") {
          addUserBubble(m.content);
          if (!titleSet) {
            const title = document.getElementById("topbarTitle");
            if (title) title.textContent = m.content.length > 38 ? m.content.slice(0,38)+"…" : m.content;
            titleSet = true;
          }
        } else {
          const meta = m.meta || {};
          if (mode === "agent" && meta.synthesizedBy) {
            addAssistantBubble({
              text: m.content,
              meta: [`Disusun oleh ${meta.synthesizedBy}`],
              agentResults: meta.agentResults ? meta.agentResults.map(a => ({
                modelName: a.modelName, ok: a.ok, latencyMs: a.latencyMs,
                preview: a.text ? a.text.slice(0,200) : null, error: a.error,
              })) : null,
            });
          } else if (mode === "image") {
            addAssistantBubble({ text: m.content, meta: meta.modelUsed ? [meta.modelUsed] : [] });
          } else {
            addAssistantBubble({ text: m.content });
          }
        }
      });
    } catch (err) {
      Toast.show("Gagal memuat percakapan.", "error");
      console.error(err);
    }
  }

  function bindSuggestionCards() {
    document.querySelectorAll(".suggestion-card").forEach(card => {
      card.addEventListener("click", () => {
        const ta = document.getElementById("chatInput");
        ta.value = card.dataset.fill;
        autoResizeTextarea();
        ta.focus();
      });
    });
  }

  // ---------- initUI ----------

  function initUI() {
    // Mode picker dropdown (topbar)
    document.querySelectorAll(".mode-picker-item").forEach(btn => {
      btn.addEventListener("click", () => {
        setMode(btn.dataset.mode);
        if (btn.dataset.mode !== "daily") closeModePickerMenu();
      });
    });
    const modePickerBtn = document.getElementById("modePickerBtn");
    if (modePickerBtn) {
      modePickerBtn.addEventListener("click", e => {
        e.stopPropagation();
        const menu = document.getElementById("modePickerMenu");
        if (menu && menu.classList.contains("open")) closeModePickerMenu();
        else openModePickerMenu();
      });
    }
    document.addEventListener("click", e => {
      if (!e.target.closest(".mode-picker")) closeModePickerMenu();
      if (!e.target.closest(".composer-model-picker")) closeComposerModelMenu();
    });

    // Composer model picker
    const composerModelBtn = document.getElementById("composerModelBtn");
    if (composerModelBtn) {
      composerModelBtn.addEventListener("click", e => {
        e.stopPropagation();
        const menu = document.getElementById("composerModelMenu");
        if (menu && menu.classList.contains("open")) closeComposerModelMenu();
        else { openComposerModelMenu(); refreshModelPicker(); }
      });
    }

    // Web Search toggle
    document.getElementById("toggleWebSearch").addEventListener("click", () => toggleWebSearch());

    // Image upload button
    const fileInput = initImageInput();
    const btnAttach = document.getElementById("btnAttachImage");
    if (btnAttach) btnAttach.addEventListener("click", () => fileInput.click());

    // Paste gambar dari clipboard
    document.addEventListener("paste", e => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith("image/")) {
          const file = item.getAsFile();
          if (!file) continue;
          const reader = new FileReader();
          reader.onload = ev => {
            const result = ev.target.result;
            pendingImageFile = file;
            pendingImageData = {
              base64: result.split(",")[1],
              mimeType: file.type,
              previewUrl: result,
            };
            renderImagePreview();
            Toast.show("Gambar dari clipboard siap dikirim.", "default");
          };
          reader.readAsDataURL(file);
          break;
        }
      }
    });

    // Send
    document.getElementById("btnSend").addEventListener("click", () => sendMessage());
    document.getElementById("chatInput").addEventListener("keydown", e => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });
    document.getElementById("chatInput").addEventListener("input", autoResizeTextarea);

    // Hapus SEMUA riwayat
    const btnClearAll = document.getElementById("btnClearAllHistory");
    if (btnClearAll) {
      btnClearAll.addEventListener("click", async () => {
        if (!TriAuth.isLoggedIn()) {
          Toast.show("Login terlebih dahulu untuk mengelola riwayat.", "error");
          return;
        }
        if (!confirm("Hapus SEMUA riwayat percakapan? Tindakan ini tidak bisa dibatalkan.")) return;
        // Hapus semua conversations milik user
        const list = await TriAPI.get("/api/conversations");
        if (list.ok && list.conversations) {
          await Promise.all(list.conversations.map(c =>
            TriAPI.del(`/api/conversations?id=${c.id}`)
          ));
        }
        newConversation();
        await refreshHistory();
        Toast.show("Semua riwayat dihapus.", "default");
      });
    }

    // New conversation
    document.getElementById("btnNewChat").addEventListener("click", newConversation);

    bindSuggestionCards();
    refreshHistory();

    // Inisialisasi model picker di mode Daily
    if (currentMode === "daily") refreshModelPicker();
  }

  return { initUI, sendMessage, setMode, newConversation, refreshHistory };
})();
