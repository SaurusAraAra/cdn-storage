/**
 * ============================================================
 *  public/js/projects.js
 * ------------------------------------------------------------
 *  Project Workspace: user buat project, AI ngerti konteks
 *  per-project. Resume Session nunjukkin progress tiap project.
 * ============================================================
 */

const TriProjects = (() => {
  let isOpen = false;
  let projects = [];
  let activeProjectId = null;   // project yang sedang dipilih untuk chat
  let activeView = "list";      // "list" | "detail"
  let detailProjectId = null;

  // Warna preset untuk project
  const COLORS = ["#ffffff", "#3ddc84", "#ffcf4d", "#ff5c5c", "#60a5fa", "#c084fc", "#fb923c"];
  const ICONS  = ["📁","🚀","💡","⚙️","🎨","📱","🔥","🧠","💼","🎯","🌐","🔬"];

  function esc(s) {
    const d = document.createElement("div"); d.textContent = s ?? ""; return d.innerHTML;
  }

  // ── Status helpers ───────────────────────────────────────
  const STATUS_INFO = {
    pending:     { icon: "⏳", label: "Belum mulai", cls: "pending" },
    in_progress: { icon: "🔄", label: "Sedang dikerjakan", cls: "progress" },
    done:        { icon: "✓",  label: "Selesai", cls: "done" },
    blocked:     { icon: "🚫", label: "Terhambat", cls: "blocked" },
  };

  function progressBar(pct) {
    return `
      <div class="proj-progress-bar-wrap">
        <div class="proj-progress-bar" style="width:${pct}%"></div>
      </div>
      <span class="proj-progress-pct">${pct}%</span>`;
  }

  // ── Render list semua project ────────────────────────────
  function renderList() {
    const panel = document.getElementById("projectsPanel");
    if (!panel) return;

    const cards = projects.length === 0 ? `
      <div class="proj-empty">
        Belum ada project.<br>
        <span style="font-size:11px;color:var(--text-tertiary)">Buat project untuk mengorganisir percakapan AI berdasarkan topik/tujuan.</span>
      </div>` : projects.map(p => {
      const done = parseInt(p.tasks_done || 0);
      const total = parseInt(p.tasks_total || 0);
      const pct = total ? Math.round((done / total) * 100) : 0;
      const isActive = p.id === activeProjectId;
      return `
        <div class="proj-card ${isActive ? "active" : ""}" data-id="${p.id}">
          <div class="proj-card-top">
            <div class="proj-card-icon" style="border-color:${p.color}40;background:${p.color}15;">${p.icon}</div>
            <div class="proj-card-info">
              <div class="proj-card-name">${esc(p.name)}</div>
              ${p.description ? `<div class="proj-card-desc">${esc(p.description)}</div>` : ""}
            </div>
            <div class="proj-card-actions">
              ${isActive
                ? `<button class="proj-action-btn active-badge" title="Project aktif">✓ Aktif</button>`
                : `<button class="proj-action-btn set-active-btn" data-id="${p.id}" title="Jadikan project aktif untuk chat">Pilih</button>`}
              <button class="proj-action-btn proj-detail-btn" data-id="${p.id}" title="Detail & tasks">Detail</button>
              <button class="proj-action-btn proj-delete-btn" data-id="${p.id}" title="Hapus project">✕</button>
            </div>
          </div>
          ${total > 0 ? `
            <div class="proj-resume">
              <div class="proj-resume-label">Progress <strong>${done}/${total}</strong> task</div>
              ${progressBar(pct)}
            </div>` : ""}
        </div>`;
    }).join("");

    panel.innerHTML = `
      <div class="proj-header">
        <div class="proj-title">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
          Project Workspace
          ${activeProjectId ? `<span class="proj-active-indicator">1 aktif</span>` : ""}
        </div>
        <button class="mp-close-btn" id="btnProjectsClose">✕</button>
      </div>

      <div class="proj-list">${cards}</div>

      <div class="proj-create-form" id="projCreateForm">
        <div class="proj-form-title">+ Buat Project Baru</div>
        <div class="proj-icon-color-row">
          <div class="proj-icon-picker" id="projIconPicker">
            ${ICONS.map(ic => `<button class="proj-icon-opt" data-icon="${ic}">${ic}</button>`).join("")}
          </div>
          <div class="proj-color-picker" id="projColorPicker">
            ${COLORS.map(cl => `<button class="proj-color-opt" data-color="${cl}" style="background:${cl};" title="${cl}"></button>`).join("")}
          </div>
        </div>
        <input type="text" id="projNameInput" placeholder="Nama project *" class="mp-input" maxlength="100">
        <input type="text" id="projDescInput" placeholder="Deskripsi (opsional)" class="mp-input">
        <textarea id="projCtxInput" placeholder="Konteks untuk AI (opsional) — mis: 'Project ini adalah aplikasi Node.js untuk WhatsApp bot, stack: Baileys + PostgreSQL'" class="mp-input proj-ctx-input" rows="2"></textarea>
        <button class="mp-add-btn" id="btnCreateProject">Buat Project</button>
      </div>`;

    // State icon & warna yang dipilih
    let selectedIcon = "📁";
    let selectedColor = "#ffffff";

    document.getElementById("btnProjectsClose")?.addEventListener("click", close);

    // Icon picker
    panel.querySelectorAll(".proj-icon-opt").forEach(btn => {
      btn.addEventListener("click", () => {
        selectedIcon = btn.dataset.icon;
        panel.querySelectorAll(".proj-icon-opt").forEach(b => b.classList.remove("selected"));
        btn.classList.add("selected");
      });
    });

    // Color picker
    panel.querySelectorAll(".proj-color-opt").forEach(btn => {
      btn.addEventListener("click", () => {
        selectedColor = btn.dataset.color;
        panel.querySelectorAll(".proj-color-opt").forEach(b => b.classList.remove("selected"));
        btn.classList.add("selected");
      });
    });

    // Set project aktif
    panel.querySelectorAll(".set-active-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        activeProjectId = parseInt(btn.dataset.id);
        updateProjectBadge();
        renderList();
        Toast.show("Project aktif dipilih. Context project akan ikut ke chat.", "success");
      });
    });

    // Kalau klik project aktif, non-aktifkan
    panel.querySelectorAll(".active-badge").forEach(btn => {
      btn.addEventListener("click", () => {
        activeProjectId = null;
        updateProjectBadge();
        renderList();
        Toast.show("Project dinonaktifkan.", "default");
      });
    });

    // Buka detail
    panel.querySelectorAll(".proj-detail-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        detailProjectId = parseInt(btn.dataset.id);
        renderDetail(detailProjectId);
      });
    });

    // Hapus project
    panel.querySelectorAll(".proj-delete-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        if (!confirm("Hapus project ini? Task di dalamnya juga akan terhapus.")) return;
        const id = btn.dataset.id;
        await TriAPI.del(`/api/projects?id=${id}`);
        if (activeProjectId === parseInt(id)) { activeProjectId = null; updateProjectBadge(); }
        await fetchProjects();
        Toast.show("Project dihapus.", "default");
      });
    });

    // Create project
    document.getElementById("btnCreateProject")?.addEventListener("click", async () => {
      const name = document.getElementById("projNameInput")?.value.trim();
      if (!name) { Toast.show("Nama project wajib diisi.", "error"); return; }
      const desc = document.getElementById("projDescInput")?.value.trim();
      const ctx  = document.getElementById("projCtxInput")?.value.trim();
      const btn  = document.getElementById("btnCreateProject");
      btn.disabled = true; btn.textContent = "Membuat...";
      const res = await TriAPI.post("/api/projects", {
        name, description: desc, context_prompt: ctx,
        icon: selectedIcon, color: selectedColor,
      });
      btn.disabled = false; btn.textContent = "Buat Project";
      if (res.ok) {
        await fetchProjects();
        Toast.show(`Project "${name}" dibuat!`, "success");
      } else {
        Toast.show(res.error || "Gagal membuat project.", "error");
      }
    });
  }

  // ── Render detail 1 project + tasks (Resume Session) ────
  async function renderDetail(projectId) {
    const panel = document.getElementById("projectsPanel");
    if (!panel) return;

    panel.innerHTML = `<div class="mp-loading"><span class="thinking-spinner"></span> Memuat tasks...</div>`;

    const [projRes, taskRes] = await Promise.all([
      TriAPI.get("/api/projects"),
      TriAPI.get(`/api/projects?tasks=${projectId}`)
    ]);

    const proj = (projRes.projects || []).find(p => p.id === projectId);
    if (!proj) { renderList(); return; }

    const tasks  = taskRes.tasks || [];
    const pct    = taskRes.progress || 0;
    const done   = taskRes.done || 0;
    const total  = taskRes.total || 0;

    const taskRows = tasks.length === 0
      ? `<div class="proj-no-tasks">Belum ada task. Tambahkan task untuk melacak progress project.</div>`
      : tasks.map(t => {
          const s = STATUS_INFO[t.status] || STATUS_INFO.pending;
          return `
            <div class="proj-task-row" data-task-id="${t.id}">
              <div class="proj-task-status ${s.cls}">${s.icon}</div>
              <div class="proj-task-title">${esc(t.title)}</div>
              <div class="proj-task-actions">
                <select class="proj-status-select" data-task-id="${t.id}">
                  ${Object.entries(STATUS_INFO).map(([v, info]) =>
                    `<option value="${v}" ${t.status===v?"selected":""}>${info.icon} ${info.label}</option>`
                  ).join("")}
                </select>
                <button class="proj-task-del" data-task-id="${t.id}" title="Hapus task">✕</button>
              </div>
            </div>`;
        }).join("");

    panel.innerHTML = `
      <div class="proj-header">
        <button class="proj-back-btn" id="btnProjBack">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
          Kembali
        </button>
        <div class="proj-title" style="flex:1;">
          <span>${proj.icon}</span> ${esc(proj.name)}
        </div>
        <button class="mp-close-btn" id="btnProjectsClose">✕</button>
      </div>

      <div class="proj-detail-resume">
        <div class="proj-resume-header">
          <span class="proj-resume-title">Resume Session</span>
          <span class="proj-resume-stat">${done}/${total} selesai</span>
        </div>
        ${progressBar(pct)}
        <div class="proj-task-list" id="projTaskList">${taskRows}</div>
        <div class="proj-add-task-row">
          <input type="text" id="projNewTaskInput" placeholder="Tambah task baru..." class="mp-input" style="flex:1;">
          <button class="mp-add-btn" id="btnAddTask" style="flex-shrink:0;padding:8px 12px;">+</button>
        </div>
      </div>`;

    document.getElementById("btnProjBack")?.addEventListener("click", () => renderList());
    document.getElementById("btnProjectsClose")?.addEventListener("click", close);

    // Update status task
    panel.querySelectorAll(".proj-status-select").forEach(sel => {
      sel.addEventListener("change", async () => {
        await TriAPI.request(`/api/projects?taskId=${sel.dataset.taskId}`, {
          method: "PUT",
          body: { status: sel.value }
        });
        await renderDetail(projectId);
      });
    });

    // Hapus task
    panel.querySelectorAll(".proj-task-del").forEach(btn => {
      btn.addEventListener("click", async () => {
        await TriAPI.del(`/api/projects?taskId=${btn.dataset.taskId}`);
        await renderDetail(projectId);
      });
    });

    // Tambah task
    const addTask = async () => {
      const title = document.getElementById("projNewTaskInput")?.value.trim();
      if (!title) return;
      await TriAPI.post(`/api/projects?addTask=${projectId}`, { title });
      await renderDetail(projectId);
    };
    document.getElementById("btnAddTask")?.addEventListener("click", addTask);
    document.getElementById("projNewTaskInput")?.addEventListener("keydown", e => {
      if (e.key === "Enter") addTask();
    });
  }

  // ── Badge di topbar/sidebar ─────────────────────────────
  function updateProjectBadge() {
    let badge = document.getElementById("activeProjectBadge");
    if (activeProjectId) {
      const proj = projects.find(p => p.id === activeProjectId);
      if (!badge) {
        badge = document.createElement("div");
        badge.id = "activeProjectBadge";
        badge.className = "active-project-badge";
        badge.title = "Klik untuk buka Project Workspace";
        badge.addEventListener("click", open);
        const topbar = document.querySelector(".topbar");
        const modePicker = document.querySelector(".mode-picker");
        if (topbar && modePicker) topbar.insertBefore(badge, modePicker);
        else if (topbar) topbar.appendChild(badge);
      }
      badge.innerHTML = `${proj ? proj.icon : "📁"} <span>${proj ? esc(proj.name) : "Project"}</span>`;
    } else {
      if (badge) badge.remove();
    }
  }

  // ── Getter untuk dipakai chat.js ─────────────────────────
  function getActiveProjectId() { return activeProjectId; }

  // ── Fetch + render ───────────────────────────────────────
  async function fetchProjects() {
    if (!TriAuth.isLoggedIn()) { projects = []; renderList(); return; }
    const res = await TriAPI.get("/api/projects");
    projects = res.ok ? (res.projects || []) : [];
    renderList();
  }

  function open() {
    if (isOpen) { close(); return; }
    isOpen = true;

    let panel = document.getElementById("projectsPanel");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "projectsPanel";
      panel.className = "projects-panel glass";
      document.body.appendChild(panel);
    }
    let scrim = document.getElementById("projectsScrim");
    if (!scrim) {
      scrim = document.createElement("div");
      scrim.id = "projectsScrim";
      scrim.className = "status-scrim";
      document.body.appendChild(scrim);
      scrim.addEventListener("click", close);
    }
    requestAnimationFrame(() => { panel.classList.add("open"); scrim.classList.add("show"); });
    panel.innerHTML = `<div class="mp-loading"><span class="thinking-spinner"></span> Memuat projects...</div>`;
    fetchProjects();
  }

  function close() {
    isOpen = false;
    ["projectsPanel","projectsScrim"].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.classList.remove("open","show");
        setTimeout(() => el.remove(), 280);
      }
    });
  }

  function init() {
    const btn = document.getElementById("btnProjects");
    if (btn) btn.addEventListener("click", open);
  }

  return { init, open, close, getActiveProjectId, updateProjectBadge };
})();
