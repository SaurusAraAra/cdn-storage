/**
 * ============================================================
 *  api/challenge.js
 * ------------------------------------------------------------
 *  POST /api/challenge
 *  Body: { question, answer }
 *
 *  AI Challenge Mode: setelah AI memberikan jawaban,
 *  endpoint ini meminta AI untuk MENGKRITIK dan mencari
 *  kelemahan, celah logika, atau hal yang terlewat dari
 *  jawabannya sendiri — lalu menyajikan versi yang diperbaiki.
 *
 *  ALUR:
 *  1. Terima pertanyaan user + jawaban AI sebelumnya
 *  2. Kirim ke AI dengan prompt "devil's advocate" khusus
 *  3. AI mengidentifikasi kelemahan + asumsi salah + celah
 *  4. AI buat versi jawaban yang lebih kuat
 *  5. Return { weaknesses, improvedAnswer, confidence }
 * ============================================================
 */

const { DAILY_CHAT_MODELS } = require("../configapi");
const { callEndpoint } = require("../lib/fetchEngine");

const CHALLENGE_PROMPT = (question, answer) => `
Kamu adalah sistem evaluasi kritis. Seorang AI baru saja memberikan jawaban berikut:

PERTANYAAN USER:
${question}

JAWABAN AI:
${answer}

Tugasmu (berperan sebagai devil's advocate yang sangat kritis):
1. Temukan KELEMAHAN, ASUMSI SALAH, atau hal yang TERLEWAT dari jawaban ini
2. Identifikasi apakah ada sudut pandang alternatif yang diabaikan
3. Cek apakah ada potensi masalah atau risiko yang tidak disebutkan
4. Buat VERSI JAWABAN YANG LEBIH KUAT dan lebih lengkap

Format respons WAJIB dalam JSON berikut (tanpa teks lain):
{
  "weaknesses": [
    "Kelemahan / celah 1",
    "Kelemahan / celah 2"
  ],
  "missed_angles": [
    "Sudut pandang yang terlewat 1"
  ],
  "confidence_original": 65,
  "improved_answer": "Jawaban yang lebih lengkap dan kuat di sini...",
  "confidence_improved": 88
}

Kalau jawaban sudah sangat bagus dan tidak ada kelemahan berarti, kembalikan weaknesses kosong dan improved_answer yang sama.
`;

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const { question, answer } = req.body || {};
    if (!question || !answer) {
      res.status(400).json({ ok: false, error: "question dan answer wajib diisi" });
      return;
    }

    const models = Object.values(DAILY_CHAT_MODELS).filter(m => m.enabled);
    if (!models.length) {
      res.status(503).json({ ok: false, error: "Tidak ada model yang aktif" });
      return;
    }

    // Gunakan model terbaik yang tersedia (coba yang kedua dulu karena lebih "segar")
    const model = models[1] || models[0];
    const prompt = CHALLENGE_PROMPT(question, answer);
    const result = await callEndpoint(model, prompt);

    if (!result.ok || !result.text) {
      res.status(502).json({ ok: false, error: "Model tidak merespons saat challenge" });
      return;
    }

    // Parse JSON dari respons
    let parsed = null;
    try {
      const cleaned = result.text.replace(/```json|```/g, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      const match = result.text.match(/\{[\s\S]*\}/);
      if (match) {
        try { parsed = JSON.parse(match[0]); } catch { parsed = null; }
      }
    }

    if (!parsed) {
      // Fallback: bungkus teks mentah jadi struktur yang bisa dipakai
      res.status(200).json({
        ok: true,
        weaknesses: ["Tidak dapat mengurai struktur evaluasi dari model"],
        missed_angles: [],
        confidence_original: null,
        improved_answer: result.text,
        confidence_improved: null,
        latencyMs: result.latencyMs,
        modelUsed: model.modelName,
      });
      return;
    }

    res.status(200).json({
      ok: true,
      weaknesses: Array.isArray(parsed.weaknesses) ? parsed.weaknesses : [],
      missed_angles: Array.isArray(parsed.missed_angles) ? parsed.missed_angles : [],
      confidence_original: parsed.confidence_original || null,
      improved_answer: parsed.improved_answer || answer,
      confidence_improved: parsed.confidence_improved || null,
      latencyMs: result.latencyMs,
      modelUsed: model.modelName,
    });
  } catch (err) {
    console.error("challenge API error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal saat AI Challenge." });
  }
};
