/**
 * ============================================================
 *  api/auth/login.js
 * ------------------------------------------------------------
 *  POST /api/auth/login
 *  Body: { identifier, password }  -> identifier = username/email
 *
 *  Memakai dataLayer.findUserForLogin() yang otomatis mencari
 *  baik di database utama maupun penyimpanan cadangan (kalau
 *  database utama sedang tidak bisa dihubungi, atau kalau user
 *  ini sempat terdaftar lewat mode cadangan).
 * ============================================================
 */

const dataLayer = require("../../lib/dataLayer");
const { comparePassword, generateToken } = require("../../lib/auth");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const { identifier, password } = req.body || {};
    if (!identifier || !password) {
      res.status(400).json({ ok: false, error: "Username/email dan password wajib diisi" });
      return;
    }

    const { user, usedFallback } = await dataLayer.findUserForLogin(identifier);

    if (!user) {
      res.status(401).json({ ok: false, error: "Akun tidak ditemukan" });
      return;
    }

    const match = await comparePassword(password, user.password_hash);
    if (!match) {
      res.status(401).json({ ok: false, error: "Password salah" });
      return;
    }

    const token = generateToken({ id: user.id, username: user.username, email: user.email });

    res.setHeader(
      "Set-Cookie",
      `tt_token=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800`
    );
    res.status(200).json({
      ok: true,
      token,
      user: { id: user.id, username: user.username, email: user.email },
      usedFallback,
      ...(usedFallback && {
        notice: "Sesi ini menggunakan data cadangan sementara karena database utama tidak dapat dihubungi.",
      }),
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({
      ok: false,
      error: "Gagal login, baik di database utama maupun cadangan. Coba lagi sesaat lagi.",
    });
  }
};
