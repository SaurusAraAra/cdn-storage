/**
 * ============================================================
 *  api/auth/register.js
 * ------------------------------------------------------------
 *  POST /api/auth/register
 *  Body: { username, email, password }
 *  Mendaftarkan user baru, langsung login (mengembalikan token).
 *
 *  Memakai dataLayer.createUser() yang otomatis fallback ke
 *  penyimpanan sementara di memori jika database utama (Supabase)
 *  sedang tidak bisa dihubungi, sehingga pendaftaran tetap bisa
 *  berhasil. Field "usedFallback" pada respons menandakan apakah
 *  user ini sempat tersimpan di mode cadangan.
 * ============================================================
 */

const dataLayer = require("../../lib/dataLayer");
const { hashPassword, generateToken } = require("../../lib/auth");

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const { username, email, password } = req.body || {};

    if (!username || !email || !password) {
      res.status(400).json({ ok: false, error: "Username, email, dan password wajib diisi" });
      return;
    }
    if (username.length < 3 || username.length > 30) {
      res.status(400).json({ ok: false, error: "Username harus 3-30 karakter" });
      return;
    }
    if (!EMAIL_REGEX.test(email)) {
      res.status(400).json({ ok: false, error: "Format email tidak valid" });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ ok: false, error: "Password minimal 6 karakter" });
      return;
    }

    const passwordHash = await hashPassword(password);

    let result;
    try {
      result = await dataLayer.createUser({ username, email, passwordHash });
    } catch (err) {
      if (err.code === "USERNAME_TAKEN") {
        res.status(409).json({ ok: false, error: "Username atau email sudah terdaftar" });
        return;
      }
      throw err;
    }

    const { user, usedFallback } = result;
    const token = generateToken({ id: user.id, username: user.username, email: user.email });

    res.setHeader(
      "Set-Cookie",
      `tt_token=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800`
    );
    res.status(201).json({
      ok: true,
      token,
      user: { id: user.id, username: user.username, email: user.email },
      usedFallback,
      ...(usedFallback && {
        notice:
          "Database utama sedang tidak dapat dihubungi. Akunmu disimpan sementara dan akan otomatis dipindahkan begitu koneksi pulih.",
      }),
    });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({
      ok: false,
      error: "Gagal mendaftarkan user, baik di database utama maupun cadangan. Coba lagi sesaat lagi.",
    });
  }
};
