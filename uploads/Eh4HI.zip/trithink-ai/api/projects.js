/**
 * ============================================================
 *  api/projects.js
 * ------------------------------------------------------------
 *  GET    /api/projects              — list semua project user
 *  POST   /api/projects              — buat project baru
 *  PUT    /api/projects?id=X         — update project
 *  DELETE /api/projects?id=X         — hapus project
 *
 *  GET    /api/projects?tasks=X      — ambil tasks 1 project
 *  POST   /api/projects?addTask=X    — tambah task ke project
 *  PUT    /api/projects?taskId=X     — update status task
 *  DELETE /api/projects?taskId=X     — hapus task
 * ============================================================
 */

const { getUserFromRequest } = require("../lib/auth");
const { query, ensureSchema } = require("../lib/db");

module.exports = async (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    res.status(401).json({ ok: false, error: "Belum login" });
    return;
  }

  try {
    await ensureSchema();
    const { id, tasks, addTask, taskId } = req.query || {};

    // ── GET tasks per project ────────────────────────────────
    if (req.method === "GET" && tasks) {
      const projCheck = await query(
        "SELECT id FROM projects WHERE id=$1 AND user_id=$2", [tasks, user.id]
      );
      if (!projCheck.rows.length) {
        res.status(404).json({ ok: false, error: "Project tidak ditemukan" }); return;
      }
      const result = await query(
        "SELECT * FROM project_tasks WHERE project_id=$1 ORDER BY sort_order ASC, id ASC",
        [tasks]
      );
      // Hitung progress
      const allTasks = result.rows;
      const done = allTasks.filter(t => t.status === "done").length;
      const pct = allTasks.length ? Math.round((done / allTasks.length) * 100) : 0;
      res.status(200).json({ ok: true, tasks: allTasks, progress: pct, done, total: allTasks.length });
      return;
    }

    // ── GET list projects ────────────────────────────────────
    if (req.method === "GET") {
      const result = await query(
        `SELECT p.*,
           COUNT(pt.id) FILTER (WHERE pt.status='done') as tasks_done,
           COUNT(pt.id) as tasks_total
         FROM projects p
         LEFT JOIN project_tasks pt ON pt.project_id = p.id
         WHERE p.user_id=$1
         GROUP BY p.id
         ORDER BY p.updated_at DESC`,
        [user.id]
      );
      res.status(200).json({ ok: true, projects: result.rows });
      return;
    }

    // ── POST tambah task ke project ──────────────────────────
    if (req.method === "POST" && addTask) {
      const { title } = req.body || {};
      if (!title) { res.status(400).json({ ok: false, error: "title wajib diisi" }); return; }
      const projCheck = await query(
        "SELECT id FROM projects WHERE id=$1 AND user_id=$2", [addTask, user.id]
      );
      if (!projCheck.rows.length) {
        res.status(404).json({ ok: false, error: "Project tidak ditemukan" }); return;
      }
      const maxOrder = await query(
        "SELECT COALESCE(MAX(sort_order),0)+1 as next FROM project_tasks WHERE project_id=$1", [addTask]
      );
      const inserted = await query(
        "INSERT INTO project_tasks (project_id, title, sort_order) VALUES ($1,$2,$3) RETURNING *",
        [addTask, title.slice(0,200), maxOrder.rows[0].next]
      );
      await query("UPDATE projects SET updated_at=NOW() WHERE id=$1", [addTask]);
      res.status(201).json({ ok: true, task: inserted.rows[0] });
      return;
    }

    // ── POST buat project baru ───────────────────────────────
    if (req.method === "POST") {
      const { name, description, color, icon, context_prompt } = req.body || {};
      if (!name) { res.status(400).json({ ok: false, error: "name wajib diisi" }); return; }
      const inserted = await query(
        `INSERT INTO projects (user_id, name, description, color, icon, context_prompt)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [user.id, name.slice(0,100), description||'', color||'#ffffff', icon||'📁', context_prompt||'']
      );
      res.status(201).json({ ok: true, project: inserted.rows[0] });
      return;
    }

    // ── PUT update task status ────────────────────────────────
    if (req.method === "PUT" && taskId) {
      const { status, title } = req.body || {};
      const validStatuses = ["pending", "in_progress", "done", "blocked"];
      if (status && !validStatuses.includes(status)) {
        res.status(400).json({ ok: false, error: "Status tidak valid" }); return;
      }
      // Pastikan task milik user ini
      const taskCheck = await query(
        `SELECT pt.id FROM project_tasks pt
         JOIN projects p ON p.id=pt.project_id
         WHERE pt.id=$1 AND p.user_id=$2`, [taskId, user.id]
      );
      if (!taskCheck.rows.length) {
        res.status(404).json({ ok: false, error: "Task tidak ditemukan" }); return;
      }
      const updates = [];
      const params = [];
      let idx = 1;
      if (status) { updates.push(`status=$${idx++}`); params.push(status); }
      if (title) { updates.push(`title=$${idx++}`); params.push(title.slice(0,200)); }
      updates.push(`updated_at=NOW()`);
      params.push(taskId);
      await query(`UPDATE project_tasks SET ${updates.join(',')} WHERE id=$${idx}`, params);
      res.status(200).json({ ok: true });
      return;
    }

    // ── PUT update project ────────────────────────────────────
    if (req.method === "PUT" && id) {
      const { name, description, color, icon, context_prompt } = req.body || {};
      const result = await query(
        `UPDATE projects SET
           name=COALESCE($1,name),
           description=COALESCE($2,description),
           color=COALESCE($3,color),
           icon=COALESCE($4,icon),
           context_prompt=COALESCE($5,context_prompt),
           updated_at=NOW()
         WHERE id=$6 AND user_id=$7 RETURNING *`,
        [name||null, description||null, color||null, icon||null, context_prompt||null, id, user.id]
      );
      if (!result.rows.length) {
        res.status(404).json({ ok: false, error: "Project tidak ditemukan" }); return;
      }
      res.status(200).json({ ok: true, project: result.rows[0] });
      return;
    }

    // ── DELETE hapus task ─────────────────────────────────────
    if (req.method === "DELETE" && taskId) {
      await query(
        `DELETE FROM project_tasks pt USING projects p
         WHERE pt.id=$1 AND pt.project_id=p.id AND p.user_id=$2`,
        [taskId, user.id]
      );
      res.status(200).json({ ok: true });
      return;
    }

    // ── DELETE hapus project ──────────────────────────────────
    if (req.method === "DELETE" && id) {
      await query("DELETE FROM projects WHERE id=$1 AND user_id=$2", [id, user.id]);
      res.status(200).json({ ok: true });
      return;
    }

    res.status(405).json({ ok: false, error: "Method/parameter tidak diizinkan" });
  } catch (err) {
    console.error("projects API error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal." });
  }
};
