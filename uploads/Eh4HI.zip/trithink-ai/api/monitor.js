/**
 * ============================================================
 *  api/monitor.js
 * ------------------------------------------------------------
 *  GET /api/monitor
 *  Mengembalikan status semua server AI lengkap dengan:
 *  - status (good/warn/down)
 *  - latency (ms)
 *  - userAgent yang dipakai
 *  - URL endpoint (domain saja, bukan full URL dengan API key)
 *  - method (GET/POST)
 *  - timeout setting
 *  - kategori (daily/agent/image/search)
 *  - latency history (disimpan di in-memory per-instance)
 * ============================================================
 */

const { pingAll } = require("../lib/serverMonitor");
const {
  DAILY_CHAT_MODELS,
  AGENT_MODELS,
  IMAGE_MODELS,
  WEB_SEARCH,
  DEFAULT_USER_AGENT,
  REQUEST_TIMEOUT_MS,
} = require("../configapi");

// Simpan history latency per server (max 20 data point per server)
// Persisten selama instance hidup (warm), reset saat cold start
const latencyHistory = {};
const MAX_HISTORY = 20;

function recordLatency(id, latencyMs, status) {
  if (!latencyHistory[id]) latencyHistory[id] = [];
  latencyHistory[id].push({ latencyMs, status, at: Date.now() });
  if (latencyHistory[id].length > MAX_HISTORY) latencyHistory[id].shift();
}

function getEndpointMeta(id) {
  const allEndpoints = {
    ...DAILY_CHAT_MODELS,
    ...AGENT_MODELS,
    ...IMAGE_MODELS,
    websearch: WEB_SEARCH,
  };
  return allEndpoints[id] || null;
}

function safeDomain(url) {
  try {
    const u = new URL(url.replace("{{Q}}", "test"));
    return `${u.protocol}//${u.hostname}`;
  } catch {
    return url.split("?")[0].slice(0, 60);
  }
}

function safeUrlDisplay(url) {
  // Tampilkan path tanpa parameter sensitif
  try {
    const u = new URL(url.replace("{{Q}}", "..."));
    return `${u.protocol}//${u.hostname}${u.pathname}`;
  } catch {
    return url.split("?")[0];
  }
}

module.exports = async (req, res) => {
  if (req.method !== "GET") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const data = await pingAll();

    // Enriched servers dengan metadata lengkap + history
    const enriched = data.servers.map((s) => {
      recordLatency(s.id, s.latencyMs, s.status);
      const meta = getEndpointMeta(s.id);
      return {
        ...s,
        // Info teknis endpoint
        domain: meta ? safeDomain(meta.url) : null,
        endpointPath: meta ? safeUrlDisplay(meta.url) : null,
        method: meta ? (meta.method || "get").toUpperCase() : null,
        timeoutMs: meta ? (meta.timeoutMs || REQUEST_TIMEOUT_MS) : REQUEST_TIMEOUT_MS,
        userAgent: meta ? (meta.userAgent || DEFAULT_USER_AGENT) : DEFAULT_USER_AGENT,
        responsePath: meta ? meta.responsePath : null,
        // Latency history untuk grafik
        latencyHistory: latencyHistory[s.id] || [],
        // Stats dari history
        avgLatencyMs: latencyHistory[s.id]?.length
          ? Math.round(latencyHistory[s.id].reduce((a, b) => a + b.latencyMs, 0) / latencyHistory[s.id].length)
          : null,
        minLatencyMs: latencyHistory[s.id]?.length
          ? Math.min(...latencyHistory[s.id].map(h => h.latencyMs))
          : null,
        maxLatencyMs: latencyHistory[s.id]?.length
          ? Math.max(...latencyHistory[s.id].map(h => h.latencyMs))
          : null,
        uptimePercent: latencyHistory[s.id]?.length
          ? Math.round((latencyHistory[s.id].filter(h => h.status !== "down").length / latencyHistory[s.id].length) * 100)
          : null,
      };
    });

    // Global info
    const globalInfo = {
      defaultUserAgent: DEFAULT_USER_AGENT,
      defaultTimeoutMs: REQUEST_TIMEOUT_MS,
      totalEndpoints: data.summary.total,
    };

    res.status(200).json({
      ok: true,
      servers: enriched,
      summary: data.summary,
      globalInfo,
      generatedAt: data.generatedAt,
    });
  } catch (err) {
    console.error("Monitor error:", err);
    res.status(500).json({ ok: false, error: "Gagal mengambil status server." });
  }
};
