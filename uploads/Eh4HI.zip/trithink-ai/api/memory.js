/**
 * ============================================================
 *  api/memory.js
 * ------------------------------------------------------------
 *  GET    /api/memory          — ambil semua memori user
 *  POST   /api/memory          — tambah/update memori manual
 *  DELETE /api/memory?id=123   — hapus satu memori
 *  DELETE /api/memory?all=1    — hapus semua memori user
 * ============================================================
 */

const { getUserFromRequest } = require("../lib/auth");
const { ensureSchema } = require("../lib/db");
const {
  getUserMemories,
  upsertMemory,
  deleteMemory,
  clearAllMemories,
} = require("../lib/memoryEngine");

module.exports = async (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    res.status(401).json({ ok: false, error: "Belum login" });
    return;
  }

  try {
    await ensureSchema();

    if (req.method === "GET") {
      const memories = await getUserMemories(user.id);
      res.status(200).json({ ok: true, memories });
      return;
    }

    if (req.method === "POST") {
      const { key, value, category } = req.body || {};
      if (!key || !value) {
        res.status(400).json({ ok: false, error: "key dan value wajib diisi" });
        return;
      }
      await upsertMemory(user.id, key, value, category || "general", null, false);
      res.status(200).json({ ok: true });
      return;
    }

    if (req.method === "DELETE") {
      const { id, all } = req.query || {};
      if (all === "1") {
        await clearAllMemories(user.id);
        res.status(200).json({ ok: true, cleared: true });
        return;
      }
      if (!id) {
        res.status(400).json({ ok: false, error: "Parameter id wajib diisi" });
        return;
      }
      await deleteMemory(user.id, parseInt(id, 10));
      res.status(200).json({ ok: true });
      return;
    }

    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
  } catch (err) {
    console.error("memory API error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal." });
  }
};
