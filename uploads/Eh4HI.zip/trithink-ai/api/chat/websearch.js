/**
 * ============================================================
 *  api/chat/websearch.js
 * ------------------------------------------------------------
 *  POST /api/chat/websearch
 *  Body: { text }
 *
 *  Pencarian web yang lebih robust: mendukung berbagai format
 *  respons API pencarian gratisan (summary, answer, snippet,
 *  description, data array, dll) dan menyajikannya sebagai
 *  teks informatif yang siap ditampilkan di chat.
 * ============================================================
 */

const { WEB_SEARCH } = require("../../configapi");
const { callEndpoint } = require("../../lib/fetchEngine");

/**
 * Coba ekstrak jawaban paling bermakna dari berbagai format
 * respons API pencarian yang berbeda-beda.
 *
 * Mendukung:
 *  - { answer: "..." }            -> banyak AI search API
 *  - { summary: "..." }           -> beberapa summarizer
 *  - { result: "..." }            -> format umum
 *  - { data: [{ title, description, url }, ...] } -> hasil list
 *  - { data: "string" }           -> single string
 *  - string biasa (raw text)      -> fallback
 */
function extractSearchText(raw, fallbackText) {
  // Kalau fetchEngine sudah menghasilkan teks siap pakai, langsung pakai
  if (fallbackText && typeof fallbackText === "string" && fallbackText.trim().length > 4
      && fallbackText !== "true" && fallbackText !== "false") {
    return fallbackText;
  }

  if (!raw) return null;
  if (typeof raw === "string") return raw.trim() || null;

  // Priority field names yang sering dipakai API pencarian
  const directKeys = ["answer","summary","result","message","text","content","response","output","reply"];
  for (const k of directKeys) {
    const v = raw[k];
    if (typeof v === "string" && v.trim().length > 4 && v !== "true" && v !== "false") {
      return v.trim();
    }
  }

  // Cek di dalam nested "data" field
  const data = raw.data;
  if (Array.isArray(data) && data.length > 0) {
    return formatResultList(data);
  }
  if (typeof data === "string" && data.trim().length > 4 && data !== "true" && data !== "false") {
    return data.trim();
  }
  if (data && typeof data === "object") {
    for (const k of directKeys) {
      if (typeof data[k] === "string" && data[k].trim().length > 4) return data[k].trim();
    }
  }

  // Cek array di root level
  const arrayKeys = ["results","items","hits","list","entries","records"];
  for (const k of arrayKeys) {
    if (Array.isArray(raw[k]) && raw[k].length > 0) {
      return formatResultList(raw[k]);
    }
  }

  return null;
}

/**
 * Format array hasil pencarian menjadi teks yang informatif.
 * Auto-detect objek dengan title/description/url atau string biasa.
 */
function formatResultList(arr, max = 5) {
  const titleKeys = ["title","judul","name","heading","label"];
  const descKeys = ["description","snippet","desc","summary","content","text","body","abstract"];
  const urlKeys = ["url","link","href","source"];

  const pick = (obj, keys) => {
    for (const k of keys) {
      if (obj && typeof obj[k] === "string" && obj[k].trim()) return obj[k].trim();
    }
    return null;
  };

  const lines = [];
  let used = 0;
  for (const item of arr.slice(0, max)) {
    if (typeof item === "string" && item.trim()) { lines.push(`• ${item.trim()}`); used++; continue; }
    if (!item || typeof item !== "object") continue;
    const title = pick(item, titleKeys);
    const desc = pick(item, descKeys);
    const url = pick(item, urlKeys);
    if (!title && !desc) continue;
    let line = `• **${title || url || "Hasil"}**`;
    if (desc) line += `\n  ${desc.slice(0, 280)}`;
    if (url && url.startsWith("http")) line += `\n  ${url}`;
    lines.push(line);
    used++;
  }
  return used > 0 ? lines.join("\n\n") : null;
}

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const { text } = req.body || {};
    const q = (text || req.query?.text || req.query?.q || req.query?.query || "").toString().trim();

    if (!q) {
      res.status(400).json({ ok: false, error: "Parameter text/q/query wajib diisi" });
      return;
    }

    const result = await callEndpoint(WEB_SEARCH, q);
    const extracted = extractSearchText(result.raw, result.text);

    if (!extracted) {
      // Endpoint bisa dihubungi tapi tidak memberikan hasil yang berarti
      res.status(200).json({
        ok: true,
        mode: "websearch",
        query: q,
        result: `Tidak ada hasil pencarian yang ditemukan untuk "${q}". Coba kata kunci yang lebih spesifik, atau ganti endpoint WEB_SEARCH di configapi.js dengan endpoint pencarian lain.`,
        latencyMs: result.latencyMs,
      });
      return;
    }

    res.status(200).json({
      ok: true,
      mode: "websearch",
      query: q,
      result: extracted,
      latencyMs: result.latencyMs,
    });
  } catch (err) {
    console.error("Web search error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal saat melakukan web search." });
  }
};
