/**
 * ============================================================
 *  api/chat/daily.js
 * ------------------------------------------------------------
 *  POST /api/chat/daily
 *  Body: { text, model } -> model: "chatgpt" | "gemini" (opsional,
 *         default akan pakai model pertama yang enabled)
 *  Mode obrolan harian biasa menggunakan salah satu dari 2 model
 *  di DAILY_CHAT_MODELS (configapi.js).
 * ============================================================
 */

const { DAILY_CHAT_MODELS } = require("../../configapi");
const { callEndpoint } = require("../../lib/fetchEngine");
const { getUserFromRequest } = require("../../lib/auth");
const dataLayer = require("../../lib/dataLayer");
const { buildMemoryContext, autoExtractMemories } = require("../../lib/memoryEngine");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const { text, model, conversationId, imageBase64, imageMimeType, hasImage, projectId } = req.body || {};
    let q = (text || req.query?.text || req.query?.q || req.query?.prompt || "").toString().trim();

    // Kalau ada gambar, inject deskripsi ke prompt supaya AI tau ada konteks visual
    if (hasImage && imageBase64) {
      const imgContext = "\n\n[Pengguna juga melampirkan sebuah gambar/foto. Analisis dan jadikan referensi jawabanmu jika relevan.]";
      q = q + imgContext;
    }

    if (!q && !hasImage) {
      res.status(400).json({ ok: false, error: "Parameter text/q/prompt wajib diisi" });
      return;
    }
    if (!q) q = "Tolong analisis gambar/foto yang dilampirkan pengguna.";

    const availableModels = Object.values(DAILY_CHAT_MODELS).filter((m) => m.enabled);
    if (availableModels.length === 0) {
      res.status(503).json({ ok: false, error: "Tidak ada model daily chat yang aktif" });
      return;
    }

    let selected = availableModels.find((m) => m.id === model) || availableModels[0];

    // Inject memory context ke prompt jika user login
    const user = getUserFromRequest(req);
    let promptWithMemory = q;
    if (user) {
      try {
        const memCtx = await buildMemoryContext(user.id);
        // Inject project context kalau ada projectId
        let projCtx = "";
        if (projectId) {
          const { query: dbQuery } = require("../../lib/db");
          const proj = await dbQuery(
            "SELECT name, description, context_prompt FROM projects WHERE id=$1 AND user_id=$2",
            [projectId, user.id]
          );
          if (proj.rows.length) {
            const p = proj.rows[0];
            projCtx = `[PROJECT: ${p.name}${p.description ? ` — ${p.description}` : ""}]${p.context_prompt ? `\nKonteks project: ${p.context_prompt}` : ""}\n\n`;
          }
        }
        if (memCtx || projCtx) promptWithMemory = (projCtx + memCtx + q);
      } catch (_) {}
    }

    let result = await callEndpoint(selected, promptWithMemory);

    // Failover otomatis ke model kedua jika model pertama gagal
    if (!result.ok && availableModels.length > 1) {
      const fallbackModel = availableModels.find((m) => m.id !== selected.id);
      if (fallbackModel) {
        const fallbackResult = await callEndpoint(fallbackModel, promptWithMemory);
        if (fallbackResult.ok) {
          selected = fallbackModel;
          result = fallbackResult;
        }
      }
    }

    if (!result.ok) {
      res.status(502).json({
        ok: false,
        error: `Server ${selected.serverName} sedang tidak merespons (${result.error}).`,
      });
      return;
    }

    // Simpan riwayat chat jika user login
    let savedConversationId = conversationId || null;
    let usedFallbackStorage = false;
    if (user) {
      try {
        if (!savedConversationId) {
          const conv = await dataLayer.createConversation({
            userId: user.id,
            title: q.slice(0, 60),
            mode: "daily",
            projectId: projectId || null,
          });
          savedConversationId = conv.conversationId;
          usedFallbackStorage = conv.usedFallback;
        }
        const saveRes = await dataLayer.saveMessages({
          conversationId: savedConversationId,
          messages: [
            { role: "user", content: q },
            { role: "assistant", content: result.text },
          ],
        });
        usedFallbackStorage = usedFallbackStorage || saveRes.usedFallback;

        // Auto-extract memories (fire & forget, tidak block respons)
        autoExtractMemories(user.id, savedConversationId, q, result.text).catch(() => {});
      } catch (dbErr) {
        console.error("Gagal menyimpan riwayat chat:", dbErr.message);
      }
    }

    res.status(200).json({
      ok: true,
      mode: "daily",
      answer: result.text,
      modelUsed: selected.modelName,
      serverUsed: selected.serverName,
      latencyMs: result.latencyMs,
      conversationId: savedConversationId,
      usedFallbackStorage,
    });
  } catch (err) {
    console.error("Daily chat error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal pada server." });
  }
};
