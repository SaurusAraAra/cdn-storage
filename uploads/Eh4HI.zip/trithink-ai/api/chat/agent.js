/**
 * ============================================================
 *  api/chat/agent.js
 * ------------------------------------------------------------
 *  POST /api/chat/agent
 *  Body: { text }
 *  Mode "AI Agent" — 5 AI dipanggil sekaligus, berdebat, dan
 *  menghasilkan satu jawaban terbaik gabungan.
 * ============================================================
 */

const { runAgentDebate } = require("../../lib/agentEngine");
const { getUserFromRequest } = require("../../lib/auth");
const dataLayer = require("../../lib/dataLayer");
const { buildMemoryContext, autoExtractMemories } = require("../../lib/memoryEngine");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  try {
    const { text, conversationId } = req.body || {};
    const q = (text || req.query?.text || req.query?.q || req.query?.prompt || "").toString().trim();

    if (!q) {
      res.status(400).json({ ok: false, error: "Parameter text/q/prompt wajib diisi" });
      return;
    }

    const user = getUserFromRequest(req);

    // Inject memory context
    let promptWithMemory = q;
    if (user) {
      try {
        const memCtx = await buildMemoryContext(user.id);
        if (memCtx) promptWithMemory = memCtx + q;
      } catch (_) {}
    }

    const debateResult = await runAgentDebate(promptWithMemory);
    let savedConversationId = conversationId || null;
    let usedFallbackStorage = false;
    if (user) {
      try {
        if (!savedConversationId) {
          const conv = await dataLayer.createConversation({
            userId: user.id,
            title: q.slice(0, 60),
            mode: "agent",
          });
          savedConversationId = conv.conversationId;
          usedFallbackStorage = conv.usedFallback;
        }
        const saveRes = await dataLayer.saveMessages({
          conversationId: savedConversationId,
          messages: [
            { role: "user", content: q, meta: {} },
            {
              role: "assistant",
              content: debateResult.finalAnswer,
              meta: { synthesizedBy: debateResult.synthesizedBy, agentResults: debateResult.agentResults },
            },
          ],
        });
        usedFallbackStorage = usedFallbackStorage || saveRes.usedFallback;

        // Auto-extract memories dari hasil debat
        autoExtractMemories(user.id, savedConversationId, q, debateResult.finalAnswer).catch(() => {});
      } catch (dbErr) {
        console.error("Gagal menyimpan riwayat agent chat:", dbErr.message);
      }
    }

    res.status(200).json({
      ok: true,
      mode: "agent",
      answer: debateResult.finalAnswer,
      synthesizedBy: debateResult.synthesizedBy,
      usedFallback: debateResult.usedFallback,
      agentResults: debateResult.agentResults.map((r) => ({
        modelName: r.modelName,
        serverName: r.serverName,
        ok: r.ok,
        latencyMs: r.latencyMs,
        preview: r.text ? r.text.slice(0, 200) : null,
        error: r.error,
      })),
      conversationId: savedConversationId,
      usedFallbackStorage,
    });
  } catch (err) {
    console.error("Agent chat error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal pada server." });
  }
};
