/**
 * ============================================================
 *  api/conversations/index.js
 * ------------------------------------------------------------
 *  GET    /api/conversations          -> daftar percakapan user
 *  DELETE /api/conversations?id=123   -> hapus 1 percakapan
 *
 *  Memakai dataLayer agar daftar percakapan otomatis menggabungkan
 *  data dari database utama dan dari penyimpanan cadangan (kalau
 *  ada sisa yang belum sempat tersinkron).
 * ============================================================
 */

const dataLayer = require("../../lib/dataLayer");
const { getUserFromRequest } = require("../../lib/auth");

module.exports = async (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) {
    res.status(401).json({ ok: false, error: "Belum login" });
    return;
  }

  try {
    if (req.method === "GET") {
      const conversations = await dataLayer.listConversations(user.id);
      res.status(200).json({ ok: true, conversations });
      return;
    }

    if (req.method === "DELETE") {
      const idRaw = req.query?.id || req.body?.id;
      if (!idRaw) {
        res.status(400).json({ ok: false, error: "Parameter id wajib diisi" });
        return;
      }
      await dataLayer.deleteConversation({ conversationId: parseInt(idRaw, 10), userId: user.id });
      res.status(200).json({ ok: true });
      return;
    }

    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
  } catch (err) {
    console.error("Conversations error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal pada server." });
  }
};
