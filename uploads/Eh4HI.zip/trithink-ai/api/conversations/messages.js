/**
 * ============================================================
 *  api/conversations/messages.js
 * ------------------------------------------------------------
 *  GET /api/conversations/messages?id=123
 *  Mengambil semua pesan dalam satu percakapan (milik user yang
 *  sedang login). conversationId bisa berasal dari database
 *  utama (id positif) atau dari penyimpanan cadangan (id negatif).
 * ============================================================
 */

const dataLayer = require("../../lib/dataLayer");
const { getUserFromRequest } = require("../../lib/auth");

module.exports = async (req, res) => {
  if (req.method !== "GET") {
    res.status(405).json({ ok: false, error: "Method tidak diizinkan" });
    return;
  }

  const user = getUserFromRequest(req);
  if (!user) {
    res.status(401).json({ ok: false, error: "Belum login" });
    return;
  }

  const idRaw = req.query?.id;
  if (!idRaw) {
    res.status(400).json({ ok: false, error: "Parameter id wajib diisi" });
    return;
  }

  try {
    const result = await dataLayer.getConversationMessages({
      conversationId: parseInt(idRaw, 10),
      userId: user.id,
    });

    if (!result) {
      res.status(404).json({ ok: false, error: "Percakapan tidak ditemukan" });
      return;
    }

    res.status(200).json({ ok: true, mode: result.mode, messages: result.messages });
  } catch (err) {
    console.error("Messages fetch error:", err);
    res.status(500).json({ ok: false, error: "Terjadi kesalahan internal pada server." });
  }
};
