/**
 * ============================================================
 *  api/storage-status.js
 * ------------------------------------------------------------
 *  GET  /api/storage-status         -> lihat status penyimpanan
 *                                       cadangan saat ini
 *  POST /api/storage-status?sync=1  -> paksa coba sinkronkan
 *                                       fallback ke database
 *                                       utama sekarang juga
 *
 *  Berguna untuk memantau apakah aplikasi sedang berjalan dalam
 *  mode cadangan (database utama down) dan berapa banyak data
 *  yang masih menunggu untuk disinkronkan.
 * ============================================================
 */

const dataLayer = require("../lib/dataLayer");

module.exports = async (req, res) => {
  try {
    const forceCheck = req.method === "POST";
    const mainDbReachable = await dataLayer.isMainDbReachable(forceCheck);
    const fallbackStats = dataLayer.getFallbackStats();

    if (req.method === "POST") {
      let syncResult = { syncedUsers: 0, syncedConversations: 0 };
      if (mainDbReachable) {
        syncResult = await dataLayer.syncFallbackToMainDb();
      }
      res.status(200).json({
        ok: true,
        mainDbReachable,
        syncAttempted: true,
        syncResult,
        fallbackStats: dataLayer.getFallbackStats(),
      });
      return;
    }

    res.status(200).json({
      ok: true,
      mainDbReachable,
      fallbackStats: {
        userCount: fallbackStats.userCount,
        conversationCount: fallbackStats.conversationCount,
        approxBytes: fallbackStats.approxBytes,
        approxKB: Math.round((fallbackStats.approxBytes / 1024) * 10) / 10,
        maxBytes: fallbackStats.maxBytes,
        maxMB: fallbackStats.maxBytes / (1024 * 1024),
        usedPercent: Math.round((fallbackStats.approxBytes / fallbackStats.maxBytes) * 1000) / 10,
      },
    });
  } catch (err) {
    console.error("Storage status error:", err);
    res.status(500).json({ ok: false, error: "Gagal mengambil status penyimpanan." });
  }
};
